(()=>{var bs=Object.defineProperty,vs=Object.defineProperties;var xs=Object.getOwnPropertyDescriptors;var fn=Object.getOwnPropertySymbols;var Ss=Object.prototype.hasOwnProperty,ks=Object.prototype.propertyIsEnumerable;var yn=(I,z,v)=>z in I?bs(I,z,{enumerable:!0,configurable:!0,writable:!0,value:v}):I[z]=v,De=(I,z)=>{for(var v in z||(z={}))Ss.call(z,v)&&yn(I,v,z[v]);if(fn)for(var v of fn(z))ks.call(z,v)&&yn(I,v,z[v]);return I},Je=(I,z)=>vs(I,xs(z));function hn(){function I(z){try{let v=z.target&&z.target.closest?z.target.closest("button"):null;if(!v)return;let M=v.closest?v.closest(".issue"):null;if(!M||!(v.closest&&v.closest(".issue-actions")))return;let B=v.getAttribute("data-id")||M.getAttribute("data-issue-id");if(!B)return;parent.postMessage({pluginMessage:{type:"select-node",id:B}},"*")}catch(v){console.error("autoSelectNodeFromIssueClick error:",v)}}document.addEventListener("click",I,!0)}function ne(I,z,v){if(!z)return;let M=document.querySelector(`.issue[data-issue-id="${I}"]`);if(!M){let Y=document.querySelector(`button.btn-fix[data-id="${I}"]`);Y&&(M=Y.closest(".issue"))}if(!M)return;let L=M.querySelector(".fix-message");L&&L.remove();let B=document.createElement("div");B.className="fix-message",B.style.cssText=`
      margin-top: 8px;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
      background: ${v?"#d4edda":"#f8d7da"};
      color: ${v?"#155724":"#721c24"};
      border: 1px solid ${v?"#c3e6cb":"#f5c6cb"};
      animation: slideIn 0.3s ease-out;
    `,B.textContent=z;let D=M.querySelector(".issue-header");D?D.parentNode.insertBefore(B,D.nextSibling):M.appendChild(B),setTimeout(()=>{B.style.animation="slideOut 0.3s ease-out",setTimeout(()=>{B.parentNode&&B.remove()},300)},5e3)}function d(I){return I==null?"":String(I).replace(/[&<>"']/g,function(v){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[v]})}function Rt(I){console.log("[showErrorModal] Called with message:",I);let z=document.getElementById("error-modal-overlay");z&&(console.log("[showErrorModal] Removing existing modal"),z.remove());let v=document.createElement("div");v.className="modal-overlay",v.id="error-modal-overlay",console.log("[showErrorModal] Created overlay element");let M=document.createElement("div");M.className="modal-dialog",M.style.maxWidth="450px";let L=String(I||"").replace(/^[❌⚠️✅]\s*/,"").trim();M.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title" style="color: #dc3545;">\u26A0\uFE0F Error</h2>
      </div>
      <div class="modal-body">
        <div style="padding: 16px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 14px; color: #721c24; line-height: 1.6;">
            ${d(L)}
          </div>
        </div>
        <div style="font-size: 12px; color: #666; line-height: 1.5;">
          Please check the issue and try again. If the problem persists, you may need to switch to Design Mode or edit the main component directly.
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-primary" id="error-modal-ok-btn" style="background: #dc3545; border-color: #dc3545; color: white;">OK</button>
      </div>
    `,v.appendChild(M),document.body.appendChild(v),console.log("[showErrorModal] Appended overlay to body, overlay visible:",v.offsetParent!==null),v.style.display="flex",v.style.visibility="visible",v.style.opacity="1";let B=M.querySelector("#error-modal-ok-btn"),D=M.querySelector(".modal-close");if(console.log("[showErrorModal] Found buttons:",{okBtn:!!B,closeBtn:!!D}),!B){console.error("[showErrorModal] OK button not found!");return}let Y=()=>{v.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{v.parentNode&&v.remove()},200)};B.onclick=Y,D&&(D.onclick=Y),v.onclick=j=>{j.target===v&&Y()},setTimeout(()=>{B.focus()},100),console.log("[showErrorModal] Modal setup complete")}function ct(I){if(!I)return 0;let z=String(I).replace("#","");if(z.length<6)return 0;let v=parseInt(z.substring(0,2),16),M=parseInt(z.substring(2,4),16),L=parseInt(z.substring(4,6),16);return isNaN(v)||isNaN(M)||isNaN(L)?0:(v*299+M*587+L*114)/1e3}function Dt(I,z){let v=String(I||"").replace("#",""),M=String(z||"").replace("#","");if(v.length<6||M.length<6)return 1/0;let L=parseInt(v.substring(0,2),16),B=parseInt(v.substring(2,4),16),D=parseInt(v.substring(4,6),16),Y=parseInt(M.substring(0,2),16),j=parseInt(M.substring(2,4),16),P=parseInt(M.substring(4,6),16);if([L,B,D,Y,j,P].some(G=>isNaN(G)))return 1/0;let U=Y-L,V=j-B,q=P-D;return Math.sqrt(U*U+V*V+q*q)}function bn(I){let z=String(I||"").replace("#","");if(z.length<6)return 0;let v=parseInt(z.substring(0,2),16)/255,M=parseInt(z.substring(2,4),16)/255,L=parseInt(z.substring(4,6),16)/255;if(isNaN(v)||isNaN(M)||isNaN(L))return 0;let B=v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4),D=M<=.03928?M/12.92:Math.pow((M+.055)/1.055,2.4),Y=L<=.03928?L/12.92:Math.pow((L+.055)/1.055,2.4);return .2126*B+.7152*D+.0722*Y}function Wt(I,z){let v=bn(I),M=bn(z),L=Math.max(v,M),B=Math.min(v,M);return(L+.05)/(B+.05)}function xt(I){if(!I||!I.message)return null;let v=(I.message||"").match(/Color (#[0-9A-Fa-f]{6})/),M=v?v[1].toUpperCase():null;if(!M)return null;let L=document.getElementById("color-scale");if(!L||!L.value.trim())return null;let B=L.value.split(",").map(j=>j.trim().toUpperCase()).filter(j=>j&&j.startsWith("#"));if(B.length===0)return null;let D=null,Y=1/0;return B.forEach(j=>{let P=Dt(M,j);P<Y&&(Y=P,D=j)}),Y>100?null:D}function St(I){if(!I||!I.message)return null;let v=(I.message||"").match(/\((\d+)px\)/);if(!v)return null;let M=parseInt(v[1],10);if(isNaN(M))return null;let L=document.getElementById("spacing-scale");if(!L||!L.value.trim())return null;let B=L.value.split(",").map(P=>parseInt(P.trim(),10)).filter(P=>!isNaN(P)&&P>=0).sort((P,U)=>P-U);if(B.length===0)return null;let D=null,Y=1/0;B.forEach(P=>{let U=Math.abs(P-M);U<Y&&(Y=U,D=P)});let j=Math.max(M*.2,10);return Y>j?null:D}function ws(I,z){if(!I||I.length===0){alert("No typography styles available. Please add styles in Typography Settings.");return}let v=document.createElement("div");v.className="modal-overlay",v.style.zIndex="10001";let M=document.createElement("div");M.className="modal-dialog",M.style.maxWidth="300px",M.style.padding="0",M.innerHTML=`
      <div class="modal-header" style="padding: 16px;">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title" style="font-size: 14px;">Choose Typography Style</h2>
      </div>
      <div style="max-height: 300px; overflow-y: auto;">
        ${I.map(B=>{let D=d(B.name||""),Y=d(B.fontFamily||""),j=d(B.fontSize||""),P=d(B.fontWeight||"");return`
          <div class="style-dropdown-item" data-style-id="${B.id}" style="padding: 12px 16px; cursor: pointer; font-size: 13px; border-bottom: 1px solid #f0f0f0;" onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background='white'">
            <div style="font-weight: 600; color: #333;">${D}</div>
            <div style="font-size: 11px; color: #666; margin-top: 4px;">
              ${Y} ${j}px ${P}
            </div>
          </div>
        `}).join("")}
      </div>
    `,v.appendChild(M),document.body.appendChild(v);let L=()=>{v.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{v.parentNode&&v.remove()},200)};M.querySelector(".modal-close").onclick=L,v.onclick=B=>{B.target===v&&L()},M.querySelectorAll(".style-dropdown-item").forEach(B=>{B.onclick=D=>{D.preventDefault(),D.stopPropagation();let Y=parseInt(B.getAttribute("data-style-id"),10),j=I.find(P=>P.id===Y);j&&z&&(z(j),L())}})}function vn(I,z){if(!I||!I.bestMatch){console.error("showTypographyFixModal: missing issue or bestMatch");return}let v=I.nodeProps||{},M=I.bestMatch,L=v.fontFamily||"",B=v.fontSize!==null&&v.fontSize!==void 0?v.fontSize:"",D=v.fontWeight||"",Y=v.lineHeight||"",j=v.letterSpacing!==null&&v.letterSpacing!==void 0?v.letterSpacing:"",P=L,U=B,V=D,q=Y,G=j;M.differences&&M.differences.forEach(X=>{X.property==="Font Family"&&X.expected?P=X.expected:X.property==="Font Size"&&X.expected?U=X.expected.replace("px",""):X.property==="Font Weight"&&X.expected?V=X.expected:X.property==="Line Height"&&X.expected?q=X.expected:X.property==="Letter Spacing"&&X.expected&&(G=X.expected)});let pe=document.createElement("div");pe.className="modal-overlay",pe.id="typography-fix-modal-overlay";let te=document.createElement("div");te.className="modal-dialog",te.style.maxWidth="500px",te.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Fix Typography Style</h2>
        <p class="modal-subtitle">Node: ${d(I.nodeName||"Unnamed")} \u2192 Suggested: ${d(M.name)}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">
            Edit values below and click Apply to fix:
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Font Family</label>
            <input type="text" class="modal-input" id="fix-font-family" value="${d(P)}" style="width: 100%;" />
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Font Size (px)</label>
            <input type="number" class="modal-input" id="fix-font-size" value="${d(U)}" style="width: 100%;" />
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Font Weight</label>
            <select class="modal-input" id="fix-font-weight" style="width: 100%;">
              <option value="Regular" ${V==="Regular"?"selected":""}>Regular</option>
              <option value="Medium" ${V==="Medium"?"selected":""}>Medium</option>
              <option value="SemiBold" ${V==="SemiBold"||V==="Semi Bold"?"selected":""}>SemiBold</option>
              <option value="Bold" ${V==="Bold"?"selected":""}>Bold</option>
            </select>
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Line Height (% or px or auto)</label>
            <input type="text" class="modal-input" id="fix-line-height" value="${d(q)}" style="width: 100%;" placeholder="e.g. 120%, 24px, auto" />
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Letter Spacing (px or %)</label>
            <input type="text" class="modal-input" id="fix-letter-spacing" value="${d(G)}" style="width: 100%;" placeholder="e.g. 0, 0.5px, 1%" />
          </div>

          <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #eee;">
            <button class="modal-btn modal-btn-cancel" id="choose-typo-style-btn" style="width: 100%; margin-bottom: 8px; background: #0071e3; border-color: #0071e3; color: white;">
              Choose Typography Style
            </button>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="typography-fix-modal-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="typography-fix-modal-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,pe.appendChild(te),document.body.appendChild(pe);let re=te.querySelector("#fix-font-family"),ce=te.querySelector("#fix-font-size"),fe=te.querySelector("#fix-font-weight"),ie=te.querySelector("#fix-line-height"),de=te.querySelector("#fix-letter-spacing"),R=te.querySelector("#choose-typo-style-btn"),ge=te.querySelector("#typography-fix-modal-cancel-btn"),J=te.querySelector("#typography-fix-modal-apply-btn"),me=te.querySelector(".modal-close");setTimeout(()=>{re.focus()},100);let h=()=>{pe.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{pe.parentNode&&pe.remove()},200)};ge.onclick=h,me.onclick=h,pe.onclick=X=>{X.target===pe&&h()},R.onclick=()=>{ws(z,X=>{X&&(re.value=X.fontFamily||"",ce.value=X.fontSize||"",fe.value=X.fontWeight||"Regular",ie.value=X.lineHeight||"",de.value=X.letterSpacing||"0")})},J.onclick=()=>{let X={fontFamily:re.value.trim(),fontSize:ce.value.trim(),fontWeight:fe.value,lineHeight:ie.value.trim(),letterSpacing:de.value.trim()};if(!X.fontFamily){re.focus(),re.style.borderColor="#ff3b30",setTimeout(()=>{re.style.borderColor="#0071e3"},2e3);return}if(!X.fontSize||isNaN(parseFloat(X.fontSize))){ce.focus(),ce.style.borderColor="#ff3b30",setTimeout(()=>{ce.style.borderColor="#0071e3"},2e3);return}h(),ne(I.id,"\u23F3 Fixing...",!0),parent.postMessage({pluginMessage:{type:"fix-issue",issue:I,fixData:X}},"*")}}function Is(I,z){if(I===z)return 100;let v=100,M=Math.abs(I-z);return Math.max(0,Math.round((1-M/v)*100))}function xn(I,z,v,M){let L=document.createElement("div");L.className="modal-overlay",L.id="spacing-picker-modal-overlay";let B=document.createElement("div");B.className="modal-dialog",B.style.maxWidth="400px";let D=M.map(q=>`
        <div class="spacing-picker-item" data-value="${q}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 1px solid ${v===q?"#0071e3":"#ddd"};
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='${v===q?"#0071e3":"#ddd"}'; this.style.boxShadow='none'">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="
              width: 40px;
              height: 40px;
              border-radius: 4px;
              background: #f0f0f0;
              border: 1px solid #ddd;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 12px;
              font-weight: 600;
              color: #666;
            ">${q}px</div>
            <div style="font-weight: 600; font-size: 12px; color: #333;">
              ${q}px
            </div>
          </div>
          ${v===q?'<div style="color: #0071e3; font-weight: 600;">Current</div>':""}
        </div>
      `).join(""),Y=String(z||"").replace(/([A-Z])/g," $1").replace(/^./,q=>q.toUpperCase()).trim();B.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Spacing Value</h2>
        <p class="modal-subtitle">Node: ${d(I.nodeName||"Unnamed")} - ${d(Y)}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Value:</div>
          <div style="font-size: 16px; font-weight: 600; color: #333;">${v}px</div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${D}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="spacing-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,L.appendChild(B),document.body.appendChild(L);let j=B.querySelector("#spacing-picker-modal-cancel-btn"),P=B.querySelector(".modal-close"),U=B.querySelectorAll(".spacing-picker-item"),V=()=>{L.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{L.parentNode&&L.remove()},200)};j.onclick=V,P.onclick=V,L.onclick=q=>{q.target===L&&V()},U.forEach(q=>{q.onclick=G=>{G.preventDefault(),G.stopPropagation();let pe=parseInt(q.getAttribute("data-value"),10);V(),Ut(I,z,v,pe)}})}function Ut(I,z,v,M,L=[],B={}){let{onApply:D,onIgnore:Y,onCancel:j,showIgnore:P=!1,progress:U}=B,V=String(z||"").replace(/([A-Z])/g," $1").replace(/^./,ee=>ee.toUpperCase()).trim(),G=(L.length>0?L:[0,4,8,12,16,24,32,40,48,64,72,80,88,96]).map(ee=>({value:ee,similarity:Is(v,ee),diff:Math.abs(v-ee)})).sort((ee,ye)=>M!==void 0&&ee.value===M?-1:M!==void 0&&ye.value===M?1:ee.diff-ye.diff).slice(0,5);if(G.length===0){alert("No spacing values available");return}let pe=G[0].value,te=(ee,ye)=>{let xe=ee.value!==v;return`
      <div class="spacing-option-item" data-value="${ee.value}" style="
        padding: 10px 12px;
        margin-bottom: 6px;
        border: 1px solid ${ye?"#0071e3":"#e0e0e0"};
        border-radius: 8px;
        cursor: pointer;
        background: ${ye?"#e3f2fd":"white"};
        display: flex;
        align-items: center;
        gap: 12px;
        transition: all 0.15s;
      ">
        <input type="radio" name="spacing-option" ${ye?"checked":""} style="margin: 0; cursor: pointer;" />
        <div style="
          width: 40px;
          height: 40px;
          border-radius: 6px;
          background: ${ye?"#e3f2fd":"#f0f0f0"};
          border: 1px solid ${ye?"#0071e3":"#ddd"};
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 600;
          color: ${ye?"#0071e3":"#666"};
          flex-shrink: 0;
        ">${ee.value}</div>
        <div style="flex: 1;">
          <div style="font-weight: 600; font-size: 13px; color: #333;">${ee.value}px</div>
          <div style="font-size: 10px; color: ${xe?"#721c24":"#155724"};">
            ${xe?`\u26A0 \u0394${ee.value>v?"+":""}${ee.value-v}px`:"\u2713 Same"}
          </div>
        </div>
        <span style="font-size: 11px; color: #666; background: #f0f0f0; padding: 2px 8px; border-radius: 10px;">${ee.similarity}%</span>
      </div>
    `},re=document.createElement("div");re.className="modal-overlay",re.id="spacing-fix-confirm-modal-overlay";let ce=document.createElement("div");ce.className="modal-dialog",ce.style.maxWidth="420px";let fe=U?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${U.current}/${U.total}</div>`:"",ie=G.map((ee,ye)=>te(ee,ye===0)).join("");ce.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Spacing</h2>
        <p class="modal-subtitle">Node: ${d(I.nodeName||"Unnamed")} - ${d(V)}</p>
      </div>
      ${fe}
      <div class="modal-body">
        <div style="margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 6px; display: flex; align-items: center; gap: 10px;">
          <div style="
            width: 40px;
            height: 40px;
            border-radius: 4px;
            background: #f0f0f0;
            border: 1px solid #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
            color: #666;
          ">${v}</div>
          <div>
            <div style="font-size: 11px; color: #666;">Current ${d(V)}:</div>
            <div style="font-size: 14px; font-weight: 600;">${v}px</div>
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px;">
          Select a value to apply (Top 5 closest):
        </div>
        <div id="spacing-options-container" style="max-height: 280px; overflow-y: auto;">
          ${ie}
        </div>
      </div>
      <div class="modal-footer">
        ${P?'<button class="modal-btn modal-btn-cancel" id="spacing-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="spacing-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="spacing-fix-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,re.appendChild(ce),document.body.appendChild(re);let de=ce.querySelector("#spacing-fix-confirm-cancel-btn"),R=ce.querySelector("#spacing-fix-confirm-apply-btn"),ge=ce.querySelector("#spacing-fix-ignore-btn"),J=ce.querySelector(".modal-close"),me=ce.querySelector("#spacing-options-container"),h=ee=>{pe=ee,me.querySelectorAll(".spacing-option-item").forEach(xe=>{let Z=parseInt(xe.getAttribute("data-value"),10)===ee;xe.style.border=Z?"2px solid #0071e3":"2px solid #e0e0e0",xe.style.background=Z?"#e3f2fd":"white";let nt=xe.querySelector('input[type="radio"]');nt&&(nt.checked=Z)})};(()=>{me.querySelectorAll(".spacing-option-item").forEach(ye=>{ye.onclick=xe=>{xe.preventDefault();let Xe=parseInt(ye.getAttribute("data-value"),10);h(Xe)}})})();let le=()=>{re.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{re.parentNode&&re.remove()},200)};de.onclick=()=>{le(),j&&typeof j=="function"&&j()},J.onclick=()=>{le(),j&&typeof j=="function"&&j()},re.onclick=ee=>{ee.target===re&&(le(),j&&typeof j=="function"&&j())},R.onclick=()=>{le(),ne(I.id,"\u23F3 Fixing spacing...",!0),parent.postMessage({pluginMessage:{type:"fix-spacing-issue",issue:I,propertyName:z,value:pe}},"*"),D&&typeof D=="function"&&D()},ge&&(ge.onclick=()=>{le(),Y&&typeof Y=="function"&&Y()})}function kt(I){try{let z=parseInt(I.slice(1,3),16),v=parseInt(I.slice(3,5),16),M=parseInt(I.slice(5,7),16);return(z*299+v*587+M*114)/1e3>128?"#000000":"#ffffff"}catch(z){return"#000000"}}function Cs(I,z){let v=I.replace("#",""),M=z.replace("#",""),L=parseInt(v.substr(0,2),16),B=parseInt(v.substr(2,2),16),D=parseInt(v.substr(4,2),16),Y=parseInt(M.substr(0,2),16),j=parseInt(M.substr(2,2),16),P=parseInt(M.substr(4,2),16);return Math.sqrt(Math.pow(L-Y,2)+Math.pow(B-j,2)+Math.pow(D-P,2))}function $s(I,z){let M=Cs(I,z);return Math.round((1-M/441.67)*100)}function po(I,z,v,M="",L=""){return kt(I),`
      <div class="color-picker-item" data-color="${d(I)}" style="
        padding: 7px;
        margin-bottom: 8px;
        border: 1px solid ${v};
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 12px;
        background: white;
        transition: all 0.2s;
      " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='${v}'; this.style.boxShadow='none'">
        <div style="
          width: 36px;
          height: 36px;
          border-radius: 6px;
          background: ${d(I)};
          border: 1px solid #ddd;
          flex-shrink: 0;
        "></div>
        <div style="flex: 1;">
          <div style="font-weight: 600; font-size: 12px; color: #333; margin-bottom: 4px;">
            ${z||d(I)}
          </div>
          <div style="font-size: 10px; color: #666; font-family: 'SF Mono', Monaco, monospace;">
            ${d(I)}
          </div>
          ${M?`<div style="font-size: 11px; color: #666; margin-top: 4px;">${M}</div>`:""}
        </div>
        ${L?`<div style="color: #0071e3; font-weight: 600; margin-left: auto;">${L}</div>`:""}
      </div>
    `}function Sn(I,z,v,M={}){if(!z){let q=(I.message||"").match(/Color (#[0-9A-Fa-f]{6})/);z=q?q[1].toUpperCase():null}if(!z){alert("Cannot determine current color from issue message");return}let L=document.createElement("div");L.className="modal-overlay",L.id="color-picker-modal-overlay";let B=document.createElement("div");B.className="modal-dialog",B.style.maxWidth="400px";let D=v.map(V=>{let q=M[V]||"";return po(V,q||V,z===V?"#0071e3":"#ddd","",z===V?"Current":"")}).join("");B.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Color</h2>
        <p class="modal-subtitle">Node: ${d(I.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Color:</div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 32px; height: 32px; border-radius: 4px; background: ${d(z)}; border: 1px solid #ddd;"></div>
            <div style="font-family: 'SF Mono', Monaco, monospace; font-size: 11px; font-weight: 600;">${d(z)}</div>
          </div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${D}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="color-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,L.appendChild(B),document.body.appendChild(L);let Y=B.querySelector("#color-picker-modal-cancel-btn"),j=B.querySelector(".modal-close"),P=B.querySelectorAll(".color-picker-item"),U=()=>{L.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{L.parentNode&&L.remove()},200)};Y.onclick=U,j.onclick=U,L.onclick=V=>{V.target===L&&U()},P.forEach(V=>{V.onclick=q=>{q.preventDefault(),q.stopPropagation();let G=V.getAttribute("data-color");U(),jt(I,z,G,M)}})}function jt(I,z,v,M={},L=[],B={}){let{onApply:D,onIgnore:Y,onCancel:j,showIgnore:P=!1,progress:U}=B,V=L.length>0?L:Object.keys(M);V.length===0&&v&&(V=[v]);let q=V.map(le=>({color:le,name:M[le]||le,similarity:$s(z,le)})).sort((le,ee)=>v&&le.color===v?-1:v&&ee.color===v?1:ee.similarity-le.similarity).slice(0,5);if(q.length===0){alert("No colors available");return}let G=q[0].color,pe=(le,ee)=>`
      <div class="color-option-item" data-color="${d(le.color)}" style="
        padding: 10px 12px;
        margin-bottom: 6px;
        border: 1px solid ${ee?"#0071e3":"#e0e0e0"};
        border-radius: 8px;
        cursor: pointer;
        background: ${ee?"#e3f2fd":"white"};
        display: flex;
        align-items: center;
        gap: 12px;
        transition: all 0.15s;
      ">
        <input type="radio" name="color-option" ${ee?"checked":""} style="margin: 0; cursor: pointer;" />
        <div style="
          width: 36px;
          height: 36px;
          border-radius: 6px;
          background: ${d(le.color)};
          border: 1px solid ${ee?"#0071e3":"#ddd"};
          flex-shrink: 0;
        "></div>
        <div style="flex: 1;">
          <div style="font-weight: 600; font-size: 13px; color: #333;">${d(le.name)}</div>
          <div style="font-size: 11px; color: #666; font-family: 'SF Mono', Monaco, monospace;">${d(le.color)}</div>
        </div>
        <span style="font-size: 11px; color: #666; background: #f0f0f0; padding: 2px 8px; border-radius: 10px;">${le.similarity}%</span>
      </div>
    `,te=document.createElement("div");te.className="modal-overlay",te.id="color-fix-confirm-modal-overlay";let re=document.createElement("div");re.className="modal-dialog",re.style.maxWidth="420px";let ce=U?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${U.current}/${U.total}</div>`:"",fe=q.map((le,ee)=>pe(le,ee===0)).join("");re.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Color</h2>
        <p class="modal-subtitle">Node: ${d(I.nodeName||"Unnamed")}</p>
      </div>
      ${ce}
      <div class="modal-body">
        <div style="margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 6px; display: flex; align-items: center; gap: 10px;">
          <div style="
            width: 32px;
            height: 32px;
            border-radius: 4px;
            background: ${d(z)};
            border: 1px solid #ddd;
          "></div>
          <div>
            <div style="font-size: 11px; color: #666;">Current:</div>
            <div style="font-size: 12px; font-weight: 600; font-family: 'SF Mono', Monaco, monospace;">${d(z)}</div>
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px;">
          Select a color to apply (Top 5 matches):
        </div>
        <div id="color-options-container" style="max-height: 280px; overflow-y: auto;">
          ${fe}
        </div>
      </div>
      <div class="modal-footer">
        ${P?'<button class="modal-btn modal-btn-cancel" id="color-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="color-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="color-fix-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,te.appendChild(re),document.body.appendChild(te);let ie=re.querySelector("#color-fix-confirm-cancel-btn"),de=re.querySelector("#color-fix-confirm-apply-btn"),R=re.querySelector("#color-fix-ignore-btn"),ge=re.querySelector(".modal-close"),J=re.querySelector("#color-options-container"),me=le=>{G=le,J.querySelectorAll(".color-option-item").forEach(ye=>{let Xe=ye.getAttribute("data-color")===le;ye.style.border=Xe?"2px solid #0071e3":"2px solid #e0e0e0",ye.style.background=Xe?"#e3f2fd":"white";let Z=ye.querySelector('input[type="radio"]');Z&&(Z.checked=Xe)})};(()=>{J.querySelectorAll(".color-option-item").forEach(ee=>{ee.onclick=ye=>{ye.preventDefault();let xe=ee.getAttribute("data-color");me(xe)}})})();let X=()=>{te.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{te.parentNode&&te.remove()},200)};ie.onclick=()=>{X(),j&&typeof j=="function"&&j()},ge.onclick=()=>{X(),j&&typeof j=="function"&&j()},te.onclick=le=>{le.target===te&&(X(),j&&typeof j=="function"&&j())},de.onclick=()=>{X(),ne(I.id,"\u23F3 Fixing color...",!0),parent.postMessage({pluginMessage:{type:"fix-color-issue",issue:I,color:G}},"*"),D&&typeof D=="function"&&D()},R&&(R.onclick=()=>{X(),Y&&typeof Y=="function"&&Y()})}function uo({reportData:I,getTypeDisplayName:z}){let v=I||{},M=v.issues||[],L=v.tokens||null,B=v.timestamp||Date.now(),D=new Date(B).toLocaleString("vi-VN"),Y="Design Review",j=U=>{try{return typeof z=="function"?z(U):String(U||"")}catch(V){return String(U||"")}},P=`<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Design Review Report - ${D}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      line-height: 1.6;
      color: #1d1d1f;
      background: #f5f5f7;
      padding: 40px 20px;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      padding: 40px;
    }
    .header {
      border-bottom: 2px solid #e5e5e7;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    .header h1 {
      font-size: 28px;
      color: #1d1d1f;
      margin-bottom: 8px;
    }
    .header .meta {
      color: #86868b;
      font-size: 14px;
    }
    .section {
      margin-bottom: 40px;
    }
    .section-title {
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 16px;
      color: #1d1d1f;
      padding-bottom: 8px;
      border-bottom: 1px solid #e5e5e7;
    }
    .export-filter-group {
      display: flex;
      gap: 8px;
      margin-bottom: 16px;
    }
    .export-filter-btn {
      padding: 4px 10px;
      font-size: 12px;
      border-radius: 999px;
      border: 1px solid #e5e7eb;
      background: #f9fafb;
      cursor: pointer;
    }
    .export-filter-btn.active {
      background: #111827;
      color: #fff;
      border-color: #111827;
    }
    .stats {
      display: flex;
      gap: 16px;
      margin-bottom: 24px;
      flex-wrap: wrap;
    }
    .stat-card {
      padding: 16px 20px;
      border-radius: 8px;
      background: #f5f5f7;
      min-width: 120px;
    }
    .stat-card.error { background: #fee; color: #c33; }
    .stat-card.warn { background: #fff4e6; color: #d97706; }
    .stat-card .value {
      font-size: 32px;
      font-weight: 700;
      margin-bottom: 4px;
    }
    .stat-card .label {
      font-size: 12px;
      text-transform: uppercase;
      opacity: 0.8;
    }
    .issue-group {
      margin-bottom: 24px;
      border: 1px solid #e5e7eb;
      border-radius: 10px;
      padding: 16px;
      background: #fff;
    }
    .issue-group-header {
      font-size: 16px;
      font-weight: 600;
      color: #1d1d1f;
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      user-select: none;
    }
    .issue-group-toggle {
      border: none;
      background: #f3f4f6;
      width: 24px;
      height: 24px;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
    }
    .issue-group-content {
      margin-top: 12px;
    }
    .issue-group.collapsed .issue-group-content {
      display: none;
    }
    .issue {
      padding: 12px 16px;
      margin-bottom: 8px;
      border-radius: 6px;
      border-left: 4px solid;
    }
    .issue.error {
      background: #fef2f2;
      border-left-color: #ef4444;
    }
    .issue.warn {
      background: #fffbeb;
      border-left-color: #f59e0b;
    }
    .issue-type {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    .issue-message {
      font-size: 14px;
      margin-bottom: 4px;
    }
    .issue-node {
      font-size: 12px;
      color: #86868b;
      font-family: monospace;
      margin-top: 4px;
    }
    .token-list {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 12px;
    }
    .token-item {
      padding: 12px;
      background: #fafafa;
      border-radius: 6px;
      border: 1px solid #e5e5e7;
    }
    .token-value {
      font-family: monospace;
      font-size: 13px;
      margin-bottom: 4px;
    }
    .token-color-preview {
      display: inline-block;
      width: 24px;
      height: 24px;
      border-radius: 4px;
      border: 1px solid #d1d1d6;
      vertical-align: middle;
      margin-right: 8px;
    }
    .token-color-type {
      display: inline-block;
      font-size: 10px;
      padding: 2px 6px;
      background: #3b82f6;
      color: white;
      border-radius: 4px;
      margin-left: 6px;
    }
    .token-node-count {
      font-size: 11px;
      color: #86868b;
      margin-top: 4px;
    }
    .token-empty-message {
      padding: 12px;
      font-size: 12px;
      color: #9ca3af;
      font-style: italic;
    }
    @media print {
      body { padding: 20px; }
      .container { box-shadow: none; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>\u{1F3A8} Design Review Report</h1>
      <div class="meta">Generated: ${D} | Page: ${Y}</div>
    </div>`;if(M&&M.length>0){let U={error:M.filter(q=>q.severity==="error").length,warn:M.filter(q=>q.severity==="warn").length,total:M.length},V=M.reduce((q,G)=>(q[G.type]=q[G.type]||[],q[G.type].push(G),q),{});P+=`
    <div class="section">
      <h2 class="section-title">\u{1F4CA} Summary</h2>
      <div class="stats">
        ${U.error>0?`<div class="stat-card error"><div class="value">${U.error}</div><div class="label">Errors</div></div>`:""}
        ${U.warn>0?`<div class="stat-card warn"><div class="value">${U.warn}</div><div class="label">Warnings</div></div>`:""}
        <div class="stat-card"><div class="value">${U.total}</div><div class="label">Total Issues</div></div>
      </div>
    </div>

    <div class="section">
      <h2 class="section-title">\u{1F50D} Issues</h2>
      <div class="export-filter-group">
        <button class="export-filter-btn active" data-severity="all">All</button>
        <button class="export-filter-btn" data-severity="error">Errors</button>
        <button class="export-filter-btn" data-severity="warn">Warnings</button>
      </div>`;for(let[q,G]of Object.entries(V)){let pe=d(j(q));P+=`
      <div class="issue-group collapsed" data-type="${q}" data-label="${pe}">
        <div class="issue-group-header">
          <button class="issue-group-toggle" type="button">+</button>
          <span>${pe} (${G.length})</span>
        </div>
        <div class="issue-group-content">`,G.forEach(te=>{P+=`
          <div class="issue ${te.severity}">
            <div class="issue-type">${String(te.severity||"").toUpperCase()}</div>
            <div class="issue-message">${d(te.message)}</div>
            ${te.nodeName?`<div class="issue-node">Node: ${d(te.nodeName)}</div>`:""}
          </div>`}),P+=`
        </div>
      </div>`}P+=`
    </div>`}if(L){P+=`
    <div class="section">
      <h2 class="section-title">\u{1F3A8} Design Tokens</h2>`;let U={colors:{label:"Colors",values:L.colors||[]},gradients:{label:"Gradients",values:L.gradients||[]},borderRadius:{label:"Border Radius",values:L.borderRadius||[]},fontWeight:{label:"Font Weight",values:L.fontWeight||[]},lineHeight:{label:"Line Height (%)",values:L.lineHeight||[]},fontSize:{label:"Font Size",values:L.fontSize||[]},fontFamily:{label:"Font Family",values:L.fontFamily||[]}};for(let[V,q]of Object.entries(U)){if(P+=`
      <div class="issue-group collapsed">
        <div class="issue-group-header">
          <button class="issue-group-toggle" type="button">+</button>
          <span>${q.label} (${q.values.length})</span>
        </div>
        <div class="issue-group-content">`,!q.values||q.values.length===0){P+=`
          <div class="token-empty-message">No tokens in this group.</div>`,P+=`
        </div>
      </div>`;continue}P+=`
          <div class="token-list">`,q.values.forEach(G=>{let pe=G.value,te=typeof G.totalNodes=="number"?G.totalNodes:G.nodes?G.nodes.length:0,re=G.colorType||"";if(V==="colors")P+=`
          <div class="token-item">
            <div class="token-value">
              <span class="token-color-preview" style="background-color: ${d(pe)}"></span>
              ${d(pe)}
              ${re?`<span class="token-color-type">${d(re)}</span>`:""}
            </div>
            ${te>1?`<div class="token-node-count">Used in ${te} nodes</div>`:""}
          </div>`;else if(V==="gradients")P+=`
          <div class="token-item">
            <div class="token-value">
              <span class="token-color-preview" style="background: ${d(pe)}"></span>
              ${d(pe)}
              ${re?`<span class="token-color-type">${d(re)}</span>`:""}
            </div>
            ${te>1?`<div class="token-node-count">Used in ${te} nodes</div>`:""}
          </div>`;else{let ce="";if(V==="fontWeight"){let fe=Array.isArray(G.fontFamilies)?G.fontFamilies:null;if(!fe){let ie={};(Array.isArray(G.nodes)?G.nodes:[]).forEach(R=>{let ge=R&&R.fontFamily?String(R.fontFamily):"Unknown";ie[ge]=(ie[ge]||0)+1}),fe=Object.entries(ie).map(([R,ge])=>({family:R,count:ge})).sort((R,ge)=>ge.count-R.count||R.family.localeCompare(ge.family))}Array.isArray(fe)&&fe.length>0&&(ce=`<div class="token-node-count" style="margin-top: 6px;">Font-family:<br/>${fe.map(de=>`${d(de.family)} (${de.count})`).join("<br/>")}</div>`)}P+=`
          <div class="token-item">
            <div class="token-value">${d(String(pe))}</div>
            ${te>1?`<div class="token-node-count">Used in ${te} nodes</div>`:""}
            ${ce}
          </div>`}}),P+=`
          </div>
        </div>
      </div>`}P+=`
    </div>`}return P+=`
  </div>
  <script>
    (function() {
      function updateGroupState(group, content, toggleBtn) {
        const collapsed = group.classList.contains('collapsed');
        if (collapsed) {
          content.style.display = 'none';
          if (toggleBtn) toggleBtn.textContent = '+';
        } else {
          content.style.display = 'block';
          if (toggleBtn) toggleBtn.textContent = '\u2212';
        }
      }

      function initCollapsibles() {
        document.querySelectorAll('.issue-group').forEach(group => {
          const header = group.querySelector('.issue-group-header');
          const content = group.querySelector('.issue-group-content');
          const toggleBtn = group.querySelector('.issue-group-toggle');
          if (!content || !header) return;

          const toggle = () => {
            group.classList.toggle('collapsed');
            updateGroupState(group, content, toggleBtn);
          };

          if (toggleBtn) {
            toggleBtn.addEventListener('click', e => {
              e.stopPropagation();
              toggle();
            });
          }

          header.addEventListener('click', e => {
            if (toggleBtn && (e.target === toggleBtn || toggleBtn.contains(e.target))) {
              return;
            }
            toggle();
          });

          updateGroupState(group, content, toggleBtn);
        });
      }

      function applySeverityFilter(filter) {
        const buttons = document.querySelectorAll('.export-filter-btn');
        buttons.forEach(btn => {
          const val = btn.getAttribute('data-severity') || 'all';
          btn.classList.toggle('active', val === filter);
        });

        document.querySelectorAll('.issue-group').forEach(group => {
          const issues = group.querySelectorAll('.issue');
          const label = group.getAttribute('data-label') || '';
          let visibleCount = 0;

          issues.forEach(issue => {
            const isError = issue.classList.contains('error');
            const isWarn = issue.classList.contains('warn');
            let show = false;
            if (filter === 'all') show = true;
            else if (filter === 'error') show = isError;
            else if (filter === 'warn') show = isWarn;
            issue.style.display = show ? '' : 'none';
            if (show) visibleCount++;
          });

          const headerCountSpan = group.querySelector('.issue-group-header span:last-child');
          if (headerCountSpan && label) {
            headerCountSpan.textContent = label + ' (' + visibleCount + ')';
          }
        });
      }

      function initExportFilters() {
        const buttons = document.querySelectorAll('.export-filter-btn');
        if (!buttons.length) return;
        let current = 'all';

        buttons.forEach(btn => {
          btn.addEventListener('click', () => {
            const val = btn.getAttribute('data-severity') || 'all';
            current = val;
            applySeverityFilter(current);
          });
        });

        // Initial apply
        applySeverityFilter(current);
      }

      function initExportUI() {
        initCollapsibles();
        initExportFilters();
      }

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initExportUI);
      } else {
        initExportUI();
      }
    })();
  <\/script>
</body>
</html>`,P}function Es(){let I=new Date,z=I.getFullYear(),v=String(I.getMonth()+1).padStart(2,"0"),M=String(I.getDate()).padStart(2,"0"),L=String(I.getHours()).padStart(2,"0"),B=String(I.getMinutes()).padStart(2,"0"),D=String(I.getSeconds()).padStart(2,"0");return`design-review-report-${z}-${v}-${M}-${L}-${B}-${D}`}function Ms(I,z){if(!I||!Array.isArray(I.colors))return I;let v=z||{};return Je(De({},I),{colors:I.colors.map(M=>Je(De({},M),{name:v[String(M.value).toUpperCase()]||"No name"}))})}function kn({format:I,reportData:z,getTypeDisplayName:v,filenameBase:M,colorNameMap:L}={}){var Y,j;let B=z||{};if(!B.issues&&!B.tokens){alert("No data to export!");return}let D=M||Es();if(I==="html"){let P=uo({reportData:B,getTypeDisplayName:v}),U=new Blob([P],{type:"text/html"}),V=URL.createObjectURL(U),q=document.createElement("a");q.href=V,q.download=`${D}.html`,q.click(),URL.revokeObjectURL(V);return}if(I==="pdf"){let P=uo({reportData:B,getTypeDisplayName:v});try{let U=window.open("","_blank");if(!U){alert("Popup blocked. Downloading HTML - you can open the file and select Print to create PDF.");let V=new Blob([P],{type:"text/html"}),q=URL.createObjectURL(V),G=document.createElement("a");G.href=q,G.download=`${D}.html`,G.click(),URL.revokeObjectURL(q);return}U.document.open(),U.document.write(P),U.document.close(),U.onload=()=>{setTimeout(()=>{U.print()},250)},setTimeout(()=>{U.document&&U.document.readyState==="complete"&&U.print()},500)}catch(U){console.error("Error opening print window:",U),alert("Cannot open print window. Downloading HTML - you can open the file and select Print to create PDF.");let V=new Blob([P],{type:"text/html"}),q=URL.createObjectURL(V),G=document.createElement("a");G.href=q,G.download=`${D}.html`,G.click(),URL.revokeObjectURL(q)}return}if(I==="json"){console.log("Export JSON - colorNameMap:",L),console.log("Export JSON - tokens.colors:",(Y=B.tokens)==null?void 0:Y.colors);let P=Je(De({},B),{tokens:Ms(B.tokens,L)});console.log("Export JSON - enriched colors:",(j=P.tokens)==null?void 0:j.colors);let U=JSON.stringify(P,null,2),V=new Blob([U],{type:"application/json"}),q=URL.createObjectURL(V),G=document.createElement("a");G.href=q,G.download=`${D}.json`,G.click(),URL.revokeObjectURL(q);return}}function wn({maxHistory:I=10,postPluginMessage:z,getCurrentReportData:v,setIsViewingTokens:M,renderResults:L,renderTokens:B}={}){let D=[],Y=!1,j=ie=>{try{typeof z=="function"&&z(ie)}catch(de){console.error("scanHistory postPluginMessage error:",de)}};function P(ie){D=(Array.isArray(ie)?ie:[]).slice(0,I)}function U(){D=[],Y=!1}function V(){return D||[]}function q(ie,de,R,ge){try{if(de==="issues"&&(!R.issues||R.issues.length===0)){console.log("Skipping save - no issues data");return}if(de==="tokens"&&(!R.tokens||Object.keys(R.tokens).length===0)){console.log("Skipping save - no tokens data");return}let J={id:Date.now().toString(),mode:ie,type:de,timestamp:new Date().toISOString(),context:ge||null,data:{issues:R.issues||null,tokens:R.tokens||null,issuesCount:R.issues?R.issues.length:0,tokensCount:R.tokens?Object.keys(R.tokens).reduce((h,X)=>{var le;return h+(((le=R.tokens[X])==null?void 0:le.length)||0)},0):0}};D.unshift(J),D=D.slice(0,I);let me=document.getElementById("history-panel");me&&me.style.display!=="none"&&ce(),j({type:"save-history-entry",entry:J})}catch(J){console.error("Error saving scan history:",J)}}function G(){j({type:"get-history"})}function pe(){try{let ie=V();if(ie.length>0){let de=ie[0],R=document.querySelector(`input[name="scope"][value="${de.mode}"]`);R&&(R.checked=!0,console.log("Loaded last scan mode:",de.mode))}}catch(ie){console.error("Error loading last scan mode:",ie)}}function te(){Y||(pe(),Y=!0)}function re(ie){try{let de=new Date(ie),ge=new Date-de,J=Math.floor(ge/6e4),me=Math.floor(ge/36e5),h=Math.floor(ge/864e5);return J<1?"Just now":J<60?`${J} minutes ago`:me<24?`${me} hours ago`:h<7?`${h} days ago`:de.toLocaleString("en-US",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"})}catch(de){return ie}}function ce(){let ie=document.getElementById("history-list");if(!ie){console.error("history-list element not found");return}let de=V();if(console.log("Rendering scan history:",de.length,"entries"),de.length===0){ie.innerHTML=`
              <div class="history-empty">
                <div class="icon">\u{1F4CB}</div>
                <p>No scan history</p>
                <p style="font-size: 11px; margin-top: 8px;">Scans will be saved automatically</p>
              </div>
            `;return}ie.innerHTML=de.map(R=>{var ee,ye;let ge=re(R.timestamp),J=R.mode==="page"?"Page":"Selection",me=R.type==="issues"?"Issues":"Tokens",h=R.type==="issues"?"issues":"tokens",X=R.context&&R.context.label?R.context.label:`${J} scan`,le="";if(R.type==="issues"){let xe=((ee=R.data.issues)==null?void 0:ee.filter(Z=>Z.severity==="error").length)||0,Xe=((ye=R.data.issues)==null?void 0:ye.filter(Z=>Z.severity==="warn").length)||0;le=`
                <span>\u274C ${xe} errors</span>
                <span>\u26A0\uFE0F ${Xe} warnings</span>
                <span>\u{1F4CA} ${R.data.issuesCount} total</span>
              `}else le=`
                <span>\u{1F3A8} ${R.data.tokensCount} tokens</span>
              `;return`
              <div class="history-item" data-id="${R.id}">
                <div class="history-item-header">
                  <span class="history-item-type ${h}">${me}</span>
                  <span class="history-item-time">${ge}</span>
                </div>
                <div class="history-item-info">${d(X)}</div>
                <div class="history-item-stats">${le}</div>
              </div>
            `}).join(""),ie.querySelectorAll(".history-item").forEach(R=>{R.onclick=()=>{let ge=R.getAttribute("data-id");fe(ge)}})}function fe(ie){try{let R=V().find(h=>h.id===ie);if(!R){alert("Scan history entry not found!");return}let ge=document.querySelector(`input[name="scope"][value="${R.mode}"]`);ge&&(ge.checked=!0);let J=typeof v=="function"?v():null;if(!J){console.warn("restoreReportFromHistory: currentReportData is not available");return}J.scanMode=R.mode,J.context=R.context||null,R.type==="issues"&&R.data.issues?(J.issues=R.data.issues,J.tokens=null,typeof M=="function"&&M(!1),typeof L=="function"&&L(R.data.issues,!0,{restoreTimestamp:R.timestamp})):R.type==="tokens"&&R.data.tokens&&(J.issues=null,J.tokens=R.data.tokens,typeof M=="function"&&M(!0),typeof B=="function"&&B(R.data.tokens,!0,{restoreTimestamp:R.timestamp}));let me=document.getElementById("history-panel");me&&(me.style.display="none"),console.log("Report restored from history:",ie)}catch(de){console.error("Error restoring report from history:",de),alert("Error restoring report: "+de.message)}}return{setHistory:P,clearLocalHistory:U,getScanHistory:V,saveScanHistory:q,requestScanHistory:G,loadLastScanMode:pe,loadLastScanModeOnce:te,renderScanHistory:ce,restoreReportFromHistory:fe}}var Ts=4;(function(){let I=document.getElementById("btn-scan"),z=document.getElementById("btn-cancel-scan"),v=document.getElementById("scan-progress"),M=document.getElementById("scan-progress-bar"),L=document.getElementById("scan-progress-text"),B=document.getElementById("btn-extract-tokens"),D=document.getElementById("btn-fill-spacing-scale"),Y=document.getElementById("btn-fill-color-scale"),j=document.getElementById("btn-extract-color-styles"),P=document.getElementById("btn-fill-font-size-scale"),U=document.getElementById("btn-fill-line-height-scale"),V=document.getElementById("btn-fill-font-size-from-typo"),q=document.getElementById("btn-fill-line-height-from-typo"),G=document.getElementById("btn-export"),pe=document.getElementById("btn-history"),te=document.getElementById("btn-close-history"),re=document.getElementById("btn-reset-all"),ce=document.getElementById("results-issues"),fe=document.getElementById("results-tokens"),ie=document.getElementById("btn-close"),de=document.querySelectorAll(".report-tab"),R=document.querySelectorAll(".report-content"),ge="issues";if(!I||!B||!ce||!fe||!ie||!G||!pe||!D||!Y||!P||!U){console.error("Required elements not found",{btnScan:I,btnExtractTokens:B,btnFillSpacingScale:D,btnFillColorScale:Y,btnFillFontSizeScale:P,btnFillLineHeightScale:U,resultsIssues:ce,resultsTokens:fe,btnClose:ie,btnExport:G,btnHistory:pe});return}hn();let J={},me={},h={issues:null,tokens:null,scanMode:null,timestamp:null,tokensTimestamp:null,context:null},X=new Map,le=1e3;function ee(){X.clear()}function ye(e,t){if(X.has(e))return X.get(e);let o=t();return X.size>=le&&Array.from(X.keys()).slice(0,100).forEach(n=>X.delete(n)),X.set(e,o),o}let xe=null,Xe=5e3,Z=[{id:1,name:"H1",fontFamily:"Inter",fontSize:48,fontWeight:"Bold",lineHeight:"120%",letterSpacing:"0",wordSpacing:"0"},{id:2,name:"H2",fontFamily:"Inter",fontSize:36,fontWeight:"Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:3,name:"H3",fontFamily:"Inter",fontSize:28,fontWeight:"SemiBold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:4,name:"H4",fontFamily:"Inter",fontSize:24,fontWeight:"SemiBold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:5,name:"H5",fontFamily:"Inter",fontSize:20,fontWeight:"Medium",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:6,name:"H6",fontFamily:"Inter",fontSize:18,fontWeight:"Medium",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:7,name:"Body",fontFamily:"Inter",fontSize:16,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"}],nt=8;function In(e,t){let o=r=>r==null||r==="Unknown"?"":String(r).toLowerCase().trim(),s=r=>r!=null&&r!=="Unknown"&&String(r).trim()!=="",n=0;s(e.fontFamily)&&s(t.fontFamily)&&o(e.fontFamily)===o(t.fontFamily)&&(n+=25),e.fontSize!==null&&e.fontSize!==void 0&&t.fontSize&&(Math.abs(e.fontSize-t.fontSize)===0?n+=30:Math.abs(e.fontSize-t.fontSize)<=2?n+=25:Math.abs(e.fontSize-t.fontSize)<=4?n+=20:Math.abs(e.fontSize-t.fontSize)<=8&&(n+=10)),s(e.fontWeight)&&s(t.fontWeight)&&o(e.fontWeight)===o(t.fontWeight)&&(n+=20),s(e.lineHeight)&&s(t.lineHeight)&&o(e.lineHeight)===o(t.lineHeight)&&(n+=15);let i=o(e.letterSpacing),l=o(t.letterSpacing||"0"),a=r=>r==="0"||r==="0px"||r==="0%"||r==="";return(s(e.letterSpacing)||s(t.letterSpacing))&&(a(i)&&a(l)||i===l)&&(n+=10),n}function Mt(e){var n;if(!e||!e.bestMatch||!e.bestMatch.name)return!1;let t=(n=e.nodeProps)==null?void 0:n.fontSize;if(t==null)return!0;let o=Z==null?void 0:Z.find(i=>i.name===e.bestMatch.name);return!o||!o.fontSize?!0:!(Math.abs(t-o.fontSize)>Ts)}function Ot(e){e&&parent.postMessage({pluginMessage:{type:"save-last-report",report:e}},"*")}function go(){parent.postMessage({pluginMessage:{type:"get-last-report"}},"*")}function ve(){var t,o,s,n,i,l,a,r,g,u,b,f,y,m,p,w;let e={spacingScale:((t=document.getElementById("spacing-scale"))==null?void 0:t.value)||"",spacingThreshold:((o=document.getElementById("spacing-threshold"))==null?void 0:o.value)||"100",colorScale:((s=document.getElementById("color-scale"))==null?void 0:s.value)||"",colorNameMap:J,ignoredIssues:me,fontSizeScale:((n=document.getElementById("font-size-scale"))==null?void 0:n.value)||"",fontSizeThreshold:((i=document.getElementById("font-size-threshold"))==null?void 0:i.value)||"100",lineHeightScale:((l=document.getElementById("line-height-scale"))==null?void 0:l.value)||"",lineHeightThreshold:((a=document.getElementById("line-height-threshold"))==null?void 0:a.value)||"300",lineHeightBaselineThreshold:((r=document.getElementById("line-height-baseline-threshold"))==null?void 0:r.value)||"120",typographyStyles:Z,skipNames:((g=document.getElementById("scan-skip-names"))==null?void 0:g.value)||"",typographyRules:{checkStyle:((u=document.getElementById("rule-typo-style"))==null?void 0:u.checked)||!0,checkFontFamily:((b=document.getElementById("rule-font-family"))==null?void 0:b.checked)||!0,checkFontSize:((f=document.getElementById("rule-font-size"))==null?void 0:f.checked)||!0,checkFontWeight:((y=document.getElementById("rule-font-weight"))==null?void 0:y.checked)||!0,checkLineHeight:((m=document.getElementById("rule-line-height"))==null?void 0:m.checked)||!0,checkLetterSpacing:((p=document.getElementById("rule-letter-spacing"))==null?void 0:p.checked)||!1,checkWordSpacing:((w=document.getElementById("rule-word-spacing"))==null?void 0:w.checked)||!1}};parent.postMessage({pluginMessage:{type:"save-input-values",values:e}},"*")}function mo(){parent.postMessage({pluginMessage:{type:"get-input-values"}},"*")}function Vt(e){if(!e)return;let t=document.getElementById("spacing-scale"),o=document.getElementById("spacing-threshold"),s=document.getElementById("color-scale"),n=document.getElementById("font-size-scale"),i=document.getElementById("font-size-threshold"),l=document.getElementById("line-height-scale"),a=document.getElementById("line-height-threshold"),r=document.getElementById("line-height-baseline-threshold");t&&e.spacingScale!==void 0&&(t.value=e.spacingScale),o&&e.spacingThreshold!==void 0&&(o.value=e.spacingThreshold),e.colorNameMap&&typeof e.colorNameMap=="object"?J=e.colorNameMap:J={},e.ignoredIssues&&typeof e.ignoredIssues=="object"?me=e.ignoredIssues:me={},s&&e.colorScale!==void 0&&(s.value=e.colorScale,typeof je=="function"&&je()),n&&e.fontSizeScale!==void 0&&(n.value=e.fontSizeScale),i&&e.fontSizeThreshold!==void 0&&(i.value=e.fontSizeThreshold),l&&e.lineHeightScale!==void 0&&(l.value=e.lineHeightScale),a&&e.lineHeightThreshold!==void 0&&(a.value=e.lineHeightThreshold),r&&e.lineHeightBaselineThreshold!==void 0&&(r.value=e.lineHeightBaselineThreshold);let g=document.getElementById("scan-skip-names");if(g&&e.skipNames!==void 0&&(g.value=e.skipNames),e.typographyStyles&&Array.isArray(e.typographyStyles)&&(Z=e.typographyStyles,nt=Math.max(...Z.map(u=>u.id||0),0)+1,Ke()),e.typographyRules){let u=e.typographyRules;document.getElementById("rule-typo-style")&&(document.getElementById("rule-typo-style").checked=u.checkStyle!==!1),document.getElementById("rule-font-family")&&(document.getElementById("rule-font-family").checked=u.checkFontFamily!==!1),document.getElementById("rule-font-size")&&(document.getElementById("rule-font-size").checked=u.checkFontSize!==!1),document.getElementById("rule-font-weight")&&(document.getElementById("rule-font-weight").checked=u.checkFontWeight!==!1),document.getElementById("rule-line-height")&&(document.getElementById("rule-line-height").checked=u.checkLineHeight!==!1),document.getElementById("rule-letter-spacing")&&(document.getElementById("rule-letter-spacing").checked=u.checkLetterSpacing===!0),document.getElementById("rule-word-spacing")&&(document.getElementById("rule-word-spacing").checked=u.checkWordSpacing===!0),Ke()}}function Cn(e){if(e){if(e.scanMode){let t=document.querySelector(`input[name="scope"][value="${e.scanMode}"]`);t&&(t.checked=!0)}h.scanMode=e.scanMode||h.scanMode,h.context=e.context||h.context,e.issues&&Array.isArray(e.issues)&&He(e.issues,!0,{skipSave:!0,restoreTimestamp:e.issuesTimestamp}),e.tokens&&It(e.tokens,!0,{skipSave:!0,restoreTimestamp:e.tokensTimestamp}),e.lastActiveTab?Ue(e.lastActiveTab):e.issues?Ue("issues"):e.tokens&&Ue("tokens")}}let st="all",We="",dt="all",Tt=!1;de.forEach(e=>{e.addEventListener("click",()=>{let t=e.dataset.tab;Ue(t),t!=="settings"&&(h.issues||h.tokens)&&Ot({issues:h.issues,issuesTimestamp:h.timestamp,tokens:h.tokens,tokensTimestamp:h.tokensTimestamp,lastActiveTab:t,scanMode:h.scanMode||null,context:h.context||null})})});function wt(e=null){let t=e?document.getElementById(`results-${e}`):ce;t&&(t.innerHTML="")}function Ue(e){de.forEach(n=>{n.dataset.tab===e?n.classList.add("active"):n.classList.remove("active")}),R.forEach(n=>{n.id===`results-${e}`?n.classList.add("active"):n.classList.remove("active")});let t=document.getElementById("filter-controls"),o=document.getElementById("filter-buttons"),s=document.getElementById("color-type-filter");if(t){if(e==="settings")t.style.display="none";else if(e==="animations"){let n=typeof window.hasAnimationData=="function"&&window.hasAnimationData();t.style.display=n?"flex":"none",o&&(o.style.display="none"),s&&(s.style.display="none")}else if(e==="tokens")(fe&&fe.querySelector(".token-group")||h.tokens)&&(t.style.display="flex"),o&&(o.style.display="none"),s&&h.tokens&&(h.tokens.colors||h.tokens.gradients)?s.style.display="block":s&&(s.style.display="none");else if(e==="issues"){let n=ce&&ce.querySelector(".issue-group"),i=h.issues&&h.issues.length>0;(n||i)&&(t.style.display="flex",o&&(o.style.display="flex")),s&&(s.style.display="none"),i&&typeof Ht=="function"&&Ht(h.issues)}}ge=e}function $n(e){return e==="error"?"\u274C":e==="warn"?"\u26A0\uFE0F":"\u2139\uFE0F"}document.documentElement.dataset.showIcons="false";function zs(e){return document.documentElement.dataset.showIcons!=="true"?"":{naming:"\u{1F3F7}\uFE0F",autolayout:"\u{1F4D0}",spacing:"\u{1F4CF}",color:"\u{1F3A8}","color-variable":"\u{1F517}",typography:"\u270D\uFE0F","typography-style":"\u{1F3A8}","typography-check":"\u{1F4DD}","typography-pass":"\u2705","typography-info":"\u2705","line-height":"\u{1F4DD}",position:"\u{1F4CD}",duplicate:"\u{1F504}",group:"\u{1F4E6}",component:"\u{1F9E9}","empty-frame":"\u{1F4ED}","nested-group":"\u{1F4DA}",contrast:"\u{1F308}","text-size-mobile":"\u{1F4F1}"}[e]||"\u{1F50D}"}function zt(e){return{naming:"Naming Layer",autolayout:"Auto Layout",spacing:"Spacing",color:"Color","color-variable":"Color Variable",typography:"Font Size","typography-style":"Text Style","typography-check":"Typography Style Match","typography-pass":"Typography \u2713 Matched","line-height":"Line Height",position:"Position Layer",duplicate:"Duplicate Layer",group:"Group Layer",component:"Component Reusable","empty-frame":"Empty Frame Layer","nested-group":"Nested Group Layer",contrast:"Contrast (ADA AA)","text-size-mobile":"Text Size (ADA)"}[e]||e.replace(/-/g," ")}function Gt(e){let t=document.createElement("div");t.className=`issue ${e.severity}`;let o="";e.type==="typography-check"&&e.nodeProps&&(o='<div class="typography-details" style="margin-top: 8px; padding: 8px; background: rgba(0,0,0,0.05); border-radius: 4px; font-size: 11px;">',o+='<div class="current-properties"><div style="margin-bottom: 6px;"><strong>Current Properties:</strong></div>',o+='<div style="padding-left: 0; line-height: 1.6;">',e.nodeProps.fontFamily&&(o+=`\u2022 Font Family: <code>${d(e.nodeProps.fontFamily)}</code><br>`),e.nodeProps.fontSize!==null&&e.nodeProps.fontSize!==void 0&&(o+=`\u2022 Font Size: <code>${e.nodeProps.fontSize}px</code><br>`),e.nodeProps.fontWeight&&(o+=`\u2022 Font Weight: <code>${d(e.nodeProps.fontWeight)}</code><br>`),e.nodeProps.lineHeight&&(o+=`\u2022 Line Height: <code>${d(e.nodeProps.lineHeight)}</code><br>`),e.nodeProps.letterSpacing!==null&&e.nodeProps.letterSpacing!==void 0&&(o+=`\u2022 Letter Spacing: <code>${d(e.nodeProps.letterSpacing)}</code><br>`),o+="</div></div>",e.bestMatch&&e.bestMatch.name&&e.severity==="error"?(o+=`<div class="closest-match"><div style="margin-bottom: 6px;"><strong>Closest Match: "${d(e.bestMatch.name)}" (${e.bestMatch.percentage||0}%)</strong></div>`,o+='<div style="padding-left: 0; line-height: 1.6;">',(e.bestMatch.differences||[]).forEach(a=>{let r=a.matches?"\u2713":"\u2717",g=a.matches?"green":"red";o+=`<span style="color: ${g}">${r} ${a.property}: <code>${d(a.current)}</code> \u2192 <code>${d(a.expected)}</code></span><br>`}),o+="</div></div>"):e.severity==="info"&&e.styleName&&(o+=`<div style="margin-top: 8px; color: green;"><strong>\u2713 All properties match style "${d(e.styleName)}"</strong></div>`),o+="</div>"),t.setAttribute("data-issue-id",e.id),t.innerHTML=`
      <div class="issue-header">
              <div>
                <span class="issue-type">${zt(e.type)}</span>
      <div class="issue-body">${d(e.message)}</div>
                ${e.nodeName?`<div class="issue-node">Node: ${d(e.nodeName)}</div>`:""}
                ${o}
              </div>
              <div class="issue-actions">
                <button class="btn-select" data-id="${e.id}">Select</button>
                ${e.bestMatch&&e.bestMatch.name&&e.type==="typography-check"&&Mt(e)?`
                  <button class="btn-suggest-fix" data-id="${e.id}" data-style-name="${d(e.bestMatch.name)}">Suggest Fix now</button>
                `:""}
                ${e.type==="typography-check"?`
                  <button class="btn-style-dropdown" data-id="${e.id}" data-issue-id="${e.id}">Select Style</button>
                `:""}
                ${(e.severity==="error"||e.severity==="warn")&&e.type==="typography-check"?`
                  <button class="btn-remove-layer" data-id="${e.id}">Remove Layer</button>
                `:""}
              </div>
      </div>
    `;let s=t.querySelector("button.btn-select");s&&(s.onclick=()=>{document.querySelectorAll(".btn-select.active").forEach(a=>a.classList.remove("active")),document.querySelectorAll(".issue.selected").forEach(a=>a.classList.remove("selected")),s.classList.add("active"),t.classList.add("selected"),parent.postMessage({pluginMessage:{type:"select-node",id:e.id}},"*")});let n=t.querySelector("button.btn-suggest-fix");n&&e.type==="typography-check"&&e.bestMatch&&e.bestMatch.name&&(function(a){n.onclick=r=>{r.preventDefault(),r.stopPropagation(),a.bestMatch&&a.bestMatch.name?eo(a,a.bestMatch.name):(console.error("Cannot apply: bestMatch.name is missing",a),alert("Error: Best match style name is missing"))}})(e);let i=t.querySelector("button.btn-style-dropdown");i&&e.type==="typography-check"&&(function(a){i.onclick=r=>{r.preventDefault(),r.stopPropagation(),parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:a.id}},"*"),window.pendingTypographyCheckIssue=a}})(e);let l=t.querySelector("button.btn-remove-layer");return l&&e.type==="typography-check"&&(function(a){l.onclick=r=>{r.preventDefault(),r.stopPropagation(),typeof Bt=="function"?Bt(a):(console.error("handleRemoveLayer is not a function"),alert("Error: handleRemoveLayer function not found"))}})(e),t}let _t=["typography-check","typography-style"];function En(e){var s;let t=new Map,o=[];for(let n of e){if(!_t.includes(n.type)||n.severity==="info"||!n.nodeProps){o.push(n);continue}let i=[];if(n.subIssues&&n.subIssues.length>0)for(let l of n.subIssues)i.push(Je(De({},n),{id:l.id,nodeName:l.nodeName,nodeProps:l.nodeProps||n.nodeProps,subIssues:void 0,affectedCount:1}));else i.push(n);for(let l of i){let a=l.nodeProps||{},r=[a.fontFamily||"",(s=a.fontSize)!=null?s:"",a.fontWeight||"",a.lineHeight||"",a.letterSpacing||""].join("|");t.has(r)||t.set(r,{key:r,issues:[],nodeProps:a,bestMatch:l.bestMatch,severity:l.severity,message:l.message,type:l.type}),t.get(r).issues.push(l)}}return{typographyGroups:[...t.values()],otherIssues:o}}let Yt=["color-variable","color"];function Mn(e){if(e.colorHex)return e.colorHex.toUpperCase();let t=(e.message||"").match(/#[0-9A-Fa-f]{6}/);return t?t[0].toUpperCase():""}function Tn(e){if(e.colorTarget)return e.colorTarget;let t=(e.message||"").toLowerCase();return t.startsWith("stroke")?"stroke":t.startsWith("effect")?"effect":"fill"}function zn(e){let t=new Map,o=[];for(let s of e){if(!Yt.includes(s.type)){o.push(s);continue}let n=[];if(s.subIssues&&s.subIssues.length>0)for(let i of s.subIssues)n.push(Je(De({},s),{id:i.id,nodeName:i.nodeName,colorHex:i.colorHex||s.colorHex,colorOpacity:i.colorOpacity!=null?i.colorOpacity:s.colorOpacity,colorTarget:i.colorTarget||s.colorTarget,fillIndex:i.fillIndex!=null?i.fillIndex:s.fillIndex,strokeIndex:i.strokeIndex!=null?i.strokeIndex:s.strokeIndex,matchingVariable:i.matchingVariable||s.matchingVariable,subIssues:void 0,affectedCount:1}));else n.push(s);for(let i of n){let l=Mn(i),a=Tn(i),r=i.matchingVariable?i.matchingVariable.name:"",g=`${i.type}|${l}|${a}|${r}`;t.has(g)||t.set(g,{key:g,issues:[],colorHex:l,colorTarget:a,matchingVariable:i.matchingVariable,severity:i.severity,type:i.type}),t.get(g).issues.push(i)}}return{colorGroups:[...t.values()],otherIssues:o}}let Jt=["typography","line-height","text-size-mobile","position"];function Bn(e){let t=e||"";return t=t.replace(/ on text "[^"]*"/g,""),t=t.replace(/ on "[^"]*"/g,""),t=t.replace(/\s*Text:\s*"[^"]*"\s*$/,""),t=t.replace(/\s*\(\d+ nodes?\)\s*$/,""),t.trim()}function Nn(e){let t=new Map,o=[];for(let s of e){if(!Jt.includes(s.type)){o.push(s);continue}let n=[];if(s.subIssues&&s.subIssues.length>0)for(let i of s.subIssues)n.push(Je(De({},s),{id:i.id,nodeName:i.nodeName,nodeProps:i.nodeProps||s.nodeProps,subIssues:void 0,affectedCount:1}));else n.push(s);for(let i of n){let l=Bn(i.message,i.nodeName);t.has(l)||t.set(l,{key:l,issues:[],message:l,severity:i.severity,type:i.type,nodeProps:i.nodeProps||null,bestMatch:i.bestMatch||null}),t.get(l).issues.push(i)}}return{simpleGroups:[...t.values()],otherIssues:o}}function Fn(e){let t=document.createElement("div");t.className=`issue-grouped-card ${e.severity}`,t.setAttribute("data-group-key",e.key),t.setAttribute("data-issue-count",e.issues.length),t.setAttribute("data-severity",e.severity);let o=e.issues.length,s=e.message||"",n="",i="";if(e.type==="typography"){let p=s.match(/fontSize\s+(\d+(?:\.\d+)?px)/i);p&&(n=p[1]),i="Font Size"}else if(e.type==="line-height"){let p=s.match(/Line-height\s+([\d.]+%|"AUTO")/i);p&&(n=p[1].replace(/"/g,"")),i="Line Height"}else if(e.type==="text-size-mobile"){let p=s.match(/\((\d+(?:\.\d+)?px)\)/);p&&(n=p[1]),i="Text Size (ADA)"}else if(e.type==="position"){let p=s.match(/\(x:(-?\d+),\s*y:(-?\d+)\)/);p&&(n=`x:${p[1]}, y:${p[2]}`),i="Position"}let l=e.type==="text-size-mobile",a="",r=null;if(l&&e.nodeProps){let p=e.nodeProps;if(Z&&Z.length>0){let w=$=>$==null?"":String($).toLowerCase().trim(),x=0;for(let $ of Z){if(!$.fontSize||$.fontSize<=12)continue;let E=0;if(w(p.fontFamily)===w($.fontFamily)&&(E+=25),p.fontSize!=null&&$.fontSize){let W=Math.abs(p.fontSize-$.fontSize);W===0?E+=30:W<=2?E+=25:W<=4?E+=20:W<=8&&(E+=10)}w(p.fontWeight)===w($.fontWeight)&&(E+=20),w(p.lineHeight)===w($.lineHeight)&&(E+=15);let C=w(p.letterSpacing),N=w($.letterSpacing||"0"),F=W=>W===""||W==="0"||W==="0px"||W==="0%";(F(C)&&F(N)||C===N)&&(E+=10),E>x&&(x=E,r={name:$.name,percentage:E,styleId:$.styleId})}}if(!r&&e.bestMatch&&e.bestMatch.name&&(r={name:e.bestMatch.name,percentage:e.bestMatch.percentage||0}),r&&r.name){let w=r.percentage||0;a=`
          <div class="issue-grouped-suggestion">
            <span class="issue-grouped-suggestion-label">Suggestion</span>
            <div class="issue-grouped-suggestion-item">
              <span class="issue-grouped-suggestion-preview">Ag</span>
              <span class="issue-grouped-suggestion-name">${d(r.name)}</span>
              <span class="issue-grouped-suggestion-pct">(${w}%)</span>
              <button class="btn-suggest-fix-all" data-group-key="${d(e.key)}">${o>1?"Apply All":"Apply"}</button>
            </div>
          </div>
        `}}let g=e.issues.map((p,w)=>{let x=p.nodeName||`Node ${w+1}`;return`<div class="issue-grouped-node-item" data-node-id="${p.id}" title="${d(x)}">
        <span class="issue-grouped-node-name">${d(x)}</span>
      </div>`}).join("");t.innerHTML=`
      <div class="issue-grouped-header">
        ${n?`
          <div class="issue-grouped-props">
            <span class="issue-grouped-font">${i}</span>
            <span class="issue-grouped-size">${d(n)}</span>
          </div>
        `:""}
        <div class="issue-body" style="margin-top:4px;">${d(s)}</div>
      </div>
      <div class="issue-grouped-nodes">
        <button class="issue-grouped-nodes-toggle" type="button">
          <span class="issue-grouped-count">${o} layer${o!==1?"s":""}</span>
          <span class="issue-grouped-nodes-arrow">\u25B6</span>
        </button>
        <div class="issue-grouped-nodes-list" style="display: none;">
          ${g}
        </div>
      </div>
      ${a}
      <div class="issue-grouped-actions">
        <button class="btn-select-all" data-group-key="${d(e.key)}">${o>1?"Select All":"Select"}</button>
        ${l?`<button class="btn-style-dropdown-all" data-group-key="${d(e.key)}">Select Style</button>`:""}
        <button class="btn-remove-layer-all" data-group-key="${d(e.key)}">${o>1?"Remove All":"Remove"}</button>
      </div>
    `;let u=t.querySelector(".issue-grouped-nodes-toggle"),b=t.querySelector(".issue-grouped-nodes-list"),f=t.querySelector(".issue-grouped-nodes-arrow");u&&b&&(u.onclick=()=>{let p=b.style.display==="none";b.style.display=p?"block":"none",f&&(f.textContent=p?"\u25BC":"\u25B6")}),t.querySelectorAll(".issue-grouped-node-item").forEach(p=>{p.onclick=()=>{let w=p.getAttribute("data-node-id");w&&(parent.postMessage({pluginMessage:{type:"focus-node",id:w}},"*"),t.querySelectorAll(".issue-grouped-node-item").forEach(x=>x.classList.remove("active")),p.classList.add("active"))}});let y=t.querySelector(".btn-select-all");if(y&&(y.onclick=()=>{let p=e.issues.map(w=>w.id);parent.postMessage({pluginMessage:{type:"select-nodes",ids:p}},"*")}),l){let p=t.querySelector(".btn-suggest-fix-all");p&&(p.onclick=x=>{x.preventDefault(),x.stopPropagation(),fo(e)});let w=t.querySelector(".btn-style-dropdown-all");w&&(w.onclick=x=>{x.preventDefault(),x.stopPropagation(),parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:e.issues[0].id}},"*"),window.pendingTypographyCheckIssue=e.issues[0],window.pendingTypographyCheckGroup=e})}let m=t.querySelector(".btn-remove-layer-all");return m&&(m.onclick=p=>{p.preventDefault(),p.stopPropagation(),confirm(`Remove ${o} layer(s)?`)&&e.issues.forEach(w=>{parent.postMessage({pluginMessage:{type:"remove-layer",id:w.id}},"*")})}),t}function An(e){let t=document.createElement("div");t.className=`issue-grouped-card ${e.severity}`,t.setAttribute("data-group-key",e.key),t.setAttribute("data-issue-count",e.issues.length),t.setAttribute("data-severity",e.severity);let o=e.nodeProps||{},s=e.issues.length,n=[o.fontFamily||"",o.fontWeight||""].filter(Boolean).join(" "),i=[o.fontSize!=null?`${o.fontSize}`:"",o.lineHeight||""].filter(Boolean).join("/"),l=null;if(Z&&Z.length>0){let x=E=>E==null?"":String(E).toLowerCase().trim(),$=0;for(let E of Z){let C=0;if(x(o.fontFamily)===x(E.fontFamily)&&(C+=25),o.fontSize!=null&&E.fontSize){let T=Math.abs(o.fontSize-E.fontSize);T===0?C+=30:T<=2?C+=25:T<=4?C+=20:T<=8&&(C+=10)}x(o.fontWeight)===x(E.fontWeight)&&(C+=20),x(o.lineHeight)===x(E.lineHeight)&&(C+=15);let N=x(o.letterSpacing),F=x(E.letterSpacing||"0"),W=T=>T===""||T==="0"||T==="0px"||T==="0%";(W(N)&&W(F)||N===F)&&(C+=10),C>$&&($=C,l={name:E.name,percentage:C,styleId:E.styleId})}}!l&&e.bestMatch&&e.bestMatch.name&&(l={name:e.bestMatch.name,percentage:e.bestMatch.percentage||0});let a="";if(l&&l.name){let x=l.percentage||0;a=`
        <div class="issue-grouped-suggestion">
          <span class="issue-grouped-suggestion-label">Suggestion</span>
          <div class="issue-grouped-suggestion-item">
            <span class="issue-grouped-suggestion-preview">Ag</span>
            <span class="issue-grouped-suggestion-name">${d(l.name)}</span>
            <span class="issue-grouped-suggestion-pct">(${x}%)</span>
            <button class="btn-suggest-fix-all" data-group-key="${d(e.key)}">${s>1?"Apply All":"Apply"}</button>
          </div>
        </div>
      `}let r=e.issues.map((x,$)=>{let E=x.nodeName||x.textPreview||`Node ${$+1}`;return`<div class="issue-grouped-node-item" data-node-id="${x.id}" title="${d(E)}">
        <span class="issue-grouped-node-name">${d(E)}</span>
      </div>`}).join("");t.innerHTML=`
      <div class="issue-grouped-header">
        <div class="issue-grouped-props">
          <span class="issue-grouped-font">${d(n)}</span>
          ${i?`<span class="issue-grouped-size">${d(i)}</span>`:""}
        </div>
      </div>
      <div class="issue-grouped-nodes">
        <button class="issue-grouped-nodes-toggle" type="button">
          <span class="issue-grouped-count">${s} layer${s!==1?"s":""}</span>
          <span class="issue-grouped-nodes-arrow">\u25B6</span>
        </button>
        <div class="issue-grouped-nodes-list" style="display: none;">
          ${r}
        </div>
      </div>
      ${a}
      <div class="issue-grouped-actions">
        <button class="btn-select-all" data-group-key="${d(e.key)}">${s>1?"Select All":"Select"}</button>
        <button class="btn-style-dropdown-all" data-group-key="${d(e.key)}">Select Style</button>
        <button class="btn-create-style-all btn-suggest-fix" data-group-key="${d(e.key)}">Create Style</button>
        <button class="btn-remove-layer-all" data-group-key="${d(e.key)}">${s>1?"Remove All":"Remove"}</button>
      </div>
    `;let g=t.querySelector(".issue-grouped-nodes-toggle"),u=t.querySelector(".issue-grouped-nodes-list"),b=t.querySelector(".issue-grouped-nodes-arrow");g&&u&&(g.onclick=()=>{let x=u.style.display==="none";u.style.display=x?"block":"none",b&&(b.textContent=x?"\u25BC":"\u25B6")}),t.querySelectorAll(".issue-grouped-node-item").forEach(x=>{x.onclick=()=>{let $=x.getAttribute("data-node-id");$&&(parent.postMessage({pluginMessage:{type:"select-node",id:$}},"*"),t.querySelectorAll(".issue-grouped-node-item").forEach(E=>E.classList.remove("active")),x.classList.add("active"))}});let f=t.querySelector(".btn-select-all");f&&(f.onclick=()=>{let x=e.issues.map($=>$.id);parent.postMessage({pluginMessage:{type:"select-nodes",ids:x}},"*")});let y=t.querySelector(".btn-suggest-fix-all");y&&(y.onclick=x=>{x.preventDefault(),x.stopPropagation(),fo(e)});let m=t.querySelector(".btn-style-dropdown-all");m&&(m.onclick=x=>{x.preventDefault(),x.stopPropagation(),parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:e.issues[0].id}},"*"),window.pendingTypographyCheckIssue=e.issues[0],window.pendingTypographyCheckGroup=e});let p=t.querySelector(".btn-create-style-all");p&&(p.onclick=x=>{x.preventDefault(),x.stopPropagation(),typeof Ao=="function"&&Ao("typography-style",e.issues)});let w=t.querySelector(".btn-remove-layer-all");return w&&(w.onclick=x=>{x.preventDefault(),x.stopPropagation(),confirm(`Remove ${s} layer(s)?`)&&e.issues.forEach($=>{parent.postMessage({pluginMessage:{type:"remove-layer",id:$.id}},"*")})}),t}function fo(e){if(!e||!e.issues||e.issues.length===0)return;let t=e.issues[0];Kt(t,null,{batchGroup:e,onApply:null})}function Ln(e){let t=document.createElement("div");t.className=`issue-grouped-card ${e.severity}`,t.setAttribute("data-group-key",e.key),t.setAttribute("data-issue-count",e.issues.length),t.setAttribute("data-severity",e.severity);let o=e.issues.length,s=e.colorHex||"#000000",n=e.colorTarget||"fill",i=n==="stroke"?"Stroke":n==="effect"?"Effect":"Fill",l=e.matchingVariable,a=e.type==="color-variable",g=(e.issues[0]&&e.issues[0].message||"").replace(/ on "[^"]*"/g,"").replace(/ on '[^']*'/g,"").trim(),u=e.issues.map((F,W)=>{let T=F.nodeName||`Node ${W+1}`;return`<div class="issue-grouped-node-item" data-node-id="${F.id}" title="${d(T)}">
        <span class="issue-grouped-node-name">${d(T)}</span>
      </div>`}).join(""),b="";a&&l&&l.name&&(b=`
        <div class="issue-grouped-suggestion">
          <span class="issue-grouped-suggestion-label">Matching Variable</span>
          <div class="issue-grouped-suggestion-item">
            <span class="issue-grouped-color-swatch" style="background:${s};"></span>
            <span class="issue-grouped-suggestion-name">${d(l.name)}</span>
            <button class="btn-suggest-fix-all btn-bind-all" data-group-key="${d(e.key)}">${o>1?"Bind All":"Bind"}</button>
          </div>
        </div>
      `);let f=`<button class="btn-select-all" data-group-key="${d(e.key)}">${o>1?"Select All":"Select"}</button>`;f+=`<button class="btn-style-dropdown-all btn-select-variable-all" data-group-key="${d(e.key)}">Select Variable</button>`,f+=`<button class="btn-create-color-style btn-suggest-fix" data-group-key="${d(e.key)}" data-color-hex="${d(s)}">Create Style</button>`,f+=`<button class="btn-create-color-variable btn-suggest-fix" data-group-key="${d(e.key)}" data-color-hex="${d(s)}">Create Variable</button>`,f+=`<button class="btn-remove-layer-all" data-group-key="${d(e.key)}">${o>1?"Remove All":"Remove"}</button>`,t.innerHTML=`
      <div class="issue-grouped-header">
        <div class="issue-grouped-props">
          <span class="issue-grouped-color-swatch" style="background:${s};"></span>
          <span class="issue-grouped-font">${d(s)}</span>
          <span class="issue-grouped-size">${d(i)}</span>
        </div>
        ${g?`<div class="issue-body" style="margin-top:4px;">${d(g)}</div>`:""}
      </div>
      <div class="issue-grouped-nodes">
        <button class="issue-grouped-nodes-toggle" type="button">
          <span class="issue-grouped-count">${o} layer${o!==1?"s":""}</span>
          <span class="issue-grouped-nodes-arrow">\u25B6</span>
        </button>
        <div class="issue-grouped-nodes-list" style="display: none;">
          ${u}
        </div>
      </div>
      ${b}
      <div class="issue-grouped-actions">
        ${f}
      </div>
    `;let y=t.querySelector(".issue-grouped-nodes-toggle"),m=t.querySelector(".issue-grouped-nodes-list"),p=t.querySelector(".issue-grouped-nodes-arrow");y&&m&&(y.onclick=()=>{let F=m.style.display==="none";m.style.display=F?"block":"none",p&&(p.textContent=F?"\u25BC":"\u25B6")}),t.querySelectorAll(".issue-grouped-node-item").forEach(F=>{F.onclick=()=>{let W=F.getAttribute("data-node-id");W&&(parent.postMessage({pluginMessage:{type:"focus-node",id:W}},"*"),t.querySelectorAll(".issue-grouped-node-item").forEach(T=>T.classList.remove("active")),F.classList.add("active"))}});let w=t.querySelector(".btn-select-all");w&&(w.onclick=()=>{let F=e.issues.map(W=>W.id);parent.postMessage({pluginMessage:{type:"select-nodes",ids:F}},"*")});let x=t.querySelector(".btn-bind-all");x&&l&&l.id&&(x.onclick=F=>{if(F.preventDefault(),F.stopPropagation(),e.issues.some(S=>S.colorOpacity&&S.colorOpacity<1)&&!confirm("Some layers have opacity < 100%. Binding a variable will reset opacity. Continue?"))return;let T=e.issues.map(S=>({id:S.id,colorTarget:S.colorTarget,fillIndex:S.fillIndex,strokeIndex:S.strokeIndex}));ne(e.issues[0].id,`\u23F3 Binding "${l.name}" to ${o} layer(s)...`,!0),parent.postMessage({pluginMessage:{type:"bind-color-variable-batch",issues:T,variableId:l.id,variableName:l.name}},"*")});let $=t.querySelector(".btn-select-variable-all");$&&($.onclick=F=>{F.preventDefault(),F.stopPropagation(),No(e.issues[0],{batchGroup:e})});let E=t.querySelector(".btn-create-color-style");E&&(E.onclick=F=>{F.preventDefault(),F.stopPropagation();let W={nodeName:`${o} layer(s) with color ${s}`,message:`Create a Paint Style for color ${s}`};Ft(W,T=>{e.issues.forEach(S=>{ne(S.id,"\u23F3 Creating color style...",!0)}),parent.postMessage({pluginMessage:{type:"create-color-style",colorHex:s,colorTarget:n,styleName:T,issues:e.issues.map(S=>({id:S.id,colorTarget:S.colorTarget||n,fillIndex:S.fillIndex,strokeIndex:S.strokeIndex}))}},"*")})});let C=t.querySelector(".btn-create-color-variable");C&&(C.onclick=F=>{F.preventDefault(),F.stopPropagation();let W={nodeName:`${o} layer(s) with color ${s}`,message:`Create a Color Variable for ${s}`};Ft(W,T=>{e.issues.forEach(S=>{ne(S.id,"\u23F3 Creating color variable...",!0)}),parent.postMessage({pluginMessage:{type:"create-color-variable",colorHex:s,colorTarget:n,variableName:T,issues:e.issues.map(S=>({id:S.id,colorTarget:S.colorTarget||n,fillIndex:S.fillIndex,strokeIndex:S.strokeIndex}))}},"*")},{title:"Create Variable",placeholder:"Variable Name",btnText:"Create Variable"})});let N=t.querySelector(".btn-remove-layer-all");return N&&(N.onclick=F=>{F.preventDefault(),F.stopPropagation(),confirm(`Remove ${o} layer(s)?`)&&e.issues.forEach(W=>{parent.postMessage({pluginMessage:{type:"remove-layer",id:W.id}},"*")})}),t}function Hn(e){let t=xt(e);if(!t){alert("No suitable color match found");return}let s=(e.message||"").match(/Color (#[0-9A-Fa-f]{6})/),n=s?s[1].toUpperCase():null;jt(e,n,t,J)}function qn(e){let t=St(e);if(!t){alert("No suitable spacing match found");return}let o=e.message||"",s=o.match(/Padding\s+(\w+)\s+\((\d+)px\)/);if(!s){console.error("Cannot parse spacing issue message:",o),alert("Cannot determine spacing property from issue message. Message: "+o);return}let n=s[1],i=parseInt(s[2]);Ut(e,n,i,t)}function pt(e){return!e||e.type!=="autolayout"?null:{action:"enable-autolayout"}}function yo(e){if(!pt(e)){alert("Cannot suggest fix for this autolayout issue");return}Pn(e)}function Pn(e){let t=document.createElement("div");t.className="modal-overlay",t.id="autolayout-fix-confirm-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="450px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Auto Layout Enable</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Action:</div>
          <div style="padding: 12px; background: #e3f2fd; border-left: 3px solid #0071e3; border-radius: 6px;">
            <div style="font-size: 14px; color: #333; margin-bottom: 8px;">
              <strong>Enable Auto Layout</strong>
            </div>
            <div style="font-size: 12px; color: #666;">
              Auto Layout will be enabled on this frame. The layout direction (horizontal/vertical) will be automatically determined based on the children arrangement.
            </div>
          </div>
        </div>
        <div style="padding: 12px; background: #f0fdf4; border-radius: 6px; border-left: 3px solid #22c55e;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">\u{1F4DD} Note:</div>
          <div style="font-size: 12px; color: #333;">
            \u2022 Layout direction will be auto-detected (horizontal or vertical)<br>
            \u2022 Spacing and padding will be preserved if possible<br>
            \u2022 Frame structure will be maintained
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="autolayout-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="autolayout-fix-confirm-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let s=o.querySelector("#autolayout-fix-confirm-cancel-btn"),n=o.querySelector("#autolayout-fix-confirm-apply-btn"),i=o.querySelector(".modal-close"),l=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};s.onclick=l,i.onclick=l,t.onclick=a=>{a.target===t&&l()},n.onclick=()=>{l(),ne(e.id,"\u23F3 Enabling auto layout...",!0),parent.postMessage({pluginMessage:{type:"fix-autolayout-issue",issue:e}},"*")}}function Rn(e,t={}){let{onApply:o,onIgnore:s,onCancel:n,progress:i}=t,l=i?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${i.current}/${i.total}</div>`:"",a=document.createElement("div");a.className="modal-overlay",a.id="autolayout-fix-confirm-modal-overlay";let r=document.createElement("div");r.className="modal-dialog",r.style.maxWidth="450px",r.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Auto Layout Enable</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${l}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Action:</div>
          <div style="padding: 12px; background: #e3f2fd; border-left: 3px solid #0071e3; border-radius: 6px;">
            <div style="font-size: 14px; color: #333; margin-bottom: 8px;">
              <strong>Enable Auto Layout</strong>
            </div>
            <div style="font-size: 12px; color: #666;">
              Auto Layout will be enabled on this frame. The layout direction (horizontal/vertical) will be automatically determined based on the children arrangement.
            </div>
          </div>
        </div>
        <div style="padding: 12px; background: #f0fdf4; border-radius: 6px; border-left: 3px solid #22c55e;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">\u{1F4DD} Note:</div>
          <div style="font-size: 12px; color: #333;">
            \u2022 Layout direction will be auto-detected (horizontal or vertical)<br>
            \u2022 Spacing and padding will be preserved if possible<br>
            \u2022 Frame structure will be maintained
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="autolayout-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="autolayout-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="autolayout-fix-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply</button>
      </div>
    `,a.appendChild(r),document.body.appendChild(a);let g=r.querySelector("#autolayout-fix-cancel-btn"),u=r.querySelector("#autolayout-fix-apply-btn"),b=r.querySelector("#autolayout-fix-ignore-btn"),f=r.querySelector(".modal-close"),y=()=>{a.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{a.parentNode&&a.remove()},200)};g.onclick=()=>{y(),n&&n()},f.onclick=()=>{y(),n&&n()},a.onclick=m=>{m.target===a&&(y(),n&&n())},b.onclick=()=>{y(),s&&s()},u.onclick=()=>{y(),ne(e.id,"\u23F3 Enabling auto layout...",!0),parent.postMessage({pluginMessage:{type:"fix-autolayout-issue",issue:e}},"*"),o&&o()}}function Dn(e){return{action:"convert-group"}}function ho(e){if(!Dn(e)){alert("Cannot suggest fix for this group issue");return}Wn(e)}function Wn(e){let t=document.createElement("div");t.className="modal-overlay",t.id="group-fix-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="450px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Convert Group to Frame</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          This will convert the Group to a Frame and enable Auto-layout automatically.
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Group</div>
        </div>
        <div style="background: #f0fdf4; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame with Auto-layout</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="group-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="group-fix-apply-btn">Apply</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let s=o.querySelector("#group-fix-cancel-btn"),n=o.querySelector(".modal-close"),i=o.querySelector("#group-fix-apply-btn"),l=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};s.onclick=l,n.onclick=l,t.onclick=a=>{a.target===t&&l()},i.onclick=()=>{i.disabled=!0,i.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-group-issue",issue:e}},"*"),l()}}function Un(e,t={}){let{onApply:o,onIgnore:s,onCancel:n,progress:i}=t,l=i?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${i.current}/${i.total}</div>`:"",a=document.createElement("div");a.className="modal-overlay",a.id="group-fix-modal-overlay";let r=document.createElement("div");r.className="modal-dialog",r.style.maxWidth="450px",r.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Convert Group to Frame</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${l}
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          This will convert the Group to a Frame and enable Auto-layout automatically.
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Group</div>
        </div>
        <div style="background: #f0fdf4; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame with Auto-layout</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="group-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="group-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="group-fix-apply-btn">Apply</button>
      </div>
    `,a.appendChild(r),document.body.appendChild(a);let g=r.querySelector("#group-fix-cancel-btn"),u=r.querySelector("#group-fix-apply-btn"),b=r.querySelector("#group-fix-ignore-btn"),f=r.querySelector(".modal-close"),y=()=>{a.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{a.parentNode&&a.remove()},200)};g.onclick=()=>{y(),n&&n()},f.onclick=()=>{y(),n&&n()},a.onclick=m=>{m.target===a&&(y(),n&&n())},b.onclick=()=>{y(),s&&s()},u.onclick=()=>{u.disabled=!0,u.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-group-issue",issue:e}},"*"),y(),o&&o()}}function lt(e){return!e||e.type!=="position"?null:{action:"fix-position"}}function ut(e){return!e||e.type!=="duplicate"&&e.type!=="component"?null:{action:"suggest-component"}}function gt(e){return!e||e.type!=="empty-frame"?null:{action:"fix-empty-frame"}}function bo(e){if(!lt(e)){alert("Cannot suggest fix for this position issue");return}jn(e)}function vo(e){if(!gt(e)){alert("Cannot suggest fix for this empty frame issue");return}Vn(e)}function jn(e){let t=e.message||"",o=t.match(/x:(-?\d+)/),s=t.match(/y:(-?\d+)/),n=o?parseInt(o[1],10):0,i=s?parseInt(s[1],10):0,l=document.createElement("div");l.className="modal-overlay",l.id="position-fix-confirm-modal-overlay";let a=document.createElement("div");a.className="modal-dialog",a.style.maxWidth="400px",a.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Fix Position Issue</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            This layer has a negative position which may cause layout issues.
          </p>
          <div style="padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Position:</strong></div>
            <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>${n}px</code><br>
              \u2022 Y: <code>${i}px</code>
            </div>
          </div>
          <div style="padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-size: 12px; color: #1976d2; margin-bottom: 8px;"><strong>After Fix:</strong></div>
            <div style="font-size: 11px; color: #1976d2; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>0px</code><br>
              \u2022 Y: <code>0px</code>
            </div>
          </div>
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          This will set the position to (0, 0) to fix the negative offset.
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="position-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="position-fix-confirm-apply-btn">Apply</button>
      </div>
    `,l.appendChild(a),document.body.appendChild(l);let r=a.querySelector("#position-fix-confirm-cancel-btn"),g=a.querySelector("#position-fix-confirm-apply-btn"),u=a.querySelector(".modal-close"),b=()=>{l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove()},200)};r.onclick=b,u.onclick=b,l.onclick=f=>{f.target===l&&b()},g.onclick=()=>{b(),ne(e.id,"\u23F3 Fixing position...",!0),parent.postMessage({pluginMessage:{type:"fix-position-issue",issue:e}},"*")}}function On(e,t={}){let{onApply:o,onIgnore:s,onCancel:n,progress:i}=t,l=i?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${i.current}/${i.total}</div>`:"",a=e.message||"",r=a.match(/x:(-?\d+)/),g=a.match(/y:(-?\d+)/),u=r?parseInt(r[1],10):0,b=g?parseInt(g[1],10):0,f=document.createElement("div");f.className="modal-overlay",f.id="position-fix-confirm-modal-overlay";let y=document.createElement("div");y.className="modal-dialog",y.style.maxWidth="400px",y.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Fix Position Issue</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${l}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            This layer has a negative position which may cause layout issues.
          </p>
          <div style="padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Position:</strong></div>
            <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>${u}px</code><br>
              \u2022 Y: <code>${b}px</code>
            </div>
          </div>
          <div style="padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-size: 12px; color: #1976d2; margin-bottom: 8px;"><strong>After Fix:</strong></div>
            <div style="font-size: 11px; color: #1976d2; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>0px</code><br>
              \u2022 Y: <code>0px</code>
            </div>
          </div>
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          This will set the position to (0, 0) to fix the negative offset.
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="position-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="position-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="position-fix-apply-btn">Apply</button>
      </div>
    `,f.appendChild(y),document.body.appendChild(f);let m=y.querySelector("#position-fix-cancel-btn"),p=y.querySelector("#position-fix-apply-btn"),w=y.querySelector("#position-fix-ignore-btn"),x=y.querySelector(".modal-close"),$=()=>{f.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{f.parentNode&&f.remove()},200)};m.onclick=()=>{$(),n&&n()},x.onclick=()=>{$(),n&&n()},f.onclick=E=>{E.target===f&&($(),n&&n())},w.onclick=()=>{$(),s&&s()},p.onclick=()=>{$(),ne(e.id,"\u23F3 Fixing position...",!0),parent.postMessage({pluginMessage:{type:"fix-position-issue",issue:e}},"*"),o&&o()}}function Bs(e){xo(e)}function Bt(e){xo(e)}function xo(e){let t=document.createElement("div");t.className="modal-overlay",t.id="remove-layer-confirm-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="400px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Remove Layer</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            Are you sure you want to remove this layer?
          </p>
          <div style="padding: 12px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 6px;">
            <div style="font-size: 12px; color: #856404; margin-bottom: 4px;"><strong>\u26A0\uFE0F Warning:</strong></div>
            <div style="font-size: 11px; color: #856404; line-height: 1.6;">
              This action cannot be undone. The layer and all its children will be permanently deleted.
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="remove-layer-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-danger" id="remove-layer-confirm-apply-btn" style="background: #ef4444; border-color: #ef4444;color: white;">Remove</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let s=o.querySelector("#remove-layer-confirm-cancel-btn"),n=o.querySelector("#remove-layer-confirm-apply-btn"),i=o.querySelector(".modal-close"),l=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};s.onclick=l,i.onclick=l,t.onclick=a=>{a.target===t&&l()},n.onclick=()=>{l(),ne(e.id,"\u23F3 Removing layer...",!0),parent.postMessage({pluginMessage:{type:"remove-layer",issue:e}},"*")}}function Vn(e){let t=e.message||"",o=t.includes("Empty frame"),s=t.includes("redundant"),n=s?"Remove Redundant Frame":"Remove Empty Frame",i=s?"This will remove the redundant frame and keep its single child. The child will inherit the frame's name if it was unnamed.":"This will remove the empty frame. If it has a child, the child will be kept.",l=document.createElement("div");l.className="modal-overlay",l.id="empty-frame-fix-modal-overlay";let a=document.createElement("div");a.className="modal-dialog",a.style.maxWidth="450px",a.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">${n}</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          ${i}
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">${d(e.message)}</div>
        </div>
        <div style="background: #f0fdf4; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame removed, child kept (if applicable)</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="empty-frame-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="empty-frame-fix-apply-btn">Apply</button>
      </div>
    `,document.body.appendChild(l),l.appendChild(a);let r=a.querySelector("#empty-frame-fix-cancel-btn"),g=a.querySelector(".modal-close"),u=a.querySelector("#empty-frame-fix-apply-btn"),b=()=>{l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove()},200)};r.onclick=b,g.onclick=b,l.onclick=f=>{f.target===l&&b()},u.onclick=()=>{u.disabled=!0,u.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-empty-frame-issue",issue:e}},"*"),b()}}function Gn(e,t={}){let{onApply:o,onIgnore:s,onCancel:n,progress:i}=t,l=i?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${i.current}/${i.total}</div>`:"",a=e.message||"",r=a.includes("Empty frame"),g=a.includes("redundant"),u=g?"Remove Redundant Frame":"Remove Empty Frame",b=g?"This will remove the redundant frame and keep its single child. The child will inherit the frame's name if it was unnamed.":"This will remove the empty frame. If it has a child, the child will be kept.",f=document.createElement("div");f.className="modal-overlay",f.id="empty-frame-fix-modal-overlay";let y=document.createElement("div");y.className="modal-dialog",y.style.maxWidth="450px",y.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">${u}</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${l}
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          ${b}
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">${d(e.message)}</div>
        </div>
        <div style="background: #f0fdf4; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame removed, child kept (if applicable)</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="empty-frame-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="empty-frame-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="empty-frame-fix-apply-btn">Apply</button>
      </div>
    `,document.body.appendChild(f),f.appendChild(y);let m=y.querySelector("#empty-frame-fix-cancel-btn"),p=y.querySelector("#empty-frame-fix-apply-btn"),w=y.querySelector("#empty-frame-fix-ignore-btn"),x=y.querySelector(".modal-close"),$=()=>{f.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{f.parentNode&&f.remove()},200)};m.onclick=()=>{$(),n&&n()},x.onclick=()=>{$(),n&&n()},f.onclick=E=>{E.target===f&&($(),n&&n())},w.onclick=()=>{$(),s&&s()},p.onclick=()=>{p.disabled=!0,p.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-empty-frame-issue",issue:e}},"*"),$(),o&&o()}}function So(e){if(!e||!e.id){console.error("Invalid issue in handleSuggestFixComponent",e),alert("Error: Invalid issue data");return}window.pendingComponentIssue=e;let t=document.querySelector(`.issue[data-issue-id="${e.id}"]`);if(t){let o=t.querySelector("button.btn-suggest-fix");if(o){let s=o.textContent;o.disabled=!0,o.textContent="Loading...",o.style.opacity="0.6",o.style.cursor="wait",o.dataset.originalText=s}}parent.postMessage({pluginMessage:{type:"get-components-for-issue",issue:e}},"*")}function ko(e){if(!e||!e.id){console.error("Invalid issue in handleSelectComponent",e),alert("Error: Invalid issue data");return}window.pendingSelectComponentIssue=e;let t=document.querySelector(`.issue[data-issue-id="${e.id}"]`);if(t){let o=t.querySelector("button.btn-select-component");if(o){let s=o.textContent;o.disabled=!0,o.textContent="Loading...",o.style.opacity="0.6",o.dataset.originalText=s}}parent.postMessage({pluginMessage:{type:"get-all-components",issue:e}},"*")}function wo(e){Yn(e)}function Io(e){_n(e)}function _n(e){let t=document.createElement("div");t.className="modal-overlay",t.id="rename-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="400px";let s=e.nodeName||"",n=s.replace(/^(Frame|Group)\s*/i,"").trim()||"";o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Rename Node</h2>
        <p class="modal-subtitle">Current: ${d(s)}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <label style="display: block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #333;">New Name:</label>
          <input type="text" id="rename-input" placeholder="Enter meaningful name" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px;" value="${d(n)}" autocomplete="off">
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          Enter a meaningful name that describes the purpose of this layer (e.g., "Header", "Button", "Card").
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="rename-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="rename-apply-btn">Rename</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let i=o.querySelector("#rename-cancel-btn"),l=o.querySelector("#rename-apply-btn"),a=o.querySelector(".modal-close"),r=o.querySelector("#rename-input");setTimeout(()=>{r.focus(),r.select()},100);let g=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};i.onclick=g,a.onclick=g,t.onclick=u=>{u.target===t&&g()},r.addEventListener("keydown",u=>{u.key==="Enter"&&(u.preventDefault(),l.click())}),l.onclick=()=>{let u=r.value.trim();if(!u){alert("Please enter a name"),r.focus();return}if(/^(Frame|Group)\s*$/i.test(u)&&!confirm("The name still contains default naming (Frame/Group). Do you want to continue?")){r.focus();return}g(),ne(e.id,"\u23F3 Renaming...",!0),parent.postMessage({pluginMessage:{type:"rename-node",issue:e,newName:u}},"*")}}function Yn(e){let t=document.createElement("div");t.className="modal-overlay",t.id="create-component-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="400px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Create New Component</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <label style="display: block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #333;">Component Name:</label>
          <input type="text" id="create-component-name-input" placeholder="Enter component name" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px;" value="${d(e.nodeName||"")}">
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          This will convert the frame to a component and replace all duplicate frames with instances of this component.
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="create-component-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="create-component-apply-btn">Create</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let s=o.querySelector("#create-component-cancel-btn"),n=o.querySelector("#create-component-apply-btn"),i=o.querySelector(".modal-close"),l=o.querySelector("#create-component-name-input");setTimeout(()=>l.focus(),100);let a=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};s.onclick=a,i.onclick=a,t.onclick=r=>{r.target===t&&a()},n.onclick=()=>{let r=l.value.trim();if(!r){alert("Please enter a component name");return}a(),ne(e.id,"\u23F3 Creating component...",!0),parent.postMessage({pluginMessage:{type:"create-component-from-issue",issue:e,componentName:r}},"*")}}function Jn(e,t){if(!t||t.length===0){console.warn("[showComponentSuggestModal] No similar components provided"),alert("No similar components found.");return}let o=t[0];Co(e,o,"This is the most similar component found.")}function Xn(e,t){if(!t||t.length===0){console.warn("[showComponentSelectModal] No components provided"),alert("No components available.");return}let o=document.createElement("div");o.className="modal-overlay",o.id="component-select-modal-overlay";let s=document.createElement("div");s.className="modal-dialog",s.style.maxWidth="500px";let n=t.map(m=>`
        <div class="component-picker-item" data-component-id="${m.id}" data-component-name="${d(m.name.toLowerCase())}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 2px solid #ddd;
          border-radius: 8px;
          cursor: pointer;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='#ddd'; this.style.boxShadow='none'">
          <div style="font-weight: 600; font-size: 12px; color: #333;">${d(m.name)}</div>
          <div style="font-size: 11px; color: #666; margin-top: 4px;">
            ${m.description||"Component"}
          </div>
        </div>
      `).join(""),i=t.length>5,l=i?`
      <div style="margin-bottom: 16px;">
        <input type="text" id="component-search-input" placeholder="Search components by name..." style="
          width: 100%;
          padding: 8px 12px;
          border: 1px solid #ddd;
          border-radius: 6px;
          font-size: 13px;
          box-sizing: border-box;
        " autocomplete="off">
        <div id="component-search-results-count" style="font-size: 11px; color: #666; margin-top: 4px; display: none;"></div>
      </div>
    `:"";s.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Select Component</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        ${l}
        <div id="component-list-container" style="max-height: 400px; overflow-y: auto;">
          ${n}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="component-select-cancel-btn">Cancel</button>
      </div>
    `,o.appendChild(s),document.body.appendChild(o),o.style.display="flex",o.style.opacity="1",o.style.zIndex="10000";let a=s.querySelector("#component-select-cancel-btn"),r=s.querySelector(".modal-close"),g=s.querySelectorAll(".component-picker-item"),u=s.querySelector("#component-search-input"),b=s.querySelector("#component-list-container"),f=s.querySelector("#component-search-results-count");u&&i&&(u.addEventListener("input",m=>{let p=m.target.value.toLowerCase().trim(),w=0;g.forEach(x=>{let $=x.getAttribute("data-component-name")||"";p===""||$.includes(p)?(x.style.display="block",w++):x.style.display="none"}),f&&(p!==""?(f.textContent=`Showing ${w} of ${t.length} components`,f.style.display="block"):f.style.display="none")}),setTimeout(()=>u.focus(),100));let y=()=>{o.style.animation="fadeIn 0.2s ease-out reverse",o.style.opacity="0",setTimeout(()=>{o.parentNode&&o.remove()},200)};a?a.onclick=m=>{m.preventDefault(),m.stopPropagation(),y()}:console.error("[showComponentSelectModal] Cancel button not found!"),r?r.onclick=m=>{m.preventDefault(),m.stopPropagation(),y()}:console.error("[showComponentSelectModal] Close button not found!"),o.onclick=m=>{m.target===o&&y()},g.forEach((m,p)=>{m.onclick=w=>{w.preventDefault(),w.stopPropagation();let x=m.getAttribute("data-component-id"),$=t.find(E=>E.id===x);$?(y(),Co(e,$,null)):console.error("[showComponentSelectModal] Component not found for ID:",x)}}),setTimeout(()=>{o.style.animation="fadeIn 0.2s ease-out",o.style.opacity="1"},10)}function Co(e,t,o){let s=document.createElement("div");s.className="modal-overlay",s.id="component-apply-confirm-modal-overlay";let n=document.createElement("div");n.className="modal-dialog",n.style.maxWidth="400px",n.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Component</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            This will replace the frame with an instance of the selected component.
          </p>
          <div style="padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-size: 12px; color: #1976d2; margin-bottom: 8px;"><strong>Selected Component:</strong></div>
            <div style="font-size: 14px; color: #333; font-weight: 600;">${d(t.name)}</div>
            ${t.description?`<div style="font-size: 11px; color: #666; margin-top: 4px;">${d(t.description)}</div>`:""}
          </div>
          ${o?`<p style="color: #666; font-size: 12px; margin-top: 12px;">${d(o)}</p>`:""}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="component-apply-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="component-apply-apply-btn">Apply</button>
      </div>
    `,s.appendChild(n),document.body.appendChild(s);let i=n.querySelector("#component-apply-cancel-btn"),l=n.querySelector("#component-apply-apply-btn"),a=n.querySelector(".modal-close"),r=()=>{s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove()},200)};i.onclick=r,a.onclick=r,s.onclick=g=>{g.target===s&&r()},l.onclick=()=>{r(),ne(e.id,"\u23F3 Applying component...",!0),parent.postMessage({pluginMessage:{type:"apply-component-to-issue",issue:e,componentId:t.id}},"*")}}function at(e){if(!e||!e.fontSize)return null;let t=e.fontSize,o=14,s=document.getElementById("font-size-scale");if(s&&s.value.trim()){let n=s.value.split(",").map(i=>parseInt(i.trim(),10)).filter(i=>!isNaN(i)&&i>=o).sort((i,l)=>i-l);if(n.length>0){let i=null,l=1/0;n.forEach(r=>{if(r>=o){let g=Math.abs(r-t);g<l&&(l=g,i=r)}});let a=Math.max(t*.5,10);if(i&&l<=a)return i}}return t<o?o:null}function mt(e){if(!e||!e.textColor||!e.backgroundColor)return null;let t=e.textColor.toUpperCase(),o=e.backgroundColor.toUpperCase(),s=e.minContrast||4.5,n=document.getElementById("color-scale");if(!n||!n.value.trim())return null;let i=n.value.split(",").map(g=>g.trim().toUpperCase()).filter(g=>g&&g.startsWith("#"));if(i.length===0)return null;let l=null,a=0,r=1/0;return i.forEach(g=>{let u=Wt(g,o);if(u>=s){let b=Dt(t,g);(u>a||u===a&&b<r)&&(a=u,l=g,r=b)}}),l}function $o(e,t){if(!t||t.length===0){alert("No text styles found in Figma. Please create text styles first.");return}let o=document.createElement("div");o.className="modal-overlay",o.id="text-style-picker-typography-modal-overlay";let s=document.createElement("div");s.className="modal-dialog",s.style.maxWidth="500px";let n=e.nodeProps||{},i=n.fontFamily||"Unknown",l=n.fontSize!==null&&n.fontSize!==void 0?n.fontSize:null,a=l!==null?`${l}px`:"Unknown",r=n.fontWeight||"Unknown",g=n.lineHeight||"Unknown",u=n.letterSpacing!==null&&n.letterSpacing!==void 0?n.letterSpacing:"Unknown",b=null;e.bestMatch&&e.bestMatch.name&&(b=e.bestMatch.name);let f=T=>{if(T==null||T==="Unknown")return"";let S=String(T).toLowerCase().trim(),k=S.match(/^([+-]?\d*\.?\d+)(px|%)?$/);if(k){let A=parseFloat(k[1]);if(Math.abs(A)<1e-6)return"0";let O=k[2]||"px";return`${Math.round(A*100)/100}${O}`}return S},y=T=>{let S=`picker_${f(i)}_${l}_${f(r)}_${f(g)}_${f(u)}_${T.id}`;return ye(S,()=>{let k=0;if(f(i)===f(T.fontFamily)&&(k+=25),l!==null&&T.fontSize){let A=Math.abs(l-T.fontSize);A===0?k+=30:A<=2?k+=25:A<=4?k+=20:A<=8&&(k+=10)}return f(r)===f(T.fontWeight)&&(k+=20),f(g)===f(T.lineHeight)&&(k+=15),f(u)===f(T.letterSpacing||"0")&&(k+=10),k})},m=[...t].sort((T,S)=>y(S)-y(T));m.length>0&&(b=m[0].name);let p=(T,S)=>f(T)!==f(S),w=T=>{let S=b===T.name,k=y(T),A=p(i,T.fontFamily),O=p(a,`${T.fontSize}px`),oe=p(r,T.fontWeight),ke=p(g,T.lineHeight),be=p(u,T.letterSpacing||"0"),$e="color: #155724;",Ie="color: #721c24; background: #f8d7da; padding: 1px 4px; border-radius: 3px; font-weight: 600;";return`
        <div class="style-picker-item" data-style-id="${T.id}" data-style-name="${d(T.name)}" data-font-size="${T.fontSize}" data-similarity="${k}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 1px solid ${S?"#0071e3":"#ddd"};
          border-radius: 8px;
          cursor: pointer;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='${S?"#0071e3":"#ddd"}'; this.style.boxShadow='none'">
          <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
            <div>
              <div style="font-weight: 600; font-size: 12px; color: #333;">${d(T.name)} ${S?"\u2B50":""}</div>
              <div style="font-size: 11px; color: #666; margin-top: 4px;">
                ${d(T.fontFamily)} ${T.fontSize}px ${d(T.fontWeight)}
              </div>
            </div>
            <div style="text-align: right;">
              ${S?'<div style="color: #0071e3; font-weight: 600; font-size: 11px;">Best Match</div>':""}
              <div style="color: #666; font-size: 10px; margin-top: 2px;">${k}% match</div>
            </div>
          </div>
          <div style="font-size: 11px; color: #666; padding-top: 8px; border-top: 1px solid #eee;">
            <div style="margin-bottom: 4px;"><strong>Details:</strong></div>
            <div style="padding-left: 8px; line-height: 1.8;">
              \u2022 Font Family: <code style="${A?Ie:$e}">${A?"\u26A0 ":"\u2713 "}${d(T.fontFamily)}</code><br>
              \u2022 Font Size: <code style="${O?Ie:$e}">${O?"\u26A0 ":"\u2713 "}${T.fontSize}px</code><br>
              \u2022 Font Weight: <code style="${oe?Ie:$e}">${oe?"\u26A0 ":"\u2713 "}${d(T.fontWeight)}</code><br>
              \u2022 Line Height: <code style="${ke?Ie:$e}">${ke?"\u26A0 ":"\u2713 "}${d(T.lineHeight)}</code><br>
              \u2022 Letter Spacing: <code style="${be?Ie:$e}">${be?"\u26A0 ":"\u2713 "}${d(T.letterSpacing||"0")}</code>
            </div>
          </div>
        </div>
      `},x=m.map(T=>w(T)).join("");s.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Text Style</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Properties:</strong></div>
          <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
            \u2022 Font Family: <code>${d(i)}</code><br>
            \u2022 Font Size: <code>${d(a)}</code><br>
            \u2022 Font Weight: <code>${d(r)}</code><br>
            \u2022 Line Height: <code>${d(g)}</code><br>
            \u2022 Letter Spacing: <code>${d(u)}</code>
          </div>
        </div>
        <!-- Search Input -->
        <div style="margin-bottom: 12px;">
          <input type="text" id="style-search-input" placeholder="\u{1F50D} Search styles by name..." style="
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 13px;
            box-sizing: border-box;
            outline: none;
          " onfocus="this.style.borderColor='#0071e3'" onblur="this.style.borderColor='#ddd'" />
        </div>
        <div id="style-list-container" style="max-height: 280px; overflow-y: auto;">
          ${x}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="text-style-picker-typography-modal-cancel-btn">Cancel</button>
      </div>
    `,o.appendChild(s),document.body.appendChild(o);let $=s.querySelector("#text-style-picker-typography-modal-cancel-btn"),E=s.querySelector(".modal-close"),C=s.querySelector("#style-search-input"),N=s.querySelector("#style-list-container"),F=()=>{o.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{o.parentNode&&o.remove()},200)};$.onclick=F,E.onclick=F,o.onclick=T=>{T.target===o&&F()},C.oninput=T=>{let S=T.target.value.toLowerCase().trim(),k=m.filter(A=>A.name.toLowerCase().includes(S));N.innerHTML=k.map(A=>w(A)).join(""),W()};let W=()=>{s.querySelectorAll(".style-picker-item").forEach(S=>{S.onclick=k=>{k.preventDefault(),k.stopPropagation();let A=S.getAttribute("data-style-id"),O=t.find(oe=>oe.id===A);O&&(o.style.display="none",Zn(e,O,o))}})};W(),setTimeout(()=>{C.focus()},100)}function Zn(e,t,o){let s=document.createElement("div");s.className="modal-overlay",s.id="typography-style-confirm-modal-overlay";let n=document.createElement("div");n.className="modal-dialog",n.style.maxWidth="500px";let i=e.nodeProps||{},l=i.fontFamily||"Unknown",a=i.fontSize!==null&&i.fontSize!==void 0?`${i.fontSize}px`:"Unknown",r=i.fontWeight||"Unknown",g=i.lineHeight||"Unknown",u=i.letterSpacing!==null&&i.letterSpacing!==void 0?i.letterSpacing:"Unknown";n.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Text Style Application</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Apply Text Style:</div>
          <div style="padding: 12px; background: #e3f2fd; border-left: 3px solid #0071e3; border-radius: 6px;">
            <div style="font-weight: 600; font-size: 16px; color: #333; margin-bottom: 8px;">${d(t.name)}</div>
            <div style="font-size: 12px; color: #666; line-height: 1.6;">
              \u2022 Font Family: <code>${d(t.fontFamily)}</code><br>
              \u2022 Font Size: <code>${t.fontSize}px</code><br>
              \u2022 Font Weight: <code>${d(t.fontWeight)}</code><br>
              \u2022 Line Height: <code>${d(t.lineHeight)}</code><br>
              \u2022 Letter Spacing: <code>${d(t.letterSpacing||"0")}</code>
            </div>
          </div>
        </div>
        <div style="padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Properties:</strong></div>
          <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
            \u2022 Font Family: <code>${d(l)}</code><br>
            \u2022 Font Size: <code>${d(a)}</code><br>
            \u2022 Font Weight: <code>${d(r)}</code><br>
            \u2022 Line Height: <code>${d(g)}</code><br>
            \u2022 Letter Spacing: <code>${d(u)}</code>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="typography-style-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="typography-style-confirm-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply</button>
      </div>
    `,s.appendChild(n),document.body.appendChild(s);let b=n.querySelector("#typography-style-confirm-cancel-btn"),f=n.querySelector("#typography-style-confirm-apply-btn"),y=n.querySelector(".modal-close"),m=()=>{s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove(),o&&o.parentNode&&(o.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{o.parentNode&&o.remove()},200))},200)},p=()=>{s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove(),o&&(o.style.display="flex")},200)};b.onclick=p,y.onclick=p,s.onclick=w=>{w.target===s&&p()},f.onclick=()=>{m();let w=window.pendingTypographyCheckGroup;w&&w.issues&&w.issues.length>1?(w.issues.forEach(x=>{ne(x.id,"\u23F3 Applying style...",!0),Qt(x,t)}),window.pendingTypographyCheckGroup=null):(ne(e.id,"\u23F3 Applying style...",!0),Qt(e,t))}}function Kn(e,t){let o=t.filter(u=>u.fontSize>=14);if(o.length===0){let u=at(e);u?Nt(e,e.fontSize||12,u,null,null):alert("No text styles found with fontSize >= 14px. Please add font sizes to Font Size input or create text styles in Figma.");return}let s=document.createElement("div");s.className="modal-overlay",s.id="text-style-picker-modal-overlay";let n=document.createElement("div");n.className="modal-dialog",n.style.maxWidth="400px";let i=o.map(u=>`
        <div class="style-picker-item" data-style-id="${u.id}" data-font-size="${u.fontSize}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 2px solid #ddd;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='#ddd'; this.style.boxShadow='none'">
          <div>
            <div style="font-weight: 600; font-size: 12px; color: #333;">${d(u.name)}</div>
            <div style="font-size: 10px; color: #666; margin-top: 4px;">
              ${d(u.fontFamily)} ${d(u.fontSize)}px ${d(u.fontWeight)}
            </div>
          </div>
          <div style="color: #22c55e; font-weight: 600; font-size: 12px;">\u2713 ADA</div>
        </div>
      `).join("");n.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Text Style</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")} - Select style with fontSize >= 14px</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Font Size:</div>
          <div style="font-size: 16px; font-weight: 600; color: #333;">${e.fontSize||12}px</div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${i}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="text-style-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,s.appendChild(n),document.body.appendChild(s);let l=n.querySelector("#text-style-picker-modal-cancel-btn"),a=n.querySelector(".modal-close"),r=n.querySelectorAll(".style-picker-item"),g=()=>{s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove()},200)};l.onclick=g,a.onclick=g,s.onclick=u=>{u.target===s&&g()},r.forEach(u=>{u.onclick=b=>{b.preventDefault(),b.stopPropagation();let f=u.getAttribute("data-style-id"),y=parseInt(u.getAttribute("data-font-size")),m=o.find(p=>p.id===f);m&&(s.style.display="none",Nt(e,e.fontSize||12,y,s,m))}})}function Qn(e,t){let o=document.getElementById("color-scale"),s=o&&o.value.trim()?o.value.split(",").map(p=>p.trim().toUpperCase()).filter(p=>p&&p.startsWith("#")):[],n=[];if(t.filter(p=>p.source==="variable").forEach(p=>{n.push({source:"Variable",name:p.name,hex:p.hex,id:p.id,variable:p.variable})}),t.filter(p=>p.source==="style").forEach(p=>{n.push({source:"Style",name:p.name,hex:p.hex,id:p.id,style:p.style})}),s.forEach(p=>{let w=J[p]||p;n.push({source:"Input",name:w,hex:p,id:null})}),n.length===0){alert("No colors available. Please add colors to Color input or create color styles/variables in Figma.");return}let i=e.backgroundColor||"#FFFFFF",l=e.minContrast||4.5,a=e.textColor||"#000000",r=document.createElement("div");r.className="modal-overlay",r.id="contrast-color-picker-modal-overlay";let g=document.createElement("div");g.className="modal-dialog",g.style.maxWidth="400px";let u=n.map(p=>{let w=Wt(p.hex,i),x=w>=l,$=x?"#22c55e":"#ddd",E=`${d(p.name)} <span style="font-size: 11px; color: #666;">(${d(p.source)})</span>`,C=`<span style="color: ${x?"#22c55e":"#ef4444"};">Contrast: ${w.toFixed(2)}:1 ${x?"\u2713":"\u2717"} (need >= ${l}:1)</span>`;return po(p.hex,E,$,C)}).join("");g.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Color</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")} - Select color that passes contrast</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Text Color:</div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 32px; height: 32px; border-radius: 4px; background: ${d(a)}; border: 1px solid #ddd;"></div>
            <div style="font-family: 'SF Mono', Monaco, monospace; font-size: 11px; font-weight: 600;">${d(a)}</div>
            <div style="font-size: 11px; color: #ef4444;">Contrast: ${e.contrast?e.contrast.toFixed(2):"N/A"}:1 (fails)</div>
          </div>
          <div style="font-size: 11px; color: #666; margin-top: 4px;">Background: ${d(i)}</div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${u}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="contrast-color-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,r.appendChild(g),document.body.appendChild(r);let b=g.querySelector("#contrast-color-picker-modal-cancel-btn"),f=g.querySelector(".modal-close"),y=g.querySelectorAll(".color-picker-item"),m=()=>{r.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{r.parentNode&&r.remove()},200)};b.onclick=m,f.onclick=m,r.onclick=p=>{p.target===r&&m()},y.forEach(p=>{p.onclick=w=>{w.preventDefault(),w.stopPropagation();let x=p.getAttribute("data-color");r.style.display="none",To(e,a,x,r)}})}function Eo(e){parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:e.id}},"*"),window.pendingTextSizeIssue=e}function Xt(e){parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:e.id}},"*"),window.pendingSuggestTextSizeIssue=e}function Nt(e,t,o,s,n){let i=(k,A)=>{if(k===A)return 100;let O=20,oe=Math.abs(k-A);return Math.max(0,Math.round((1-oe/O)*100))},a=[14,16,18,20,24,28,32,36,40,48].map(k=>({size:k,similarity:i(t,k),diff:Math.abs(t-k)})).sort((k,A)=>o!==void 0&&k.size===o?-1:o!==void 0&&A.size===o?1:k.diff-A.diff).slice(0,5),r=a.length>0?a[0].size:o,g=(k,A)=>{let O=k.size>=14;return`
        <div class="text-size-option-item" data-size="${k.size}" style="
          padding: 6px 8px;
          margin-bottom: 6px;
          border: 1px solid ${A?"#0071e3":"#e0e0e0"};
          border-radius: 8px;
          cursor: pointer;
          background: ${A?"#e3f2fd":"white"};
          display: flex;
          align-items: center;
          gap: 12px;
          transition: all 0.15s;
        ">
          <input type="radio" name="text-size-option" ${A?"checked":""} style="margin: 0; cursor: pointer; display: none;" />
          <div style="
            width: 40px;
            height: 40px;
            border-radius: 6px;
            background: ${A?"#e3f2fd":"#f0f0f0"};
            border: 1px solid ${A?"#0071e3":"#ddd"};
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 600;
            color: ${A?"#0071e3":"#666"};
            flex-shrink: 0;
          ">${k.size}</div>
          <div style="flex: 1;">
            <div style="font-weight: 600; font-size: 11px; color: #333;">${k.size}px</div>
            <div style="font-size: 10px; color: ${O?"#155724":"#721c24"};">
              ${O?"\u2713 ADA compliant":"\u26A0 Below minimum"}
            </div>
          </div>
          <span style="font-size: 11px; color: #666; background: #f0f0f0; padding: 2px 8px; border-radius: 10px;">${k.similarity}%</span>
        </div>
      `},u=document.createElement("div");u.className="modal-overlay",u.id="text-size-fix-confirm-modal-overlay";let b=document.createElement("div");b.className="modal-dialog",b.style.maxWidth="420px";let f=window.pendingTextSizeFixAllCallbacks||null,y=f&&f.progress?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${f.progress.current}/${f.progress.total}</div>`:"",m=n?`
      <div style="margin-top: 12px; padding: 10px; background: #f0fdf4; border-radius: 6px; border-left: 3px solid #22c55e;">
        <div style="font-size: 11px; color: #666; margin-bottom: 4px;">\u{1F4DD} Text Style s\u1EBD \u0111\u01B0\u1EE3c \xE1p d\u1EE5ng:</div>
        <div style="font-weight: 600; font-size: 13px; color: #333;">${d(n.name)}</div>
        <div style="font-size: 10px; color: #666; margin-top: 4px;">
          ${d(n.fontFamily)} ${n.fontSize}px ${d(n.fontWeight)}
        </div>
      </div>
    `:"",p=a.map((k,A)=>g(k,A===0)).join("");b.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Text Size</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${y}
      <div class="modal-body">
        <div style="margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 6px; display: flex; align-items: center; gap: 10px;">
          <div style="
            width: 40px;
            height: 40px;
            border-radius: 4px;
            background: #f0f0f0;
            border: 1px solid #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
            color: #666;
          ">${t}</div>
          <div>
            <div style="font-size: 11px; color: #666;">Current Size:</div>
            <div style="font-size: 14px; font-weight: 600;">${t}px <span style="font-size: 11px; color: #ef4444;">(Too small)</span></div>
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px;">
          Select a size to apply (Top 5 closest):
        </div>
        <div id="text-size-options-container" style="max-height: 280px; overflow-y: auto;">
          ${p}
        </div>
        ${m}
      </div>
      <div class="modal-footer">
        ${window.pendingTextSizeFixAllCallbacks?'<button class="modal-btn modal-btn-cancel" id="text-size-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="text-size-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="text-size-fix-confirm-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply</button>
      </div>
    `,u.appendChild(b),document.body.appendChild(u);let w=b.querySelector("#text-size-fix-confirm-cancel-btn"),x=b.querySelector("#text-size-fix-confirm-apply-btn"),$=b.querySelector("#text-size-fix-ignore-btn"),E=b.querySelector(".modal-close"),C=b.querySelector("#text-size-options-container"),N=f,F=k=>{r=k,C.querySelectorAll(".text-size-option-item").forEach(O=>{let ke=parseInt(O.getAttribute("data-size"),10)===k;O.style.border=ke?"2px solid #0071e3":"2px solid #e0e0e0",O.style.background=ke?"#e3f2fd":"white";let be=O.querySelector('input[type="radio"]');be&&(be.checked=ke)})};(()=>{C.querySelectorAll(".text-size-option-item").forEach(A=>{A.onclick=O=>{O.preventDefault();let oe=parseInt(A.getAttribute("data-size"),10);F(oe)}})})();let T=()=>{u.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{u.parentNode&&u.remove(),s&&(s.style.display="block")},200)},S=()=>{u.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{u.parentNode&&u.remove(),s&&s.parentNode&&(s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove()},200))},200)};w.onclick=()=>{N&&N.onCancel?(S(),window.pendingTextSizeFixAllCallbacks=null,N.onCancel()):T()},E.onclick=()=>{N&&N.onCancel?(S(),window.pendingTextSizeFixAllCallbacks=null,N.onCancel()):T()},u.onclick=k=>{k.target===u&&(N&&N.onCancel?(S(),window.pendingTextSizeFixAllCallbacks=null,N.onCancel()):T())},$&&($.onclick=()=>{S(),N&&N.onIgnore&&(window.pendingTextSizeFixAllCallbacks=null,N.onIgnore())}),x.onclick=()=>{S(),ne(e.id,"\u23F3 Fixing text size...",!0),n&&n.id?parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:e,styleId:n.id,styleName:n.name}},"*"):parent.postMessage({pluginMessage:{type:"fix-text-size-issue",issue:e,fontSize:r}},"*"),N&&N.onApply&&(window.pendingTextSizeFixAllCallbacks=null,N.onApply())}}function Mo(e){parent.postMessage({pluginMessage:{type:"get-contrast-colors",issue:e}},"*"),window.pendingContrastIssue=e}function Zt(e){let t=mt(e);if(!t){alert("No suitable color found that passes contrast requirements");return}To(e,e.textColor,t,null)}function To(e,t,o,s){let n=e.backgroundColor||"#FFFFFF",i=e.minContrast||4.5,l=(k,A)=>{let O=k.replace("#",""),oe=A.replace("#",""),ke=parseInt(O.substr(0,2),16),be=parseInt(O.substr(2,2),16),$e=parseInt(O.substr(4,2),16),Ie=parseInt(oe.substr(0,2),16),Ee=parseInt(oe.substr(2,2),16),H=parseInt(oe.substr(4,2),16);return Math.sqrt(Math.pow(ke-Ie,2)+Math.pow(be-Ee,2)+Math.pow($e-H,2))},a=(k,A)=>{let oe=l(k,A);return Math.round((1-oe/441.67)*100)},g=Object.keys(J).map(k=>{let A=Wt(k,n);return{color:k,name:J[k]||k,contrast:A,passes:A>=i,similarity:a(t,k),distance:l(t,k)}}).filter(k=>k.passes).sort((k,A)=>o&&k.color===o?-1:o&&A.color===o?1:k.distance-A.distance).slice(0,5),u=g.length>0?g[0].color:o,b=(k,A)=>`
        <div class="contrast-color-option-item" data-color="${d(k.color)}" style="
          padding: 10px 12px;
          margin-bottom: 6px;
          border: 1px solid ${A?"#0071e3":"#e0e0e0"};
          border-radius: 8px;
          cursor: pointer;
          background: ${A?"#e3f2fd":"white"};
          display: flex;
          align-items: center;
          gap: 12px;
          transition: all 0.15s;
        ">
          <input type="radio" name="contrast-color-option" ${A?"checked":""} style="margin: 0; cursor: pointer;" />
          <div style="
            width: 36px;
            height: 36px;
            border-radius: 6px;
            background: ${d(k.color)};
            border: 1px solid ${A?"#0071e3":"#ddd"};
            flex-shrink: 0;
          "></div>
          <div style="flex: 1;">
            <div style="font-weight: 600; font-size: 13px; color: #333;">${d(k.name)}</div>
            <div style="font-size: 10px; color: #666; font-family: 'SF Mono', Monaco, monospace;">${d(k.color)}</div>
            <div style="font-size: 10px; color: #22c55e; margin-top: 2px;">\u2713 ${k.contrast.toFixed(2)}:1</div>
          </div>
          <span style="font-size: 11px; color: #666; background: #f0f0f0; padding: 2px 8px; border-radius: 10px;">${k.similarity}%</span>
        </div>
      `,f=window.pendingContrastFixAllCallbacks||null,y=f&&f.progress?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${f.progress.current}/${f.progress.total}</div>`:"",m=document.createElement("div");m.className="modal-overlay",m.id="contrast-fix-confirm-modal-overlay";let p=document.createElement("div");p.className="modal-dialog",p.style.maxWidth="420px";let w=g.length>0?g.map((k,A)=>b(k,A===0)).join(""):`<div style="padding: 20px; text-align: center; color: #666;">No colors available that pass contrast requirements (>= ${i}:1)</div>`;p.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Contrast Color</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${y}
      <div class="modal-body">
        <div style="margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 6px;">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
            <div style="
              width: 32px;
              height: 32px;
              border-radius: 4px;
              background: ${d(t)};
              border: 1px solid #ddd;
            "></div>
            <div>
              <div style="font-size: 11px; color: #666;">Current:</div>
              <div style="font-size: 12px; font-weight: 600; font-family: 'SF Mono', Monaco, monospace;">${d(t)}</div>
              <div style="font-size: 10px; color: #ef4444;">Contrast: ${e.contrast?e.contrast.toFixed(2):"N/A"}:1 \u2717</div>
            </div>
          </div>
          <div style="font-size: 10px; color: #666; padding: 4px 8px; background: #e0e0e0; border-radius: 4px; display: inline-block;">
            Background: ${d(n)} | Minimum: ${i}:1
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px;">
          Select a color to apply (Top 5 passing contrast):
        </div>
        <div id="contrast-color-options-container" style="max-height: 280px; overflow-y: auto;">
          ${w}
        </div>
      </div>
      <div class="modal-footer">
        ${window.pendingContrastFixAllCallbacks?'<button class="modal-btn modal-btn-cancel" id="contrast-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="contrast-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="contrast-fix-confirm-apply-btn" style="background: #22c55e; border-color: #22c55e;" ${g.length===0?"disabled":""}>Apply</button>
      </div>
    `,m.appendChild(p),document.body.appendChild(m);let x=p.querySelector("#contrast-fix-confirm-cancel-btn"),$=p.querySelector("#contrast-fix-confirm-apply-btn"),E=p.querySelector("#contrast-fix-ignore-btn"),C=p.querySelector(".modal-close"),N=p.querySelector("#contrast-color-options-container"),F=f,W=k=>{u=k,N.querySelectorAll(".contrast-color-option-item").forEach(O=>{let ke=O.getAttribute("data-color")===k;O.style.border=ke?"2px solid #0071e3":"2px solid #e0e0e0",O.style.background=ke?"#e3f2fd":"white";let be=O.querySelector('input[type="radio"]');be&&(be.checked=ke)})};(()=>{N.querySelectorAll(".contrast-color-option-item").forEach(A=>{A.onclick=O=>{O.preventDefault();let oe=A.getAttribute("data-color");W(oe)}})})();let S=()=>{m.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{m.parentNode&&m.remove(),s&&(s.style.display="block")},200)};x.onclick=()=>{F&&F.onCancel?(S(),window.pendingContrastFixAllCallbacks=null,F.onCancel()):S()},C.onclick=()=>{F&&F.onCancel?(S(),window.pendingContrastFixAllCallbacks=null,F.onCancel()):S()},m.onclick=k=>{k.target===m&&(F&&F.onCancel?(S(),window.pendingContrastFixAllCallbacks=null,F.onCancel()):S())},E&&(E.onclick=()=>{S(),F&&F.onIgnore&&(window.pendingContrastFixAllCallbacks=null,F.onIgnore())}),$.onclick=()=>{g.length!==0&&(S(),ne(e.id,"\u23F3 Fixing contrast...",!0),parent.postMessage({pluginMessage:{type:"fix-contrast-issue",issue:e,color:u}},"*"),F&&F.onApply&&(window.pendingContrastFixAllCallbacks=null,F.onApply()))}}function zo(e){try{if(me[e.id]===!0){if(delete me[e.id],h&&h.issues){let o=h.issues.find(s=>s.id===e.id);if(o){o.ignored=!1;let s=o.originalSeverity||(o.severity==="info"?"error":o.severity);o.severity=s,o.originalSeverity=void 0,e.severity=s,e.ignored=!1}}ve(),Bo(e,!1),Ze(),parent.postMessage({pluginMessage:{type:"notify",message:"\u2705 Issue un-ignored"}},"*")}else{if(!confirm(`Ignore this contrast issue?

Node: ${e.nodeName||"Unnamed"}

This issue will be marked as "Pass with ignore custom" and won't be counted as an error.`))return;if(h&&h.issues){let o=h.issues.find(s=>s.id===e.id);o&&(o.originalSeverity||(o.originalSeverity=o.severity),o.ignored=!0,o.severity="info",e.ignored=!0,e.originalSeverity=o.originalSeverity,e.severity="info")}me[e.id]=!0,ve(),Bo(e,!0),Ze(),parent.postMessage({pluginMessage:{type:"notify",message:"\u2705 Issue ignored"}},"*")}}catch(t){console.error("Error in handleIgnoreIssue:",t),parent.postMessage({pluginMessage:{type:"notify",message:`\u274C Error: ${t.message}`}},"*")}}function Bo(e,t){let o=document.querySelector(`.issue[data-issue-id="${e.id}"]`);if(o)if(t){let s=e.originalSeverity||"error";o.className=o.className.replace(/\b(error|warn)\b/g,"info");let n=o.querySelector(".issue-type");if(n){let l=n.querySelector(".issue-number");if(l){let a=l.textContent;n.innerHTML=`<span class="issue-number">${a}</span> \u2139\uFE0F INFO`}else n.innerHTML=n.innerHTML.replace(/❌|⚠️/g,"\u2139\uFE0F").replace(/ERROR|WARNING/g,"INFO")}if(!o.querySelector(".issue-ignored-tag")){let l=o.querySelector(".issue-body"),a=o.querySelector(".issue-node"),r=document.createElement("div");if(r.className="issue-ignored-tag",r.style.cssText="margin-top: 4px; padding: 4px 8px; background: #e3f2fd; color: #22c55e; border-radius: 4px; font-size: 11px; font-weight: 600; display: inline-block;",r.textContent="\u2713 Pass with ignore custom",a)a.parentNode.insertBefore(r,a.nextSibling);else if(l)l.parentNode.insertBefore(r,l.nextSibling);else{let g=o.querySelector(".issue-header");g?g.parentNode.insertBefore(r,g.nextSibling):o.appendChild(r)}}let i=document.querySelector(`button.btn-ignore[data-id="${e.id}"]`);i&&(i.removeAttribute("disabled"),i.innerHTML="Ignored",i.style.cssText="padding: 6px 12px; border: 1px solid #22c55e; background: #22c55e; border-radius: 6px; font-size: 12px; font-weight: 500; cursor: pointer; transition: all 0.2s; color: white;")}else{let s=e.originalSeverity||(e.severity==="info"?"error":e.severity);o.className=o.className.replace(/\binfo\b/g,s);let n=o.querySelector(".issue-type");if(n){let a=s==="error"?"\u274C":s==="warn"?"\u26A0\uFE0F":"\u2139\uFE0F",r=s.toUpperCase(),g=n.querySelector(".issue-number");if(g){let u=g.textContent;n.innerHTML=`<span class="issue-number">${u}</span> ${a} ${r}`}else n.innerHTML=n.innerHTML.replace(/ℹ️/g,a).replace(/INFO/g,r)}let i=o.querySelector(".issue-ignored-tag");i&&i.remove();let l=document.querySelector(`button.btn-ignore[data-id="${e.id}"]`);l&&(l.removeAttribute("disabled"),l.innerHTML="Ignore",l.style.cssText="padding: 6px 12px; border: 1px solid #64748b; background: #64748b; border-radius: 6px; font-size: 12px; font-weight: 500; cursor: pointer; transition: all 0.2s; color: white;")}}function Ze(){if(!h||!h.issues)return;let e=h.issues,t={error:e.filter(o=>o.severity==="error"&&!o.ignored).length,warn:e.filter(o=>o.severity==="warn"&&!o.ignored).length,total:e.length};Ht(e),document.querySelectorAll(".issue-group").forEach(o=>{let s=o.querySelector(".badge");if(s){let n=o.getAttribute("data-issue-type");if(n){let l=e.filter(a=>a.type===n).filter(a=>a.ignored?!1:a.severity==="error"||a.severity==="warn").length;s.textContent=l}}})}function es(e){let t=e.message||"",o=t.match(/Padding\s+(\w+)\s+\((\d+)px\)/),s=null,n=null;if(o?(s=o[1],n=parseInt(o[2])):(o=t.match(/Gap\s+\(itemSpacing:\s+(\d+)px\)/),o&&(s="itemSpacing",n=parseInt(o[1]))),!o||!s||n===null){console.error("Cannot parse spacing issue message:",t),alert("Cannot determine spacing property from issue message. Message: "+t);return}let i=document.getElementById("spacing-scale");if(!i||!i.value.trim()){alert("No spacing scale defined. Please add spacing values to the Spacing input.");return}let l=i.value.split(",").map(a=>parseInt(a.trim(),10)).filter(a=>!isNaN(a)&&a>=0).sort((a,r)=>a-r);if(l.length===0){alert("No valid spacing values found in Spacing input.");return}xn(e,s,n,l)}function ts(e){let o=(e.message||"").match(/Color (#[0-9A-Fa-f]{6})/),s=o?o[1].toUpperCase():null;if(!s){alert("Cannot determine current color from issue message");return}let n=document.getElementById("color-scale");if(!n||!n.value.trim()){alert("No color scale defined. Please add colors to the Color input.");return}let i=n.value.split(",").map(l=>l.trim().toUpperCase()).filter(l=>l&&l.startsWith("#"));if(i.length===0){alert("No valid colors found in Color input.");return}Sn(e,s,i,J)}function os(e){var t;if(e.type==="typography-check"&&e.bestMatch){vn(e,Z);return}if(ne(e.id,"\u23F3 Fixing...",!0),!e.bestMatch&&e.type!=="typography-check"){let o=prompt(`Cannot auto-fix this issue.

Issue: ${e.message}

Please provide fix instructions or press Cancel.`);if(o)parent.postMessage({pluginMessage:{type:"fix-issue",issue:e,manualFix:o}},"*");else{let s=document.querySelector(`.issue[data-issue-id="${e.id}"]`)||((t=document.querySelector(`button.btn-fix[data-id="${e.id}"]`))==null?void 0:t.closest(".issue"));if(s){let n=s.querySelector(".fix-message");n&&n.remove()}}return}parent.postMessage({pluginMessage:{type:"fix-issue",issue:e}},"*")}function Ft(e,t,o){let s=o&&o.title||"Create Style",n=o&&o.placeholder||"Style Name",i=o&&o.btnText||"Create",l=document.createElement("div");l.className="modal-overlay",l.id="create-style-modal-overlay";let a=document.createElement("div");a.className="modal-dialog";let r=e.nodeName||"Unnamed";if(e.message&&e.message.includes("(")&&e.message.includes("nodes")){let m=e.message.match(/\((\d+) nodes\)/);m&&(r=`${r} (${m[1]} nodes)`)}a.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">${d(s)}</h2>
        <p class="modal-subtitle">${d(r)}</p>
      </div>
      <div class="modal-body">
        <input
          type="text"
          class="modal-input"
          id="style-name-input"
          placeholder="${d(n)}"
          value="${d(e.nodeName||"New Style")}"
          autofocus
        />
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="modal-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="modal-create-btn">${d(i)}</button>
      </div>
    `,l.appendChild(a),document.body.appendChild(l);let g=a.querySelector("#style-name-input"),u=a.querySelector("#modal-cancel-btn"),b=a.querySelector("#modal-create-btn"),f=a.querySelector(".modal-close");setTimeout(()=>{g.focus(),g.select()},100),g.onkeydown=m=>{m.key==="Enter"?(m.preventDefault(),b.click()):m.key==="Escape"&&(m.preventDefault(),u.click())};let y=()=>{l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove()},200)};u.onclick=y,f.onclick=y,l.onclick=m=>{m.target===l&&y()},b.onclick=()=>{let m=g.value.trim();if(!m){g.focus(),g.style.borderColor="#ff3b30",setTimeout(()=>{g.style.borderColor="#0071e3"},2e3);return}y(),t&&t(m)}}function Kt(e,t,o={}){if(!e){console.error("[showSuggestApplyModal] Missing issue:",{issue:e,styleName:t});return}let{onApply:s,onIgnore:n,onCancel:i,showIgnore:l=!1,progress:a}=o,r=e.nodeProps||{},g=r.fontFamily||"Unknown",u=r.fontSize!==null&&r.fontSize!==void 0?r.fontSize:null,b=u!==null?`${u}px`:"Unknown",f=r.fontWeight||"Unknown",y=r.lineHeight||"Unknown",m=r.letterSpacing!==null&&r.letterSpacing!==void 0?r.letterSpacing:"Unknown",p=H=>H==null||H==="Unknown"?"":String(H).toLowerCase().trim(),w=H=>{let ae=p(H);return ae===""||ae==="0"||ae==="0px"||ae==="0%"||ae==="0em"},x=(H,ae)=>p(H)!==p(ae),$=H=>{let ae=`typo_${p(g)}_${u}_${p(f)}_${p(y)}_${p(m)}_${H.id}`;return ye(ae,()=>{let K=0;if(p(g)===p(H.fontFamily)&&(K+=25),u!==null&&H.fontSize){let c=Math.abs(u-H.fontSize);c===0?K+=30:c<=2?K+=25:c<=4?K+=20:c<=8&&(K+=10)}return p(f)===p(H.fontWeight)&&(K+=20),p(y)===p(H.lineHeight)&&(K+=15),(w(m)&&w(H.letterSpacing||"0")||p(m)===p(H.letterSpacing||"0"))&&(K+=10),K})},C=[...e.type==="text-size-mobile"?Z.filter(H=>H.fontSize>12):Z].map(H=>Je(De({},H),{similarity:$(H)})).sort((H,ae)=>t&&H.name===t?-1:t&&ae.name===t?1:ae.similarity-H.similarity).slice(0,5);if(C.length===0){console.error("[showSuggestApplyModal] No typography styles available"),alert("No typography styles available");return}let N=C[0].id,F=(H,ae,K)=>{let c=x(g,H.fontFamily),ue=x(b,`${H.fontSize}px`),se=x(f,H.fontWeight),Ce=x(y,H.lineHeight),Q=w(m)&&w(H.letterSpacing||"0")?!1:x(m,H.letterSpacing||"0%"),Be="color: #155724;",Ye="color: #721c24; background: #f8d7da; padding: 2px 6px; border-radius: 4px; font-weight: 600;",Fe=K===0;return`
        <div class="style-option-item" data-style-id="${H.id}" style="
          padding: 14px 16px;
          margin-bottom: 10px;
          border: 1px solid ${ae?"#0071e3":"#e0e0e0"};
          border-radius: 10px;
          cursor: pointer;
          background: ${ae?"#f8fbff":"white"};
          transition: all 0.15s;
          border-left: 4px solid ${ae?"#0071e3":"#e0e0e0"};
        ">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
            <div style="display: flex; align-items: center; gap: 10px; flex: 1;">
              <input type="radio" name="style-option" ${ae?"checked":""} style="margin: 0; cursor: pointer; width: 18px; height: 18px; display: none;" />
              <div>
                <div style="display: flex; align-items: center; gap: 8px;">
                  <span style="font-weight: 600; font-size: 12px; color: #333;">${d(H.name)}</span>
                  ${Fe?'<span style="color: #f5a623;">\u2B50</span>':""}
                </div>
                <div style="font-size: 12px; color: #666; margin-top: 2px;">
                  ${d(H.fontFamily)} ${H.fontSize}px ${d(H.fontWeight)}
                </div>
              </div>
            </div>
            <div style="text-align: right;">
              ${Fe?'<div style="color: #0071e3; font-size: 11px; font-weight: 600;">Best Match</div>':""}
              <div style="font-size: 12px; color: #666; background: #f0f0f0; padding: 3px 10px; border-radius: 12px; margin-top: 2px;">${H.similarity}% match</div>
            </div>
          </div>
          <div style="margin-left: 28px; padding: 0 12px; background: #f8f9fa; border-radius: 6px;">
            <div style="font-size: 11px; font-weight: 600; color: #333; margin-bottom: 8px;">Details:</div>
            <div style="font-size: 11px; color: #555; line-height: 1.2;">
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span style="color: #888; min-width: 90px;">\u2022 Font Family:</span>
                <span style="${c?Ye:Be}">${c?"\u26A0":"\u2713"} ${d(H.fontFamily)}</span>
              </div>
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span style="color: #888; min-width: 90px;">\u2022 Font Size:</span>
                <span style="${ue?Ye:Be}">${ue?"\u26A0":"\u2713"} ${H.fontSize}px</span>
              </div>
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span style="color: #888; min-width: 90px;">\u2022 Font Weight:</span>
                <span style="${se?Ye:Be}">${se?"\u26A0":"\u2713"} ${d(H.fontWeight)}</span>
              </div>
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span style="color: #888; min-width: 90px;">\u2022 Line Height:</span>
                <span style="${Ce?Ye:Be}">${Ce?"\u26A0":"\u2713"} ${d(H.lineHeight)}</span>
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #888; min-width: 90px;">\u2022 Letter Spacing:</span>
                <span style="${Q?Ye:Be}">${Q?"\u26A0":"\u2713"} ${d(H.letterSpacing||"0%")}</span>
              </div>
            </div>
          </div>
        </div>
      `},W=document.createElement("div");W.className="modal-overlay",W.id="suggest-apply-modal-overlay";let T=document.createElement("div");T.className="modal-dialog",T.style.maxWidth="480px";let S=a?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${a.current}/${a.total}</div>`:"",k=C.map((H,ae)=>F(H,ae===0,ae)).join("");T.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Style</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${S}
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #fff8e6; border-radius: 8px; border-left: 4px solid #f5a623;">
          <div style="font-size: 11px; font-weight: 600; color: #666; margin-bottom: 6px;">Current Node Properties:</div>
          <div style="font-size: 12px; color: #333; line-height: 1.6;">
            <div><strong>Font:</strong> ${d(g)} \u2022 ${d(b)} \u2022 ${d(f)}</div>
            <div><strong>Line Height:</strong> ${d(y)} \u2022 <strong>Letter Spacing:</strong> ${d(m)}</div>
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 10px;">
          Select a style to apply (Top 5 matches):
        </div>
        <div id="style-options-container" style="max-height: 400px; overflow-y: auto;">
          ${k}
        </div>
      </div>
      <div class="modal-footer">
        ${l?'<button class="modal-btn modal-btn-cancel" id="suggest-modal-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="suggest-modal-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="suggest-modal-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply Style</button>
      </div>
    `,W.appendChild(T),document.body.appendChild(W);let A=T.querySelector("#suggest-modal-cancel-btn"),O=T.querySelector("#suggest-modal-apply-btn"),oe=T.querySelector("#suggest-modal-ignore-btn"),ke=T.querySelector(".modal-close"),be=T.querySelector("#style-options-container"),$e=H=>{N=H,be.querySelectorAll(".style-option-item").forEach(K=>{let ue=K.getAttribute("data-style-id")===String(H);K.style.border=ue?"2px solid #0071e3":"2px solid #e0e0e0",K.style.borderLeft=ue?"4px solid #0071e3":"4px solid #e0e0e0",K.style.background=ue?"#f8fbff":"white";let se=K.querySelector('input[type="radio"]');se&&(se.checked=ue)})};(()=>{be.querySelectorAll(".style-option-item").forEach(ae=>{ae.onclick=K=>{K.preventDefault();let c=ae.getAttribute("data-style-id");$e(c)}})})();let Ee=()=>{W.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{W.parentNode&&W.remove()},200)};A.onclick=()=>{Ee(),l&&o.onCancel&&typeof o.onCancel=="function"&&o.onCancel()},ke.onclick=()=>{Ee(),l&&o.onCancel&&typeof o.onCancel=="function"&&o.onCancel()},W.onclick=H=>{H.target===W&&(Ee(),l&&o.onCancel&&typeof o.onCancel=="function"&&o.onCancel())},O.onclick=()=>{let H=C.find(K=>String(K.id)===String(N));if(!H){console.error("[showSuggestApplyModal] Selected style not found:",N);return}Ee();let ae=o.batchGroup;if(ae&&ae.issues&&ae.issues.length>1&&H.styleId){let K=ae.issues.map(c=>c.id);ne(K[0],`\u23F3 Applying "${H.name}" to ${K.length} layers...`,!0),parent.postMessage({pluginMessage:{type:"apply-figma-text-style-batch",issueIds:K,styleId:H.styleId,styleName:H.name}},"*")}else ne(e.id,"\u23F3 Applying style...",!0),H.styleId?parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:e,styleId:H.styleId,styleName:H.name}},"*"):parent.postMessage({pluginMessage:{type:"apply-typography-style",issue:e,style:H}},"*");s&&typeof s=="function"&&s()},oe&&(oe.onclick=()=>{Ee(),n&&typeof n=="function"&&n()})}function No(e,t){let o=t&&t.batchGroup,s=o?o.issues.length:1;parent.postMessage({pluginMessage:{type:"extract-color-variables"}},"*");function n(i){let l=i.data&&i.data.pluginMessage;if(!l||l.type!=="color-variables-extracted")return;window.removeEventListener("message",n);let a=l.colors||[];if(a.length===0){alert("No color variables found in this file.");return}let r=(e.colorHex||"").toUpperCase(),g=[...a].sort((w,x)=>{let $=w.hex.toUpperCase()===r?0:1,E=x.hex.toUpperCase()===r?0:1;return $!==E?$-E:w.name.localeCompare(x.name)}),u=document.createElement("div");u.className="modal-overlay",u.style.cssText="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.4);z-index:9999;display:flex;align-items:center;justify-content:center;";let b=document.createElement("div");b.style.cssText="background:#fff;border-radius:12px;padding:20px;max-width:400px;width:90%;max-height:70vh;display:flex;flex-direction:column;";let f=document.createElement("h3");f.style.cssText="margin:0 0 4px 0;font-size:16px;",f.textContent="Select Variable";let y=document.createElement("div");y.style.cssText="font-size:12px;color:#666;margin-bottom:12px;",y.textContent=o?`Color: ${r} \u2014 ${s} layer(s)`:`Color: ${r} on "${e.nodeName}"`;let m=document.createElement("div");m.style.cssText="overflow-y:auto;flex:1;",g.forEach(w=>{let x=w.hex.toUpperCase()===r,$=document.createElement("div");$.style.cssText=`display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;cursor:pointer;border:2px solid ${x?"#22c55e":"transparent"};margin-bottom:4px;background:${x?"#f0fdf4":"#fafafa"};`,$.innerHTML=`
          <div style="width:28px;height:28px;border-radius:6px;background:${w.hex};border:1px solid #ddd;flex-shrink:0;"></div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${w.name}</div>
            <div style="font-size:11px;color:#888;">${w.hex}${x?" \u2014 exact match":""}</div>
          </div>
        `,$.onclick=()=>{if(u.remove(),o&&o.issues.length>0){let E=o.issues.map(C=>({id:C.id,colorTarget:C.colorTarget,fillIndex:C.fillIndex,strokeIndex:C.strokeIndex}));ne(o.issues[0].id,`\u23F3 Binding "${w.name}" to ${s} layer(s)...`,!0),parent.postMessage({pluginMessage:{type:"bind-color-variable-by-name-batch",issues:E,variableName:w.name,variableHex:w.hex}},"*")}else ne(e.id,"\u23F3 Binding variable...",!0),parent.postMessage({pluginMessage:{type:"bind-color-variable-by-name",issue:e,variableName:w.name,variableHex:w.hex}},"*")},m.appendChild($)});let p=document.createElement("button");p.textContent="Cancel",p.style.cssText="margin-top:12px;padding:8px 16px;border:1px solid #ddd;border-radius:8px;background:#fff;cursor:pointer;font-size:13px;",p.onclick=()=>u.remove(),b.appendChild(f),b.appendChild(y),b.appendChild(m),b.appendChild(p),u.appendChild(b),u.onclick=w=>{w.target===u&&u.remove()},document.body.appendChild(u)}window.addEventListener("message",n)}function ot(e){if(!e||!e.nodeProps)return null;for(let t of Z)if(In(e.nodeProps,t)===100)return t;return null}function ns(e){let t=[];(e||[]).forEach(C=>{C.type!=="typography-check"&&C.type!=="typography-style"||(C.subIssues&&C.subIssues.length>0?C.subIssues.forEach(N=>{let F=Object.assign({},C,{id:N.id,nodeName:N.nodeName,nodeProps:N.nodeProps||C.nodeProps,subIssues:void 0});F.nodeProps&&ot(F)!==null&&t.push(F)}):C.nodeProps&&ot(C)!==null&&t.push(C))});let o=t;if(o.length===0){alert("No typography issues with 100% match found.");return}let s=0,n=0,i=0,l=!1,a=document.getElementById("btn-fix-all-100");a&&(a.disabled=!0,a.textContent="Fixing...");let r=document.querySelector('.btn-fix-all[data-type="typography-style"]');r&&(r.disabled=!0,r.textContent="Fixing...");let g=o.length,u=document.getElementById("fix-all-progress");u&&u.remove();let b=document.createElement("div");b.id="fix-all-progress",b.className="fix-all-progress",b.innerHTML=`
      <div class="fix-all-progress-info">
        <span class="fix-all-progress-text">Fixing Text Style... 0/${g}</span>
        <button class="fix-all-progress-cancel" title="Cancel">\u2715</button>
      </div>
      <div class="fix-all-progress-bar"><div class="fix-all-progress-fill" style="width: 0%"></div></div>
    `;let f=document.getElementById("results-issues");f&&f.parentNode.insertBefore(b,f);let y=b.querySelector(".fix-all-progress-text"),m=b.querySelector(".fix-all-progress-fill"),p=b.querySelector(".fix-all-progress-cancel");p.onclick=()=>{l=!0,x()};function w(){let C=Math.round(s/g*100);y&&(y.textContent=`Fixing Text Style... ${s}/${g}`),m&&(m.style.width=C+"%")}function x(){if(b&&b.parentNode&&b.remove(),a&&(a.disabled=!1,a.textContent="Fix all now"),r){r.disabled=!1;let C=o.length-n;C>0?r.textContent=`Fix all now (${C})`:r.style.display="none"}alert(`${l?"Cancelled!":"\u2705 Done!"}

Processed ${s} / ${o.length} item(s):
\u2022 Applied: ${n}
\u2022 Failed: ${i}`)}function $(C){let N=C.data&&C.data.pluginMessage;!N||N.type!=="apply-typography-style-result"||(s++,N.success?n++:i++,w(),l||s>=o.length?(window.removeEventListener("message",$),setTimeout(x,500)):setTimeout(()=>E(o[s]),300))}function E(C){if(l){window.removeEventListener("message",$),setTimeout(x,500);return}let N=ot(C);if(!N){s++,i++,w(),l||s>=o.length?(window.removeEventListener("message",$),setTimeout(x,500)):setTimeout(()=>E(o[s]),300);return}ne(C.id,"\u23F3 Applying style...",!0),N.styleId?parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:C,styleId:N.styleId,styleName:N.name}},"*"):parent.postMessage({pluginMessage:{type:"apply-typography-style",issue:C,style:N}},"*")}window.addEventListener("message",$),E(o[0])}window._batchFixInProgress=!1;function ss(e){window._batchFixInProgress=!0;let t=["typography-check","typography-style"],o=(e||[]).filter(k=>t.includes(k.type)&&k.nodeProps&&ot(k)!==null),s=[];o.forEach(function(k){k.subIssues&&k.subIssues.length>1?k.subIssues.forEach(function(A){A.nodeProps&&ot(Object.assign({},k,A))!==null&&s.push(Object.assign({},k,A))}):s.push(k)});let n=(e||[]).some(k=>k.type==="color-variable"&&k.matchingVariable&&(!k.colorOpacity||k.colorOpacity>=1));if(s.length===0&&!n){alert("No auto-fixable issues found.");return}let i=document.getElementById("btn-fix-all-100");i&&(i.disabled=!0,i.textContent="Fixing...");let l=0,a=0,r=0,g=0,u=!1,b=s.length+(n?1:0),f=0,y=document.getElementById("fix-all-progress");y&&y.remove();let m=document.createElement("div");m.id="fix-all-progress",m.className="fix-all-progress",m.innerHTML=`
      <div class="fix-all-progress-info">
        <span class="fix-all-progress-text">Fixing... 0/${b}</span>
        <button class="fix-all-progress-cancel" title="Cancel">\u2715</button>
      </div>
      <div class="fix-all-progress-bar"><div class="fix-all-progress-fill" style="width: 0%"></div></div>
    `;let p=document.getElementById("results-issues");p&&p.parentNode.insertBefore(m,p);let w=m.querySelector(".fix-all-progress-text"),x=m.querySelector(".fix-all-progress-fill"),$=m.querySelector(".fix-all-progress-cancel");$.onclick=()=>{u=!0,C()};function E(k){f++;let A=Math.round(f/b*100);w&&(w.textContent=k+" "+f+"/"+b),x&&(x.style.width=A+"%")}function C(){window._batchFixInProgress=!1,i&&(i.disabled=!1,i.textContent="Fix all now"),m&&m.parentNode&&m.remove(),r>0&&h&&h.issues&&(h.issues=h.issues.filter(O=>O.type!=="color-variable"||!O.matchingVariable)),setTimeout(function(){Ze(),h&&h.issues&&He(h.issues,!1)},300);let k=r+l,A=g+a;alert((u?`Cancelled!

`:`Done!

`)+"Color variables: "+r+" applied, "+g+` failed
Typography: `+l+" applied, "+a+` failed

Total: `+(k+A)+" processed")}function N(){i&&(i.textContent="Fixing colors...");function k(A){let O=A.data&&A.data.pluginMessage;!O||O.type!=="batch-bind-color-variables-result"||(window.removeEventListener("message",k),r=O.applied||0,g=O.failed||0,E("Colors done."),s.length>0&&!u?setTimeout(function(){W()},300):C())}window.addEventListener("message",k),parent.postMessage({pluginMessage:{type:"batch-bind-color-variables",skipOpacity:!0}},"*")}let F=0;function W(){i&&(i.textContent="Fixing Text Style..."),window.addEventListener("message",T),S(s[0])}function T(k){let A=k.data&&k.data.pluginMessage;!A||A.type!=="apply-typography-style-result"||(F++,A.success?l++:a++,E("Fixing Text Style"),u||F>=s.length?(window.removeEventListener("message",T),C()):setTimeout(function(){S(s[F])},300))}function S(k){let A=ot(k);if(!A){F++,a++,E("Fixing Text Style"),u||F>=s.length?(window.removeEventListener("message",T),C()):setTimeout(function(){S(s[F])},300);return}ne(k.id,"\u23F3 Applying style...",!0),A.styleId?parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:k,styleId:A.styleId,styleName:A.name}},"*"):parent.postMessage({pluginMessage:{type:"apply-typography-style",issue:k,style:A}},"*")}n?N():s.length>0&&W()}function is(e,t){if(!t||t.length===0){alert("No issues to process");return}window._batchFixInProgress=!0;let o=0,s=0,n=0,i=!1,l=document.getElementById("fix-all-progress");l&&l.remove();let a=document.createElement("div");a.id="fix-all-progress",a.className="fix-all-progress",a.innerHTML=`
      <div class="fix-all-progress-info">
        <span class="fix-all-progress-text">Fixing... 0/${t.length}</span>
        <button class="fix-all-progress-cancel" title="Cancel">\u2715</button>
      </div>
      <div class="fix-all-progress-bar"><div class="fix-all-progress-fill" style="width: 0%"></div></div>
    `;let r=document.getElementById("results-issues");r&&r.parentNode.insertBefore(a,r);let g=a.querySelector(".fix-all-progress-text"),u=a.querySelector(".fix-all-progress-fill"),b=a.querySelector(".fix-all-progress-cancel");b.onclick=()=>{i=!0};function f(){let p=Math.round(o/t.length*100);g&&(g.textContent="Fixing... "+o+"/"+t.length),u&&(u.style.width=p+"%")}function y(){window._batchFixInProgress=!1,a&&a.parentNode&&a.remove(),Ze(),h&&h.issues&&He(h.issues,!1);let w=(i?`Cancelled!

`:`Done!

`)+`Processed ${o} item(s):
\u2022 Applied: ${s}
\u2022 Ignored: ${n}`;alert(w)}function m(){if(i||o>=t.length){y();return}let p=t[o];o++,f(),parent.postMessage({pluginMessage:{type:"select-node",id:p.id}},"*");let w={current:o,total:t.length};if(p.type==="typography-check"||p.type==="typography-style"){let x=p.bestMatch&&p.bestMatch.name&&typeof p.bestMatch.name=="string"&&p.bestMatch.name.trim().length>0?p.bestMatch.name:null;if(!x){n++,m();return}Kt(p,x,{showIgnore:!0,progress:w,onApply:()=>{s++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{i=!0,y()}})}else if(p.type==="color"){let x=xt(p),E=(p.message||"").match(/Color (#[0-9A-Fa-f]{6})/),C=E?E[1].toUpperCase():null;ls(p,C,x,{progress:w,onApply:()=>{s++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{i=!0,y()}})}else if(p.type==="spacing"){let x=St(p),E=(p.message||"").match(/Padding\s+(\w+)\s+\((\d+)px\)/);if(E){let C=E[1],N=parseInt(E[2]);as(p,C,N,x,{progress:w,onApply:()=>{s++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{i=!0,y()}})}else n++,m()}else if(p.type==="autolayout")Rn(p,{progress:w,onApply:()=>{s++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{i=!0,y()}});else if(p.type==="position")On(p,{progress:w,onApply:()=>{s++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{i=!0,y()}});else if(p.type==="group")Un(p,{progress:w,onApply:()=>{s++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{i=!0,y()}});else if(p.type==="empty-frame")Gn(p,{progress:w,onApply:()=>{s++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{i=!0,y()}});else if(p.type==="text-size-mobile")window.pendingTextSizeFixAllCallbacks={progress:w,onApply:()=>{s++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{i=!0,y()}},Xt(p);else if(p.type==="contrast")window.pendingContrastFixAllCallbacks={progress:w,onApply:()=>{s++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{i=!0,y()}},Zt(p);else if(p.type==="color-variable")if(p.matchingVariable&&p.matchingVariable.id){let x=function($){let E=$.data&&$.data.pluginMessage;!E||E.type!=="bind-color-variable-result"||E.issueId===p.id&&(window.removeEventListener("message",x),E.success?s++:n++,setTimeout(()=>{m()},300))};ne(p.id,"\u23F3 Binding variable...",!0),window.addEventListener("message",x),parent.postMessage({pluginMessage:{type:"bind-color-variable",issue:p,variableId:p.matchingVariable.id}},"*")}else n++,m();else n++,m()}m()}function ls(e,t,o,s={}){let n=Object.keys(J);jt(e,t,o,J,n,Je(De({},s),{showIgnore:!0}))}function as(e,t,o,s,n={}){let i=document.getElementById("spacing-scale"),l=[0,4,8,12,16,24,32,40,48,64,72,80,88,96];if(i&&i.value.trim()){let a=i.value.split(",").map(r=>parseInt(r.trim(),10)).filter(r=>!isNaN(r));a.length>0&&(l=a)}Ut(e,t,o,s,l,Je(De({},n),{showIgnore:!0}))}function Qt(e,t){if(!e||!t){console.error("handleApplyFigmaTextStyle: missing issue or style");return}ne(e.id,"\u23F3 Applying style...",!0),parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:e,styleId:t.id,styleName:t.name}},"*")}function eo(e,t){if(!e||!t){console.error("handleApplyTypographyStyle: missing issue or styleName");return}Kt(e,t)}function Fo(e){if(!e){console.error("handleCreateTextStyle: issue is null/undefined");return}Ft(e,t=>{ne(e.id,"\u23F3 Creating style...",!0),parent.postMessage({pluginMessage:{type:"create-text-style",issue:e,styleName:t}},"*")})}function Ao(e,t){if(e==="typography-style"){let n={nodeName:`${t.length} text node(s)`,message:`Found ${t.length} text node(s) without text style`};Ft(n,i=>{t.forEach(l=>{ne(l.id,"\u23F3 Creating style...",!0)}),parent.postMessage({pluginMessage:{type:"create-text-style-all",issues:t,styleName:i}},"*")});return}let o=t.filter(n=>n.bestMatch&&n.type==="typography-check"),s=t.filter(n=>!n.bestMatch||n.type!=="typography-check");if(o.length===0){alert(`No auto-fixable issues found in ${zt(e)}.

All ${t.length} issues require manual intervention.`);return}s.length>0&&!confirm(`Found ${o.length} auto-fixable issues and ${s.length} issues that require manual fix.

Do you want to auto-fix the ${o.length} issues now?

The ${s.length} issues will need to be fixed manually.`)||parent.postMessage({pluginMessage:{type:"fix-all-issues",issues:o,issueType:e}},"*")}function rs(e){let t=e;if(st!=="all"&&(t=t.filter(o=>o.severity===st)),We.trim()){let o=We.toLowerCase();t=t.filter(s=>{let n=(s.message||"").toLowerCase(),i=(s.nodeName||"").toLowerCase(),l=(s.type||"").toLowerCase();return n.includes(o)||i.includes(o)||l.includes(o)})}return t}function He(e=[],t=!1,o={}){let{skipSave:s=!1,restoreTimestamp:n=null,skipTabSwitch:i=!1}=o;i||Ue("issues"),document.getElementById("issues-count").textContent=e.length,e&&Array.isArray(e)&&e.forEach(S=>{me[S.id]===!0&&(S.ignored=!0,S.originalSeverity||(S.originalSeverity=S.severity),S.severity="info")});let l=h.issues!==e;h.issues=e;let a=n||new Date().toISOString();h.timestamp=a,Tt=!1,(t||l)&&(st="all",dt="all",Oe&&(Oe.value=""),We="",qe&&(qe.style.display="none"),Pe&&Pe.length>0&&Pe.forEach(S=>{S.classList.remove("active"),S.getAttribute("data-filter")==="all"&&S.classList.add("active")}));let r=document.getElementById("filter-controls"),g=document.getElementById("color-type-filter"),u=document.getElementById("filter-buttons");r&&(r.style.display=e.length>0?"flex":"none"),g&&(g.style.display="none"),u&&(u.style.display="flex");let b=document.getElementById("export-group");b.style.display=e.length>0?"flex":"none";let f=rs(e),y=new Set;if(l||document.querySelectorAll(".issue-group").forEach(k=>{let A=k.getAttribute("data-issue-type");A&&!k.classList.contains("collapsed")&&y.add(A)}),wt("issues"),f.length===0&&e.length===0){ce.innerHTML=`
              <div class="empty-state success">
                <div class="icon">\u2705</div>
                <p><strong>No issues found!</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Your design passed all configured checks.</p>
              </div>
            `;return}if(f.length===0&&e.length>0&&st!=="all"){ce.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F50D}</div>
                <p><strong>No results found</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Try changing the filter or search keyword.</p>
              </div>
            `;return}let m={error:f.filter(S=>S.severity==="error"&&!S.ignored).length,warn:f.filter(S=>S.severity==="warn"&&!S.ignored).length,total:f.length,originalTotal:e.length},p=0,w=0;f.forEach(function(S){S.ignored||((S.type==="typography-check"||S.type==="typography-style")&&S.nodeProps&&ot(S)!==null&&p++,S.type==="color-variable"&&S.matchingVariable&&(!S.colorOpacity||S.colorOpacity>=1)&&w++)});let x=p+w,$=document.createElement("div");$.className="results-header";let E=x>0;$.innerHTML=`<h3>Check Result</h3><button class="btn-fix-all" id="btn-fix-all-100"${E?"":' style="display:none"'}>Fix all now (${x})</button>`,ce.appendChild($);let C=$.querySelector("#btn-fix-all-100");C&&(C.onclick=S=>{S.preventDefault(),S.stopPropagation(),ss(e)}),Ht(e);let N=f.reduce((S,k)=>(S[k.type]=S[k.type]||[],S[k.type].push(k),S),{}),F=e.reduce((S,k)=>(S[k.type]=S[k.type]||[],S[k.type].push(k),S),{}),W=["naming","autolayout","spacing","color","color-variable","typography","typography-style","typography-check","line-height","position","duplicate","group","component","empty-frame","nested-group","contrast","text-size-mobile"],T=h.disabledChecks||[];for(let S of W){if(T.includes(S))continue;let k=N[S]||[],A=k.length,O=k.filter(c=>c.ignored?!1:c.severity==="error"||c.severity==="warn").length;if(A===0&&e.length===0||A===0&&st!=="all")continue;let oe=document.createElement("div"),ke=y.has(S);oe.className=ke?"issue-group":"issue-group collapsed",oe.setAttribute("data-issue-type",S);let be=document.createElement("div");be.className="issue-group-header";let $e=(F[S]||[]).some(c=>{try{if(!c)return!1;switch(c.type){case"color":return xt(c)!==null;case"spacing":return St(c)!==null;case"autolayout":return typeof pt=="function"&&pt(c)!==null;case"text-size-mobile":return typeof at=="function"&&at(c)!==null;case"contrast":return typeof mt=="function"&&mt(c)!==null;case"typography-style":case"typography-check":return c.bestMatch&&c.bestMatch.name&&typeof c.bestMatch.name=="string"&&c.bestMatch.name.trim().length>0&&Mt(c);case"position":return typeof lt=="function"&&lt(c)!==null;case"duplicate":case"component":return typeof ut=="function"&&ut(c)!==null;case"group":return!0;case"empty-frame":return typeof gt=="function"&&gt(c)!==null;default:return!1}}catch(ue){return console.error("[hasSuggestFixButton] Error checking issue:",c,ue),!1}}),Ie=0;S==="typography-style"&&(F[S]||[]).forEach(c=>{c.subIssues&&c.subIssues.length>0?c.subIssues.forEach(ue=>{let se=Object.assign({},c,{nodeProps:ue.nodeProps||c.nodeProps,subIssues:void 0});se.nodeProps&&ot(se)!==null&&Ie++}):c.nodeProps&&ot(c)!==null&&Ie++}),be.innerHTML=`
              <div class="issue-group-header-left">
                <button class="issue-group-toggle" type="button">
                  <span class="issue-group-toggle-icon">\u25B6</span>
                </button>
                <h4>${zt(S)}</h4>
                <span class="badge">${O}</span>
              </div>
              ${S==="typography-style"&&Ie>0?`<button class="btn-fix-all" data-type="${S}">Fix all now (${Ie})</button>`:A>0&&S!=="typography"&&S!=="line-height"&&S!=="naming"&&S!=="component"&&S!=="duplicate"&&$e?`<button class="btn-fix-all" data-type="${S}">Fix all now</button>`:""}
            `;let Ee=be.querySelector(".issue-group-toggle"),H=()=>{oe.classList.contains("collapsed")?(oe.classList.remove("collapsed"),K.style.display="block",setTimeout(()=>{K.style.opacity="1"},10)):(K.style.opacity="0",setTimeout(()=>{oe.classList.add("collapsed"),K.style.display="none"},200))};Ee.onclick=c=>{c.stopPropagation(),H()},be.onclick=c=>{c.target!==Ee&&!Ee.contains(c.target)&&H()};let ae=be.querySelector(".btn-fix-all");ae&&(ae.onclick=c=>{try{if(c.preventDefault(),c.stopPropagation(),S==="typography-style"){ns(F[S]||[]);return}let ue=(F[S]||[]).filter(se=>{if(!se)return!1;switch(se.type){case"color":return xt(se)!==null;case"spacing":return St(se)!==null;case"autolayout":return typeof pt=="function"&&pt(se)!==null;case"text-size-mobile":return typeof at=="function"&&at(se)!==null;case"contrast":return typeof mt=="function"&&mt(se)!==null;case"typography-style":case"typography-check":return se.bestMatch&&se.bestMatch.name&&typeof se.bestMatch.name=="string"&&se.bestMatch.name.trim().length>0&&Mt(se);case"position":return typeof lt=="function"&&lt(se)!==null;case"duplicate":case"component":return typeof ut=="function"&&ut(se)!==null;case"group":return!0;case"empty-frame":return typeof gt=="function"&&gt(se)!==null;default:return!1}});if(ue.length===0){alert("No issues with suggest fix available");return}is(S,ue)}catch(ue){console.error("[Fix All] Error:",ue.message),alert("Error: "+ue.message)}}),oe.appendChild(be);let K=document.createElement("div");if(K.className="issue-group-content",ke?(K.style.display="block",K.style.opacity="1"):K.style.display="none",A===0){let c=document.createElement("div");c.className="issue info",c.style.opacity="0.7",c.innerHTML=`
                <div class="issue-header">
                  <div>
                    <span class="issue-type">\u2705 PASSED</span>
                    <div class="issue-body">No issues in this type.</div>
                  </div>
                </div>
              `,K.appendChild(c)}else{if(N[S].forEach((c,ue)=>{let se=ue+1,Ce=me[c.id]===!0;if(Ce&&(c.originalSeverity||(c.originalSeverity=c.severity),c.severity="info",c.ignored=!0),_t.includes(c.type)&&c.nodeProps||Yt.includes(c.type)||Jt.includes(c.type))return;let Q=document.createElement("div"),Be=Ce?"info":c.severity;Q.className=`issue ${Be}`,Q.setAttribute("data-issue-id",c.id);let Ye=d(c.message);if(c.type==="contrast"){let _=[];if(c.textColor&&_.push(`Text color: <code style="background: ${d(c.textColor)}; padding: 2px 6px; border-radius: 3px; color: ${kt(c.textColor)};">${d(c.textColor)}</code> (${c.textColorNode||c.nodeName||"Unnamed"})`),c.backgroundColor){let he="Background:",ht="",bt="";c.isGradient&&c.gradientString?(he="Background (gradient):",ht=`<code style="background: ${d(c.backgroundColor)}; padding: 2px 6px; border-radius: 3px; color: ${kt(c.backgroundColor)}; font-family: 'SF Mono', Monaco, monospace; font-size: 11px;">${d(c.gradientString)}</code>`,bt=" <span style='font-size: 11px; color: #999;'>(average: "+d(c.backgroundColor)+")</span>"):ht=`<code style="background: ${d(c.backgroundColor)}; padding: 2px 6px; border-radius: 3px; color: ${kt(c.backgroundColor)};">${d(c.backgroundColor)}</code>`,c.fromSibling&&(bt+=" <span style='font-size: 11px; color: #3b82f6;'>(from sibling layer)</span>"),_.push(`${he} ${ht}${bt} (${c.backgroundColorNode||"Unknown"})`)}_.length>0&&(Ye+=`<div style="margin-top: 8px; font-size: 10px; color: #666;">${_.join(" | ")}</div>`)}Q.innerHTML=`
                <div class="issue-header">
                  <div>
                    <span class="issue-type">
                      <span class="issue-number">#${se}</span>
                      ${$n(Ce?"info":c.severity)} ${Ce?"INFO":c.severity.toUpperCase()}
                    </span>
                    <div class="issue-body">${Ye}</div>
                    ${c.nodeName?`<div class="issue-node">Node: ${d(c.nodeName)}</div>`:""}
                    ${c.type==="typography"||c.type==="line-height"?`<div style="margin-top: 8px; padding: 8px 12px; background: #fff3cd; border-left: 3px solid #ffc107; border-radius: 4px; font-size: 10px; color: #856404; line-height: 1.5;"><strong>Note:</strong> Check 'Typography Style Match' to resolve this issue.</div>`:""}
                    ${c.ignored?'<div class="issue-ignored-tag" style="margin-top: 4px; padding: 4px 8px; background: #e3f2fd; color: #1976d2; border-radius: 4px; font-size: 11px; font-weight: 600; display: inline-block;">\u2713 Pass with ignore custom</div>':""}
                  </div>
                  <div class="issue-actions">
                    <button class="btn-select" data-id="${c.id}">Select</button>
                    ${c.type==="color"?`
                      ${xt(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select Color</button>
                    `:""}
                    ${c.type==="color-variable"?`
                      ${c.matchingVariable?`<button class="btn-suggest-fix btn-bind-variable" data-id="${c.id}" data-variable-id="${c.matchingVariable.id}" data-variable-name="${d(c.matchingVariable.name)}">Bind Variable</button>`:""}
                      <button class="btn-fix btn-select-variable" data-id="${c.id}">Select Variable</button>
                    `:""}
                    ${c.type==="spacing"?`
                      ${St(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select Spacing</button>
                    `:""}
                    ${c.type==="autolayout"?`
                      ${pt(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select</button>
                    `:""}
                    ${c.type==="text-size-mobile"?`
                      ${at(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select Style</button>
                    `:""}
                    ${c.type==="contrast"?`
                      ${mt(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select Color</button>
                      <button class="btn-ignore" data-id="${c.id}" ${c.ignored?'style="background: #22c55e; border-color: #22c55e;"':""}>${c.ignored?"Ignored":"Ignore"}</button>
                    `:""}
                    ${c.type==="typography-style"?`
                      ${c.bestMatch&&c.bestMatch.name&&Mt(c)?`
                        <button class="btn-suggest-fix" data-id="${c.id}" data-style-name="${d(c.bestMatch.name)}">Suggest Fix now</button>
                      `:""}
                      <button class="btn-fix" data-id="${c.id}">Select Style</button>
                      <button class="btn-create-style" data-id="${c.id}" data-issue-type="${c.type}">Create Style</button>
                    `:""}
                    ${c.type==="position"?`
                      ${lt(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-remove-layer" data-id="${c.id}">Remove Layer</button>
                    `:""}
                    ${(c.severity==="error"||c.severity==="warn")&&c.type!=="position"?`
                      <button class="btn-remove-layer" data-id="${c.id}">Remove Layer</button>
                    `:""}
                    ${c.type==="duplicate"?`
                      ${ut(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-select-component" data-id="${c.id}">Select Component</button>
                      <button class="btn-create-component" data-id="${c.id}">Create New Component</button>
                    `:""}
                    ${c.type==="component"?`
                      ${ut(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-select-component" data-id="${c.id}">Select Component</button>
                      <button class="btn-create-component" data-id="${c.id}">Create New Component</button>
                    `:""}
                    ${c.type==="group"?`
                      <button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>
                    `:""}
                    ${c.type==="naming"?`
                      <button class="btn-rename" data-id="${c.id}">Rename</button>
                    `:""}
                    ${c.type==="empty-frame"?`
                      ${gt(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                    `:""}
                  </div>
                </div>
              `,K.appendChild(Q),Q.setAttribute("data-issue-id",c.id),Q.setAttribute("data-issue-type",c.type);let Fe=Q.querySelector("button.btn-select");Fe&&(Fe.onclick=()=>{document.querySelectorAll(".btn-select.active").forEach(_=>_.classList.remove("active")),document.querySelectorAll(".issue.selected").forEach(_=>_.classList.remove("selected")),Fe.classList.add("active"),Q.classList.add("selected"),parent.postMessage({pluginMessage:{type:"select-node",id:c.id}},"*")});let we=Q.querySelector("button.btn-fix");we&&(c.type==="color"?we.onclick=()=>{ts(c)}:c.type==="spacing"?we.onclick=()=>{es(c)}:c.type==="text-size-mobile"?we.onclick=_=>{_.preventDefault(),_.stopPropagation(),typeof Eo=="function"?Eo(c):(console.error("handleFixTextSizeIssue is not a function"),alert("Error: handleFixTextSizeIssue function not found"))}:c.type==="contrast"?we.onclick=_=>{_.preventDefault(),_.stopPropagation(),typeof Mo=="function"?Mo(c):(console.error("handleFixContrastIssue is not a function"),alert("Error: handleFixContrastIssue function not found"))}:we.onclick=()=>{os(c)});let Ne=Q.querySelector("button.btn-suggest-fix");Ne&&(c.type==="color"?Ne.onclick=()=>{Hn(c)}:c.type==="spacing"?Ne.onclick=()=>{qn(c)}:c.type==="autolayout"?Ne.onclick=_=>{_.preventDefault(),_.stopPropagation(),typeof yo=="function"?yo(c):(console.error("handleSuggestFixAutolayout is not a function"),alert("Error: handleSuggestFixAutolayout function not found"))}:c.type==="text-size-mobile"?Ne.onclick=_=>{_.preventDefault(),_.stopPropagation(),typeof Xt=="function"?Xt(c):(console.error("handleSuggestFixTextSize is not a function"),alert("Error: handleSuggestFixTextSize function not found"))}:c.type==="position"?Ne.onclick=_=>{_.preventDefault(),_.stopPropagation(),typeof bo=="function"?bo(c):(console.error("handleSuggestFixPosition is not a function"),alert("Error: handleSuggestFixPosition function not found"))}:c.type==="duplicate"||c.type==="component"?Ne.onclick=_=>{_.preventDefault(),_.stopPropagation(),typeof So=="function"?So(c):(console.error("handleSuggestFixComponent is not a function"),alert("Error: handleSuggestFixComponent function not found"))}:c.type==="contrast"?Ne.onclick=_=>{_.preventDefault(),_.stopPropagation(),typeof Zt=="function"?Zt(c):(console.error("handleSuggestFixContrast is not a function"),alert("Error: handleSuggestFixContrast function not found"))}:c.type==="group"?Ne.onclick=_=>{_.preventDefault(),_.stopPropagation(),typeof ho=="function"?ho(c):(console.error("handleSuggestFixGroup is not a function"),alert("Error: handleSuggestFixGroup function not found"))}:c.type==="empty-frame"?Ne.onclick=_=>{_.preventDefault(),_.stopPropagation(),typeof vo=="function"?vo(c):(console.error("handleSuggestFixEmptyFrame is not a function"),alert("Error: handleSuggestFixEmptyFrame function not found"))}:c.type==="color-variable"&&(Ne.onclick=_=>{if(_.preventDefault(),_.stopPropagation(),c.matchingVariable&&c.matchingVariable.id){if(c.colorOpacity&&c.colorOpacity<1){let he=Math.round(c.colorOpacity*100);if(!confirm(`This layer has opacity ${he}%. Binding a variable will reset opacity to 100%. Continue?`))return}ne(c.id,"\u23F3 Binding variable...",!0),parent.postMessage({pluginMessage:{type:"bind-color-variable",issue:c,variableId:c.matchingVariable.id}},"*")}}));let Re=Q.querySelector("button.btn-select-component");Re&&(c.type==="duplicate"||c.type==="component")&&(function(_){Re.onclick=he=>{he.preventDefault(),he.stopPropagation(),typeof ko=="function"?ko(_):(console.error("handleSelectComponent is not a function"),alert("Error: handleSelectComponent function not found"))}})(c);let tt=Q.querySelector("button.btn-create-component");tt&&(c.type==="duplicate"||c.type==="component")&&(function(_){tt.onclick=he=>{he.preventDefault(),he.stopPropagation(),typeof wo=="function"?wo(_):(console.error("handleCreateComponent is not a function"),alert("Error: handleCreateComponent function not found"))}})(c);let pn=Q.querySelector("button.btn-select-variable");pn&&c.type==="color-variable"&&(function(_){pn.onclick=he=>{he.preventDefault(),he.stopPropagation(),No(_)}})(c);let un=Q.querySelector("button.btn-rename");un&&c.type==="naming"&&(function(_){un.onclick=he=>{he.preventDefault(),he.stopPropagation(),typeof Io=="function"?Io(_):(console.error("handleRenameNode is not a function"),alert("Error: handleRenameNode function not found"))}})(c);let gn=Q.querySelector("button.btn-remove-layer");gn&&(function(_){gn.onclick=he=>{he.preventDefault(),he.stopPropagation(),typeof Bt=="function"?Bt(_):(console.error("handleRemoveLayer is not a function"),alert("Error: handleRemoveLayer function not found"))}})(c);let co=Q.querySelector("button.btn-ignore");if(co&&c.type==="contrast"&&(co.removeAttribute("disabled"),co.onclick=_=>{_.preventDefault(),_.stopPropagation();try{typeof zo=="function"?zo(c):(console.error("handleIgnoreIssue is not a function"),alert("Error: handleIgnoreIssue function not found"))}catch(he){console.error("Error handling ignore:",he),alert(`Error: ${he.message}`)}}),c.type==="typography-style"){let _=Q.querySelector("button.btn-create-style");_?(function(Ae){_.onclick=Le=>{Le.preventDefault(),Le.stopPropagation(),typeof Fo=="function"?Fo(Ae):(console.error("handleCreateTextStyle is not a function"),alert("Error: handleCreateTextStyle function not found"))}})(c):console.error("Create Style button not found in DOM",{issueId:c.id,issueType:c.type,hasIssueEl:!!Q,innerHTML:Q.innerHTML.substring(0,200)});let he=Q.querySelector("button.btn-suggest-fix");he&&c.bestMatch&&c.bestMatch.name&&c.type==="typography-style"&&(function(Ae){he.onclick=Le=>{Le.preventDefault(),Le.stopPropagation();let vt=he.getAttribute("data-style-name");vt?eo(Ae,vt):(console.error("Cannot apply: styleName is missing from button",Ae),alert("Error: Style name is missing"))}})(c),he&&c.bestMatch&&c.bestMatch.name&&c.type==="typography-check"&&(function(Ae){he.onclick=Le=>{Le.preventDefault(),Le.stopPropagation(),Ae.bestMatch&&Ae.bestMatch.name?eo(Ae,Ae.bestMatch.name):(console.error("Cannot apply: bestMatch.name is missing",Ae),alert("Error: Best match style name is missing"))}})(c);let ht=Q.querySelector("button.btn-fix");ht&&c.type==="typography-style"&&(function(Ae){ht.onclick=Le=>{Le.preventDefault(),Le.stopPropagation(),parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:Ae.id}},"*"),window.pendingTypographyStyleIssue=Ae}})(c);let bt=Q.querySelector("button.btn-style-dropdown"),rt=Q.querySelector(".style-dropdown-menu");if(bt&&rt){let Ae=!1;bt.onclick=Le=>{Le.preventDefault(),Le.stopPropagation();let vt=rt.style.display!=="none";document.querySelectorAll(".style-dropdown-menu").forEach(mn=>{mn!==rt&&(mn.style.display="none")}),vt?rt.style.display="none":(rt.style.display="block",Ae||(rt.innerHTML='<div style="padding: 8px 12px; color: #999; font-size: 12px; text-align: center;">Loading...</div>',parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:c.id}},"*")))},document.addEventListener("click",function(vt){Q.contains(vt.target)||(rt.style.display="none")})}}}),_t.includes(S)){let ue=(N[S]||[]).filter(se=>!se.ignored&&se.severity!=="info"&&se.nodeProps);if(ue.length>0){let{typographyGroups:se,otherIssues:Ce}=En(ue);Ce.forEach(Q=>{let Be=Gt(Q);Be&&K.appendChild(Be)}),se.forEach(Q=>{let Be=An(Q);Be&&K.appendChild(Be)})}}if(Yt.includes(S)){let c=(N[S]||[]).filter(ue=>!ue.ignored);if(c.length>0){let{colorGroups:ue,otherIssues:se}=zn(c);se.forEach(Ce=>{let Q=Gt(Ce);Q&&K.appendChild(Q)}),ue.forEach(Ce=>{let Q=Ln(Ce);Q&&K.appendChild(Q)})}}if(Jt.includes(S)){let c=(N[S]||[]).filter(ue=>!ue.ignored);if(c.length>0){let{simpleGroups:ue,otherIssues:se}=Nn(c);se.forEach(Ce=>{let Q=Gt(Ce);Q&&K.appendChild(Q)}),ue.forEach(Ce=>{let Q=Fn(Ce);Q&&K.appendChild(Q)})}}}oe.appendChild(K),ce.appendChild(oe)}s||Ot({issues:e,issuesTimestamp:a,tokens:h.tokens,tokensTimestamp:h.tokensTimestamp,lastActiveTab:"issues",scanMode:h.scanMode||null,context:h.context||null})}function cs(e){if(!e)return null;let t={},o=!1;for(let[s,n]of Object.entries(e)){let i=n||[];if((s==="colors"||s==="gradients")&&dt!=="all"&&(i=i.filter(l=>(l.colorType||"").toLowerCase().includes(dt.toLowerCase()))),We.trim()){let l=We.toLowerCase();i=i.map(a=>{let r=String(a.value||"").toLowerCase(),g=(a.nodes||[]).map(m=>m.name||"").join(" ").toLowerCase(),u=(a.colorType||"").toLowerCase(),b=r.includes(l),f=g.includes(l),y=u.includes(l);if(b||f||y){let m=[];return b&&m.push("value"),f&&m.push("nodeName"),y&&m.push("colorType"),Je(De({},a),{_matchedBy:m,_matchedNodeNames:f?(a.nodes||[]).filter(p=>(p.name||"").toLowerCase().includes(l)).map(p=>p.name):[]})}return null}).filter(a=>a!==null)}i.length>0&&(o=!0),t[s]=i}return{tokens:t,hasMatches:o}}function ds(e){let t=document.getElementById("spacing-scale");if(!t)return;let o=document.getElementById("spacing-threshold"),s=o?parseInt(o.value,10):100,n=isNaN(s)?100:s,l=(e&&Array.isArray(e.spacing)?e.spacing:[]).map(r=>{let g=parseInt(String(r&&r.value!==void 0?r.value:"").trim(),10);return isNaN(g)?null:Math.abs(g)}).filter(r=>r!==null&&r<=n);if(!l.length)return;let a=Array.from(new Set(l)).sort((r,g)=>r-g);t.value=a.join(", ");try{t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(r){}}function It(e,t=!1,o={}){let{skipSave:s=!1,restoreTimestamp:n=null,skipTabSwitch:i=!1}=o;i||Ue("tokens");let l=Object.values(e||{}).reduce((C,N)=>C+(Array.isArray(N)?N.length:0),0);document.getElementById("tokens-count").textContent=l;let a=h.tokens!==e;h.tokens=e;let r=n||new Date().toISOString();h.tokensTimestamp=r,Tt=!0,(t||a)&&(st="all",dt="all",Oe&&(Oe.value=""),We="",qe&&(qe.style.display="none"),Pe&&Pe.length>0&&Pe.forEach(C=>{C.classList.remove("active"),C.getAttribute("data-filter")==="all"&&C.classList.add("active")}),$t&&($t.value="all"));let g=document.getElementById("filter-controls"),u=document.getElementById("color-type-filter"),b=document.getElementById("filter-buttons");g&&(g.style.display=e&&Object.keys(e).length>0?"flex":"none"),u&&(u.style.display=e&&(e.colors||e.gradients)?"block":"none"),b&&(b.style.display="none");let f=document.getElementById("export-group");f.style.display=e&&Object.keys(e).length>0?"flex":"none";let y=cs(e);if(wt("tokens"),!e||Object.keys(e).length===0){fe.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F4CB}</div>
                <p>No design tokens found</p>
              </div>
            `;return}if(!y){fe.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F50D}</div>
                <p><strong>No results found</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Try changing the filter or search keyword.</p>
              </div>
            `;return}let m=y.tokens||{},p=y.hasMatches;if((We.trim()||dt!=="all")&&!p){fe.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F50D}</div>
                <p><strong>No results found</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Try changing the filter or search keyword.</p>
              </div>
            `;return}let x={colors:{icon:"",label:"Colors",values:m.colors||[]},gradients:{icon:"",label:"Gradients",values:m.gradients||[]},spacing:{icon:"",label:"Spacing (px)",values:m.spacing||[]},borderRadius:{icon:"",label:"Border Radius",values:m.borderRadius||[]},fontWeight:{icon:"",label:"Font Weight",values:m.fontWeight||[]},lineHeight:{icon:"",label:"Line Height (%)",values:m.lineHeight||[]},fontSize:{icon:"",label:"Font Size",values:m.fontSize||[]},fontFamily:{icon:"",label:"Font Family",values:m.fontFamily||[]}},$=document.createElement("div");$.className="results-header";let E=Object.values(x).reduce((C,N)=>C+N.values.length,0);$.innerHTML=`
            <h3>Design Tokens</h3>
            <div class="results-stats">
              <span class="stat">${E} Tokens</span>
            </div>
          `,fe.appendChild($);for(let[C,N]of Object.entries(x)){let F=document.createElement("div");F.className="issue-group collapsed";let W=document.createElement("div");W.className="issue-group-header",W.innerHTML=`
              <div class="issue-group-header-left">
                <button class="issue-group-toggle" type="button">
                  <span class="issue-group-toggle-icon">\u25B6</span>
                </button>
                <h4>${document.documentElement.dataset.showIcons==="true"?N.icon+" ":""}${N.label}</h4>
                <span class="badge">${N.values.length}</span>
              </div>
            `;let T=document.createElement("div");T.className="issue-group-content",T.style.display="none";let S=W.querySelector(".issue-group-toggle"),k=()=>{F.classList.contains("collapsed")?(F.classList.remove("collapsed"),T.style.display="block",setTimeout(()=>{T.style.opacity="1"},10)):(T.style.opacity="0",setTimeout(()=>{F.classList.add("collapsed"),T.style.display="none"},200))};if(S.onclick=O=>{O.stopPropagation(),k()},W.onclick=O=>{O.target!==S&&!S.contains(O.target)&&k()},F.appendChild(W),Array.isArray(N.values)&&N.values.length>0){let O=document.createElement("div");O.className="token-list",N.values.forEach((oe,ke)=>{let be=ke+1,$e=document.createElement("div");$e.className="token-item";let Ie=oe.value,Ee=oe.nodes||[],H=Ee.length>0?Ee[0]:null,ae=typeof oe.totalNodes=="number"?oe.totalNodes:Ee.length,K=oe.colorType||null,c="";if(C==="colors"){let Fe=K?`<span class="token-color-type">${d(K)}</span>`:"";c=`
                  <span class="token-number">#${be}</span>
                  <span class="token-color-preview" style="background-color: ${d(Ie)}"></span>
                  <code>${d(Ie)}</code>
                  ${Fe}
                `}else if(C==="gradients"){let Fe=K?`<span class="token-color-type">${d(K)}</span>`:"";c=`
                  <span class="token-number">#${be}</span>
                  <span class="token-gradient-preview" style="background: ${d(Ie)}"></span>
                  <code>${d(Ie)}</code>
                  ${Fe}
                `}else c=`<span class="token-number">#${be}</span><code>${d(String(Ie))}</code>`;let ue=oe._matchedBy||[],se=oe._matchedNodeNames||[],Ce=ue.includes("nodeName"),Q="";H&&H.name&&(Ce&&se.length>0?Q=`<div class="token-node-name token-matched-by-name">
                    <span class="match-indicator">\u{1F50D} Matched in:</span> ${se.map(we=>`<span class="token-matched-node">${d(we)}</span>`).join(", ")}
                  </div>`:Q=`<div class="token-node-name">Node: ${d(H.name)}</div>`);let Be="";if(C==="fontWeight"){let we=Array.isArray(oe.fontFamilies)?oe.fontFamilies:null;if(!we){let Ne={};Ee.forEach(Re=>{let tt=Re&&Re.fontFamily?String(Re.fontFamily):"Unknown";Ne[tt]=(Ne[tt]||0)+1}),we=Object.entries(Ne).map(([Re,tt])=>({family:Re,count:tt})).sort((Re,tt)=>tt.count-Re.count||Re.family.localeCompare(tt.family))}Array.isArray(we)&&we.length>0&&(Be=`
                    <div class="token-note">
                      <div class="token-note-label">Font-family:</div>
                      <ul class="token-note-list">${we.map(Re=>`<li><code>${d(Re.family)}</code> (${Re.count})</li>`).join("")}</ul>
                    </div>
                  `)}$e.innerHTML=`
                <div class="token-item-row">
                  <div class="token-value">
                    ${c}
                  </div>
                  ${H?`
                    <div class="token-actions">
                      <button class="btn-select" data-id="${H.id}">${ae>1?"Select All":"Select"}</button>
                      ${ae>1?`<span class="token-node-count">(${ae})</span>`:""}
                    </div>
                  `:""}
                </div>
                ${Q}
                ${Be}
              `;let Ye=$e.querySelector("button.btn-select");Ye&&(Ye.onclick=()=>{document.querySelectorAll(".btn-select.active").forEach(we=>we.classList.remove("active")),document.querySelectorAll(".issue.selected, .token-item.selected").forEach(we=>we.classList.remove("selected")),Ye.classList.add("active"),$e.classList.add("selected");let Fe=Ee.map(we=>we.id).filter(Boolean);Fe.length>1?parent.postMessage({pluginMessage:{type:"select-nodes",ids:Fe}},"*"):parent.postMessage({pluginMessage:{type:"select-node",id:H.id}},"*")}),O.appendChild($e)}),T.appendChild(O)}else{let O=document.createElement("div");O.className="token-empty-message",O.textContent="No tokens in this group.",T.appendChild(O)}F.appendChild(T),fe.appendChild(F)}s||Ot({issues:h.issues,issuesTimestamp:h.timestamp,tokens:e,tokensTimestamp:r,lastActiveTab:"tokens",scanMode:h.scanMode||null,context:h.context||null})}function it(e){let t=document.getElementById("validation-error"),o=document.getElementById("validation-error-message"),s=document.getElementById("btn-close-validation-error");t&&o&&(o.textContent=e,t.style.display="block",I.style.display="block",z.style.display="none",v.style.display="none",I.disabled=!1,B.disabled=!1,setTimeout(()=>{t.style.display==="block"&&(t.style.display="none")},1e4),s&&(s.onclick=()=>{t.style.display="none"}))}function Lo(e){var N,F,W,T,S,k,A;I.style.display="none",z.style.display="block",v.style.display="block",M.style.transition="none",M.style.width="0%",L.textContent="0%",setTimeout(()=>{M.style.transition="width 0.3s"},10),ee();let t=document.getElementById("spacing-scale"),o=document.getElementById("spacing-threshold"),s=document.getElementById("color-scale"),n=document.getElementById("font-size-scale"),i=document.getElementById("font-size-threshold"),l=document.getElementById("line-height-scale"),a=document.getElementById("line-height-threshold"),r=document.getElementById("line-height-baseline-threshold"),g=t?t.value.trim():"",u=o?parseInt(o.value,10):100,b=s?s.value.trim():"",f=n?n.value.trim():"",y=i?parseInt(i.value,10):100,m=l?l.value.trim():"",p=a?parseInt(a.value,10):300,w=r?parseInt(r.value,10):120,x={checkStyle:((N=document.getElementById("rule-typo-style"))==null?void 0:N.checked)||!1,checkFontFamily:((F=document.getElementById("rule-font-family"))==null?void 0:F.checked)||!1,checkFontSize:((W=document.getElementById("rule-font-size"))==null?void 0:W.checked)||!1,checkFontWeight:((T=document.getElementById("rule-font-weight"))==null?void 0:T.checked)||!1,checkLineHeight:((S=document.getElementById("rule-line-height"))==null?void 0:S.checked)||!1,checkLetterSpacing:((k=document.getElementById("rule-letter-spacing"))==null?void 0:k.checked)||!1,checkWordSpacing:((A=document.getElementById("rule-word-spacing"))==null?void 0:A.checked)||!1},$=document.getElementById("scan-skip-names"),E=$?$.value.trim():"not check design, sticky note, vector, Clip path group, Clip path",C=typeof window.getAppliedScanSettings=="function"?window.getAppliedScanSettings():{};parent.postMessage({pluginMessage:{type:"scan",mode:e,spacingScale:g,spacingThreshold:u,colorScale:b,fontSizeScale:f,fontSizeThreshold:y,lineHeightScale:m,lineHeightThreshold:p,lineHeightBaselineThreshold:w,typographyStyles:Z,typographyRules:x,ignoredIssues:me,skipNames:E,scanSettings:C}},"*")}I.onclick=()=>{var e;try{let t=document.getElementById("validation-error");t&&(t.style.display="none");let o=((e=document.querySelector('input[name="scope"]:checked'))==null?void 0:e.value)||"page",s=document.getElementById("spacing-scale"),n=document.getElementById("spacing-threshold"),i=document.getElementById("color-scale"),l=document.getElementById("font-size-scale"),a=document.getElementById("font-size-threshold"),r=document.getElementById("line-height-scale"),g=document.getElementById("line-height-threshold"),u=document.getElementById("line-height-baseline-threshold"),b=s?s.value.trim():"",f=n?parseInt(n.value,10):100,y=i?i.value.trim():"",m=l?l.value.trim():"",p=a?parseInt(a.value,10):100,w=r?r.value.trim():"",x=g?parseInt(g.value,10):300,$=u?parseInt(u.value,10):120;if(b&&!/^\d+(\s*,\s*\d+)*$/.test(b)){it("Spacing guidelines format is incorrect. Please enter the numbers separated by commas (e.g. 4, 8, 12, 16)");return}if(y){let E=y.split(",").map(F=>F.trim()).filter(F=>F),C=/^#[0-9a-fA-F]{3,8}$/,N=E.filter(F=>!C.test(F));if(N.length>0){it(`Color format is incorrect. Invalid colors: ${N.join(", ")}. Please use hex format only.`);return}}if(m&&!/^\d+(\s*,\s*\d+)*$/.test(m)){it("Font-size scale format is incorrect. Please enter the numbers separated by commas (e.g. 32, 24, 20, 18)");return}if(w){let E=w.split(",").map(N=>N.trim()).filter(N=>N);if(!E.every(N=>N.toLowerCase()==="auto"||/^\d+$/.test(N))||E.length===0){it('Line-height scale format is incorrect. Please enter "auto" and/or numbers separated by commas.');return}}if(isNaN(f)||f<0){it("Spacing threshold must be a number >= 0");return}if(isNaN(p)||p<0){it("Font-size threshold must be a number >= 0");return}if(isNaN(x)||x<0){it("Line-height threshold must be a number >= 0");return}if(isNaN($)||$<0){it("Line-height baseline threshold must be a number >= 0");return}ce.innerHTML=`
        <div class="scanning">
          <div class="spinner"></div>
          <p>Checking design size...</p>
        </div>
      `,Ue("issues"),I.disabled=!0,B.disabled=!0,h.scanMode=o,ve(),xe={scope:o},parent.postMessage({pluginMessage:{type:"get-node-count",mode:o}},"*")}catch(t){console.error("Error in btnScan.onclick:",t),ce.innerHTML=`<div class="error-message">Error: ${d(t.message)}</div>`,Ue("issues"),I.disabled=!1,B.disabled=!1}},B.onclick=()=>{var e;try{B.style.display="none",z.style.display="block",v.style.display="block",M.style.transition="none",M.style.width="0%",L.textContent="0%",setTimeout(()=>{M.style.transition="width 0.3s"},10);let t=((e=document.querySelector('input[name="scope"]:checked'))==null?void 0:e.value)||"page";fe.innerHTML=`
        <div class="scanning">
          <div class="spinner"></div>
          <p>Extracting design tokens... Please wait</p>
        </div>
      `,Ue("tokens"),I.disabled=!0,B.disabled=!0,h.scanMode=t,parent.postMessage({pluginMessage:{type:"extract-tokens",mode:t}},"*")}catch(t){console.error("Error in btnExtractTokens.onclick:",t),fe.innerHTML=`<div class="error-message">Error: ${d(t.message)}</div>`,Ue("tokens"),I.disabled=!1,B.disabled=!1}},D.onclick=()=>{try{ds(h.tokens)}catch(e){console.error("Failed to fill spacing guidelines from tokens",e)}},Y.onclick=()=>{try{let e=h.tokens;if(!e||!Array.isArray(e.colors)||!e.colors.length){alert("No color tokens found. Please run 'Extract Design Tokens' first.");return}let t=document.getElementById("color-scale");if(!t)return;let s=(e.colors||[]).map(i=>String(i&&i.value!==void 0?i.value:"").trim().toUpperCase()).filter(i=>i&&i.startsWith("#"));if(!s.length)return;let n=Array.from(new Set(s)).sort((i,l)=>ct(i)-ct(l));t.value=n.join(", "),typeof je=="function"&&je();try{t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(i){}}catch(e){console.error("Failed to fill color from tokens",e)}},j.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-color-styles"}},"*")};let Ho=document.getElementById("btn-extract-color-variables");Ho&&(Ho.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-color-variables"}},"*")}),P.onclick=()=>{try{let e=h.tokens;if(!e||!Array.isArray(e.fontSize)||!e.fontSize.length){alert("No font size tokens found. Please run 'Extract Design Tokens' first.");return}let t=document.getElementById("font-size-scale");if(!t)return;let o=document.getElementById("font-size-threshold"),s=o?parseInt(o.value,10):100,n=isNaN(s)?100:s,i=e.fontSize.map(a=>parseInt(String(a&&a.value!==void 0?a.value:"").trim(),10)).filter(a=>!isNaN(a)&&a<=n);if(!i.length)return;let l=Array.from(new Set(i)).sort((a,r)=>r-a);t.value=l.join(", "),t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(e){console.error("Failed to fill font size from tokens",e)}},U.onclick=()=>{try{let e=h.tokens;if(!e||!Array.isArray(e.lineHeight)||!e.lineHeight.length){alert("No line height tokens found. Please run 'Extract Design Tokens' first.");return}let t=document.getElementById("line-height-scale");if(!t)return;let o=document.getElementById("line-height-threshold"),s=o?parseInt(o.value,10):300,n=isNaN(s)?300:s,i=[];if(e.lineHeight.forEach(u=>{let b=String(u&&u.value!==void 0?u.value:"").trim();if(b==="auto")i.push("auto");else{let f=parseFloat(b);!isNaN(f)&&f<=n&&i.push(f)}}),!i.length)return;let l=i.includes("auto"),a=i.filter(u=>u!=="auto"),r=Array.from(new Set(a)).sort((u,b)=>u-b),g=l?["auto",...r]:r;t.value=g.join(", "),t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(e){console.error("Failed to fill line height from tokens",e)}},V.onclick=()=>{try{if(!Z||!Array.isArray(Z)||Z.length===0){alert("No typography styles defined. Please add typography styles or extract from Figma first.");return}let e=document.getElementById("font-size-scale");if(!e)return;let t=Z.map(s=>{let n=parseInt(String(s.fontSize||"").trim(),10);return isNaN(n)?null:n}).filter(s=>s!==null);if(!t.length){alert("No valid font sizes found in typography styles.");return}let o=Array.from(new Set(t)).sort((s,n)=>n-s);e.value=o.join(", "),ve(),e.focus(),e.setSelectionRange(e.value.length,e.value.length)}catch(e){console.error("Failed to fill font size from typography",e)}},q.onclick=()=>{try{if(!Z||!Array.isArray(Z)||Z.length===0){alert("No typography styles defined. Please add typography styles or extract from Figma first.");return}let e=document.getElementById("line-height-scale");if(!e)return;let t=[];if(Z.forEach(l=>{let a=String(l.lineHeight||"").trim();if(a==="auto")t.push("auto");else{let r=parseFloat(a.replace("%",""));isNaN(r)||t.push(r)}}),!t.length){alert("No valid line heights found in typography styles.");return}let o=t.includes("auto"),s=t.filter(l=>l!=="auto"),n=Array.from(new Set(s)).sort((l,a)=>l-a),i=o?["auto",...n]:n;e.value=i.join(", "),ve(),e.focus(),e.setSelectionRange(e.value.length,e.value.length)}catch(e){console.error("Failed to fill line height from typography",e)}};let to=document.getElementById("typography-panel"),qo=document.getElementById("typography-panel-header"),Po=document.getElementById("typography-panel-toggle");qo&&to&&Po&&(qo.onclick=()=>{let e=to.classList.contains("collapsed");to.classList.toggle("collapsed");let t=Po.querySelector(".issue-group-toggle-icon");t&&(t.textContent="\u25B6")});let oo=document.getElementById("settings-panel"),Ro=document.getElementById("settings-panel-header"),Ct=document.getElementById("settings-panel-toggle");if(Ro&&oo&&Ct){let e=()=>{let t=oo.classList.contains("collapsed");oo.classList.toggle("collapsed");let o=Ct.querySelector(".issue-group-toggle-icon");o&&(o.textContent="\u25B6")};Ro.onclick=t=>{t.target===Ct||Ct.contains(t.target)||e()},Ct.onclick=t=>{t.stopPropagation(),e()}}function no(){let e=document.getElementById("color-preview-panel"),t=document.getElementById("color-preview-panel-header"),o=document.getElementById("color-preview-panel-toggle");if(!e||!t||!o){setTimeout(no,100);return}let s=()=>{let n=e.classList.contains("collapsed");e.classList.toggle("collapsed");let i=o.querySelector(".issue-group-toggle-icon");i&&(i.textContent="\u25B6")};t.onclick=n=>{n.preventDefault(),n.stopPropagation(),s()},o.onclick=n=>{n.preventDefault(),n.stopPropagation(),s()}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",no):no();function je(){let e=document.getElementById("color-scale"),t=document.getElementById("color-preview");if(!e||!t)return;let o=e.value.trim();if(t.innerHTML="",!o)return;let s=o.split(",").map(l=>l.trim()).filter(l=>l),n=1;s.forEach(l=>{let a=l.toUpperCase(),r=J[a];if(r&&/^No name \d+$/.test(r)){let g=parseInt(r.replace("No name ",""),10);g>=n&&(n=g+1)}});let i=1;s.forEach((l,a)=>{let r=/^#[0-9A-Fa-f]{3,8}$/.test(l),g=/^rgba?\(/.test(l);if(!r&&!g)return;let u=document.createElement("div");u.className="color-swatch-container";let b=document.createElement("div");b.className="color-swatch",b.style.background=l;let f=document.createElement("button");f.innerHTML="\xD7",f.className="color-swatch-close",f.onclick=function($){var F;$.stopPropagation();let E=e.value.split(",").map(W=>W.trim()).filter(W=>W),C=(F=E[a])==null?void 0:F.toUpperCase(),N=E.filter((W,T)=>T!==a);e.value=N.join(", "),C&&J[C]&&delete J[C],je(),typeof ve=="function"&&ve()};let y=l.toUpperCase(),m=J[y];if(!m){for(;Object.values(J).includes(`No name ${i}`);)i++;m=`No name ${i}`,J[y]=m,i++,typeof ve=="function"&&ve()}let p=document.createElement("div");p.className="color-swatch-label";let w=document.createElement("div");w.className="color-swatch-label-name",w.textContent=m,w.title="Click to edit name",w.style.cursor="pointer",w.onclick=function($){$.stopPropagation();let E=document.createElement("input");E.type="text",E.value=m,E.className="color-swatch-name-input",E.style.cssText="width: 100%; font-size: 11px; padding: 2px 4px; border: 1px solid #3b82f6; border-radius: 4px; text-align: center; box-sizing: border-box;",w.style.display="none",w.parentNode.insertBefore(E,w),E.focus(),E.select();let C=()=>{let N=E.value.trim()||`No name ${i}`;J[y]=N,w.textContent=N,w.style.display="",E.remove(),typeof ve=="function"&&ve()};E.onblur=C,E.onkeydown=function(N){N.key==="Enter"?(N.preventDefault(),C()):N.key==="Escape"&&(w.style.display="",E.remove())}};let x=document.createElement("div");x.className="color-swatch-label-hex",x.textContent=y,p.appendChild(w),p.appendChild(x),b.appendChild(f),u.appendChild(b),u.appendChild(p),t.appendChild(u)})}function ps(){var e,t,o,s,n,i;return{fontFamily:((e=document.getElementById("rule-font-family"))==null?void 0:e.checked)||!1,fontSize:((t=document.getElementById("rule-font-size"))==null?void 0:t.checked)||!1,fontWeight:((o=document.getElementById("rule-font-weight"))==null?void 0:o.checked)||!1,lineHeight:((s=document.getElementById("rule-line-height"))==null?void 0:s.checked)||!1,letterSpacing:((n=document.getElementById("rule-letter-spacing"))==null?void 0:n.checked)||!1,wordSpacing:((i=document.getElementById("rule-word-spacing"))==null?void 0:i.checked)||!1}}function Ke(){let e=document.getElementById("typography-table-body"),t=document.querySelector("#typography-table thead tr");if(!e||!t)return;let o=ps(),s='<th class="typography-table-actions">Actions</th>';if(s+='<th class="typography-table-style-name" style="width: 120px;">Style Name</th>',o.fontFamily&&(s+='<th class="typography-table-font-family" style="width: 140px;">Font Family</th>'),o.fontSize&&(s+='<th class="typography-table-font-size" style="width: 80px;">Size (px)</th>'),o.fontWeight&&(s+='<th class="typography-table-font-weight" style="width: 100px;">Weight</th>'),o.lineHeight&&(s+='<th class="typography-table-line-height" style="width: 100px;">Line Height</th>'),o.letterSpacing&&(s+='<th class="typography-table-letter-spacing" style="width: 100px;">Letter Spacing</th>'),o.wordSpacing&&(s+='<th class="typography-table-word-spacing" style="width: 100px;">Word Spacing</th>'),t.innerHTML=s,Z.length===0){let n=Object.values(o).filter(i=>i).length+2;e.innerHTML=`
        <tr>
          <td colspan="${n}" class="typography-empty-message">
            No typography styles defined. Click "Add Typography Style" to create one.
          </td>
        </tr>
      `;return}e.innerHTML=Z.map(n=>{let i=`<tr data-id="${n.id}">`;return i+='<td class="typography-table-actions">',n.styleId&&(i+=`<button class="btn-table-action" onclick="selectTypographyStyle('${n.styleId}')" title="Select layer in Figma" style="background: #0071e3; color: white;">\u{1F441}</button>`),i+=`<button class="btn-table-action delete" onclick="deleteTypographyStyle(${n.id})" title="Delete">\u{1F5D1}</button>
        </td>`,i+=`<td><input type="text" value="${d(n.name)}" data-field="name"></td>`,o.fontFamily&&(i+=`<td><input type="text" value="${d(n.fontFamily)}" data-field="fontFamily"></td>`),o.fontSize&&(i+=`<td><input type="number" value="${n.fontSize}" data-field="fontSize" min="1"></td>`),o.fontWeight&&(i+=`<td>
          <select data-field="fontWeight">
            <option value="Thin" ${n.fontWeight==="Thin"?"selected":""}>Thin (100)</option>
            <option value="ExtraLight" ${n.fontWeight==="ExtraLight"?"selected":""}>ExtraLight (200)</option>
            <option value="Light" ${n.fontWeight==="Light"?"selected":""}>Light (300)</option>
            <option value="Regular" ${n.fontWeight==="Regular"?"selected":""}>Regular (400)</option>
            <option value="Medium" ${n.fontWeight==="Medium"?"selected":""}>Medium (500)</option>
            <option value="SemiBold" ${n.fontWeight==="SemiBold"?"selected":""}>SemiBold (600)</option>
            <option value="Bold" ${n.fontWeight==="Bold"?"selected":""}>Bold (700)</option>
            <option value="ExtraBold" ${n.fontWeight==="ExtraBold"?"selected":""}>ExtraBold (800)</option>
            <option value="Black" ${n.fontWeight==="Black"?"selected":""}>Black (900)</option>
          </select>
        </td>`),o.lineHeight&&(i+=`<td><input type="text" value="${d(n.lineHeight)}" data-field="lineHeight" placeholder="120% or auto"></td>`),o.letterSpacing&&(i+=`<td><input type="text" value="${d(n.letterSpacing||"0")}" data-field="letterSpacing" placeholder="0 or 0.5px"></td>`),o.wordSpacing&&(i+=`<td><input type="text" value="${d(n.wordSpacing||"0")}" data-field="wordSpacing" placeholder="0"></td>`),i+="</tr>",i}).join(""),e.querySelectorAll("input, select").forEach(n=>{n.addEventListener("change",i=>{let l=i.target.closest("tr"),a=parseInt(l.dataset.id),r=i.target.dataset.field,g=i.target.value;us(a,r,g)})})}window.addTypographyStyle=function(){let e={id:nt++,name:"New Style",fontFamily:"Inter",fontSize:16,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"};Z.push(e),Ke(),ve()};function us(e,t,o){let s=Z.find(n=>n.id===e);s&&(t==="fontSize"?s[t]=parseInt(o)||16:s[t]=o,ve())}window.deleteTypographyStyle=function(e){confirm("Delete this typography style?")&&(Z=Z.filter(t=>t.id!==e),ee(),Ke(),ve())},window.selectTypographyStyle=function(e){parent.postMessage({pluginMessage:{type:"select-text-style",styleId:e}},"*")};let Do=document.getElementById("btn-add-typo-style");Do&&(Do.onclick=()=>addTypographyStyle());let Wo=document.getElementById("btn-extract-typo-desktop");Wo&&(Wo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"desktop"}},"*")});let Uo=document.getElementById("btn-extract-typo-tablet");Uo&&(Uo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"tablet"}},"*")});let jo=document.getElementById("btn-extract-typo-mobile");jo&&(jo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"mobile"}},"*")});let Oo=document.getElementById("btn-extract-typo-all");Oo&&(Oo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"all"}},"*")});let Vo=document.getElementById("btn-reset-typo-table");Vo&&(Vo.onclick=()=>{confirm(`\u26A0\uFE0F Reset typography table to default styles?

This will:
\u2022 Clear all current styles
\u2022 Restore default H1-H6 and Body styles

This action cannot be undone.`)&&(Z=[{id:1,name:"H1",fontFamily:"Inter",fontSize:48,fontWeight:"Bold",lineHeight:"120%",letterSpacing:"0",wordSpacing:"0"},{id:2,name:"H2",fontFamily:"Inter",fontSize:36,fontWeight:"Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:3,name:"H3",fontFamily:"Inter",fontSize:30,fontWeight:"Semi Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:4,name:"H4",fontFamily:"Inter",fontSize:24,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:5,name:"H5",fontFamily:"Inter",fontSize:20,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:6,name:"H6",fontFamily:"Inter",fontSize:16,fontWeight:"Semi Bold",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"},{id:7,name:"Body",fontFamily:"Inter",fontSize:14,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"}],nt=8,Ke(),ve(),alert("\u2705 Typography table has been reset to default styles!"))});let At=document.getElementById("btn-update-fonts");At&&(At.onclick=()=>{let e=document.querySelector('input[name="scope"]:checked'),t=e&&e.value==="page"?"page":"selection";At.disabled=!0,At.textContent="\u23F3 Updating...",parent.postMessage({pluginMessage:{type:"update-fonts",scope:t}},"*")}),Ke(),["rule-font-family","rule-font-size","rule-font-weight","rule-line-height","rule-letter-spacing","rule-word-spacing"].forEach(e=>{let t=document.getElementById(e);t&&t.addEventListener("change",()=>{Ke(),ve()})});let Go=document.getElementById("color-scale");Go&&(Go.addEventListener("input",()=>{je()}),je());let gs=wn({maxHistory:10,postPluginMessage:e=>parent.postMessage({pluginMessage:e},"*"),getCurrentReportData:()=>h,setIsViewingTokens:e=>{Tt=!!e},renderResults:He,renderTokens:It}),{saveScanHistory:_o,requestScanHistory:Yo,renderScanHistory:so,restoreReportFromHistory:Fs,loadLastScanModeOnce:ms,setHistory:fs,clearLocalHistory:ys}=gs,hs=document.getElementById("export-group"),Lt=document.getElementById("export-dropdown");G.onclick=e=>{e.stopPropagation(),Lt.style.display=Lt.style.display==="block"?"none":"block"},document.querySelectorAll(".export-option").forEach(e=>{e.onclick=t=>{t.stopPropagation();let o=e.getAttribute("data-format");kn({format:o,reportData:h,getTypeDisplayName:zt,colorNameMap:J}),Lt.style.display="none"}}),document.addEventListener("click",e=>{hs.contains(e.target)||(Lt.style.display="none")});let Oe,qe,Pe,$t;function Ht(e){if(!e)return;let t=e.filter(a=>a.severity==="error"&&!a.ignored).length,o=e.filter(a=>a.severity==="warn"&&!a.ignored).length,s=e.filter(a=>!a.ignored).length,n=document.getElementById("filter-count-all"),i=document.getElementById("filter-count-error"),l=document.getElementById("filter-count-warn");n&&(n.textContent=s),i&&(i.textContent=t),l&&(l.textContent=o)}function qt(){let e=document.querySelector(".report-tab.active"),t=e?e.getAttribute("data-tab"):null;t==="animations"?typeof window.searchAnimations=="function"&&window.searchAnimations(We):t==="tokens"&&h.tokens?It(h.tokens,!1,{skipTabSwitch:!0}):t==="issues"&&h.issues?He(h.issues,!1,{skipTabSwitch:!0}):Tt&&h.tokens?It(h.tokens,!1,{skipTabSwitch:!0}):h.issues&&He(h.issues,!1,{skipTabSwitch:!0})}function io(){if(Oe=document.getElementById("search-input"),qe=document.getElementById("btn-clear-search"),Pe=document.querySelectorAll(".filter-btn"),$t=document.getElementById("color-type-select"),!Oe||!qe||!Pe||Pe.length===0){console.warn("Filter elements not found, retrying...",{searchInput:!!Oe,btnClearSearch:!!qe,filterButtons:Pe?Pe.length:0}),setTimeout(io,100);return}Oe.addEventListener("input",e=>{We=e.target.value,qe&&(qe.style.display=We.trim()?"block":"none"),qt()}),qe&&(qe.onclick=e=>{e.preventDefault(),e.stopPropagation(),Oe&&(Oe.value=""),We="",qe.style.display="none",qt()}),Pe.forEach((e,t)=>{e.onclick=o=>{o.preventDefault(),o.stopPropagation();let s=e.getAttribute("data-filter");e.classList.contains("active")&&s!=="all"?(e.classList.remove("active"),st="all",Pe.forEach(i=>{i.getAttribute("data-filter")==="all"&&i.classList.add("active")})):(Pe.forEach(i=>i.classList.remove("active")),e.classList.add("active"),st=s),qt()}}),$t&&$t.addEventListener("change",e=>{dt=e.target.value,qt()})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{io(),go(),mo(),Yo()}):(io(),go(),mo(),Yo()),pe&&(z.onclick=()=>{parent.postMessage({pluginMessage:{type:"cancel-scan"}},"*"),I.style.display="block",I.disabled=!1,B.style.display="block",B.disabled=!1,z.style.display="none",v.style.display="none"},re.onclick=()=>{if(confirm(`\u26A0\uFE0F Are you sure you want to reset all settings to default and clear history?

This will:
\u2022 Reset all input values to default
\u2022 Clear scan history
\u2022 Clear current reports

This action cannot be undone.`)){document.getElementById("spacing-scale").value="0, 4, 8, 12, 16, 24, 32, 40, 48, 64, 72, 80, 88, 96",document.getElementById("spacing-threshold").value="100",document.getElementById("color-scale").value="",document.getElementById("font-size-scale").value="32, 24, 20, 18, 16, 14, 12",document.getElementById("font-size-threshold").value="100",document.getElementById("line-height-scale").value="auto, 100, 110, 120, 130, 140, 150, 160, 170",document.getElementById("line-height-threshold").value="300",document.getElementById("line-height-baseline-threshold").value="120",Z=[{id:1,name:"H1",fontFamily:"Inter",fontSize:48,fontWeight:"Bold",lineHeight:"120%",letterSpacing:"0",wordSpacing:"0"},{id:2,name:"H2",fontFamily:"Inter",fontSize:36,fontWeight:"Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:3,name:"H3",fontFamily:"Inter",fontSize:30,fontWeight:"Semi Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:4,name:"H4",fontFamily:"Inter",fontSize:24,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:5,name:"H5",fontFamily:"Inter",fontSize:20,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:6,name:"H6",fontFamily:"Inter",fontSize:16,fontWeight:"Semi Bold",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"},{id:7,name:"Body",fontFamily:"Inter",fontSize:14,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"}],nt=8,Ke(),document.getElementById("rule-typo-style").checked=!0,document.getElementById("rule-font-family").checked=!0,document.getElementById("rule-font-size").checked=!0,document.getElementById("rule-font-weight").checked=!0,document.getElementById("rule-line-height").checked=!0,document.getElementById("rule-letter-spacing").checked=!1,document.getElementById("rule-word-spacing").checked=!1,Ke(),je(),h={issues:null,tokens:null,scanMode:null,timestamp:null,context:null,lastActiveTab:"issues"},wt("issues"),wt("tokens"),wt("animations"),Ue("issues");let e=document.getElementById("issues-count"),t=document.getElementById("tokens-count"),o=document.getElementById("animations-count");e&&(e.textContent="0"),t&&(t.textContent="0"),o&&(o.textContent="0");let s=document.getElementById("filter-count-all"),n=document.getElementById("filter-count-error"),i=document.getElementById("filter-count-warn");s&&(s.textContent="0"),n&&(n.textContent="0"),i&&(i.textContent="0"),Oe&&(Oe.value="",We=""),qe&&(qe.style.display="none");let l=document.getElementById("filter-controls"),a=document.getElementById("export-group");l&&(l.style.display="none"),a&&(a.style.display="none"),ys(),parent.postMessage({pluginMessage:{type:"clear-history"}},"*");let r=document.getElementById("history-panel");r&&r.style.display!=="none"&&so(),typeof window.resetScanSettings=="function"&&window.resetScanSettings(),ve(),alert("\u2705 All settings have been reset to default and history has been cleared!")}},pe.onclick=()=>{let e=document.getElementById("history-panel");if(e){let t=e.style.display!=="none";e.style.display=t?"none":"flex",t||so()}}),te&&(te.onclick=()=>{let e=document.getElementById("history-panel");e&&(e.style.display="none")});let Jo=document.getElementById("btn-save-settings"),Ve=document.getElementById("save-settings-modal"),Se=document.getElementById("setting-name-input"),Pt=document.getElementById("btn-confirm-save-settings"),Xo=document.getElementById("btn-cancel-save-settings"),Zo=document.getElementById("btn-close-save-settings");Jo&&(Jo.onclick=()=>{parent.postMessage({pluginMessage:{type:"get-project-name"}},"*"),Ve&&(Ve.style.display="flex",Se&&(Se.value="",Se.focus(),Se.onkeydown=e=>{e.key==="Enter"&&(e.preventDefault(),Pt&&Pt.click())}))}),Zo&&(Zo.onclick=()=>{Ve&&(Ve.style.display="none")}),Xo&&(Xo.onclick=()=>{Ve&&(Ve.style.display="none")});let Me=document.getElementById("replace-confirm-modal"),Ko=document.getElementById("replace-setting-name"),Qo=document.getElementById("btn-confirm-replace"),en=document.getElementById("btn-cancel-replace"),tn=document.getElementById("btn-close-replace-confirm"),Te=null;function on(e,t){parent.postMessage({pluginMessage:{type:"save-settings",name:e,values:t,forceReplace:!0}},"*")}Pt&&(Pt.onclick=()=>{var o,s,n,i,l,a,r,g,u,b,f,y,m,p,w,x,$;let e=(o=Se==null?void 0:Se.value)==null?void 0:o.trim();if(!e){alert("\u26A0\uFE0F Please enter a setting name");return}let t={spacingScale:((s=document.getElementById("spacing-scale"))==null?void 0:s.value)||"",spacingThreshold:((n=document.getElementById("spacing-threshold"))==null?void 0:n.value)||"100",colorScale:((i=document.getElementById("color-scale"))==null?void 0:i.value)||"",colorNameMap:J,ignoredIssues:me,fontSizeScale:((l=document.getElementById("font-size-scale"))==null?void 0:l.value)||"",fontSizeThreshold:((a=document.getElementById("font-size-threshold"))==null?void 0:a.value)||"100",lineHeightScale:((r=document.getElementById("line-height-scale"))==null?void 0:r.value)||"",lineHeightThreshold:((g=document.getElementById("line-height-threshold"))==null?void 0:g.value)||"300",lineHeightBaselineThreshold:((u=document.getElementById("line-height-baseline-threshold"))==null?void 0:u.value)||"120",typographyStyles:Z,skipNames:((b=document.getElementById("scan-skip-names"))==null?void 0:b.value)||"",typographyRules:{checkStyle:((f=document.getElementById("rule-typo-style"))==null?void 0:f.checked)||!0,checkFontFamily:((y=document.getElementById("rule-font-family"))==null?void 0:y.checked)||!0,checkFontSize:((m=document.getElementById("rule-font-size"))==null?void 0:m.checked)||!0,checkFontWeight:((p=document.getElementById("rule-font-weight"))==null?void 0:p.checked)||!0,checkLineHeight:((w=document.getElementById("rule-line-height"))==null?void 0:w.checked)||!0,checkLetterSpacing:((x=document.getElementById("rule-letter-spacing"))==null?void 0:x.checked)||!1,checkWordSpacing:(($=document.getElementById("rule-word-spacing"))==null?void 0:$.checked)||!1}};Te={name:e,values:t},parent.postMessage({pluginMessage:{type:"check-setting-name",name:e}},"*")}),Qo&&(Qo.onclick=()=>{Te&&(on(Te.name,Te.values),Te=null),Me&&(Me.style.display="none")}),en&&(en.onclick=()=>{Te=null,Me&&(Me.style.display="none"),Se&&(Se.focus(),Se.select())}),tn&&(tn.onclick=()=>{Te=null,Me&&(Me.style.display="none"),Se&&(Se.focus(),Se.select())}),Me&&(Me.onclick=e=>{e.target===Me&&(Te=null,Me.style.display="none",Se&&(Se.focus(),Se.select()))});let nn=document.getElementById("btn-load-settings"),Ge=document.getElementById("load-settings-modal"),Et=document.getElementById("settings-list"),lo=document.getElementById("settings-empty-state"),sn=document.getElementById("btn-close-load-settings");function ln(e){if(!(!Et||!lo)){if(!e||e.length===0){Et.innerHTML="",lo.style.display="block";return}lo.style.display="none",Et.innerHTML=e.map(t=>{let o=new Date(t.updatedAt||t.createdAt),s=o.toLocaleDateString()+" "+o.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});return`
        <div class="settings-item" data-setting-name="${d(t.name)}">
          <div class="settings-item-info">
            <div class="settings-item-name">${d(t.name)}</div>
            <div class="settings-item-date">Updated: ${s}</div>
          </div>
          <div class="settings-item-actions">
            <button class="btn-remove-setting" data-setting-name="${d(t.name)}" title="Remove">\u{1F5D1}\uFE0F</button>
          </div>
        </div>
      `}).join(""),Et.querySelectorAll(".settings-item").forEach(t=>{let o=t.getAttribute("data-setting-name");t.onclick=s=>{s.target.closest(".btn-remove-setting")||(parent.postMessage({pluginMessage:{type:"load-settings",name:o}},"*"),Ge&&(Ge.style.display="none"))}}),Et.querySelectorAll(".btn-remove-setting").forEach(t=>{t.onclick=o=>{o.stopPropagation();let s=t.getAttribute("data-setting-name");confirm(`\u26A0\uFE0F Are you sure you want to remove "${s}"?`)&&parent.postMessage({pluginMessage:{type:"remove-settings",name:s}},"*")}})}}nn&&(nn.onclick=()=>{parent.postMessage({pluginMessage:{type:"get-saved-settings"}},"*"),Ge&&(Ge.style.display="flex")}),sn&&(sn.onclick=()=>{Ge&&(Ge.style.display="none")});let an=document.getElementById("btn-export-settings");an&&(an.onclick=()=>{var i,l,a,r,g,u,b,f,y,m,p,w,x,$,E;let e=((i=document.getElementById("color-scale"))==null?void 0:i.value)||"",t=e.split(",").map(C=>C.trim().toUpperCase()).filter(C=>C&&C.startsWith("#")),o=De({},J),s=1;Object.values(o).forEach(C=>{if(C&&/^No name \d+$/.test(C)){let N=parseInt(C.replace("No name ",""),10);N>=s&&(s=N+1)}}),t.forEach(C=>{o[C]||(o[C]=`No name ${s}`,s++)});let n={spacingScale:((l=document.getElementById("spacing-scale"))==null?void 0:l.value)||"",spacingThreshold:((a=document.getElementById("spacing-threshold"))==null?void 0:a.value)||"100",colorScale:e,colorNameMap:o,ignoredIssues:me,fontSizeScale:((r=document.getElementById("font-size-scale"))==null?void 0:r.value)||"",fontSizeThreshold:((g=document.getElementById("font-size-threshold"))==null?void 0:g.value)||"100",lineHeightScale:((u=document.getElementById("line-height-scale"))==null?void 0:u.value)||"",lineHeightThreshold:((b=document.getElementById("line-height-threshold"))==null?void 0:b.value)||"300",lineHeightBaselineThreshold:((f=document.getElementById("line-height-baseline-threshold"))==null?void 0:f.value)||"120",typographyStyles:Z,typographyRules:{checkStyle:((y=document.getElementById("rule-typo-style"))==null?void 0:y.checked)||!0,checkFontFamily:((m=document.getElementById("rule-font-family"))==null?void 0:m.checked)||!0,checkFontSize:((p=document.getElementById("rule-font-size"))==null?void 0:p.checked)||!0,checkFontWeight:((w=document.getElementById("rule-font-weight"))==null?void 0:w.checked)||!0,checkLineHeight:((x=document.getElementById("rule-line-height"))==null?void 0:x.checked)||!0,checkLetterSpacing:(($=document.getElementById("rule-letter-spacing"))==null?void 0:$.checked)||!1,checkWordSpacing:((E=document.getElementById("rule-word-spacing"))==null?void 0:E.checked)||!1}};parent.postMessage({pluginMessage:{type:"get-project-name"}},"*"),window.pendingExportValues=n});let rn=document.getElementById("btn-import-settings"),ft=document.getElementById("import-settings-modal"),Qe=document.getElementById("import-settings-file-input"),cn=document.getElementById("btn-select-import-file"),et=document.getElementById("import-file-info"),dn=document.getElementById("import-file-name"),_e=document.getElementById("btn-confirm-import"),ao=document.getElementById("btn-cancel-import"),ro=document.getElementById("btn-close-import-settings"),yt=null,ze=null;if(rn&&(rn.onclick=()=>{yt=null,ze=null,Qe&&(Qe.value=""),et&&(et.style.display="none"),_e&&(_e.disabled=!0),ft&&(ft.style.display="flex")}),cn&&Qe&&(cn.onclick=()=>{Qe.click()}),Qe&&(Qe.onchange=e=>{let t=e.target.files[0];if(!t)return;if(!t.name.endsWith(".json")){alert("\u26A0\uFE0F Please select a JSON file");return}yt=t,dn&&(dn.textContent=t.name),et&&(et.style.display="block"),_e&&(_e.disabled=!1);let o=new FileReader;o.onload=s=>{try{ze=JSON.parse(s.target.result)}catch(n){alert("\u274C Error parsing JSON file: "+n.message),yt=null,ze=null,et&&(et.style.display="none"),_e&&(_e.disabled=!0)}},o.onerror=()=>{alert("\u274C Error reading file"),yt=null,ze=null},o.readAsText(t)}),_e&&(_e.onclick=()=>{if(!ze){alert("\u274C No file data to import");return}let e=null;if(Array.isArray(ze)){if(ze.length===0){alert("\u274C No settings found in file");return}if(e=ze[0].values,!e){alert("\u274C Invalid settings format. No values found in setting object.");return}}else if(ze.values)e=ze.values;else if(ze.spacingScale!==void 0||ze.colorScale!==void 0)e=ze;else{alert("\u274C Invalid settings file format. Expected an array of settings, a single setting object, or a values object."),console.error("Invalid import data structure:",ze);return}if(!e||typeof e!="object"){alert("\u274C Invalid settings format. No values found.");return}Vt(e),ve(),ft&&(ft.style.display="none"),yt=null,ze=null,Qe&&(Qe.value=""),et&&(et.style.display="none"),_e&&(_e.disabled=!0),alert("\u2705 Settings imported and applied to input fields successfully")}),ao||ro){let e=()=>{ft&&(ft.style.display="none"),yt=null,ze=null,Qe&&(Qe.value=""),et&&(et.style.display="none"),_e&&(_e.disabled=!0)};ao&&(ao.onclick=e),ro&&(ro.onclick=e)}Ve&&(Ve.onclick=e=>{e.target===Ve&&(Ve.style.display="none")}),Ge&&(Ge.onclick=e=>{e.target===Ge&&(Ge.style.display="none")}),ie.onclick=()=>{parent.postMessage({pluginMessage:{type:"close"}},"*")},window.onmessage=e=>{var o,s;let t=e.data.pluginMessage;if(t&&t.type==="create-color-style-result"&&(t.success?(t.issueIds&&t.issueIds.length>0&&(t.issueIds.forEach(n=>ne(n,t.message||"\u2705 Color style created",!0)),h&&h.issues&&(h.issues=h.issues.filter(n=>!t.issueIds.includes(String(n.id)))),t.issueIds.forEach(n=>{let i=document.querySelector(`.issue-grouped-card [data-node-id="${n}"]`);i&&(i.style.opacity="0.5")})),alert(t.message||"\u2705 Color style created and applied")):alert(`\u274C ${t.message||"Failed to create color style"}`)),t&&t.type==="create-color-variable-result"&&(t.success?(t.issueIds&&t.issueIds.length>0&&(t.issueIds.forEach(n=>ne(n,t.message||"\u2705 Color variable created",!0)),h&&h.issues&&(h.issues=h.issues.filter(n=>!t.issueIds.includes(String(n.id)))),t.issueIds.forEach(n=>{let i=document.querySelector(`.issue-grouped-card [data-node-id="${n}"]`);i&&(i.style.opacity="0.5")})),alert(t.message||"\u2705 Color variable created and bound")):alert(`\u274C ${t.message||"Failed to create color variable"}`)),t&&t.type==="update-fonts-result"){let n=document.getElementById("btn-update-fonts");n&&(n.disabled=!1,n.textContent="\u{1F524} Update Fonts"),t.success?alert(`\u2705 Updated fonts for ${t.count} text node(s)${t.errors>0?` (${t.errors} failed)`:""}`):alert(`\u274C ${t.message||"Failed to update fonts"}`)}if(t&&t.type==="fix-issue-result"){if(ne(t.issueId,t.message,t.success),!t.success){let n=t.message||"An error occurred while fixing the issue.";try{Rt(n)}catch(i){console.error("[fix-issue-result] Error showing error modal:",i),alert("Error: "+n)}}if(t.success&&(h&&h.issues&&(h.issues=h.issues.filter(n=>String(n.id)!==String(t.issueId))),!window._batchFixInProgress)){let n=`.issue[data-issue-id="${t.issueId}"]`,i=document.querySelectorAll(n);[...document.querySelectorAll(`button.btn-fix[data-id="${t.issueId}"]`),...document.querySelectorAll(`button.btn-suggest-fix[data-id="${t.issueId}"]`)].forEach(r=>{let g=r.closest(".issue");g&&!Array.from(i).includes(g)&&i.push(g)});let a=Array.from(new Set(Array.from(i)));if(a.length>0){let r=new Map;a.forEach(g=>{let u=g.closest(".issue-group");if(u){let b=u.getAttribute("data-issue-type");if(!r.has(b)){let y=u.querySelector(".badge");if(y){let m=parseInt(y.textContent)||0;r.set(b,{groupEl:u,badge:y,currentCount:m,removeCount:0})}}let f=r.get(b);f&&f.removeCount++}}),a.forEach(g=>{g.style.transition="opacity 0.3s ease-out",g.style.opacity="0",setTimeout(()=>{g.parentNode&&g.remove()},300)}),setTimeout(()=>{r.forEach(g=>{let u=Math.max(0,g.currentCount-g.removeCount);g.badge.textContent=u,u===0&&(g.groupEl.style.display="none")}),Ze(),h&&h.issues&&He(h.issues,!1)},350)}else Ze(),h&&h.issues&&He(h.issues,!1)}return}if(t&&t.type==="create-text-style-result"){window._createStyleSuccessIds||(window._createStyleSuccessIds=[]),window._createStylePendingTimer||(window._createStylePendingTimer=null),t.success&&t.issueId&&window._createStyleSuccessIds.push(t.issueId),window._createStylePendingTimer&&clearTimeout(window._createStylePendingTimer),window._createStylePendingTimer=setTimeout(()=>{let n=window._createStyleSuccessIds||[];window._createStyleSuccessIds=[],window._createStylePendingTimer=null,n.length>0&&h&&h.issues&&(h.issues=h.issues.filter(i=>!(n.includes(i.id)||i.subIssues&&i.subIssues.length>0&&(i.subIssues=i.subIssues.filter(l=>!n.includes(l.id)),i.subIssues.length===0))),He(h.issues,!1))},500);return}if(t&&t.type==="components-for-issue-loaded"){let n=window.pendingComponentIssue;if(n){let i=document.querySelector(`.issue[data-issue-id="${n.id}"]`);if(i){let l=i.querySelector("button.btn-suggest-fix");l&&(l.disabled=!1,l.style.opacity="1",l.style.cursor="pointer",l.dataset.originalText&&(l.textContent=l.dataset.originalText,delete l.dataset.originalText))}}if(t.similarComponents&&t.similarComponents.length>0){let i=n||{id:t.issueId,nodeName:"Unnamed"};try{Jn(i,t.similarComponents)}catch(l){console.error("[components-for-issue-loaded] Error showing modal:",l),alert("Error showing component suggestion modal: "+l.message)}window.pendingComponentIssue=null;return}else{console.warn("[components-for-issue-loaded] No similar components found"),alert("No similar components found. Please use 'Select Component' to choose from all components or 'Create New Component' to create a new one."),window.pendingComponentIssue=null;return}}if(t&&t.type==="all-components-loaded"){let n=window.pendingSelectComponentIssue;if(n){let i=document.querySelector(`.issue[data-issue-id="${n.id}"]`);if(i){let l=i.querySelector("button.btn-select-component");l&&(l.disabled=!1,l.style.opacity="1",l.style.cursor="pointer",l.dataset.originalText&&(l.textContent=l.dataset.originalText,delete l.dataset.originalText))}}if(t.components&&t.components.length>0){let i=n||{id:t.issueId,nodeName:"Unnamed"};try{Xn(i,t.components)}catch(l){console.error("[all-components-loaded] \u2717 Error showing modal:",l),console.error("[all-components-loaded] Error stack:",l.stack),alert("Error showing component selection modal: "+l.message)}window.pendingSelectComponentIssue=null;return}else{console.warn("[all-components-loaded] \u2717 No components available"),alert("No components found. Please use 'Create New Component' to create a new one."),window.pendingSelectComponentIssue=null;return}}if(t&&t.type==="figma-text-styles-loaded"){let n=window.pendingSuggestTextSizeIssue;if(n&&n.id===t.issueId){let g=n.fontSize||12,u=(t.styles||[]).filter(y=>y.fontSize>=14);if(u.length===0){let y=at(n);y?Nt(n,g,y,null,null):alert("No suitable text size match found (need >= 14px for ADA compliance). Please add font sizes to Font Size input or create text styles in Figma."),window.pendingSuggestTextSizeIssue=null;return}let b=null,f=1/0;u.forEach(y=>{let m=Math.abs(y.fontSize-g);m<f&&(f=m,b=y)}),b?Nt(n,g,b.fontSize,null,b):alert("No suitable text style found (need >= 14px for ADA compliance)"),window.pendingSuggestTextSizeIssue=null;return}let i=window.pendingTextSizeIssue;if(i&&i.id===t.issueId){Kn(i,t.styles||[]),window.pendingTextSizeIssue=null;return}let l=window.pendingTypographyStyleIssue;if(l&&l.id===t.issueId){if(t.error||!t.styles||t.styles.length===0){let g=document.querySelector(`.issue[data-issue-id="${t.issueId}"]`);if(g){let u=g.querySelector("button.btn-fix"),b=g.querySelector("button.btn-suggest-fix");u&&(u.style.display="none"),b&&(b.style.display="none")}window.pendingTypographyStyleIssue=null;return}$o(l,t.styles||[]),window.pendingTypographyStyleIssue=null;return}let a=window.pendingTypographyCheckIssue;if(a&&a.id===t.issueId){if(t.error||!t.styles||t.styles.length===0){let u=document.querySelector(`.issue[data-issue-id="${t.issueId}"]`);if(u){let b=u.querySelector("button.btn-style-dropdown"),f=u.querySelector("button.btn-suggest-fix");b&&(b.style.display="none"),f&&(f.style.display="none")}window.pendingTypographyCheckIssue=null;return}let g=t.styles||[];a.type==="text-size-mobile"&&(g=g.filter(u=>u.fontSize>12)),$o(a,g),window.pendingTypographyCheckIssue=null;return}let r=document.querySelector(`.style-dropdown-menu[data-issue-id="${t.issueId}"]`);if(r){let g=r.closest(".issue"),u=g?g.getAttribute("data-issue-id"):null,b=g?g.getAttribute("data-issue-type"):null;if(t.error){r.innerHTML=`<div style="padding: 8px 12px; color: #ef4444; font-size: 12px;">Error: ${d(t.error)}</div>`;let f=g?g.querySelector("button.btn-style-dropdown"):null;f&&(f.style.display="none");let y=g?g.querySelector("button.btn-suggest-fix"):null;y&&(b==="typography-style"||b==="typography-check")&&(y.style.display="none")}else if(t.styles&&t.styles.length>0){let f=null;if(u&&h&&h.issues){let y=h.issues.find(m=>m.id===u);y&&y.bestMatch&&(f=y.bestMatch.name)}r.innerHTML=t.styles.map(y=>`
            <div class="style-dropdown-item" data-issue-id="${t.issueId}" data-style-id="${y.id}" data-style-name="${d(y.name)}" style="padding: 8px 12px; cursor: pointer; font-size: 12px; ${f===y.name?"background: #e3f2fd; font-weight: 600;":""}" onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background='${f===y.name?"#e3f2fd":"white"}'">
              ${d(y.name)} ${f===y.name?"\u2B50":""}
            </div>
          `).join(""),r.querySelectorAll(".style-dropdown-item").forEach(y=>{y.onclick=m=>{m.preventDefault(),m.stopPropagation();try{let x=y.getAttribute("data-issue-id");x&&parent.postMessage({pluginMessage:{type:"select-node",id:x}},"*")}catch(x){console.error("Failed to auto-select node for style dropdown item:",x)}let p=y.getAttribute("data-style-id"),w=y.getAttribute("data-style-name");if(g&&h&&h.issues){let x=h.issues.find($=>$.id===u);if(x){let $=t.styles.find(E=>E.id===p);$&&(r.style.display="none",Qt(x,$))}}}})}else{r.innerHTML='<div style="padding: 8px 12px; color: #999; font-size: 12px;">No text styles found in Figma</div>';let f=g?g.querySelector("button.btn-style-dropdown"):null;f&&(f.style.display="none");let y=g?g.querySelector("button.btn-suggest-fix"):null;y&&(b==="typography-style"||b==="typography-check")&&(y.style.display="none")}}return}if(t&&t.type==="contrast-colors-loaded"){let n=window.pendingContrastIssue;n&&n.id===t.issueId&&(Qn(n,t.colors||[]),window.pendingContrastIssue=null);return}if(t&&t.type==="apply-typography-style-result"){if(ne(t.issueId,t.message,t.success),t.success||Rt(t.message||"An error occurred while applying the style."),t.success){let n=["typography-check","typography-style","typography"];h&&h.issues&&(h.issues=h.issues.filter(i=>!(String(i.id)===String(t.issueId)&&n.includes(i.type)))),window._batchFixInProgress||setTimeout(()=>{Ze(),h&&h.issues&&He(h.issues,!1)},350)}return}if(t&&t.type==="apply-typography-style-batch-result"){if(t.success&&t.successIds&&t.successIds.length>0){let n=["typography-check","typography-style","typography"],i=new Set(t.successIds.map(String));h&&h.issues&&(h.issues=h.issues.filter(l=>!(i.has(String(l.id))&&n.includes(l.type)))),ne(t.successIds[0],t.message,!0),setTimeout(()=>{Ze(),h&&h.issues&&He(h.issues,!1)},350)}else Rt(t.message||"An error occurred while applying styles.");return}if(t&&t.type==="bind-color-variable-result"){ne(t.issueId,t.message,t.success),t.success&&(h&&h.issues&&(h.issues=h.issues.filter(n=>!(String(n.id)===String(t.issueId)&&n.type==="color-variable"))),window._batchFixInProgress||setTimeout(()=>{Ze(),h&&h.issues&&He(h.issues,!1)},350));return}if(t&&t.type==="bind-color-variable-batch-result"){if(t.success&&t.successIds&&t.successIds.length>0){let n=new Set(t.successIds.map(String));h&&h.issues&&(h.issues=h.issues.filter(i=>i.type!=="color-variable"?!0:!(n.has(String(i.id))||i.subIssues&&(i.subIssues=i.subIssues.filter(l=>!n.has(String(l.id))),i.subIssues.length===0)))),setTimeout(()=>{Ze(),h&&h.issues&&He(h.issues,!1)},350)}return}if(t&&t.type==="scan-progress"){M&&L&&(M.style.width=t.progress+"%",L.textContent=t.progress+"% ("+t.current+"/"+t.total+")");return}if(t&&t.type==="node-count-result"){let n=t.count||0,i=t.mode||"page";n>Xe?confirm(`\u26A0\uFE0F Large Design Warning

This ${i==="page"?"page":"selection"} contains ${n.toLocaleString()} nodes.

Scanning large designs may take a while and could slow down Figma.

Do you want to continue?`)&&xe?Lo(xe.scope):(I&&(I.disabled=!1,I.textContent="Scan Issues"),v&&(v.style.display="none")):xe&&Lo(xe.scope),xe=null;return}if(t&&t.type==="last-report"){t.report&&Cn(t.report);return}if(t&&t.type==="history-data"){fs(t.history),ms();let n=document.getElementById("history-panel");n&&n.style.display!=="none"&&so();return}if(t&&t.type==="input-values-data"){t.values&&Vt(t.values);return}if(t&&t.type==="project-name"){let n=t.name||"settings";if(window.pendingExportValues){let i=window.pendingExportValues;window.pendingExportValues=null;let l={name:n,values:i,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()},a=JSON.stringify([l],null,2),r=new Blob([a],{type:"application/json"}),g=URL.createObjectURL(r),u=document.createElement("a");u.href=g;let b=n.replace(/[^a-z0-9]/gi,"_").toLowerCase();u.download=`${b}-settings.json`,document.body.appendChild(u),u.click(),document.body.removeChild(u),URL.revokeObjectURL(g);return}Se&&(Se.value=n);return}if(t&&t.type==="check-setting-name-result"){t.exists?(Ko&&Te&&(Ko.textContent=t.name||Te.name),Me&&(Me.style.display="flex")):Te&&(on(Te.name,Te.values),Te=null);return}if(t&&t.type==="save-settings-result"){t.success?(Me&&(Me.style.display="none"),Ve&&(Ve.style.display="none"),Se&&(Se.value=""),Te=null,Ge&&Ge.style.display!=="none"&&parent.postMessage({pluginMessage:{type:"get-saved-settings"}},"*")):(alert("\u274C Failed to save settings: "+(t.error||"Unknown error")),Me&&(Me.style.display="none"),Te=null);return}if(t&&t.type==="saved-settings-list"){ln(t.settings||[]);return}if(t&&t.type==="project-name"){let n=t.name||"settings";if(window.pendingExportValues){let i=window.pendingExportValues;window.pendingExportValues=null;let l={name:n,values:i,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()},a=JSON.stringify([l],null,2),r=new Blob([a],{type:"application/json"}),g=URL.createObjectURL(r),u=document.createElement("a");u.href=g;let b=n.replace(/[^a-z0-9]/gi,"_").toLowerCase();u.download=`${b}-settings.json`,document.body.appendChild(u),u.click(),document.body.removeChild(u),URL.revokeObjectURL(g)}return}if(t&&t.type==="load-settings-result"){t.success&&t.values?(Vt(t.values),ve()):alert("\u274C Failed to load settings: "+(t.error||"Unknown error"));return}if(t&&t.type==="remove-settings-result"){t.success?ln(t.settings||[]):alert("\u274C Failed to remove settings: "+(t.error||"Unknown error"));return}if(t&&t.type==="report"){I.style.display="block",I.disabled=!1,z.style.display="none",v.style.display="none",B.disabled=!1;let n=t.issues||[];h.context=t.context||null,h.disabledChecks=t.disabledChecks||[],He(n);let i=((o=document.querySelector('input[name="scope"]:checked'))==null?void 0:o.value)||"page";_o(i,"issues",{issues:n},t.context||null)}if(t&&t.type==="tokens-report")if(B.style.display="block",B.disabled=!1,z.style.display="none",v.style.display="none",I.disabled=!1,t.error)fe.innerHTML=`<div class="error-message">Error: ${d(t.error)}</div>`,Ue("tokens");else{h.context=t.context||null,It(t.tokens),D.disabled=!(t.tokens&&Array.isArray(t.tokens.spacing)&&t.tokens.spacing.length>0),Y.disabled=!(t.tokens&&Array.isArray(t.tokens.colors)&&t.tokens.colors.length>0),P.disabled=!(t.tokens&&Array.isArray(t.tokens.fontSize)&&t.tokens.fontSize.length>0),U.disabled=!(t.tokens&&Array.isArray(t.tokens.lineHeight)&&t.tokens.lineHeight.length>0);let n=((s=document.querySelector('input[name="scope"]:checked'))==null?void 0:s.value)||"page";_o(n,"tokens",{tokens:t.tokens},t.context||null)}if(t&&t.type==="typography-styles-extracted")if(t.styles&&Array.isArray(t.styles)&&t.styles.length>0){let n=t.mode==="desktop"?"Desktop":t.mode==="tablet"?"Tablet":t.mode==="mobile"?"Mobile":"All";Z=t.styles.map((i,l)=>({id:l+1,name:i.name,styleId:i.styleId,fontFamily:i.fontFamily,fontSize:i.fontSize,fontWeight:i.fontWeight,lineHeight:i.lineHeight,letterSpacing:i.letterSpacing||"0",wordSpacing:i.wordSpacing||"0"})),nt=Z.length+1,ee(),Ke(),ve(),alert(`\u2705 Successfully imported ${t.styles.length} ${n} typography styles from Figma!

Styles: ${t.styles.map(i=>i.name).join(", ")}`)}else{let n=t.mode==="desktop"?"Desktop":t.mode==="tablet"?"Tablet":t.mode==="mobile"?"Mobile":"";alert(`\u26A0\uFE0F No ${n.toLowerCase()} text styles found in this Figma file.

Make sure you have defined text styles in your design system.`)}if(t&&t.type==="color-styles-extracted")if(t.colors&&Array.isArray(t.colors)&&t.colors.length>0){let n=document.getElementById("color-scale");if(!n)return;let l=Array.from(new Set(t.colors.map(a=>a.hex))).sort((a,r)=>ct(a)-ct(r));J={},t.colors.forEach(a=>{a.hex&&a.name&&(J[a.hex.toUpperCase()]=a.name)}),n.value=l.join(", "),typeof je=="function"&&je(),ve();try{n.focus(),n.setSelectionRange(n.value.length,n.value.length)}catch(a){}alert(`\u2705 Successfully imported ${t.colors.length} color styles from Figma!

Colors: ${t.colors.map(a=>a.name+" ("+a.hex+")").join(", ")}`)}else alert(`\u26A0\uFE0F No color styles found in this Figma file.

Make sure you have defined color styles (paint styles) in your design system.`);if(t&&t.type==="color-variables-extracted")if(t.colors&&Array.isArray(t.colors)&&t.colors.length>0){let n=document.getElementById("color-scale");if(!n)return;let l=Array.from(new Set(t.colors.map(a=>a.hex))).sort((a,r)=>ct(a)-ct(r));J={},t.colors.forEach(a=>{a.hex&&a.name&&(J[a.hex.toUpperCase()]=a.name)}),n.value=l.join(", "),typeof je=="function"&&je(),ve();try{n.focus(),n.setSelectionRange(n.value.length,n.value.length)}catch(a){}alert(`\u2705 Successfully imported ${t.colors.length} color variables from Figma!

Colors: ${t.colors.map(a=>a.name+" ("+a.hex+")").join(", ")}`)}else alert(`\u26A0\uFE0F No color variables found in this Figma file.

Make sure you have defined color variables in your design system.`)}})();})();
