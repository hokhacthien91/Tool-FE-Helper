(()=>{var ol=Object.defineProperty,nl=Object.defineProperties;var ll=Object.getOwnPropertyDescriptors;var sn=Object.getOwnPropertySymbols;var sl=Object.prototype.hasOwnProperty,il=Object.prototype.propertyIsEnumerable;var an=(v,C,y)=>C in v?ol(v,C,{enumerable:!0,configurable:!0,writable:!0,value:y}):v[C]=y,Ke=(v,C)=>{for(var y in C||(C={}))sl.call(C,y)&&an(v,y,C[y]);if(sn)for(var y of sn(C))il.call(C,y)&&an(v,y,C[y]);return v},ot=(v,C)=>nl(v,ll(C));function rn(){function v(C){try{let y=C.target&&C.target.closest?C.target.closest("button"):null;if(!y)return;let w=y.closest?y.closest(".issue"):null;if(!w||!(y.closest&&y.closest(".issue-actions")))return;let I=y.getAttribute("data-id")||w.getAttribute("data-issue-id");if(!I)return;parent.postMessage({pluginMessage:{type:"select-node",id:I}},"*")}catch(y){console.error("autoSelectNodeFromIssueClick error:",y)}}document.addEventListener("click",v,!0)}function re(v,C,y){if(!C)return;let w=document.querySelector(`.issue[data-issue-id="${v}"]`);if(!w){let _=document.querySelector(`button.btn-fix[data-id="${v}"]`);_&&(w=_.closest(".issue"))}if(!w)return;let $=w.querySelector(".fix-message");$&&$.remove();let I=document.createElement("div");I.className="fix-message",I.style.cssText=`
      margin-top: 8px;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
      background: ${y?"#d4edda":"#f8d7da"};
      color: ${y?"#155724":"#721c24"};
      border: 1px solid ${y?"#c3e6cb":"#f5c6cb"};
      animation: slideIn 0.3s ease-out;
    `,I.textContent=C;let R=w.querySelector(".issue-header");R?R.parentNode.insertBefore(I,R.nextSibling):w.appendChild(I),setTimeout(()=>{I.style.animation="slideOut 0.3s ease-out",setTimeout(()=>{I.parentNode&&I.remove()},300)},5e3)}function u(v){return v==null?"":String(v).replace(/[&<>"']/g,function(y){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[y]})}function to(v){console.log("[showErrorModal] Called with message:",v);let C=document.getElementById("error-modal-overlay");C&&(console.log("[showErrorModal] Removing existing modal"),C.remove());let y=document.createElement("div");y.className="modal-overlay",y.id="error-modal-overlay",console.log("[showErrorModal] Created overlay element");let w=document.createElement("div");w.className="modal-dialog",w.style.maxWidth="450px";let $=String(v||"").replace(/^[❌⚠️✅]\s*/,"").trim();w.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title" style="color: #dc3545;">\u26A0\uFE0F Error</h2>
      </div>
      <div class="modal-body">
        <div style="padding: 16px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 14px; color: #721c24; line-height: 1.6;">
            ${u($)}
          </div>
        </div>
        <div style="font-size: 12px; color: #666; line-height: 1.5;">
          Please check the issue and try again. If the problem persists, you may need to switch to Design Mode or edit the main component directly.
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-primary" id="error-modal-ok-btn" style="background: #dc3545; border-color: #dc3545; color: white;">OK</button>
      </div>
    `,y.appendChild(w),document.body.appendChild(y),console.log("[showErrorModal] Appended overlay to body, overlay visible:",y.offsetParent!==null),y.style.display="flex",y.style.visibility="visible",y.style.opacity="1";let I=w.querySelector("#error-modal-ok-btn"),R=w.querySelector(".modal-close");if(console.log("[showErrorModal] Found buttons:",{okBtn:!!I,closeBtn:!!R}),!I){console.error("[showErrorModal] OK button not found!");return}let _=()=>{y.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{y.parentNode&&y.remove()},200)};I.onclick=_,R&&(R.onclick=_),y.onclick=O=>{O.target===y&&_()},setTimeout(()=>{I.focus()},100),console.log("[showErrorModal] Modal setup complete")}function dt(v){if(!v)return 0;let C=String(v).replace("#","");if(C.length<6)return 0;let y=parseInt(C.substring(0,2),16),w=parseInt(C.substring(2,4),16),$=parseInt(C.substring(4,6),16);return isNaN(y)||isNaN(w)||isNaN($)?0:(y*299+w*587+$*114)/1e3}function qt(v,C){let y=String(v||"").replace("#",""),w=String(C||"").replace("#","");if(y.length<6||w.length<6)return 1/0;let $=parseInt(y.substring(0,2),16),I=parseInt(y.substring(2,4),16),R=parseInt(y.substring(4,6),16),_=parseInt(w.substring(0,2),16),O=parseInt(w.substring(2,4),16),L=parseInt(w.substring(4,6),16);if([$,I,R,_,O,L].some(G=>isNaN(G)))return 1/0;let U=_-$,V=O-I,B=L-R;return Math.sqrt(U*U+V*V+B*B)}function cn(v){let C=String(v||"").replace("#","");if(C.length<6)return 0;let y=parseInt(C.substring(0,2),16)/255,w=parseInt(C.substring(2,4),16)/255,$=parseInt(C.substring(4,6),16)/255;if(isNaN(y)||isNaN(w)||isNaN($))return 0;let I=y<=.03928?y/12.92:Math.pow((y+.055)/1.055,2.4),R=w<=.03928?w/12.92:Math.pow((w+.055)/1.055,2.4),_=$<=.03928?$/12.92:Math.pow(($+.055)/1.055,2.4);return .2126*I+.7152*R+.0722*_}function Pt(v,C){let y=cn(v),w=cn(C),$=Math.max(y,w),I=Math.min(y,w);return($+.05)/(I+.05)}function St(v){if(!v||!v.message)return null;let y=(v.message||"").match(/Color (#[0-9A-Fa-f]{6})/),w=y?y[1].toUpperCase():null;if(!w)return null;let $=document.getElementById("color-scale");if(!$||!$.value.trim())return null;let I=$.value.split(",").map(O=>O.trim().toUpperCase()).filter(O=>O&&O.startsWith("#"));if(I.length===0)return null;let R=null,_=1/0;return I.forEach(O=>{let L=qt(w,O);L<_&&(_=L,R=O)}),_>100?null:R}function kt(v){if(!v||!v.message)return null;let y=(v.message||"").match(/\((\d+)px\)/);if(!y)return null;let w=parseInt(y[1],10);if(isNaN(w))return null;let $=document.getElementById("spacing-scale");if(!$||!$.value.trim())return null;let I=$.value.split(",").map(L=>parseInt(L.trim(),10)).filter(L=>!isNaN(L)&&L>=0).sort((L,U)=>L-U);if(I.length===0)return null;let R=null,_=1/0;I.forEach(L=>{let U=Math.abs(L-w);U<_&&(_=U,R=L)});let O=Math.max(w*.2,10);return _>O?null:R}function al(v,C){if(!v||v.length===0){alert("No typography styles available. Please add styles in Typography Settings.");return}let y=document.createElement("div");y.className="modal-overlay",y.style.zIndex="10001";let w=document.createElement("div");w.className="modal-dialog",w.style.maxWidth="300px",w.style.padding="0",w.innerHTML=`
      <div class="modal-header" style="padding: 16px;">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title" style="font-size: 14px;">Choose Typography Style</h2>
      </div>
      <div style="max-height: 300px; overflow-y: auto;">
        ${v.map(I=>{let R=u(I.name||""),_=u(I.fontFamily||""),O=u(I.fontSize||""),L=u(I.fontWeight||"");return`
          <div class="style-dropdown-item" data-style-id="${I.id}" style="padding: 12px 16px; cursor: pointer; font-size: 13px; border-bottom: 1px solid #f0f0f0;" onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background='white'">
            <div style="font-weight: 600; color: #333;">${R}</div>
            <div style="font-size: 11px; color: #666; margin-top: 4px;">
              ${_} ${O}px ${L}
            </div>
          </div>
        `}).join("")}
      </div>
    `,y.appendChild(w),document.body.appendChild(y);let $=()=>{y.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{y.parentNode&&y.remove()},200)};w.querySelector(".modal-close").onclick=$,y.onclick=I=>{I.target===y&&$()},w.querySelectorAll(".style-dropdown-item").forEach(I=>{I.onclick=R=>{R.preventDefault(),R.stopPropagation();let _=parseInt(I.getAttribute("data-style-id"),10),O=v.find(L=>L.id===_);O&&C&&(C(O),$())}})}function dn(v,C){if(!v||!v.bestMatch){console.error("showTypographyFixModal: missing issue or bestMatch");return}let y=v.nodeProps||{},w=v.bestMatch,$=y.fontFamily||"",I=y.fontSize!==null&&y.fontSize!==void 0?y.fontSize:"",R=y.fontWeight||"",_=y.lineHeight||"",O=y.letterSpacing!==null&&y.letterSpacing!==void 0?y.letterSpacing:"",L=$,U=I,V=R,B=_,G=O;w.differences&&w.differences.forEach(Y=>{Y.property==="Font Family"&&Y.expected?L=Y.expected:Y.property==="Font Size"&&Y.expected?U=Y.expected.replace("px",""):Y.property==="Font Weight"&&Y.expected?V=Y.expected:Y.property==="Line Height"&&Y.expected?B=Y.expected:Y.property==="Letter Spacing"&&Y.expected&&(G=Y.expected)});let ae=document.createElement("div");ae.className="modal-overlay",ae.id="typography-fix-modal-overlay";let Z=document.createElement("div");Z.className="modal-dialog",Z.style.maxWidth="500px",Z.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Fix Typography Style</h2>
        <p class="modal-subtitle">Node: ${u(v.nodeName||"Unnamed")} \u2192 Suggested: ${u(w.name)}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">
            Edit values below and click Apply to fix:
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Font Family</label>
            <input type="text" class="modal-input" id="fix-font-family" value="${u(L)}" style="width: 100%;" />
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Font Size (px)</label>
            <input type="number" class="modal-input" id="fix-font-size" value="${u(U)}" style="width: 100%;" />
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Font Weight</label>
            <select class="modal-input" id="fix-font-weight" style="width: 100%;">
              <option value="Regular" ${V==="Regular"?"selected":""}>Regular</option>
              <option value="Medium" ${V==="Medium"?"selected":""}>Medium</option>
              <option value="SemiBold" ${V==="SemiBold"||V==="Semi Bold"?"selected":""}>SemiBold</option>
              <option value="Bold" ${V==="Bold"?"selected":""}>Bold</option>
            </select>
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Line Height (% or px or auto)</label>
            <input type="text" class="modal-input" id="fix-line-height" value="${u(B)}" style="width: 100%;" placeholder="e.g. 120%, 24px, auto" />
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Letter Spacing (px or %)</label>
            <input type="text" class="modal-input" id="fix-letter-spacing" value="${u(G)}" style="width: 100%;" placeholder="e.g. 0, 0.5px, 1%" />
          </div>

          <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #eee;">
            <button class="modal-btn modal-btn-cancel" id="choose-typo-style-btn" style="width: 100%; margin-bottom: 8px; background: #0071e3; border-color: #0071e3; color: white;">
              Choose Typography Style
            </button>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="typography-fix-modal-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="typography-fix-modal-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,ae.appendChild(Z),document.body.appendChild(ae);let oe=Z.querySelector("#fix-font-family"),ne=Z.querySelector("#fix-font-size"),me=Z.querySelector("#fix-font-weight"),ee=Z.querySelector("#fix-line-height"),le=Z.querySelector("#fix-letter-spacing"),H=Z.querySelector("#choose-typo-style-btn"),pe=Z.querySelector("#typography-fix-modal-cancel-btn"),J=Z.querySelector("#typography-fix-modal-apply-btn"),ue=Z.querySelector(".modal-close");setTimeout(()=>{oe.focus()},100);let k=()=>{ae.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{ae.parentNode&&ae.remove()},200)};pe.onclick=k,ue.onclick=k,ae.onclick=Y=>{Y.target===ae&&k()},H.onclick=()=>{al(C,Y=>{Y&&(oe.value=Y.fontFamily||"",ne.value=Y.fontSize||"",me.value=Y.fontWeight||"Regular",ee.value=Y.lineHeight||"",le.value=Y.letterSpacing||"0")})},J.onclick=()=>{let Y={fontFamily:oe.value.trim(),fontSize:ne.value.trim(),fontWeight:me.value,lineHeight:ee.value.trim(),letterSpacing:le.value.trim()};if(!Y.fontFamily){oe.focus(),oe.style.borderColor="#ff3b30",setTimeout(()=>{oe.style.borderColor="#0071e3"},2e3);return}if(!Y.fontSize||isNaN(parseFloat(Y.fontSize))){ne.focus(),ne.style.borderColor="#ff3b30",setTimeout(()=>{ne.style.borderColor="#0071e3"},2e3);return}k(),re(v.id,"\u23F3 Fixing...",!0),parent.postMessage({pluginMessage:{type:"fix-issue",issue:v,fixData:Y}},"*")}}function rl(v,C){if(v===C)return 100;let y=100,w=Math.abs(v-C);return Math.max(0,Math.round((1-w/y)*100))}function pn(v,C,y,w){let $=document.createElement("div");$.className="modal-overlay",$.id="spacing-picker-modal-overlay";let I=document.createElement("div");I.className="modal-dialog",I.style.maxWidth="400px";let R=w.map(B=>`
        <div class="spacing-picker-item" data-value="${B}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 1px solid ${y===B?"#0071e3":"#ddd"};
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='${y===B?"#0071e3":"#ddd"}'; this.style.boxShadow='none'">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="
              width: 40px;
              height: 40px;
              border-radius: 4px;
              background: #f0f0f0;
              border: 1px solid #ddd;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 12px;
              font-weight: 600;
              color: #666;
            ">${B}px</div>
            <div style="font-weight: 600; font-size: 12px; color: #333;">
              ${B}px
            </div>
          </div>
          ${y===B?'<div style="color: #0071e3; font-weight: 600;">Current</div>':""}
        </div>
      `).join(""),_=String(C||"").replace(/([A-Z])/g," $1").replace(/^./,B=>B.toUpperCase()).trim();I.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Spacing Value</h2>
        <p class="modal-subtitle">Node: ${u(v.nodeName||"Unnamed")} - ${u(_)}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Value:</div>
          <div style="font-size: 16px; font-weight: 600; color: #333;">${y}px</div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${R}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="spacing-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,$.appendChild(I),document.body.appendChild($);let O=I.querySelector("#spacing-picker-modal-cancel-btn"),L=I.querySelector(".modal-close"),U=I.querySelectorAll(".spacing-picker-item"),V=()=>{$.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{$.parentNode&&$.remove()},200)};O.onclick=V,L.onclick=V,$.onclick=B=>{B.target===$&&V()},U.forEach(B=>{B.onclick=G=>{G.preventDefault(),G.stopPropagation();let ae=parseInt(B.getAttribute("data-value"),10);V(),Rt(v,C,y,ae)}})}function Rt(v,C,y,w,$=[],I={}){let{onApply:R,onIgnore:_,onCancel:O,showIgnore:L=!1,progress:U}=I,V=String(C||"").replace(/([A-Z])/g," $1").replace(/^./,X=>X.toUpperCase()).trim(),G=($.length>0?$:[0,4,8,12,16,24,32,40,48,64,72,80,88,96]).map(X=>({value:X,similarity:rl(y,X),diff:Math.abs(y-X)})).sort((X,fe)=>w!==void 0&&X.value===w?-1:w!==void 0&&fe.value===w?1:X.diff-fe.diff).slice(0,5);if(G.length===0){alert("No spacing values available");return}let ae=G[0].value,Z=(X,fe)=>{let Se=X.value!==y;return`
      <div class="spacing-option-item" data-value="${X.value}" style="
        padding: 10px 12px;
        margin-bottom: 6px;
        border: 1px solid ${fe?"#0071e3":"#e0e0e0"};
        border-radius: 8px;
        cursor: pointer;
        background: ${fe?"#e3f2fd":"white"};
        display: flex;
        align-items: center;
        gap: 12px;
        transition: all 0.15s;
      ">
        <input type="radio" name="spacing-option" ${fe?"checked":""} style="margin: 0; cursor: pointer;" />
        <div style="
          width: 40px;
          height: 40px;
          border-radius: 6px;
          background: ${fe?"#e3f2fd":"#f0f0f0"};
          border: 1px solid ${fe?"#0071e3":"#ddd"};
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 12px;
          font-weight: 600;
          color: ${fe?"#0071e3":"#666"};
          flex-shrink: 0;
        ">${X.value}</div>
        <div style="flex: 1;">
          <div style="font-weight: 600; font-size: 13px; color: #333;">${X.value}px</div>
          <div style="font-size: 10px; color: ${Se?"#721c24":"#155724"};">
            ${Se?`\u26A0 \u0394${X.value>y?"+":""}${X.value-y}px`:"\u2713 Same"}
          </div>
        </div>
        <span style="font-size: 11px; color: #666; background: #f0f0f0; padding: 2px 8px; border-radius: 10px;">${X.similarity}%</span>
      </div>
    `},oe=document.createElement("div");oe.className="modal-overlay",oe.id="spacing-fix-confirm-modal-overlay";let ne=document.createElement("div");ne.className="modal-dialog",ne.style.maxWidth="420px";let me=U?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${U.current}/${U.total}</div>`:"",ee=G.map((X,fe)=>Z(X,fe===0)).join("");ne.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Spacing</h2>
        <p class="modal-subtitle">Node: ${u(v.nodeName||"Unnamed")} - ${u(V)}</p>
      </div>
      ${me}
      <div class="modal-body">
        <div style="margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 6px; display: flex; align-items: center; gap: 10px;">
          <div style="
            width: 40px;
            height: 40px;
            border-radius: 4px;
            background: #f0f0f0;
            border: 1px solid #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
            color: #666;
          ">${y}</div>
          <div>
            <div style="font-size: 11px; color: #666;">Current ${u(V)}:</div>
            <div style="font-size: 14px; font-weight: 600;">${y}px</div>
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px;">
          Select a value to apply (Top 5 closest):
        </div>
        <div id="spacing-options-container" style="max-height: 280px; overflow-y: auto;">
          ${ee}
        </div>
      </div>
      <div class="modal-footer">
        ${L?'<button class="modal-btn modal-btn-cancel" id="spacing-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="spacing-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="spacing-fix-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,oe.appendChild(ne),document.body.appendChild(oe);let le=ne.querySelector("#spacing-fix-confirm-cancel-btn"),H=ne.querySelector("#spacing-fix-confirm-apply-btn"),pe=ne.querySelector("#spacing-fix-ignore-btn"),J=ne.querySelector(".modal-close"),ue=ne.querySelector("#spacing-options-container"),k=X=>{ae=X,ue.querySelectorAll(".spacing-option-item").forEach(Se=>{let Q=parseInt(Se.getAttribute("data-value"),10)===X;Se.style.border=Q?"2px solid #0071e3":"2px solid #e0e0e0",Se.style.background=Q?"#e3f2fd":"white";let nt=Se.querySelector('input[type="radio"]');nt&&(nt.checked=Q)})};(()=>{ue.querySelectorAll(".spacing-option-item").forEach(fe=>{fe.onclick=Se=>{Se.preventDefault();let Oe=parseInt(fe.getAttribute("data-value"),10);k(Oe)}})})();let te=()=>{oe.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{oe.parentNode&&oe.remove()},200)};le.onclick=()=>{te(),O&&typeof O=="function"&&O()},J.onclick=()=>{te(),O&&typeof O=="function"&&O()},oe.onclick=X=>{X.target===oe&&(te(),O&&typeof O=="function"&&O())},H.onclick=()=>{te(),re(v.id,"\u23F3 Fixing spacing...",!0),parent.postMessage({pluginMessage:{type:"fix-spacing-issue",issue:v,propertyName:C,value:ae}},"*"),R&&typeof R=="function"&&R()},pe&&(pe.onclick=()=>{te(),_&&typeof _=="function"&&_()})}function wt(v){try{let C=parseInt(v.slice(1,3),16),y=parseInt(v.slice(3,5),16),w=parseInt(v.slice(5,7),16);return(C*299+y*587+w*114)/1e3>128?"#000000":"#ffffff"}catch(C){return"#000000"}}function cl(v,C){let y=v.replace("#",""),w=C.replace("#",""),$=parseInt(y.substr(0,2),16),I=parseInt(y.substr(2,2),16),R=parseInt(y.substr(4,2),16),_=parseInt(w.substr(0,2),16),O=parseInt(w.substr(2,2),16),L=parseInt(w.substr(4,2),16);return Math.sqrt(Math.pow($-_,2)+Math.pow(I-O,2)+Math.pow(R-L,2))}function dl(v,C){let w=cl(v,C);return Math.round((1-w/441.67)*100)}function oo(v,C,y,w="",$=""){return wt(v),`
      <div class="color-picker-item" data-color="${u(v)}" style="
        padding: 7px;
        margin-bottom: 8px;
        border: 1px solid ${y};
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 12px;
        background: white;
        transition: all 0.2s;
      " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='${y}'; this.style.boxShadow='none'">
        <div style="
          width: 36px;
          height: 36px;
          border-radius: 6px;
          background: ${u(v)};
          border: 1px solid #ddd;
          flex-shrink: 0;
        "></div>
        <div style="flex: 1;">
          <div style="font-weight: 600; font-size: 12px; color: #333; margin-bottom: 4px;">
            ${C||u(v)}
          </div>
          <div style="font-size: 10px; color: #666; font-family: 'SF Mono', Monaco, monospace;">
            ${u(v)}
          </div>
          ${w?`<div style="font-size: 11px; color: #666; margin-top: 4px;">${w}</div>`:""}
        </div>
        ${$?`<div style="color: #0071e3; font-weight: 600; margin-left: auto;">${$}</div>`:""}
      </div>
    `}function un(v,C,y,w={}){if(!C){let B=(v.message||"").match(/Color (#[0-9A-Fa-f]{6})/);C=B?B[1].toUpperCase():null}if(!C){alert("Cannot determine current color from issue message");return}let $=document.createElement("div");$.className="modal-overlay",$.id="color-picker-modal-overlay";let I=document.createElement("div");I.className="modal-dialog",I.style.maxWidth="400px";let R=y.map(V=>{let B=w[V]||"";return oo(V,B||V,C===V?"#0071e3":"#ddd","",C===V?"Current":"")}).join("");I.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Color</h2>
        <p class="modal-subtitle">Node: ${u(v.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Color:</div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 32px; height: 32px; border-radius: 4px; background: ${u(C)}; border: 1px solid #ddd;"></div>
            <div style="font-family: 'SF Mono', Monaco, monospace; font-size: 11px; font-weight: 600;">${u(C)}</div>
          </div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${R}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="color-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,$.appendChild(I),document.body.appendChild($);let _=I.querySelector("#color-picker-modal-cancel-btn"),O=I.querySelector(".modal-close"),L=I.querySelectorAll(".color-picker-item"),U=()=>{$.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{$.parentNode&&$.remove()},200)};_.onclick=U,O.onclick=U,$.onclick=V=>{V.target===$&&U()},L.forEach(V=>{V.onclick=B=>{B.preventDefault(),B.stopPropagation();let G=V.getAttribute("data-color");U(),Dt(v,C,G,w)}})}function Dt(v,C,y,w={},$=[],I={}){let{onApply:R,onIgnore:_,onCancel:O,showIgnore:L=!1,progress:U}=I,V=$.length>0?$:Object.keys(w);V.length===0&&y&&(V=[y]);let B=V.map(te=>({color:te,name:w[te]||te,similarity:dl(C,te)})).sort((te,X)=>y&&te.color===y?-1:y&&X.color===y?1:X.similarity-te.similarity).slice(0,5);if(B.length===0){alert("No colors available");return}let G=B[0].color,ae=(te,X)=>`
      <div class="color-option-item" data-color="${u(te.color)}" style="
        padding: 10px 12px;
        margin-bottom: 6px;
        border: 1px solid ${X?"#0071e3":"#e0e0e0"};
        border-radius: 8px;
        cursor: pointer;
        background: ${X?"#e3f2fd":"white"};
        display: flex;
        align-items: center;
        gap: 12px;
        transition: all 0.15s;
      ">
        <input type="radio" name="color-option" ${X?"checked":""} style="margin: 0; cursor: pointer;" />
        <div style="
          width: 36px;
          height: 36px;
          border-radius: 6px;
          background: ${u(te.color)};
          border: 1px solid ${X?"#0071e3":"#ddd"};
          flex-shrink: 0;
        "></div>
        <div style="flex: 1;">
          <div style="font-weight: 600; font-size: 13px; color: #333;">${u(te.name)}</div>
          <div style="font-size: 11px; color: #666; font-family: 'SF Mono', Monaco, monospace;">${u(te.color)}</div>
        </div>
        <span style="font-size: 11px; color: #666; background: #f0f0f0; padding: 2px 8px; border-radius: 10px;">${te.similarity}%</span>
      </div>
    `,Z=document.createElement("div");Z.className="modal-overlay",Z.id="color-fix-confirm-modal-overlay";let oe=document.createElement("div");oe.className="modal-dialog",oe.style.maxWidth="420px";let ne=U?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${U.current}/${U.total}</div>`:"",me=B.map((te,X)=>ae(te,X===0)).join("");oe.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Color</h2>
        <p class="modal-subtitle">Node: ${u(v.nodeName||"Unnamed")}</p>
      </div>
      ${ne}
      <div class="modal-body">
        <div style="margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 6px; display: flex; align-items: center; gap: 10px;">
          <div style="
            width: 32px;
            height: 32px;
            border-radius: 4px;
            background: ${u(C)};
            border: 1px solid #ddd;
          "></div>
          <div>
            <div style="font-size: 11px; color: #666;">Current:</div>
            <div style="font-size: 12px; font-weight: 600; font-family: 'SF Mono', Monaco, monospace;">${u(C)}</div>
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px;">
          Select a color to apply (Top 5 matches):
        </div>
        <div id="color-options-container" style="max-height: 280px; overflow-y: auto;">
          ${me}
        </div>
      </div>
      <div class="modal-footer">
        ${L?'<button class="modal-btn modal-btn-cancel" id="color-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="color-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="color-fix-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,Z.appendChild(oe),document.body.appendChild(Z);let ee=oe.querySelector("#color-fix-confirm-cancel-btn"),le=oe.querySelector("#color-fix-confirm-apply-btn"),H=oe.querySelector("#color-fix-ignore-btn"),pe=oe.querySelector(".modal-close"),J=oe.querySelector("#color-options-container"),ue=te=>{G=te,J.querySelectorAll(".color-option-item").forEach(fe=>{let Oe=fe.getAttribute("data-color")===te;fe.style.border=Oe?"2px solid #0071e3":"2px solid #e0e0e0",fe.style.background=Oe?"#e3f2fd":"white";let Q=fe.querySelector('input[type="radio"]');Q&&(Q.checked=Oe)})};(()=>{J.querySelectorAll(".color-option-item").forEach(X=>{X.onclick=fe=>{fe.preventDefault();let Se=X.getAttribute("data-color");ue(Se)}})})();let Y=()=>{Z.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{Z.parentNode&&Z.remove()},200)};ee.onclick=()=>{Y(),O&&typeof O=="function"&&O()},pe.onclick=()=>{Y(),O&&typeof O=="function"&&O()},Z.onclick=te=>{te.target===Z&&(Y(),O&&typeof O=="function"&&O())},le.onclick=()=>{Y(),re(v.id,"\u23F3 Fixing color...",!0),parent.postMessage({pluginMessage:{type:"fix-color-issue",issue:v,color:G}},"*"),R&&typeof R=="function"&&R()},H&&(H.onclick=()=>{Y(),_&&typeof _=="function"&&_()})}function no({reportData:v,getTypeDisplayName:C}){let y=v||{},w=y.issues||[],$=y.tokens||null,I=y.timestamp||Date.now(),R=new Date(I).toLocaleString("vi-VN"),_="Design Review",O=U=>{try{return typeof C=="function"?C(U):String(U||"")}catch(V){return String(U||"")}},L=`<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Design Review Report - ${R}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      line-height: 1.6;
      color: #1d1d1f;
      background: #f5f5f7;
      padding: 40px 20px;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      padding: 40px;
    }
    .header {
      border-bottom: 2px solid #e5e5e7;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    .header h1 {
      font-size: 28px;
      color: #1d1d1f;
      margin-bottom: 8px;
    }
    .header .meta {
      color: #86868b;
      font-size: 14px;
    }
    .section {
      margin-bottom: 40px;
    }
    .section-title {
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 16px;
      color: #1d1d1f;
      padding-bottom: 8px;
      border-bottom: 1px solid #e5e5e7;
    }
    .export-filter-group {
      display: flex;
      gap: 8px;
      margin-bottom: 16px;
    }
    .export-filter-btn {
      padding: 4px 10px;
      font-size: 12px;
      border-radius: 999px;
      border: 1px solid #e5e7eb;
      background: #f9fafb;
      cursor: pointer;
    }
    .export-filter-btn.active {
      background: #111827;
      color: #fff;
      border-color: #111827;
    }
    .stats {
      display: flex;
      gap: 16px;
      margin-bottom: 24px;
      flex-wrap: wrap;
    }
    .stat-card {
      padding: 16px 20px;
      border-radius: 8px;
      background: #f5f5f7;
      min-width: 120px;
    }
    .stat-card.error { background: #fee; color: #c33; }
    .stat-card.warn { background: #fff4e6; color: #d97706; }
    .stat-card .value {
      font-size: 32px;
      font-weight: 700;
      margin-bottom: 4px;
    }
    .stat-card .label {
      font-size: 12px;
      text-transform: uppercase;
      opacity: 0.8;
    }
    .issue-group {
      margin-bottom: 24px;
      border: 1px solid #e5e7eb;
      border-radius: 10px;
      padding: 16px;
      background: #fff;
    }
    .issue-group-header {
      font-size: 16px;
      font-weight: 600;
      color: #1d1d1f;
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      user-select: none;
    }
    .issue-group-toggle {
      border: none;
      background: #f3f4f6;
      width: 24px;
      height: 24px;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
    }
    .issue-group-content {
      margin-top: 12px;
    }
    .issue-group.collapsed .issue-group-content {
      display: none;
    }
    .issue {
      padding: 12px 16px;
      margin-bottom: 8px;
      border-radius: 6px;
      border-left: 4px solid;
    }
    .issue.error {
      background: #fef2f2;
      border-left-color: #ef4444;
    }
    .issue.warn {
      background: #fffbeb;
      border-left-color: #f59e0b;
    }
    .issue-type {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    .issue-message {
      font-size: 14px;
      margin-bottom: 4px;
    }
    .issue-node {
      font-size: 12px;
      color: #86868b;
      font-family: monospace;
      margin-top: 4px;
    }
    .token-list {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 12px;
    }
    .token-item {
      padding: 12px;
      background: #fafafa;
      border-radius: 6px;
      border: 1px solid #e5e5e7;
    }
    .token-value {
      font-family: monospace;
      font-size: 13px;
      margin-bottom: 4px;
    }
    .token-color-preview {
      display: inline-block;
      width: 24px;
      height: 24px;
      border-radius: 4px;
      border: 1px solid #d1d1d6;
      vertical-align: middle;
      margin-right: 8px;
    }
    .token-color-type {
      display: inline-block;
      font-size: 10px;
      padding: 2px 6px;
      background: #3b82f6;
      color: white;
      border-radius: 4px;
      margin-left: 6px;
    }
    .token-node-count {
      font-size: 11px;
      color: #86868b;
      margin-top: 4px;
    }
    .token-empty-message {
      padding: 12px;
      font-size: 12px;
      color: #9ca3af;
      font-style: italic;
    }
    @media print {
      body { padding: 20px; }
      .container { box-shadow: none; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>\u{1F3A8} Design Review Report</h1>
      <div class="meta">Generated: ${R} | Page: ${_}</div>
    </div>`;if(w&&w.length>0){let U={error:w.filter(B=>B.severity==="error").length,warn:w.filter(B=>B.severity==="warn").length,total:w.length},V=w.reduce((B,G)=>(B[G.type]=B[G.type]||[],B[G.type].push(G),B),{});L+=`
    <div class="section">
      <h2 class="section-title">\u{1F4CA} Summary</h2>
      <div class="stats">
        ${U.error>0?`<div class="stat-card error"><div class="value">${U.error}</div><div class="label">Errors</div></div>`:""}
        ${U.warn>0?`<div class="stat-card warn"><div class="value">${U.warn}</div><div class="label">Warnings</div></div>`:""}
        <div class="stat-card"><div class="value">${U.total}</div><div class="label">Total Issues</div></div>
      </div>
    </div>

    <div class="section">
      <h2 class="section-title">\u{1F50D} Issues</h2>
      <div class="export-filter-group">
        <button class="export-filter-btn active" data-severity="all">All</button>
        <button class="export-filter-btn" data-severity="error">Errors</button>
        <button class="export-filter-btn" data-severity="warn">Warnings</button>
      </div>`;for(let[B,G]of Object.entries(V)){let ae=u(O(B));L+=`
      <div class="issue-group collapsed" data-type="${B}" data-label="${ae}">
        <div class="issue-group-header">
          <button class="issue-group-toggle" type="button">+</button>
          <span>${ae} (${G.length})</span>
        </div>
        <div class="issue-group-content">`,G.forEach(Z=>{L+=`
          <div class="issue ${Z.severity}">
            <div class="issue-type">${String(Z.severity||"").toUpperCase()}</div>
            <div class="issue-message">${u(Z.message)}</div>
            ${Z.nodeName?`<div class="issue-node">Node: ${u(Z.nodeName)}</div>`:""}
          </div>`}),L+=`
        </div>
      </div>`}L+=`
    </div>`}if($){L+=`
    <div class="section">
      <h2 class="section-title">\u{1F3A8} Design Tokens</h2>`;let U={colors:{label:"Colors",values:$.colors||[]},gradients:{label:"Gradients",values:$.gradients||[]},borderRadius:{label:"Border Radius",values:$.borderRadius||[]},fontWeight:{label:"Font Weight",values:$.fontWeight||[]},lineHeight:{label:"Line Height (%)",values:$.lineHeight||[]},fontSize:{label:"Font Size",values:$.fontSize||[]},fontFamily:{label:"Font Family",values:$.fontFamily||[]}};for(let[V,B]of Object.entries(U)){if(L+=`
      <div class="issue-group collapsed">
        <div class="issue-group-header">
          <button class="issue-group-toggle" type="button">+</button>
          <span>${B.label} (${B.values.length})</span>
        </div>
        <div class="issue-group-content">`,!B.values||B.values.length===0){L+=`
          <div class="token-empty-message">No tokens in this group.</div>`,L+=`
        </div>
      </div>`;continue}L+=`
          <div class="token-list">`,B.values.forEach(G=>{let ae=G.value,Z=typeof G.totalNodes=="number"?G.totalNodes:G.nodes?G.nodes.length:0,oe=G.colorType||"";if(V==="colors")L+=`
          <div class="token-item">
            <div class="token-value">
              <span class="token-color-preview" style="background-color: ${u(ae)}"></span>
              ${u(ae)}
              ${oe?`<span class="token-color-type">${u(oe)}</span>`:""}
            </div>
            ${Z>1?`<div class="token-node-count">Used in ${Z} nodes</div>`:""}
          </div>`;else if(V==="gradients")L+=`
          <div class="token-item">
            <div class="token-value">
              <span class="token-color-preview" style="background: ${u(ae)}"></span>
              ${u(ae)}
              ${oe?`<span class="token-color-type">${u(oe)}</span>`:""}
            </div>
            ${Z>1?`<div class="token-node-count">Used in ${Z} nodes</div>`:""}
          </div>`;else{let ne="";if(V==="fontWeight"){let me=Array.isArray(G.fontFamilies)?G.fontFamilies:null;if(!me){let ee={};(Array.isArray(G.nodes)?G.nodes:[]).forEach(H=>{let pe=H&&H.fontFamily?String(H.fontFamily):"Unknown";ee[pe]=(ee[pe]||0)+1}),me=Object.entries(ee).map(([H,pe])=>({family:H,count:pe})).sort((H,pe)=>pe.count-H.count||H.family.localeCompare(pe.family))}Array.isArray(me)&&me.length>0&&(ne=`<div class="token-node-count" style="margin-top: 6px;">Font-family:<br/>${me.map(le=>`${u(le.family)} (${le.count})`).join("<br/>")}</div>`)}L+=`
          <div class="token-item">
            <div class="token-value">${u(String(ae))}</div>
            ${Z>1?`<div class="token-node-count">Used in ${Z} nodes</div>`:""}
            ${ne}
          </div>`}}),L+=`
          </div>
        </div>
      </div>`}L+=`
    </div>`}return L+=`
  </div>
  <script>
    (function() {
      function updateGroupState(group, content, toggleBtn) {
        const collapsed = group.classList.contains('collapsed');
        if (collapsed) {
          content.style.display = 'none';
          if (toggleBtn) toggleBtn.textContent = '+';
        } else {
          content.style.display = 'block';
          if (toggleBtn) toggleBtn.textContent = '\u2212';
        }
      }

      function initCollapsibles() {
        document.querySelectorAll('.issue-group').forEach(group => {
          const header = group.querySelector('.issue-group-header');
          const content = group.querySelector('.issue-group-content');
          const toggleBtn = group.querySelector('.issue-group-toggle');
          if (!content || !header) return;

          const toggle = () => {
            group.classList.toggle('collapsed');
            updateGroupState(group, content, toggleBtn);
          };

          if (toggleBtn) {
            toggleBtn.addEventListener('click', e => {
              e.stopPropagation();
              toggle();
            });
          }

          header.addEventListener('click', e => {
            if (toggleBtn && (e.target === toggleBtn || toggleBtn.contains(e.target))) {
              return;
            }
            toggle();
          });

          updateGroupState(group, content, toggleBtn);
        });
      }

      function applySeverityFilter(filter) {
        const buttons = document.querySelectorAll('.export-filter-btn');
        buttons.forEach(btn => {
          const val = btn.getAttribute('data-severity') || 'all';
          btn.classList.toggle('active', val === filter);
        });

        document.querySelectorAll('.issue-group').forEach(group => {
          const issues = group.querySelectorAll('.issue');
          const label = group.getAttribute('data-label') || '';
          let visibleCount = 0;

          issues.forEach(issue => {
            const isError = issue.classList.contains('error');
            const isWarn = issue.classList.contains('warn');
            let show = false;
            if (filter === 'all') show = true;
            else if (filter === 'error') show = isError;
            else if (filter === 'warn') show = isWarn;
            issue.style.display = show ? '' : 'none';
            if (show) visibleCount++;
          });

          const headerCountSpan = group.querySelector('.issue-group-header span:last-child');
          if (headerCountSpan && label) {
            headerCountSpan.textContent = label + ' (' + visibleCount + ')';
          }
        });
      }

      function initExportFilters() {
        const buttons = document.querySelectorAll('.export-filter-btn');
        if (!buttons.length) return;
        let current = 'all';

        buttons.forEach(btn => {
          btn.addEventListener('click', () => {
            const val = btn.getAttribute('data-severity') || 'all';
            current = val;
            applySeverityFilter(current);
          });
        });

        // Initial apply
        applySeverityFilter(current);
      }

      function initExportUI() {
        initCollapsibles();
        initExportFilters();
      }

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initExportUI);
      } else {
        initExportUI();
      }
    })();
  <\/script>
</body>
</html>`,L}function pl(){let v=new Date,C=v.getFullYear(),y=String(v.getMonth()+1).padStart(2,"0"),w=String(v.getDate()).padStart(2,"0"),$=String(v.getHours()).padStart(2,"0"),I=String(v.getMinutes()).padStart(2,"0"),R=String(v.getSeconds()).padStart(2,"0");return`design-review-report-${C}-${y}-${w}-${$}-${I}-${R}`}function ul(v,C){if(!v||!Array.isArray(v.colors))return v;let y=C||{};return ot(Ke({},v),{colors:v.colors.map(w=>ot(Ke({},w),{name:y[String(w.value).toUpperCase()]||"No name"}))})}function gn({format:v,reportData:C,getTypeDisplayName:y,filenameBase:w,colorNameMap:$}={}){var _,O;let I=C||{};if(!I.issues&&!I.tokens){alert("No data to export!");return}let R=w||pl();if(v==="html"){let L=no({reportData:I,getTypeDisplayName:y}),U=new Blob([L],{type:"text/html"}),V=URL.createObjectURL(U),B=document.createElement("a");B.href=V,B.download=`${R}.html`,B.click(),URL.revokeObjectURL(V);return}if(v==="pdf"){let L=no({reportData:I,getTypeDisplayName:y});try{let U=window.open("","_blank");if(!U){alert("Popup blocked. Downloading HTML - you can open the file and select Print to create PDF.");let V=new Blob([L],{type:"text/html"}),B=URL.createObjectURL(V),G=document.createElement("a");G.href=B,G.download=`${R}.html`,G.click(),URL.revokeObjectURL(B);return}U.document.open(),U.document.write(L),U.document.close(),U.onload=()=>{setTimeout(()=>{U.print()},250)},setTimeout(()=>{U.document&&U.document.readyState==="complete"&&U.print()},500)}catch(U){console.error("Error opening print window:",U),alert("Cannot open print window. Downloading HTML - you can open the file and select Print to create PDF.");let V=new Blob([L],{type:"text/html"}),B=URL.createObjectURL(V),G=document.createElement("a");G.href=B,G.download=`${R}.html`,G.click(),URL.revokeObjectURL(B)}return}if(v==="json"){console.log("Export JSON - colorNameMap:",$),console.log("Export JSON - tokens.colors:",(_=I.tokens)==null?void 0:_.colors);let L=ot(Ke({},I),{tokens:ul(I.tokens,$)});console.log("Export JSON - enriched colors:",(O=L.tokens)==null?void 0:O.colors);let U=JSON.stringify(L,null,2),V=new Blob([U],{type:"application/json"}),B=URL.createObjectURL(V),G=document.createElement("a");G.href=B,G.download=`${R}.json`,G.click(),URL.revokeObjectURL(B);return}}function mn({maxHistory:v=10,postPluginMessage:C,getCurrentReportData:y,setIsViewingTokens:w,renderResults:$,renderTokens:I}={}){let R=[],_=!1,O=ee=>{try{typeof C=="function"&&C(ee)}catch(le){console.error("scanHistory postPluginMessage error:",le)}};function L(ee){R=(Array.isArray(ee)?ee:[]).slice(0,v)}function U(){R=[],_=!1}function V(){return R||[]}function B(ee,le,H,pe){try{if(le==="issues"&&(!H.issues||H.issues.length===0)){console.log("Skipping save - no issues data");return}if(le==="tokens"&&(!H.tokens||Object.keys(H.tokens).length===0)){console.log("Skipping save - no tokens data");return}let J={id:Date.now().toString(),mode:ee,type:le,timestamp:new Date().toISOString(),context:pe||null,data:{issues:H.issues||null,tokens:H.tokens||null,issuesCount:H.issues?H.issues.length:0,tokensCount:H.tokens?Object.keys(H.tokens).reduce((k,Y)=>{var te;return k+(((te=H.tokens[Y])==null?void 0:te.length)||0)},0):0}};R.unshift(J),R=R.slice(0,v);let ue=document.getElementById("history-panel");ue&&ue.style.display!=="none"&&ne(),O({type:"save-history-entry",entry:J})}catch(J){console.error("Error saving scan history:",J)}}function G(){O({type:"get-history"})}function ae(){try{let ee=V();if(ee.length>0){let le=ee[0],H=document.querySelector(`input[name="scope"][value="${le.mode}"]`);H&&(H.checked=!0,console.log("Loaded last scan mode:",le.mode))}}catch(ee){console.error("Error loading last scan mode:",ee)}}function Z(){_||(ae(),_=!0)}function oe(ee){try{let le=new Date(ee),pe=new Date-le,J=Math.floor(pe/6e4),ue=Math.floor(pe/36e5),k=Math.floor(pe/864e5);return J<1?"Just now":J<60?`${J} minutes ago`:ue<24?`${ue} hours ago`:k<7?`${k} days ago`:le.toLocaleString("en-US",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"})}catch(le){return ee}}function ne(){let ee=document.getElementById("history-list");if(!ee){console.error("history-list element not found");return}let le=V();if(console.log("Rendering scan history:",le.length,"entries"),le.length===0){ee.innerHTML=`
              <div class="history-empty">
                <div class="icon">\u{1F4CB}</div>
                <p>No scan history</p>
                <p style="font-size: 11px; margin-top: 8px;">Scans will be saved automatically</p>
              </div>
            `;return}ee.innerHTML=le.map(H=>{var X,fe;let pe=oe(H.timestamp),J=H.mode==="page"?"Page":"Selection",ue=H.type==="issues"?"Issues":"Tokens",k=H.type==="issues"?"issues":"tokens",Y=H.context&&H.context.label?H.context.label:`${J} scan`,te="";if(H.type==="issues"){let Se=((X=H.data.issues)==null?void 0:X.filter(Q=>Q.severity==="error").length)||0,Oe=((fe=H.data.issues)==null?void 0:fe.filter(Q=>Q.severity==="warn").length)||0;te=`
                <span>\u274C ${Se} errors</span>
                <span>\u26A0\uFE0F ${Oe} warnings</span>
                <span>\u{1F4CA} ${H.data.issuesCount} total</span>
              `}else te=`
                <span>\u{1F3A8} ${H.data.tokensCount} tokens</span>
              `;return`
              <div class="history-item" data-id="${H.id}">
                <div class="history-item-header">
                  <span class="history-item-type ${k}">${ue}</span>
                  <span class="history-item-time">${pe}</span>
                </div>
                <div class="history-item-info">${u(Y)}</div>
                <div class="history-item-stats">${te}</div>
              </div>
            `}).join(""),ee.querySelectorAll(".history-item").forEach(H=>{H.onclick=()=>{let pe=H.getAttribute("data-id");me(pe)}})}function me(ee){try{let H=V().find(k=>k.id===ee);if(!H){alert("Scan history entry not found!");return}let pe=document.querySelector(`input[name="scope"][value="${H.mode}"]`);pe&&(pe.checked=!0);let J=typeof y=="function"?y():null;if(!J){console.warn("restoreReportFromHistory: currentReportData is not available");return}J.scanMode=H.mode,J.context=H.context||null,H.type==="issues"&&H.data.issues?(J.issues=H.data.issues,J.tokens=null,typeof w=="function"&&w(!1),typeof $=="function"&&$(H.data.issues,!0,{restoreTimestamp:H.timestamp})):H.type==="tokens"&&H.data.tokens&&(J.issues=null,J.tokens=H.data.tokens,typeof w=="function"&&w(!0),typeof I=="function"&&I(H.data.tokens,!0,{restoreTimestamp:H.timestamp}));let ue=document.getElementById("history-panel");ue&&(ue.style.display="none"),console.log("Report restored from history:",ee)}catch(le){console.error("Error restoring report from history:",le),alert("Error restoring report: "+le.message)}}return{setHistory:L,clearLocalHistory:U,getScanHistory:V,saveScanHistory:B,requestScanHistory:G,loadLastScanMode:ae,loadLastScanModeOnce:Z,renderScanHistory:ne,restoreReportFromHistory:me}}var fn=4;console.log("Header.js22121211thien2");console.log("ui.js loaded");(function(){console.log("Initializing ui.js...");let v=document.getElementById("btn-scan"),C=document.getElementById("btn-cancel-scan"),y=document.getElementById("scan-progress"),w=document.getElementById("scan-progress-bar"),$=document.getElementById("scan-progress-text"),I=document.getElementById("btn-extract-tokens"),R=document.getElementById("btn-fill-spacing-scale"),_=document.getElementById("btn-fill-color-scale"),O=document.getElementById("btn-extract-color-styles"),L=document.getElementById("btn-fill-font-size-scale"),U=document.getElementById("btn-fill-line-height-scale"),V=document.getElementById("btn-fill-font-size-from-typo"),B=document.getElementById("btn-fill-line-height-from-typo"),G=document.getElementById("btn-export"),ae=document.getElementById("btn-history"),Z=document.getElementById("btn-close-history"),oe=document.getElementById("btn-reset-all"),ne=document.getElementById("results-issues"),me=document.getElementById("results-tokens"),ee=document.getElementById("btn-close"),le=document.querySelectorAll(".report-tab"),H=document.querySelectorAll(".report-content"),pe="issues";if(!v||!I||!ne||!me||!ee||!G||!ae||!R||!_||!L||!U){console.error("Required elements not found",{btnScan:v,btnExtractTokens:I,btnFillSpacingScale:R,btnFillColorScale:_,btnFillFontSizeScale:L,btnFillLineHeightScale:U,resultsIssues:ne,resultsTokens:me,btnClose:ee,btnExport:G,btnHistory:ae});return}rn();let J={},ue={},k={issues:null,tokens:null,scanMode:null,timestamp:null,tokensTimestamp:null,context:null},Y=new Map,te=1e3;function X(){Y.clear()}function fe(e,t){if(Y.has(e))return Y.get(e);let o=t();return Y.size>=te&&Array.from(Y.keys()).slice(0,100).forEach(n=>Y.delete(n)),Y.set(e,o),o}let Se=null,Oe=5e3,Q=[{id:1,name:"H1",fontFamily:"Inter",fontSize:48,fontWeight:"Bold",lineHeight:"120%",letterSpacing:"0",wordSpacing:"0"},{id:2,name:"H2",fontFamily:"Inter",fontSize:36,fontWeight:"Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:3,name:"H3",fontFamily:"Inter",fontSize:28,fontWeight:"SemiBold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:4,name:"H4",fontFamily:"Inter",fontSize:24,fontWeight:"SemiBold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:5,name:"H5",fontFamily:"Inter",fontSize:20,fontWeight:"Medium",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:6,name:"H6",fontFamily:"Inter",fontSize:18,fontWeight:"Medium",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:7,name:"Body",fontFamily:"Inter",fontSize:16,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"}],nt=8;function yn(e,t){let o=c=>c==null||c==="Unknown"?"":String(c).toLowerCase().trim(),l=c=>c!=null&&c!=="Unknown"&&String(c).trim()!=="",n=0;l(e.fontFamily)&&l(t.fontFamily)&&o(e.fontFamily)===o(t.fontFamily)&&(n+=25),e.fontSize!==null&&e.fontSize!==void 0&&t.fontSize&&(Math.abs(e.fontSize-t.fontSize)===0?n+=30:Math.abs(e.fontSize-t.fontSize)<=2?n+=25:Math.abs(e.fontSize-t.fontSize)<=4?n+=20:Math.abs(e.fontSize-t.fontSize)<=8&&(n+=10)),l(e.fontWeight)&&l(t.fontWeight)&&o(e.fontWeight)===o(t.fontWeight)&&(n+=20),l(e.lineHeight)&&l(t.lineHeight)&&o(e.lineHeight)===o(t.lineHeight)&&(n+=15);let s=o(e.letterSpacing),a=o(t.letterSpacing||"0"),i=c=>c==="0"||c==="0px"||c==="0%"||c==="";return(l(e.letterSpacing)||l(t.letterSpacing))&&(i(s)&&i(a)||s===a)&&(n+=10),n}function Mt(e){var n;if(!e||!e.bestMatch||!e.bestMatch.name)return!1;let t=(n=e.nodeProps)==null?void 0:n.fontSize;if(t==null)return!0;let o=Q==null?void 0:Q.find(s=>s.name===e.bestMatch.name);if(!o||!o.fontSize)return!0;let l=Math.abs(t-o.fontSize);return l>fn?(console.log(`[isValidTypographySuggestion] Font-size difference (${l}px) exceeds threshold (${fn}px) for issue:`,e.id,`Current: ${t}px, Suggested: ${o.fontSize}px`),!1):!0}function Wt(e){e&&parent.postMessage({pluginMessage:{type:"save-last-report",report:e}},"*")}function lo(){parent.postMessage({pluginMessage:{type:"get-last-report"}},"*")}function ve(){var t,o,l,n,s,a,i,c,p,d,S,h,f,m,g,M;let e={spacingScale:((t=document.getElementById("spacing-scale"))==null?void 0:t.value)||"",spacingThreshold:((o=document.getElementById("spacing-threshold"))==null?void 0:o.value)||"100",colorScale:((l=document.getElementById("color-scale"))==null?void 0:l.value)||"",colorNameMap:J,ignoredIssues:ue,fontSizeScale:((n=document.getElementById("font-size-scale"))==null?void 0:n.value)||"",fontSizeThreshold:((s=document.getElementById("font-size-threshold"))==null?void 0:s.value)||"100",lineHeightScale:((a=document.getElementById("line-height-scale"))==null?void 0:a.value)||"",lineHeightThreshold:((i=document.getElementById("line-height-threshold"))==null?void 0:i.value)||"300",lineHeightBaselineThreshold:((c=document.getElementById("line-height-baseline-threshold"))==null?void 0:c.value)||"120",typographyStyles:Q,skipNames:((p=document.getElementById("scan-skip-names"))==null?void 0:p.value)||"",typographyRules:{checkStyle:((d=document.getElementById("rule-typo-style"))==null?void 0:d.checked)||!0,checkFontFamily:((S=document.getElementById("rule-font-family"))==null?void 0:S.checked)||!0,checkFontSize:((h=document.getElementById("rule-font-size"))==null?void 0:h.checked)||!0,checkFontWeight:((f=document.getElementById("rule-font-weight"))==null?void 0:f.checked)||!0,checkLineHeight:((m=document.getElementById("rule-line-height"))==null?void 0:m.checked)||!0,checkLetterSpacing:((g=document.getElementById("rule-letter-spacing"))==null?void 0:g.checked)||!1,checkWordSpacing:((M=document.getElementById("rule-word-spacing"))==null?void 0:M.checked)||!1}};parent.postMessage({pluginMessage:{type:"save-input-values",values:e}},"*")}function so(){parent.postMessage({pluginMessage:{type:"get-input-values"}},"*")}function Ut(e){if(!e)return;let t=document.getElementById("spacing-scale"),o=document.getElementById("spacing-threshold"),l=document.getElementById("color-scale"),n=document.getElementById("font-size-scale"),s=document.getElementById("font-size-threshold"),a=document.getElementById("line-height-scale"),i=document.getElementById("line-height-threshold"),c=document.getElementById("line-height-baseline-threshold");t&&e.spacingScale!==void 0&&(t.value=e.spacingScale),o&&e.spacingThreshold!==void 0&&(o.value=e.spacingThreshold),e.colorNameMap&&typeof e.colorNameMap=="object"?J=e.colorNameMap:J={},e.ignoredIssues&&typeof e.ignoredIssues=="object"?ue=e.ignoredIssues:ue={},l&&e.colorScale!==void 0&&(l.value=e.colorScale,typeof He=="function"&&He()),n&&e.fontSizeScale!==void 0&&(n.value=e.fontSizeScale),s&&e.fontSizeThreshold!==void 0&&(s.value=e.fontSizeThreshold),a&&e.lineHeightScale!==void 0&&(a.value=e.lineHeightScale),i&&e.lineHeightThreshold!==void 0&&(i.value=e.lineHeightThreshold),c&&e.lineHeightBaselineThreshold!==void 0&&(c.value=e.lineHeightBaselineThreshold);let p=document.getElementById("scan-skip-names");if(p&&e.skipNames!==void 0&&(p.value=e.skipNames),e.typographyStyles&&Array.isArray(e.typographyStyles)&&(Q=e.typographyStyles,nt=Math.max(...Q.map(d=>d.id||0),0)+1,Ge()),e.typographyRules){let d=e.typographyRules;document.getElementById("rule-typo-style")&&(document.getElementById("rule-typo-style").checked=d.checkStyle!==!1),document.getElementById("rule-font-family")&&(document.getElementById("rule-font-family").checked=d.checkFontFamily!==!1),document.getElementById("rule-font-size")&&(document.getElementById("rule-font-size").checked=d.checkFontSize!==!1),document.getElementById("rule-font-weight")&&(document.getElementById("rule-font-weight").checked=d.checkFontWeight!==!1),document.getElementById("rule-line-height")&&(document.getElementById("rule-line-height").checked=d.checkLineHeight!==!1),document.getElementById("rule-letter-spacing")&&(document.getElementById("rule-letter-spacing").checked=d.checkLetterSpacing===!0),document.getElementById("rule-word-spacing")&&(document.getElementById("rule-word-spacing").checked=d.checkWordSpacing===!0),Ge()}}function hn(e){if(!e){console.log("No last report to apply");return}if(e.scanMode){let t=document.querySelector(`input[name="scope"][value="${e.scanMode}"]`);t&&(t.checked=!0)}k.scanMode=e.scanMode||k.scanMode,k.context=e.context||k.context,e.issues&&Array.isArray(e.issues)&&(console.log("Applying saved issues report"),We(e.issues,!0,{skipSave:!0,restoreTimestamp:e.issuesTimestamp})),e.tokens&&(console.log("Applying saved tokens report"),It(e.tokens,!0,{skipSave:!0,restoreTimestamp:e.tokensTimestamp})),e.lastActiveTab?Le(e.lastActiveTab):e.issues?Le("issues"):e.tokens&&Le("tokens")}let Ae="all",Ie="",Ve="all",Ct=!1;console.log("All elements found, setting up event listeners"),le.forEach(e=>{e.addEventListener("click",()=>{let t=e.dataset.tab;Le(t),t!=="settings"&&(k.issues||k.tokens)&&Wt({issues:k.issues,issuesTimestamp:k.timestamp,tokens:k.tokens,tokensTimestamp:k.tokensTimestamp,lastActiveTab:t,scanMode:k.scanMode||null,context:k.context||null})})});function zt(e=null){let t=e?document.getElementById(`results-${e}`):ne;t&&(t.innerHTML="")}function Le(e){le.forEach(n=>{n.dataset.tab===e?n.classList.add("active"):n.classList.remove("active")}),H.forEach(n=>{n.id===`results-${e}`?n.classList.add("active"):n.classList.remove("active")});let t=document.getElementById("filter-controls"),o=document.getElementById("filter-buttons"),l=document.getElementById("color-type-filter");if(t){if(e==="settings")t.style.display="none";else if(e==="animations"){let n=typeof window.hasAnimationData=="function"&&window.hasAnimationData();t.style.display=n?"flex":"none",o&&(o.style.display="none"),l&&(l.style.display="none")}else if(e==="tokens")(me&&me.querySelector(".token-group")||k.tokens)&&(t.style.display="flex"),o&&(o.style.display="none"),l&&k.tokens&&(k.tokens.colors||k.tokens.gradients)?l.style.display="block":l&&(l.style.display="none");else if(e==="issues"){let n=ne&&ne.querySelector(".issue-group"),s=k.issues&&k.issues.length>0;(n||s)&&(t.style.display="flex",o&&(o.style.display="flex")),l&&(l.style.display="none"),s&&typeof At=="function"&&At(k.issues)}}pe=e}function bn(e){return e==="error"?"\u274C":e==="warn"?"\u26A0\uFE0F":"\u2139\uFE0F"}function io(e){return{naming:"\u{1F3F7}\uFE0F",autolayout:"\u{1F4D0}",spacing:"\u{1F4CF}",color:"\u{1F3A8}","color-variable":"\u{1F517}",typography:"\u270D\uFE0F","typography-style":"\u{1F3A8}","typography-check":"\u{1F4DD}","typography-pass":"\u2705","typography-info":"\u2705","line-height":"\u{1F4DD}",position:"\u{1F4CD}",duplicate:"\u{1F504}",group:"\u{1F4E6}",component:"\u{1F9E9}","empty-frame":"\u{1F4ED}","nested-group":"\u{1F4DA}",contrast:"\u{1F308}","text-size-mobile":"\u{1F4F1}"}[e]||"\u{1F50D}"}function Tt(e){return{naming:"Naming Layer",autolayout:"Auto Layout",spacing:"Spacing",color:"Color","color-variable":"Color Variable",typography:"Font Size","typography-style":"Text Style (variable)","typography-check":"Typography Style Match","typography-pass":"Typography \u2713 Matched","line-height":"Line Height",position:"Position Layer",duplicate:"Duplicate Layer",group:"Group Layer",component:"Component Reusable","empty-frame":"Empty Frame Layer","nested-group":"Nested Group Layer",contrast:"Contrast (ADA AA)","text-size-mobile":"Text Size (ADA)"}[e]||e.replace(/-/g," ")}function xn(e){let t=document.createElement("div");t.className=`issue ${e.severity}`;let o="";e.type==="typography-check"&&e.nodeProps&&(o='<div class="typography-details" style="margin-top: 8px; padding: 8px; background: rgba(0,0,0,0.05); border-radius: 4px; font-size: 11px;">',o+='<div class="current-properties"><div style="margin-bottom: 6px;"><strong>Current Properties:</strong></div>',o+='<div style="padding-left: 0; line-height: 1.6;">',e.nodeProps.fontFamily&&(o+=`\u2022 Font Family: <code>${u(e.nodeProps.fontFamily)}</code><br>`),e.nodeProps.fontSize!==null&&e.nodeProps.fontSize!==void 0&&(o+=`\u2022 Font Size: <code>${e.nodeProps.fontSize}px</code><br>`),e.nodeProps.fontWeight&&(o+=`\u2022 Font Weight: <code>${u(e.nodeProps.fontWeight)}</code><br>`),e.nodeProps.lineHeight&&(o+=`\u2022 Line Height: <code>${u(e.nodeProps.lineHeight)}</code><br>`),e.nodeProps.letterSpacing!==null&&e.nodeProps.letterSpacing!==void 0&&(o+=`\u2022 Letter Spacing: <code>${u(e.nodeProps.letterSpacing)}</code><br>`),o+="</div></div>",e.bestMatch&&e.bestMatch.name&&e.severity==="error"?(o+=`<div class="closest-match"><div style="margin-bottom: 6px;"><strong>Closest Match: "${u(e.bestMatch.name)}" (${e.bestMatch.percentage||0}%)</strong></div>`,o+='<div style="padding-left: 0; line-height: 1.6;">',(e.bestMatch.differences||[]).forEach(i=>{let c=i.matches?"\u2713":"\u2717",p=i.matches?"green":"red";o+=`<span style="color: ${p}">${c} ${i.property}: <code>${u(i.current)}</code> \u2192 <code>${u(i.expected)}</code></span><br>`}),o+="</div></div>"):e.severity==="info"&&e.styleName&&(o+=`<div style="margin-top: 8px; color: green;"><strong>\u2713 All properties match style "${u(e.styleName)}"</strong></div>`),o+="</div>"),t.setAttribute("data-issue-id",e.id),t.innerHTML=`
      <div class="issue-header">
              <div>
                <span class="issue-type">${io(e.type)} ${Tt(e.type)}</span>
      <div class="issue-body">${u(e.message)}</div>
                ${e.nodeName?`<div class="issue-node">Node: ${u(e.nodeName)}</div>`:""}
                ${o}
              </div>
              <div class="issue-actions">
                <button class="btn-select" data-id="${e.id}">Select</button>
                ${e.bestMatch&&e.bestMatch.name&&e.type==="typography-check"&&Mt(e)?`
                  <button class="btn-suggest-fix" data-id="${e.id}" data-style-name="${u(e.bestMatch.name)}">Suggest Fix now</button>
                `:""}
                ${e.type==="typography-check"?`
                  <button class="btn-style-dropdown" data-id="${e.id}" data-issue-id="${e.id}">Select Style</button>
                `:""}
                ${(e.severity==="error"||e.severity==="warn")&&e.type==="typography-check"?`
                  <button class="btn-remove-layer" data-id="${e.id}">Remove Layer</button>
                `:""}
              </div>
      </div>
    `;let l=t.querySelector("button.btn-select");l&&(l.onclick=()=>{document.querySelectorAll(".btn-select.active").forEach(i=>i.classList.remove("active")),document.querySelectorAll(".issue.selected").forEach(i=>i.classList.remove("selected")),l.classList.add("active"),t.classList.add("selected"),parent.postMessage({pluginMessage:{type:"select-node",id:e.id}},"*")});let n=t.querySelector("button.btn-suggest-fix");n&&e.type==="typography-check"&&e.bestMatch&&e.bestMatch.name&&(function(i){n.onclick=c=>{c.preventDefault(),c.stopPropagation(),i.bestMatch&&i.bestMatch.name?Vt(i,i.bestMatch.name):(console.error("Cannot apply: bestMatch.name is missing",i),alert("Error: Best match style name is missing"))}})(e);let s=t.querySelector("button.btn-style-dropdown");s&&e.type==="typography-check"&&(function(i){s.onclick=c=>{c.preventDefault(),c.stopPropagation(),parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:i.id}},"*"),window.pendingTypographyCheckIssue=i}})(e);let a=t.querySelector("button.btn-remove-layer");return a&&e.type==="typography-check"&&(function(i){a.onclick=c=>{c.preventDefault(),c.stopPropagation(),console.log("Remove Layer button clicked for typography-check",i),typeof Ft=="function"?Ft(i):(console.error("handleRemoveLayer is not a function"),alert("Error: handleRemoveLayer function not found"))}})(e),t}function vn(e){let t=St(e);if(!t){alert("No suitable color match found");return}let l=(e.message||"").match(/Color (#[0-9A-Fa-f]{6})/),n=l?l[1].toUpperCase():null;Dt(e,n,t,J)}function Sn(e){let t=kt(e);if(!t){alert("No suitable spacing match found");return}let o=e.message||"",l=o.match(/Padding\s+(\w+)\s+\((\d+)px\)/);if(!l){console.error("Cannot parse spacing issue message:",o),alert("Cannot determine spacing property from issue message. Message: "+o);return}let n=l[1],s=parseInt(l[2]);Rt(e,n,s,t)}function pt(e){return!e||e.type!=="autolayout"?null:{action:"enable-autolayout"}}function ao(e){if(!pt(e)){alert("Cannot suggest fix for this autolayout issue");return}kn(e)}function kn(e){let t=document.createElement("div");t.className="modal-overlay",t.id="autolayout-fix-confirm-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="450px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Auto Layout Enable</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Action:</div>
          <div style="padding: 12px; background: #e3f2fd; border-left: 3px solid #0071e3; border-radius: 6px;">
            <div style="font-size: 14px; color: #333; margin-bottom: 8px;">
              <strong>Enable Auto Layout</strong>
            </div>
            <div style="font-size: 12px; color: #666;">
              Auto Layout will be enabled on this frame. The layout direction (horizontal/vertical) will be automatically determined based on the children arrangement.
            </div>
          </div>
        </div>
        <div style="padding: 12px; background: #f0fdf4; border-radius: 6px; border-left: 3px solid #22c55e;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">\u{1F4DD} Note:</div>
          <div style="font-size: 12px; color: #333;">
            \u2022 Layout direction will be auto-detected (horizontal or vertical)<br>
            \u2022 Spacing and padding will be preserved if possible<br>
            \u2022 Frame structure will be maintained
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="autolayout-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="autolayout-fix-confirm-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let l=o.querySelector("#autolayout-fix-confirm-cancel-btn"),n=o.querySelector("#autolayout-fix-confirm-apply-btn"),s=o.querySelector(".modal-close"),a=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};l.onclick=a,s.onclick=a,t.onclick=i=>{i.target===t&&a()},n.onclick=()=>{a(),re(e.id,"\u23F3 Enabling auto layout...",!0),parent.postMessage({pluginMessage:{type:"fix-autolayout-issue",issue:e}},"*")}}function wn(e,t={}){let{onApply:o,onIgnore:l,onCancel:n,progress:s}=t,a=s?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${s.current}/${s.total}</div>`:"",i=document.createElement("div");i.className="modal-overlay",i.id="autolayout-fix-confirm-modal-overlay";let c=document.createElement("div");c.className="modal-dialog",c.style.maxWidth="450px",c.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Auto Layout Enable</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      ${a}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Action:</div>
          <div style="padding: 12px; background: #e3f2fd; border-left: 3px solid #0071e3; border-radius: 6px;">
            <div style="font-size: 14px; color: #333; margin-bottom: 8px;">
              <strong>Enable Auto Layout</strong>
            </div>
            <div style="font-size: 12px; color: #666;">
              Auto Layout will be enabled on this frame. The layout direction (horizontal/vertical) will be automatically determined based on the children arrangement.
            </div>
          </div>
        </div>
        <div style="padding: 12px; background: #f0fdf4; border-radius: 6px; border-left: 3px solid #22c55e;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">\u{1F4DD} Note:</div>
          <div style="font-size: 12px; color: #333;">
            \u2022 Layout direction will be auto-detected (horizontal or vertical)<br>
            \u2022 Spacing and padding will be preserved if possible<br>
            \u2022 Frame structure will be maintained
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="autolayout-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="autolayout-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="autolayout-fix-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply</button>
      </div>
    `,i.appendChild(c),document.body.appendChild(i);let p=c.querySelector("#autolayout-fix-cancel-btn"),d=c.querySelector("#autolayout-fix-apply-btn"),S=c.querySelector("#autolayout-fix-ignore-btn"),h=c.querySelector(".modal-close"),f=()=>{i.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{i.parentNode&&i.remove()},200)};p.onclick=()=>{f(),n&&n()},h.onclick=()=>{f(),n&&n()},i.onclick=m=>{m.target===i&&(f(),n&&n())},S.onclick=()=>{f(),l&&l()},d.onclick=()=>{f(),re(e.id,"\u23F3 Enabling auto layout...",!0),parent.postMessage({pluginMessage:{type:"fix-autolayout-issue",issue:e}},"*"),o&&o()}}function Cn(e){return{action:"convert-group"}}function ro(e){if(!Cn(e)){alert("Cannot suggest fix for this group issue");return}In(e)}function In(e){let t=document.createElement("div");t.className="modal-overlay",t.id="group-fix-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="450px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Convert Group to Frame</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          This will convert the Group to a Frame and enable Auto-layout automatically.
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Group</div>
        </div>
        <div style="background: #f0fdf4; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame with Auto-layout</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="group-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="group-fix-apply-btn">Apply</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let l=o.querySelector("#group-fix-cancel-btn"),n=o.querySelector(".modal-close"),s=o.querySelector("#group-fix-apply-btn"),a=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};l.onclick=a,n.onclick=a,t.onclick=i=>{i.target===t&&a()},s.onclick=()=>{s.disabled=!0,s.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-group-issue",issue:e}},"*"),a()}}function $n(e,t={}){let{onApply:o,onIgnore:l,onCancel:n,progress:s}=t,a=s?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${s.current}/${s.total}</div>`:"",i=document.createElement("div");i.className="modal-overlay",i.id="group-fix-modal-overlay";let c=document.createElement("div");c.className="modal-dialog",c.style.maxWidth="450px",c.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Convert Group to Frame</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      ${a}
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          This will convert the Group to a Frame and enable Auto-layout automatically.
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Group</div>
        </div>
        <div style="background: #f0fdf4; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame with Auto-layout</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="group-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="group-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="group-fix-apply-btn">Apply</button>
      </div>
    `,i.appendChild(c),document.body.appendChild(i);let p=c.querySelector("#group-fix-cancel-btn"),d=c.querySelector("#group-fix-apply-btn"),S=c.querySelector("#group-fix-ignore-btn"),h=c.querySelector(".modal-close"),f=()=>{i.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{i.parentNode&&i.remove()},200)};p.onclick=()=>{f(),n&&n()},h.onclick=()=>{f(),n&&n()},i.onclick=m=>{m.target===i&&(f(),n&&n())},S.onclick=()=>{f(),l&&l()},d.onclick=()=>{d.disabled=!0,d.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-group-issue",issue:e}},"*"),f(),o&&o()}}function it(e){return!e||e.type!=="position"?null:{action:"fix-position"}}function ut(e){return!e||e.type!=="duplicate"&&e.type!=="component"?null:{action:"suggest-component"}}function gt(e){return!e||e.type!=="empty-frame"?null:{action:"fix-empty-frame"}}function co(e){if(!it(e)){alert("Cannot suggest fix for this position issue");return}En(e)}function po(e){if(!gt(e)){alert("Cannot suggest fix for this empty frame issue");return}zn(e)}function En(e){let t=e.message||"",o=t.match(/x:(-?\d+)/),l=t.match(/y:(-?\d+)/),n=o?parseInt(o[1],10):0,s=l?parseInt(l[1],10):0,a=document.createElement("div");a.className="modal-overlay",a.id="position-fix-confirm-modal-overlay";let i=document.createElement("div");i.className="modal-dialog",i.style.maxWidth="400px",i.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Fix Position Issue</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            This layer has a negative position which may cause layout issues.
          </p>
          <div style="padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Position:</strong></div>
            <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>${n}px</code><br>
              \u2022 Y: <code>${s}px</code>
            </div>
          </div>
          <div style="padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-size: 12px; color: #1976d2; margin-bottom: 8px;"><strong>After Fix:</strong></div>
            <div style="font-size: 11px; color: #1976d2; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>0px</code><br>
              \u2022 Y: <code>0px</code>
            </div>
          </div>
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          This will set the position to (0, 0) to fix the negative offset.
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="position-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="position-fix-confirm-apply-btn">Apply</button>
      </div>
    `,a.appendChild(i),document.body.appendChild(a);let c=i.querySelector("#position-fix-confirm-cancel-btn"),p=i.querySelector("#position-fix-confirm-apply-btn"),d=i.querySelector(".modal-close"),S=()=>{a.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{a.parentNode&&a.remove()},200)};c.onclick=S,d.onclick=S,a.onclick=h=>{h.target===a&&S()},p.onclick=()=>{S(),re(e.id,"\u23F3 Fixing position...",!0),parent.postMessage({pluginMessage:{type:"fix-position-issue",issue:e}},"*")}}function Mn(e,t={}){let{onApply:o,onIgnore:l,onCancel:n,progress:s}=t,a=s?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${s.current}/${s.total}</div>`:"",i=e.message||"",c=i.match(/x:(-?\d+)/),p=i.match(/y:(-?\d+)/),d=c?parseInt(c[1],10):0,S=p?parseInt(p[1],10):0,h=document.createElement("div");h.className="modal-overlay",h.id="position-fix-confirm-modal-overlay";let f=document.createElement("div");f.className="modal-dialog",f.style.maxWidth="400px",f.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Fix Position Issue</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      ${a}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            This layer has a negative position which may cause layout issues.
          </p>
          <div style="padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Position:</strong></div>
            <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>${d}px</code><br>
              \u2022 Y: <code>${S}px</code>
            </div>
          </div>
          <div style="padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-size: 12px; color: #1976d2; margin-bottom: 8px;"><strong>After Fix:</strong></div>
            <div style="font-size: 11px; color: #1976d2; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>0px</code><br>
              \u2022 Y: <code>0px</code>
            </div>
          </div>
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          This will set the position to (0, 0) to fix the negative offset.
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="position-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="position-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="position-fix-apply-btn">Apply</button>
      </div>
    `,h.appendChild(f),document.body.appendChild(h);let m=f.querySelector("#position-fix-cancel-btn"),g=f.querySelector("#position-fix-apply-btn"),M=f.querySelector("#position-fix-ignore-btn"),T=f.querySelector(".modal-close"),A=()=>{h.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{h.parentNode&&h.remove()},200)};m.onclick=()=>{A(),n&&n()},T.onclick=()=>{A(),n&&n()},h.onclick=F=>{F.target===h&&(A(),n&&n())},M.onclick=()=>{A(),l&&l()},g.onclick=()=>{A(),re(e.id,"\u23F3 Fixing position...",!0),parent.postMessage({pluginMessage:{type:"fix-position-issue",issue:e}},"*"),o&&o()}}function gl(e){uo(e)}function Ft(e){uo(e)}function uo(e){let t=document.createElement("div");t.className="modal-overlay",t.id="remove-layer-confirm-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="400px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Remove Layer</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            Are you sure you want to remove this layer?
          </p>
          <div style="padding: 12px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 6px;">
            <div style="font-size: 12px; color: #856404; margin-bottom: 4px;"><strong>\u26A0\uFE0F Warning:</strong></div>
            <div style="font-size: 11px; color: #856404; line-height: 1.6;">
              This action cannot be undone. The layer and all its children will be permanently deleted.
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="remove-layer-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-danger" id="remove-layer-confirm-apply-btn" style="background: #ef4444; border-color: #ef4444;color: white;">Remove</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let l=o.querySelector("#remove-layer-confirm-cancel-btn"),n=o.querySelector("#remove-layer-confirm-apply-btn"),s=o.querySelector(".modal-close"),a=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};l.onclick=a,s.onclick=a,t.onclick=i=>{i.target===t&&a()},n.onclick=()=>{a(),re(e.id,"\u23F3 Removing layer...",!0),parent.postMessage({pluginMessage:{type:"remove-layer",issue:e}},"*")}}function zn(e){let t=e.message||"",o=t.includes("Empty frame"),l=t.includes("redundant"),n=l?"Remove Redundant Frame":"Remove Empty Frame",s=l?"This will remove the redundant frame and keep its single child. The child will inherit the frame's name if it was unnamed.":"This will remove the empty frame. If it has a child, the child will be kept.",a=document.createElement("div");a.className="modal-overlay",a.id="empty-frame-fix-modal-overlay";let i=document.createElement("div");i.className="modal-dialog",i.style.maxWidth="450px",i.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">${n}</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          ${s}
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">${u(e.message)}</div>
        </div>
        <div style="background: #f0fdf4; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame removed, child kept (if applicable)</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="empty-frame-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="empty-frame-fix-apply-btn">Apply</button>
      </div>
    `,document.body.appendChild(a),a.appendChild(i);let c=i.querySelector("#empty-frame-fix-cancel-btn"),p=i.querySelector(".modal-close"),d=i.querySelector("#empty-frame-fix-apply-btn"),S=()=>{a.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{a.parentNode&&a.remove()},200)};c.onclick=S,p.onclick=S,a.onclick=h=>{h.target===a&&S()},d.onclick=()=>{d.disabled=!0,d.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-empty-frame-issue",issue:e}},"*"),S()}}function Tn(e,t={}){let{onApply:o,onIgnore:l,onCancel:n,progress:s}=t,a=s?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${s.current}/${s.total}</div>`:"",i=e.message||"",c=i.includes("Empty frame"),p=i.includes("redundant"),d=p?"Remove Redundant Frame":"Remove Empty Frame",S=p?"This will remove the redundant frame and keep its single child. The child will inherit the frame's name if it was unnamed.":"This will remove the empty frame. If it has a child, the child will be kept.",h=document.createElement("div");h.className="modal-overlay",h.id="empty-frame-fix-modal-overlay";let f=document.createElement("div");f.className="modal-dialog",f.style.maxWidth="450px",f.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">${d}</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      ${a}
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          ${S}
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">${u(e.message)}</div>
        </div>
        <div style="background: #f0fdf4; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame removed, child kept (if applicable)</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="empty-frame-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="empty-frame-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="empty-frame-fix-apply-btn">Apply</button>
      </div>
    `,document.body.appendChild(h),h.appendChild(f);let m=f.querySelector("#empty-frame-fix-cancel-btn"),g=f.querySelector("#empty-frame-fix-apply-btn"),M=f.querySelector("#empty-frame-fix-ignore-btn"),T=f.querySelector(".modal-close"),A=()=>{h.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{h.parentNode&&h.remove()},200)};m.onclick=()=>{A(),n&&n()},T.onclick=()=>{A(),n&&n()},h.onclick=F=>{F.target===h&&(A(),n&&n())},M.onclick=()=>{A(),l&&l()},g.onclick=()=>{g.disabled=!0,g.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-empty-frame-issue",issue:e}},"*"),A(),o&&o()}}function go(e){if(console.log("handleSuggestFixComponent called",e),!e||!e.id){console.error("Invalid issue in handleSuggestFixComponent",e),alert("Error: Invalid issue data");return}window.pendingComponentIssue=e,console.log("Stored pendingComponentIssue:",window.pendingComponentIssue);let t=document.querySelector(`.issue[data-issue-id="${e.id}"]`);if(t){let o=t.querySelector("button.btn-suggest-fix");if(o){let l=o.textContent;o.disabled=!0,o.textContent="Loading...",o.style.opacity="0.6",o.style.cursor="wait",o.dataset.originalText=l}}console.log("Sending get-components-for-issue message",{issueId:e.id,issue:e}),parent.postMessage({pluginMessage:{type:"get-components-for-issue",issue:e}},"*")}function mo(e){if(console.log("handleSelectComponent called",e),!e||!e.id){console.error("Invalid issue in handleSelectComponent",e),alert("Error: Invalid issue data");return}window.pendingSelectComponentIssue=e,console.log("Stored pendingSelectComponentIssue:",window.pendingSelectComponentIssue);let t=document.querySelector(`.issue[data-issue-id="${e.id}"]`);if(t){let o=t.querySelector("button.btn-select-component");if(o){let l=o.textContent;o.disabled=!0,o.textContent="Loading...",o.style.opacity="0.6",o.dataset.originalText=l}}console.log("Sending get-all-components message",{issueId:e.id,issue:e}),parent.postMessage({pluginMessage:{type:"get-all-components",issue:e}},"*")}function fo(e){Nn(e)}function yo(e){Fn(e)}function Fn(e){let t=document.createElement("div");t.className="modal-overlay",t.id="rename-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="400px";let l=e.nodeName||"",n=l.replace(/^(Frame|Group)\s*/i,"").trim()||"";o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Rename Node</h2>
        <p class="modal-subtitle">Current: ${u(l)}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <label style="display: block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #333;">New Name:</label>
          <input type="text" id="rename-input" placeholder="Enter meaningful name" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px;" value="${u(n)}" autocomplete="off">
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          Enter a meaningful name that describes the purpose of this layer (e.g., "Header", "Button", "Card").
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="rename-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="rename-apply-btn">Rename</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let s=o.querySelector("#rename-cancel-btn"),a=o.querySelector("#rename-apply-btn"),i=o.querySelector(".modal-close"),c=o.querySelector("#rename-input");setTimeout(()=>{c.focus(),c.select()},100);let p=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};s.onclick=p,i.onclick=p,t.onclick=d=>{d.target===t&&p()},c.addEventListener("keydown",d=>{d.key==="Enter"&&(d.preventDefault(),a.click())}),a.onclick=()=>{let d=c.value.trim();if(!d){alert("Please enter a name"),c.focus();return}if(/^(Frame|Group)\s*$/i.test(d)&&!confirm("The name still contains default naming (Frame/Group). Do you want to continue?")){c.focus();return}p(),re(e.id,"\u23F3 Renaming...",!0),parent.postMessage({pluginMessage:{type:"rename-node",issue:e,newName:d}},"*")}}function Nn(e){let t=document.createElement("div");t.className="modal-overlay",t.id="create-component-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="400px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Create New Component</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <label style="display: block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #333;">Component Name:</label>
          <input type="text" id="create-component-name-input" placeholder="Enter component name" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px;" value="${u(e.nodeName||"")}">
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          This will convert the frame to a component and replace all duplicate frames with instances of this component.
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="create-component-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="create-component-apply-btn">Create</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let l=o.querySelector("#create-component-cancel-btn"),n=o.querySelector("#create-component-apply-btn"),s=o.querySelector(".modal-close"),a=o.querySelector("#create-component-name-input");setTimeout(()=>a.focus(),100);let i=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};l.onclick=i,s.onclick=i,t.onclick=c=>{c.target===t&&i()},n.onclick=()=>{let c=a.value.trim();if(!c){alert("Please enter a component name");return}i(),re(e.id,"\u23F3 Creating component...",!0),parent.postMessage({pluginMessage:{type:"create-component-from-issue",issue:e,componentName:c}},"*")}}function Bn(e,t){if(console.log("[showComponentSuggestModal] Called with",{issue:e,similarComponents:t}),!t||t.length===0){console.warn("[showComponentSuggestModal] No similar components provided"),alert("No similar components found.");return}let o=t[0];console.log("[showComponentSuggestModal] Using best match:",o),ho(e,o,"This is the most similar component found.")}function An(e,t){if(console.log("[showComponentSelectModal] Called with",{issue:e,components:t}),!t||t.length===0){console.warn("[showComponentSelectModal] No components provided"),alert("No components available.");return}let o=document.createElement("div");o.className="modal-overlay",o.id="component-select-modal-overlay";let l=document.createElement("div");l.className="modal-dialog",l.style.maxWidth="500px";let n=t.map(m=>`
        <div class="component-picker-item" data-component-id="${m.id}" data-component-name="${u(m.name.toLowerCase())}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 2px solid #ddd;
          border-radius: 8px;
          cursor: pointer;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='#ddd'; this.style.boxShadow='none'">
          <div style="font-weight: 600; font-size: 12px; color: #333;">${u(m.name)}</div>
          <div style="font-size: 11px; color: #666; margin-top: 4px;">
            ${m.description||"Component"}
          </div>
        </div>
      `).join(""),s=t.length>5,a=s?`
      <div style="margin-bottom: 16px;">
        <input type="text" id="component-search-input" placeholder="Search components by name..." style="
          width: 100%;
          padding: 8px 12px;
          border: 1px solid #ddd;
          border-radius: 6px;
          font-size: 13px;
          box-sizing: border-box;
        " autocomplete="off">
        <div id="component-search-results-count" style="font-size: 11px; color: #666; margin-top: 4px; display: none;"></div>
      </div>
    `:"";l.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Select Component</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        ${a}
        <div id="component-list-container" style="max-height: 400px; overflow-y: auto;">
          ${n}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="component-select-cancel-btn">Cancel</button>
      </div>
    `,o.appendChild(l),document.body.appendChild(o),console.log("[showComponentSelectModal] Modal added to DOM"),console.log("[showComponentSelectModal] Overlay element:",o),console.log("[showComponentSelectModal] Dialog element:",l),o.style.display="flex",o.style.opacity="1",o.style.zIndex="10000";let i=l.querySelector("#component-select-cancel-btn"),c=l.querySelector(".modal-close"),p=l.querySelectorAll(".component-picker-item"),d=l.querySelector("#component-search-input"),S=l.querySelector("#component-list-container"),h=l.querySelector("#component-search-results-count");console.log("[showComponentSelectModal] Found",p.length,"component items"),console.log("[showComponentSelectModal] Cancel button:",i,"Close button:",c),d&&s&&(d.addEventListener("input",m=>{let g=m.target.value.toLowerCase().trim(),M=0;p.forEach(T=>{let A=T.getAttribute("data-component-name")||"";g===""||A.includes(g)?(T.style.display="block",M++):T.style.display="none"}),h&&(g!==""?(h.textContent=`Showing ${M} of ${t.length} components`,h.style.display="block"):h.style.display="none")}),setTimeout(()=>d.focus(),100));let f=()=>{console.log("[showComponentSelectModal] Closing modal"),o.style.animation="fadeIn 0.2s ease-out reverse",o.style.opacity="0",setTimeout(()=>{o.parentNode&&(o.remove(),console.log("[showComponentSelectModal] Modal removed from DOM"))},200)};i?i.onclick=m=>{m.preventDefault(),m.stopPropagation(),f()}:console.error("[showComponentSelectModal] Cancel button not found!"),c?c.onclick=m=>{m.preventDefault(),m.stopPropagation(),f()}:console.error("[showComponentSelectModal] Close button not found!"),o.onclick=m=>{m.target===o&&f()},p.forEach((m,g)=>{m.onclick=M=>{M.preventDefault(),M.stopPropagation(),console.log("[showComponentSelectModal] Component item clicked",g);let T=m.getAttribute("data-component-id");console.log("[showComponentSelectModal] Component ID:",T);let A=t.find(F=>F.id===T);console.log("[showComponentSelectModal] Found component:",A),A?(f(),ho(e,A,null)):console.error("[showComponentSelectModal] Component not found for ID:",T)}}),setTimeout(()=>{o.style.animation="fadeIn 0.2s ease-out",o.style.opacity="1",console.log("[showComponentSelectModal] Animation triggered, overlay visible:",o.offsetParent!==null)},10),console.log("[showComponentSelectModal] Modal setup complete")}function ho(e,t,o){let l=document.createElement("div");l.className="modal-overlay",l.id="component-apply-confirm-modal-overlay";let n=document.createElement("div");n.className="modal-dialog",n.style.maxWidth="400px",n.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Component</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            This will replace the frame with an instance of the selected component.
          </p>
          <div style="padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-size: 12px; color: #1976d2; margin-bottom: 8px;"><strong>Selected Component:</strong></div>
            <div style="font-size: 14px; color: #333; font-weight: 600;">${u(t.name)}</div>
            ${t.description?`<div style="font-size: 11px; color: #666; margin-top: 4px;">${u(t.description)}</div>`:""}
          </div>
          ${o?`<p style="color: #666; font-size: 12px; margin-top: 12px;">${u(o)}</p>`:""}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="component-apply-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="component-apply-apply-btn">Apply</button>
      </div>
    `,l.appendChild(n),document.body.appendChild(l);let s=n.querySelector("#component-apply-cancel-btn"),a=n.querySelector("#component-apply-apply-btn"),i=n.querySelector(".modal-close"),c=()=>{l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove()},200)};s.onclick=c,i.onclick=c,l.onclick=p=>{p.target===l&&c()},a.onclick=()=>{c(),re(e.id,"\u23F3 Applying component...",!0),parent.postMessage({pluginMessage:{type:"apply-component-to-issue",issue:e,componentId:t.id}},"*")}}function at(e){if(!e||!e.fontSize)return null;let t=e.fontSize,o=14,l=document.getElementById("font-size-scale");if(l&&l.value.trim()){let n=l.value.split(",").map(s=>parseInt(s.trim(),10)).filter(s=>!isNaN(s)&&s>=o).sort((s,a)=>s-a);if(n.length>0){let s=null,a=1/0;n.forEach(c=>{if(c>=o){let p=Math.abs(c-t);p<a&&(a=p,s=c)}});let i=Math.max(t*.5,10);if(s&&a<=i)return s}}return t<o?o:null}function mt(e){if(!e||!e.textColor||!e.backgroundColor)return null;let t=e.textColor.toUpperCase(),o=e.backgroundColor.toUpperCase(),l=e.minContrast||4.5,n=document.getElementById("color-scale");if(!n||!n.value.trim())return null;let s=n.value.split(",").map(p=>p.trim().toUpperCase()).filter(p=>p&&p.startsWith("#"));if(s.length===0)return null;let a=null,i=0,c=1/0;return s.forEach(p=>{let d=Pt(p,o);if(d>=l){let S=qt(t,p);(d>i||d===i&&S<c)&&(i=d,a=p,c=S)}}),a}function bo(e,t){if(!t||t.length===0){alert("No text styles found in Figma. Please create text styles first.");return}let o=document.createElement("div");o.className="modal-overlay",o.id="text-style-picker-typography-modal-overlay";let l=document.createElement("div");l.className="modal-dialog",l.style.maxWidth="500px";let n=e.nodeProps||{},s=n.fontFamily||"Unknown",a=n.fontSize!==null&&n.fontSize!==void 0?n.fontSize:null,i=a!==null?`${a}px`:"Unknown",c=n.fontWeight||"Unknown",p=n.lineHeight||"Unknown",d=n.letterSpacing!==null&&n.letterSpacing!==void 0?n.letterSpacing:"Unknown",S=null;e.bestMatch&&e.bestMatch.name&&(S=e.bestMatch.name);let h=b=>{if(b==null||b==="Unknown")return"";let P=String(b).toLowerCase().trim(),x=P.match(/^([+-]?\d*\.?\d+)(px|%)?$/);if(x){let E=parseFloat(x[1]);if(Math.abs(E)<1e-6)return"0";let q=x[2]||"px";return`${Math.round(E*100)/100}${q}`}return P},f=b=>{let P=`picker_${h(s)}_${a}_${h(c)}_${h(p)}_${h(d)}_${b.id}`;return fe(P,()=>{let x=0;if(h(s)===h(b.fontFamily)&&(x+=25),a!==null&&b.fontSize){let E=Math.abs(a-b.fontSize);E===0?x+=30:E<=2?x+=25:E<=4?x+=20:E<=8&&(x+=10)}return h(c)===h(b.fontWeight)&&(x+=20),h(p)===h(b.lineHeight)&&(x+=15),h(d)===h(b.letterSpacing||"0")&&(x+=10),x})},m=[...t].sort((b,P)=>S===b.name?-1:S===P.name?1:f(P)-f(b)),g=(b,P)=>h(b)!==h(P),M=b=>{let P=S===b.name,x=f(b),E=g(s,b.fontFamily),q=g(i,`${b.fontSize}px`),se=g(c,b.fontWeight),he=g(p,b.lineHeight),Ee=g(d,b.letterSpacing||"0"),be="color: #155724;",N="color: #721c24; background: #f8d7da; padding: 1px 4px; border-radius: 3px; font-weight: 600;";return`
        <div class="style-picker-item" data-style-id="${b.id}" data-style-name="${u(b.name)}" data-font-size="${b.fontSize}" data-similarity="${x}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 1px solid ${P?"#0071e3":"#ddd"};
          border-radius: 8px;
          cursor: pointer;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='${P?"#0071e3":"#ddd"}'; this.style.boxShadow='none'">
          <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
            <div>
              <div style="font-weight: 600; font-size: 12px; color: #333;">${u(b.name)} ${P?"\u2B50":""}</div>
              <div style="font-size: 11px; color: #666; margin-top: 4px;">
                ${u(b.fontFamily)} ${b.fontSize}px ${u(b.fontWeight)}
              </div>
            </div>
            <div style="text-align: right;">
              ${P?'<div style="color: #0071e3; font-weight: 600; font-size: 11px;">Best Match</div>':""}
              <div style="color: #666; font-size: 10px; margin-top: 2px;">${x}% match</div>
            </div>
          </div>
          <div style="font-size: 11px; color: #666; padding-top: 8px; border-top: 1px solid #eee;">
            <div style="margin-bottom: 4px;"><strong>Details:</strong></div>
            <div style="padding-left: 8px; line-height: 1.8;">
              \u2022 Font Family: <code style="${E?N:be}">${E?"\u26A0 ":"\u2713 "}${u(b.fontFamily)}</code><br>
              \u2022 Font Size: <code style="${q?N:be}">${q?"\u26A0 ":"\u2713 "}${b.fontSize}px</code><br>
              \u2022 Font Weight: <code style="${se?N:be}">${se?"\u26A0 ":"\u2713 "}${u(b.fontWeight)}</code><br>
              \u2022 Line Height: <code style="${he?N:be}">${he?"\u26A0 ":"\u2713 "}${u(b.lineHeight)}</code><br>
              \u2022 Letter Spacing: <code style="${Ee?N:be}">${Ee?"\u26A0 ":"\u2713 "}${u(b.letterSpacing||"0")}</code>
            </div>
          </div>
        </div>
      `},T=m.map(b=>M(b)).join("");l.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Text Style</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Properties:</strong></div>
          <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
            \u2022 Font Family: <code>${u(s)}</code><br>
            \u2022 Font Size: <code>${u(i)}</code><br>
            \u2022 Font Weight: <code>${u(c)}</code><br>
            \u2022 Line Height: <code>${u(p)}</code><br>
            \u2022 Letter Spacing: <code>${u(d)}</code>
          </div>
        </div>
        <!-- Search Input -->
        <div style="margin-bottom: 12px;">
          <input type="text" id="style-search-input" placeholder="\u{1F50D} Search styles by name..." style="
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 13px;
            box-sizing: border-box;
            outline: none;
          " onfocus="this.style.borderColor='#0071e3'" onblur="this.style.borderColor='#ddd'" />
        </div>
        <div id="style-list-container" style="max-height: 280px; overflow-y: auto;">
          ${T}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="text-style-picker-typography-modal-cancel-btn">Cancel</button>
      </div>
    `,o.appendChild(l),document.body.appendChild(o);let A=l.querySelector("#text-style-picker-typography-modal-cancel-btn"),F=l.querySelector(".modal-close"),j=l.querySelector("#style-search-input"),z=l.querySelector("#style-list-container"),D=()=>{o.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{o.parentNode&&o.remove()},200)};A.onclick=D,F.onclick=D,o.onclick=b=>{b.target===o&&D()},j.oninput=b=>{let P=b.target.value.toLowerCase().trim(),x=m.filter(E=>E.name.toLowerCase().includes(P));z.innerHTML=x.map(E=>M(E)).join(""),ye()};let ye=()=>{l.querySelectorAll(".style-picker-item").forEach(P=>{P.onclick=x=>{x.preventDefault(),x.stopPropagation();let E=P.getAttribute("data-style-id"),q=t.find(se=>se.id===E);q&&(o.style.display="none",Ln(e,q,o))}})};ye(),setTimeout(()=>{j.focus()},100)}function Ln(e,t,o){let l=document.createElement("div");l.className="modal-overlay",l.id="typography-style-confirm-modal-overlay";let n=document.createElement("div");n.className="modal-dialog",n.style.maxWidth="500px";let s=e.nodeProps||{},a=s.fontFamily||"Unknown",i=s.fontSize!==null&&s.fontSize!==void 0?`${s.fontSize}px`:"Unknown",c=s.fontWeight||"Unknown",p=s.lineHeight||"Unknown",d=s.letterSpacing!==null&&s.letterSpacing!==void 0?s.letterSpacing:"Unknown";n.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Text Style Application</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Apply Text Style:</div>
          <div style="padding: 12px; background: #e3f2fd; border-left: 3px solid #0071e3; border-radius: 6px;">
            <div style="font-weight: 600; font-size: 16px; color: #333; margin-bottom: 8px;">${u(t.name)}</div>
            <div style="font-size: 12px; color: #666; line-height: 1.6;">
              \u2022 Font Family: <code>${u(t.fontFamily)}</code><br>
              \u2022 Font Size: <code>${t.fontSize}px</code><br>
              \u2022 Font Weight: <code>${u(t.fontWeight)}</code><br>
              \u2022 Line Height: <code>${u(t.lineHeight)}</code><br>
              \u2022 Letter Spacing: <code>${u(t.letterSpacing||"0")}</code>
            </div>
          </div>
        </div>
        <div style="padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Properties:</strong></div>
          <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
            \u2022 Font Family: <code>${u(a)}</code><br>
            \u2022 Font Size: <code>${u(i)}</code><br>
            \u2022 Font Weight: <code>${u(c)}</code><br>
            \u2022 Line Height: <code>${u(p)}</code><br>
            \u2022 Letter Spacing: <code>${u(d)}</code>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="typography-style-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="typography-style-confirm-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply</button>
      </div>
    `,l.appendChild(n),document.body.appendChild(l);let S=n.querySelector("#typography-style-confirm-cancel-btn"),h=n.querySelector("#typography-style-confirm-apply-btn"),f=n.querySelector(".modal-close"),m=()=>{l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove(),o&&o.parentNode&&(o.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{o.parentNode&&o.remove()},200))},200)},g=()=>{l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove(),o&&(o.style.display="flex")},200)};S.onclick=g,f.onclick=g,l.onclick=M=>{M.target===l&&g()},h.onclick=()=>{m(),re(e.id,"\u23F3 Applying style...",!0),$o(e,t)}}function Hn(e,t){let o=t.filter(d=>d.fontSize>=14);if(o.length===0){let d=at(e);d?Nt(e,e.fontSize||12,d,null,null):alert("No text styles found with fontSize >= 14px. Please add font sizes to Font Size input or create text styles in Figma.");return}let l=document.createElement("div");l.className="modal-overlay",l.id="text-style-picker-modal-overlay";let n=document.createElement("div");n.className="modal-dialog",n.style.maxWidth="400px";let s=o.map(d=>`
        <div class="style-picker-item" data-style-id="${d.id}" data-font-size="${d.fontSize}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 2px solid #ddd;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='#ddd'; this.style.boxShadow='none'">
          <div>
            <div style="font-weight: 600; font-size: 12px; color: #333;">${u(d.name)}</div>
            <div style="font-size: 10px; color: #666; margin-top: 4px;">
              ${u(d.fontFamily)} ${u(d.fontSize)}px ${u(d.fontWeight)}
            </div>
          </div>
          <div style="color: #22c55e; font-weight: 600; font-size: 12px;">\u2713 ADA</div>
        </div>
      `).join("");n.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Text Style</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")} - Select style with fontSize >= 14px</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Font Size:</div>
          <div style="font-size: 16px; font-weight: 600; color: #333;">${e.fontSize||12}px</div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${s}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="text-style-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,l.appendChild(n),document.body.appendChild(l);let a=n.querySelector("#text-style-picker-modal-cancel-btn"),i=n.querySelector(".modal-close"),c=n.querySelectorAll(".style-picker-item"),p=()=>{l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove()},200)};a.onclick=p,i.onclick=p,l.onclick=d=>{d.target===l&&p()},c.forEach(d=>{d.onclick=S=>{S.preventDefault(),S.stopPropagation();let h=d.getAttribute("data-style-id"),f=parseInt(d.getAttribute("data-font-size")),m=o.find(g=>g.id===h);m&&(l.style.display="none",Nt(e,e.fontSize||12,f,l,m))}})}function qn(e,t){let o=document.getElementById("color-scale"),l=o&&o.value.trim()?o.value.split(",").map(g=>g.trim().toUpperCase()).filter(g=>g&&g.startsWith("#")):[],n=[];if(t.filter(g=>g.source==="variable").forEach(g=>{n.push({source:"Variable",name:g.name,hex:g.hex,id:g.id,variable:g.variable})}),t.filter(g=>g.source==="style").forEach(g=>{n.push({source:"Style",name:g.name,hex:g.hex,id:g.id,style:g.style})}),l.forEach(g=>{let M=J[g]||g;n.push({source:"Input",name:M,hex:g,id:null})}),n.length===0){alert("No colors available. Please add colors to Color input or create color styles/variables in Figma.");return}let s=e.backgroundColor||"#FFFFFF",a=e.minContrast||4.5,i=e.textColor||"#000000",c=document.createElement("div");c.className="modal-overlay",c.id="contrast-color-picker-modal-overlay";let p=document.createElement("div");p.className="modal-dialog",p.style.maxWidth="400px";let d=n.map(g=>{let M=Pt(g.hex,s),T=M>=a,A=T?"#22c55e":"#ddd",F=`${u(g.name)} <span style="font-size: 11px; color: #666;">(${u(g.source)})</span>`,j=`<span style="color: ${T?"#22c55e":"#ef4444"};">Contrast: ${M.toFixed(2)}:1 ${T?"\u2713":"\u2717"} (need >= ${a}:1)</span>`;return oo(g.hex,F,A,j)}).join("");p.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Color</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")} - Select color that passes contrast</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Text Color:</div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 32px; height: 32px; border-radius: 4px; background: ${u(i)}; border: 1px solid #ddd;"></div>
            <div style="font-family: 'SF Mono', Monaco, monospace; font-size: 11px; font-weight: 600;">${u(i)}</div>
            <div style="font-size: 11px; color: #ef4444;">Contrast: ${e.contrast?e.contrast.toFixed(2):"N/A"}:1 (fails)</div>
          </div>
          <div style="font-size: 11px; color: #666; margin-top: 4px;">Background: ${u(s)}</div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${d}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="contrast-color-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,c.appendChild(p),document.body.appendChild(c);let S=p.querySelector("#contrast-color-picker-modal-cancel-btn"),h=p.querySelector(".modal-close"),f=p.querySelectorAll(".color-picker-item"),m=()=>{c.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{c.parentNode&&c.remove()},200)};S.onclick=m,h.onclick=m,c.onclick=g=>{g.target===c&&m()},f.forEach(g=>{g.onclick=M=>{M.preventDefault(),M.stopPropagation();let T=g.getAttribute("data-color");c.style.display="none",So(e,i,T,c)}})}function xo(e){parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:e.id}},"*"),window.pendingTextSizeIssue=e}function jt(e){parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:e.id}},"*"),window.pendingSuggestTextSizeIssue=e}function Nt(e,t,o,l,n){let s=(x,E)=>{if(x===E)return 100;let q=20,se=Math.abs(x-E);return Math.max(0,Math.round((1-se/q)*100))},i=[14,16,18,20,24,28,32,36,40,48].map(x=>({size:x,similarity:s(t,x),diff:Math.abs(t-x)})).sort((x,E)=>o!==void 0&&x.size===o?-1:o!==void 0&&E.size===o?1:x.diff-E.diff).slice(0,5),c=i.length>0?i[0].size:o,p=(x,E)=>{let q=x.size>=14;return`
        <div class="text-size-option-item" data-size="${x.size}" style="
          padding: 6px 8px;
          margin-bottom: 6px;
          border: 1px solid ${E?"#0071e3":"#e0e0e0"};
          border-radius: 8px;
          cursor: pointer;
          background: ${E?"#e3f2fd":"white"};
          display: flex;
          align-items: center;
          gap: 12px;
          transition: all 0.15s;
        ">
          <input type="radio" name="text-size-option" ${E?"checked":""} style="margin: 0; cursor: pointer; display: none;" />
          <div style="
            width: 40px;
            height: 40px;
            border-radius: 6px;
            background: ${E?"#e3f2fd":"#f0f0f0"};
            border: 1px solid ${E?"#0071e3":"#ddd"};
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 11px;
            font-weight: 600;
            color: ${E?"#0071e3":"#666"};
            flex-shrink: 0;
          ">${x.size}</div>
          <div style="flex: 1;">
            <div style="font-weight: 600; font-size: 11px; color: #333;">${x.size}px</div>
            <div style="font-size: 10px; color: ${q?"#155724":"#721c24"};">
              ${q?"\u2713 ADA compliant":"\u26A0 Below minimum"}
            </div>
          </div>
          <span style="font-size: 11px; color: #666; background: #f0f0f0; padding: 2px 8px; border-radius: 10px;">${x.similarity}%</span>
        </div>
      `},d=document.createElement("div");d.className="modal-overlay",d.id="text-size-fix-confirm-modal-overlay";let S=document.createElement("div");S.className="modal-dialog",S.style.maxWidth="420px";let h=window.pendingTextSizeFixAllCallbacks||null,f=h&&h.progress?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${h.progress.current}/${h.progress.total}</div>`:"",m=n?`
      <div style="margin-top: 12px; padding: 10px; background: #f0fdf4; border-radius: 6px; border-left: 3px solid #22c55e;">
        <div style="font-size: 11px; color: #666; margin-bottom: 4px;">\u{1F4DD} Text Style s\u1EBD \u0111\u01B0\u1EE3c \xE1p d\u1EE5ng:</div>
        <div style="font-weight: 600; font-size: 13px; color: #333;">${u(n.name)}</div>
        <div style="font-size: 10px; color: #666; margin-top: 4px;">
          ${u(n.fontFamily)} ${n.fontSize}px ${u(n.fontWeight)}
        </div>
      </div>
    `:"",g=i.map((x,E)=>p(x,E===0)).join("");S.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Text Size</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      ${f}
      <div class="modal-body">
        <div style="margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 6px; display: flex; align-items: center; gap: 10px;">
          <div style="
            width: 40px;
            height: 40px;
            border-radius: 4px;
            background: #f0f0f0;
            border: 1px solid #ddd;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: 600;
            color: #666;
          ">${t}</div>
          <div>
            <div style="font-size: 11px; color: #666;">Current Size:</div>
            <div style="font-size: 14px; font-weight: 600;">${t}px <span style="font-size: 11px; color: #ef4444;">(Too small)</span></div>
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px;">
          Select a size to apply (Top 5 closest):
        </div>
        <div id="text-size-options-container" style="max-height: 280px; overflow-y: auto;">
          ${g}
        </div>
        ${m}
      </div>
      <div class="modal-footer">
        ${window.pendingTextSizeFixAllCallbacks?'<button class="modal-btn modal-btn-cancel" id="text-size-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="text-size-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="text-size-fix-confirm-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply</button>
      </div>
    `,d.appendChild(S),document.body.appendChild(d);let M=S.querySelector("#text-size-fix-confirm-cancel-btn"),T=S.querySelector("#text-size-fix-confirm-apply-btn"),A=S.querySelector("#text-size-fix-ignore-btn"),F=S.querySelector(".modal-close"),j=S.querySelector("#text-size-options-container"),z=h,D=x=>{c=x,j.querySelectorAll(".text-size-option-item").forEach(q=>{let he=parseInt(q.getAttribute("data-size"),10)===x;q.style.border=he?"2px solid #0071e3":"2px solid #e0e0e0",q.style.background=he?"#e3f2fd":"white";let Ee=q.querySelector('input[type="radio"]');Ee&&(Ee.checked=he)})};(()=>{j.querySelectorAll(".text-size-option-item").forEach(E=>{E.onclick=q=>{q.preventDefault();let se=parseInt(E.getAttribute("data-size"),10);D(se)}})})();let b=()=>{d.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{d.parentNode&&d.remove(),l&&(l.style.display="block")},200)},P=()=>{d.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{d.parentNode&&d.remove(),l&&l.parentNode&&(l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove()},200))},200)};M.onclick=()=>{z&&z.onCancel?(P(),window.pendingTextSizeFixAllCallbacks=null,z.onCancel()):b()},F.onclick=()=>{z&&z.onCancel?(P(),window.pendingTextSizeFixAllCallbacks=null,z.onCancel()):b()},d.onclick=x=>{x.target===d&&(z&&z.onCancel?(P(),window.pendingTextSizeFixAllCallbacks=null,z.onCancel()):b())},A&&(A.onclick=()=>{P(),z&&z.onIgnore&&(window.pendingTextSizeFixAllCallbacks=null,z.onIgnore())}),T.onclick=()=>{P(),re(e.id,"\u23F3 Fixing text size...",!0),n&&n.id?parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:e,styleId:n.id,styleName:n.name}},"*"):parent.postMessage({pluginMessage:{type:"fix-text-size-issue",issue:e,fontSize:c}},"*"),z&&z.onApply&&(window.pendingTextSizeFixAllCallbacks=null,z.onApply())}}function vo(e){parent.postMessage({pluginMessage:{type:"get-contrast-colors",issue:e}},"*"),window.pendingContrastIssue=e}function Ot(e){let t=mt(e);if(!t){alert("No suitable color found that passes contrast requirements");return}So(e,e.textColor,t,null)}function So(e,t,o,l){let n=e.backgroundColor||"#FFFFFF",s=e.minContrast||4.5,a=(x,E)=>{let q=x.replace("#",""),se=E.replace("#",""),he=parseInt(q.substr(0,2),16),Ee=parseInt(q.substr(2,2),16),be=parseInt(q.substr(4,2),16),N=parseInt(se.substr(0,2),16),ce=parseInt(se.substr(2,2),16),K=parseInt(se.substr(4,2),16);return Math.sqrt(Math.pow(he-N,2)+Math.pow(Ee-ce,2)+Math.pow(be-K,2))},i=(x,E)=>{let se=a(x,E);return Math.round((1-se/441.67)*100)},p=Object.keys(J).map(x=>{let E=Pt(x,n);return{color:x,name:J[x]||x,contrast:E,passes:E>=s,similarity:i(t,x),distance:a(t,x)}}).filter(x=>x.passes).sort((x,E)=>o&&x.color===o?-1:o&&E.color===o?1:x.distance-E.distance).slice(0,5),d=p.length>0?p[0].color:o,S=(x,E)=>`
        <div class="contrast-color-option-item" data-color="${u(x.color)}" style="
          padding: 10px 12px;
          margin-bottom: 6px;
          border: 1px solid ${E?"#0071e3":"#e0e0e0"};
          border-radius: 8px;
          cursor: pointer;
          background: ${E?"#e3f2fd":"white"};
          display: flex;
          align-items: center;
          gap: 12px;
          transition: all 0.15s;
        ">
          <input type="radio" name="contrast-color-option" ${E?"checked":""} style="margin: 0; cursor: pointer;" />
          <div style="
            width: 36px;
            height: 36px;
            border-radius: 6px;
            background: ${u(x.color)};
            border: 1px solid ${E?"#0071e3":"#ddd"};
            flex-shrink: 0;
          "></div>
          <div style="flex: 1;">
            <div style="font-weight: 600; font-size: 13px; color: #333;">${u(x.name)}</div>
            <div style="font-size: 10px; color: #666; font-family: 'SF Mono', Monaco, monospace;">${u(x.color)}</div>
            <div style="font-size: 10px; color: #22c55e; margin-top: 2px;">\u2713 ${x.contrast.toFixed(2)}:1</div>
          </div>
          <span style="font-size: 11px; color: #666; background: #f0f0f0; padding: 2px 8px; border-radius: 10px;">${x.similarity}%</span>
        </div>
      `,h=window.pendingContrastFixAllCallbacks||null,f=h&&h.progress?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${h.progress.current}/${h.progress.total}</div>`:"",m=document.createElement("div");m.className="modal-overlay",m.id="contrast-fix-confirm-modal-overlay";let g=document.createElement("div");g.className="modal-dialog",g.style.maxWidth="420px";let M=p.length>0?p.map((x,E)=>S(x,E===0)).join(""):`<div style="padding: 20px; text-align: center; color: #666;">No colors available that pass contrast requirements (>= ${s}:1)</div>`;g.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Contrast Color</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      ${f}
      <div class="modal-body">
        <div style="margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 6px;">
          <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
            <div style="
              width: 32px;
              height: 32px;
              border-radius: 4px;
              background: ${u(t)};
              border: 1px solid #ddd;
            "></div>
            <div>
              <div style="font-size: 11px; color: #666;">Current:</div>
              <div style="font-size: 12px; font-weight: 600; font-family: 'SF Mono', Monaco, monospace;">${u(t)}</div>
              <div style="font-size: 10px; color: #ef4444;">Contrast: ${e.contrast?e.contrast.toFixed(2):"N/A"}:1 \u2717</div>
            </div>
          </div>
          <div style="font-size: 10px; color: #666; padding: 4px 8px; background: #e0e0e0; border-radius: 4px; display: inline-block;">
            Background: ${u(n)} | Minimum: ${s}:1
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 8px;">
          Select a color to apply (Top 5 passing contrast):
        </div>
        <div id="contrast-color-options-container" style="max-height: 280px; overflow-y: auto;">
          ${M}
        </div>
      </div>
      <div class="modal-footer">
        ${window.pendingContrastFixAllCallbacks?'<button class="modal-btn modal-btn-cancel" id="contrast-fix-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="contrast-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="contrast-fix-confirm-apply-btn" style="background: #22c55e; border-color: #22c55e;" ${p.length===0?"disabled":""}>Apply</button>
      </div>
    `,m.appendChild(g),document.body.appendChild(m);let T=g.querySelector("#contrast-fix-confirm-cancel-btn"),A=g.querySelector("#contrast-fix-confirm-apply-btn"),F=g.querySelector("#contrast-fix-ignore-btn"),j=g.querySelector(".modal-close"),z=g.querySelector("#contrast-color-options-container"),D=h,ye=x=>{d=x,z.querySelectorAll(".contrast-color-option-item").forEach(q=>{let he=q.getAttribute("data-color")===x;q.style.border=he?"2px solid #0071e3":"2px solid #e0e0e0",q.style.background=he?"#e3f2fd":"white";let Ee=q.querySelector('input[type="radio"]');Ee&&(Ee.checked=he)})};(()=>{z.querySelectorAll(".contrast-color-option-item").forEach(E=>{E.onclick=q=>{q.preventDefault();let se=E.getAttribute("data-color");ye(se)}})})();let P=()=>{m.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{m.parentNode&&m.remove(),l&&(l.style.display="block")},200)};T.onclick=()=>{D&&D.onCancel?(P(),window.pendingContrastFixAllCallbacks=null,D.onCancel()):P()},j.onclick=()=>{D&&D.onCancel?(P(),window.pendingContrastFixAllCallbacks=null,D.onCancel()):P()},m.onclick=x=>{x.target===m&&(D&&D.onCancel?(P(),window.pendingContrastFixAllCallbacks=null,D.onCancel()):P())},F&&(F.onclick=()=>{P(),D&&D.onIgnore&&(window.pendingContrastFixAllCallbacks=null,D.onIgnore())}),A.onclick=()=>{p.length!==0&&(P(),re(e.id,"\u23F3 Fixing contrast...",!0),parent.postMessage({pluginMessage:{type:"fix-contrast-issue",issue:e,color:d}},"*"),D&&D.onApply&&(window.pendingContrastFixAllCallbacks=null,D.onApply()))}}function ko(e){try{if(ue[e.id]===!0){if(delete ue[e.id],k&&k.issues){let o=k.issues.find(l=>l.id===e.id);if(o){o.ignored=!1;let l=o.originalSeverity||(o.severity==="info"?"error":o.severity);o.severity=l,o.originalSeverity=void 0,e.severity=l,e.ignored=!1}}ve(),wo(e,!1),lt(),parent.postMessage({pluginMessage:{type:"notify",message:"\u2705 Issue un-ignored"}},"*")}else{if(!confirm(`Ignore this contrast issue?

Node: ${e.nodeName||"Unnamed"}

This issue will be marked as "Pass with ignore custom" and won't be counted as an error.`))return;if(k&&k.issues){let o=k.issues.find(l=>l.id===e.id);o&&(o.originalSeverity||(o.originalSeverity=o.severity),o.ignored=!0,o.severity="info",e.ignored=!0,e.originalSeverity=o.originalSeverity,e.severity="info")}ue[e.id]=!0,ve(),wo(e,!0),lt(),parent.postMessage({pluginMessage:{type:"notify",message:"\u2705 Issue ignored"}},"*")}}catch(t){console.error("Error in handleIgnoreIssue:",t),parent.postMessage({pluginMessage:{type:"notify",message:`\u274C Error: ${t.message}`}},"*")}}function wo(e,t){let o=document.querySelector(`.issue[data-issue-id="${e.id}"]`);if(o)if(t){let l=e.originalSeverity||"error";o.className=o.className.replace(/\b(error|warn)\b/g,"info");let n=o.querySelector(".issue-type");if(n){let a=n.querySelector(".issue-number");if(a){let i=a.textContent;n.innerHTML=`<span class="issue-number">${i}</span> \u2139\uFE0F INFO`}else n.innerHTML=n.innerHTML.replace(/❌|⚠️/g,"\u2139\uFE0F").replace(/ERROR|WARNING/g,"INFO")}if(!o.querySelector(".issue-ignored-tag")){let a=o.querySelector(".issue-body"),i=o.querySelector(".issue-node"),c=document.createElement("div");if(c.className="issue-ignored-tag",c.style.cssText="margin-top: 4px; padding: 4px 8px; background: #e3f2fd; color: #22c55e; border-radius: 4px; font-size: 11px; font-weight: 600; display: inline-block;",c.textContent="\u2713 Pass with ignore custom",i)i.parentNode.insertBefore(c,i.nextSibling);else if(a)a.parentNode.insertBefore(c,a.nextSibling);else{let p=o.querySelector(".issue-header");p?p.parentNode.insertBefore(c,p.nextSibling):o.appendChild(c)}}let s=document.querySelector(`button.btn-ignore[data-id="${e.id}"]`);s&&(s.removeAttribute("disabled"),s.innerHTML="Ignored",s.style.cssText="padding: 6px 12px; border: 1px solid #22c55e; background: #22c55e; border-radius: 6px; font-size: 12px; font-weight: 500; cursor: pointer; transition: all 0.2s; color: white;")}else{let l=e.originalSeverity||(e.severity==="info"?"error":e.severity);o.className=o.className.replace(/\binfo\b/g,l);let n=o.querySelector(".issue-type");if(n){let i=l==="error"?"\u274C":l==="warn"?"\u26A0\uFE0F":"\u2139\uFE0F",c=l.toUpperCase(),p=n.querySelector(".issue-number");if(p){let d=p.textContent;n.innerHTML=`<span class="issue-number">${d}</span> ${i} ${c}`}else n.innerHTML=n.innerHTML.replace(/ℹ️/g,i).replace(/INFO/g,c)}let s=o.querySelector(".issue-ignored-tag");s&&s.remove();let a=document.querySelector(`button.btn-ignore[data-id="${e.id}"]`);a&&(a.removeAttribute("disabled"),a.innerHTML="Ignore",a.style.cssText="padding: 6px 12px; border: 1px solid #64748b; background: #64748b; border-radius: 6px; font-size: 12px; font-weight: 500; cursor: pointer; transition: all 0.2s; color: white;")}}function lt(){if(!k||!k.issues)return;let e=k.issues,t={error:e.filter(o=>o.severity==="error"&&!o.ignored).length,warn:e.filter(o=>o.severity==="warn"&&!o.ignored).length,total:e.length};At(e),document.querySelectorAll(".issue-group").forEach(o=>{let l=o.querySelector(".badge");if(l){let n=o.getAttribute("data-issue-type");if(n){let a=e.filter(i=>i.type===n).filter(i=>i.ignored?!1:i.severity==="error"||i.severity==="warn").length;l.textContent=a}}})}function Pn(e){let t=e.message||"",o=t.match(/Padding\s+(\w+)\s+\((\d+)px\)/),l=null,n=null;if(o?(l=o[1],n=parseInt(o[2])):(o=t.match(/Gap\s+\(itemSpacing:\s+(\d+)px\)/),o&&(l="itemSpacing",n=parseInt(o[1]))),!o||!l||n===null){console.error("Cannot parse spacing issue message:",t),alert("Cannot determine spacing property from issue message. Message: "+t);return}let s=document.getElementById("spacing-scale");if(!s||!s.value.trim()){alert("No spacing scale defined. Please add spacing values to the Spacing input.");return}let a=s.value.split(",").map(i=>parseInt(i.trim(),10)).filter(i=>!isNaN(i)&&i>=0).sort((i,c)=>i-c);if(a.length===0){alert("No valid spacing values found in Spacing input.");return}pn(e,l,n,a)}function Rn(e){let o=(e.message||"").match(/Color (#[0-9A-Fa-f]{6})/),l=o?o[1].toUpperCase():null;if(!l){alert("Cannot determine current color from issue message");return}let n=document.getElementById("color-scale");if(!n||!n.value.trim()){alert("No color scale defined. Please add colors to the Color input.");return}let s=n.value.split(",").map(a=>a.trim().toUpperCase()).filter(a=>a&&a.startsWith("#"));if(s.length===0){alert("No valid colors found in Color input.");return}un(e,l,s,J)}function Dn(e){var t;if(e.type==="typography-check"&&e.bestMatch){dn(e,Q);return}if(re(e.id,"\u23F3 Fixing...",!0),!e.bestMatch&&e.type!=="typography-check"){let o=prompt(`Cannot auto-fix this issue.

Issue: ${e.message}

Please provide fix instructions or press Cancel.`);if(o)parent.postMessage({pluginMessage:{type:"fix-issue",issue:e,manualFix:o}},"*");else{let l=document.querySelector(`.issue[data-issue-id="${e.id}"]`)||((t=document.querySelector(`button.btn-fix[data-id="${e.id}"]`))==null?void 0:t.closest(".issue"));if(l){let n=l.querySelector(".fix-message");n&&n.remove()}}return}parent.postMessage({pluginMessage:{type:"fix-issue",issue:e}},"*")}function Co(e,t){let o=document.createElement("div");o.className="modal-overlay",o.id="create-style-modal-overlay";let l=document.createElement("div");l.className="modal-dialog";let n=e.nodeName||"Unnamed";if(e.message&&e.message.includes("(")&&e.message.includes("nodes")){let d=e.message.match(/\((\d+) nodes\)/);d&&(n=`${n} (${d[1]} nodes)`)}l.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Create Style</h2>
        <p class="modal-subtitle">${u(n)}</p>
      </div>
      <div class="modal-body">
        <input 
          type="text" 
          class="modal-input" 
          id="style-name-input" 
          placeholder="Style Name" 
          value="${u(e.nodeName||"New Style")}"
          autofocus
        />
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="modal-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="modal-create-btn">Create</button>
      </div>
    `,o.appendChild(l),document.body.appendChild(o);let s=l.querySelector("#style-name-input"),a=l.querySelector("#modal-cancel-btn"),i=l.querySelector("#modal-create-btn"),c=l.querySelector(".modal-close");setTimeout(()=>{s.focus(),s.select()},100),s.onkeydown=d=>{d.key==="Enter"?(d.preventDefault(),i.click()):d.key==="Escape"&&(d.preventDefault(),a.click())};let p=()=>{o.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{o.parentNode&&o.remove()},200)};a.onclick=p,c.onclick=p,o.onclick=d=>{d.target===o&&p()},i.onclick=()=>{let d=s.value.trim();if(!d){s.focus(),s.style.borderColor="#ff3b30",setTimeout(()=>{s.style.borderColor="#0071e3"},2e3);return}p(),t&&t(d)}}function Io(e,t,o={}){if(console.log("[showSuggestApplyModal] Called with issue:",e,"styleName:",t,"options:",o),!e){console.error("[showSuggestApplyModal] Missing issue:",{issue:e,styleName:t});return}let{onApply:l,onIgnore:n,onCancel:s,showIgnore:a=!1,progress:i}=o,c=e.nodeProps||{},p=c.fontFamily||"Unknown",d=c.fontSize!==null&&c.fontSize!==void 0?c.fontSize:null,S=d!==null?`${d}px`:"Unknown",h=c.fontWeight||"Unknown",f=c.lineHeight||"Unknown",m=c.letterSpacing!==null&&c.letterSpacing!==void 0?c.letterSpacing:"Unknown",g=N=>N==null||N==="Unknown"?"":String(N).toLowerCase().trim(),M=N=>{let ce=`typo_${g(p)}_${d}_${g(h)}_${g(f)}_${g(m)}_${N.id}`;return fe(ce,()=>{let K=0;if(g(p)===g(N.fontFamily)&&(K+=25),d!==null&&N.fontSize){let r=Math.abs(d-N.fontSize);r===0?K+=30:r<=2?K+=25:r<=4?K+=20:r<=8&&(K+=10)}return g(h)===g(N.fontWeight)&&(K+=20),g(f)===g(N.lineHeight)&&(K+=15),g(m)===g(N.letterSpacing||"0")&&(K+=10),K})},T=[...Q].map(N=>ot(Ke({},N),{similarity:M(N)})).sort((N,ce)=>t&&N.name===t?-1:t&&ce.name===t?1:ce.similarity-N.similarity).slice(0,5);if(T.length===0){console.error("[showSuggestApplyModal] No typography styles available"),alert("No typography styles available");return}let A=T[0].id,F=(N,ce)=>g(N)!==g(ce),j=(N,ce,K)=>{let r=F(p,N.fontFamily),xe=F(S,`${N.fontSize}px`),ge=F(h,N.fontWeight),Qe=F(f,N.lineHeight),de=F(m,N.letterSpacing||"0%"),et="color: #155724;",De="color: #721c24; background: #f8d7da; padding: 2px 6px; border-radius: 4px; font-weight: 600;",tt=K===0;return`
        <div class="style-option-item" data-style-id="${N.id}" style="
          padding: 14px 16px;
          margin-bottom: 10px;
          border: 1px solid ${ce?"#0071e3":"#e0e0e0"};
          border-radius: 10px;
          cursor: pointer;
          background: ${ce?"#f8fbff":"white"};
          transition: all 0.15s;
          border-left: 4px solid ${ce?"#0071e3":"#e0e0e0"};
        ">
          <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">
            <div style="display: flex; align-items: center; gap: 10px; flex: 1;">
              <input type="radio" name="style-option" ${ce?"checked":""} style="margin: 0; cursor: pointer; width: 18px; height: 18px; display: none;" />
              <div>
                <div style="display: flex; align-items: center; gap: 8px;">
                  <span style="font-weight: 600; font-size: 12px; color: #333;">${u(N.name)}</span>
                  ${tt?'<span style="color: #f5a623;">\u2B50</span>':""}
                </div>
                <div style="font-size: 12px; color: #666; margin-top: 2px;">
                  ${u(N.fontFamily)} ${N.fontSize}px ${u(N.fontWeight)}
                </div>
              </div>
            </div>
            <div style="text-align: right;">
              ${tt?'<div style="color: #0071e3; font-size: 11px; font-weight: 600;">Best Match</div>':""}
              <div style="font-size: 12px; color: #666; background: #f0f0f0; padding: 3px 10px; border-radius: 12px; margin-top: 2px;">${N.similarity}% match</div>
            </div>
          </div>
          <div style="margin-left: 28px; padding: 0 12px; background: #f8f9fa; border-radius: 6px;">
            <div style="font-size: 11px; font-weight: 600; color: #333; margin-bottom: 8px;">Details:</div>
            <div style="font-size: 11px; color: #555; line-height: 1.2;">
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span style="color: #888; min-width: 90px;">\u2022 Font Family:</span>
                <span style="${r?De:et}">${r?"\u26A0":"\u2713"} ${u(N.fontFamily)}</span>
              </div>
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span style="color: #888; min-width: 90px;">\u2022 Font Size:</span>
                <span style="${xe?De:et}">${xe?"\u26A0":"\u2713"} ${N.fontSize}px</span>
              </div>
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span style="color: #888; min-width: 90px;">\u2022 Font Weight:</span>
                <span style="${ge?De:et}">${ge?"\u26A0":"\u2713"} ${u(N.fontWeight)}</span>
              </div>
              <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
                <span style="color: #888; min-width: 90px;">\u2022 Line Height:</span>
                <span style="${Qe?De:et}">${Qe?"\u26A0":"\u2713"} ${u(N.lineHeight)}</span>
              </div>
              <div style="display: flex; align-items: center; gap: 6px;">
                <span style="color: #888; min-width: 90px;">\u2022 Letter Spacing:</span>
                <span style="${de?De:et}">${de?"\u26A0":"\u2713"} ${u(N.letterSpacing||"0%")}</span>
              </div>
            </div>
          </div>
        </div>
      `},z=document.createElement("div");z.className="modal-overlay",z.id="suggest-apply-modal-overlay";let D=document.createElement("div");D.className="modal-dialog",D.style.maxWidth="480px";let ye=i?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${i.current}/${i.total}</div>`:"",b=T.map((N,ce)=>j(N,ce===0,ce)).join("");D.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Style</h2>
        <p class="modal-subtitle">Node: ${u(e.nodeName||"Unnamed")}</p>
      </div>
      ${ye}
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #fff8e6; border-radius: 8px; border-left: 4px solid #f5a623;">
          <div style="font-size: 11px; font-weight: 600; color: #666; margin-bottom: 6px;">Current Node Properties:</div>
          <div style="font-size: 12px; color: #333; line-height: 1.6;">
            <div><strong>Font:</strong> ${u(p)} \u2022 ${u(S)} \u2022 ${u(h)}</div>
            <div><strong>Line Height:</strong> ${u(f)} \u2022 <strong>Letter Spacing:</strong> ${u(m)}</div>
          </div>
        </div>
        <div style="font-size: 12px; font-weight: 600; color: #333; margin-bottom: 10px;">
          Select a style to apply (Top 5 matches):
        </div>
        <div id="style-options-container" style="max-height: 400px; overflow-y: auto;">
          ${b}
        </div>
      </div>
      <div class="modal-footer">
        ${a?'<button class="modal-btn modal-btn-cancel" id="suggest-modal-ignore-btn" style="background: #64748b; border-color: #64748b; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="suggest-modal-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="suggest-modal-apply-btn" style="background: #22c55e; border-color: #22c55e;">Apply Style</button>
      </div>
    `,z.appendChild(D),document.body.appendChild(z);let P=D.querySelector("#suggest-modal-cancel-btn"),x=D.querySelector("#suggest-modal-apply-btn"),E=D.querySelector("#suggest-modal-ignore-btn"),q=D.querySelector(".modal-close"),se=D.querySelector("#style-options-container"),he=N=>{A=N,se.querySelectorAll(".style-option-item").forEach(K=>{let xe=K.getAttribute("data-style-id")===String(N);K.style.border=xe?"2px solid #0071e3":"2px solid #e0e0e0",K.style.borderLeft=xe?"4px solid #0071e3":"4px solid #e0e0e0",K.style.background=xe?"#f8fbff":"white";let ge=K.querySelector('input[type="radio"]');ge&&(ge.checked=xe)})};(()=>{se.querySelectorAll(".style-option-item").forEach(ce=>{ce.onclick=K=>{K.preventDefault();let r=ce.getAttribute("data-style-id");he(r)}})})();let be=()=>{z.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{z.parentNode&&z.remove()},200)};P.onclick=()=>{be(),a&&o.onCancel&&typeof o.onCancel=="function"&&o.onCancel()},q.onclick=()=>{be(),a&&o.onCancel&&typeof o.onCancel=="function"&&o.onCancel()},z.onclick=N=>{N.target===z&&(be(),a&&o.onCancel&&typeof o.onCancel=="function"&&o.onCancel())},x.onclick=()=>{let N=T.find(ce=>String(ce.id)===String(A));if(!N){console.error("[showSuggestApplyModal] Selected style not found:",A);return}be(),re(e.id,"\u23F3 Applying style...",!0),N.styleId?parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:e,styleId:N.styleId,styleName:N.name}},"*"):parent.postMessage({pluginMessage:{type:"apply-typography-style",issue:e,style:N}},"*"),l&&typeof l=="function"&&l()},E&&(E.onclick=()=>{be(),n&&typeof n=="function"&&n()})}function Wn(e){parent.postMessage({pluginMessage:{type:"extract-color-variables"}},"*");function t(o){let l=o.data&&o.data.pluginMessage;if(!l||l.type!=="color-variables-extracted")return;window.removeEventListener("message",t);let n=l.colors||[];if(n.length===0){alert("No color variables found in this file.");return}let s=(e.colorHex||"").toUpperCase(),a=[...n].sort((f,m)=>{let g=f.hex.toUpperCase()===s?0:1,M=m.hex.toUpperCase()===s?0:1;return g!==M?g-M:f.name.localeCompare(m.name)}),i=document.createElement("div");i.className="modal-overlay",i.style.cssText="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.4);z-index:9999;display:flex;align-items:center;justify-content:center;";let c=document.createElement("div");c.style.cssText="background:#fff;border-radius:12px;padding:20px;max-width:400px;width:90%;max-height:70vh;display:flex;flex-direction:column;";let p=document.createElement("h3");p.style.cssText="margin:0 0 4px 0;font-size:16px;",p.textContent="Select Variable";let d=document.createElement("div");d.style.cssText="font-size:12px;color:#666;margin-bottom:12px;",d.textContent=`Color: ${s} on "${e.nodeName}"`;let S=document.createElement("div");S.style.cssText="overflow-y:auto;flex:1;",a.forEach(f=>{let m=f.hex.toUpperCase()===s,g=document.createElement("div");g.style.cssText=`display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;cursor:pointer;border:2px solid ${m?"#22c55e":"transparent"};margin-bottom:4px;background:${m?"#f0fdf4":"#fafafa"};`,g.innerHTML=`
          <div style="width:28px;height:28px;border-radius:6px;background:${f.hex};border:1px solid #ddd;flex-shrink:0;"></div>
          <div style="flex:1;min-width:0;">
            <div style="font-size:13px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${f.name}</div>
            <div style="font-size:11px;color:#888;">${f.hex}${m?" \u2014 exact match":""}</div>
          </div>
        `,g.onclick=()=>{i.remove(),re(e.id,"\u23F3 Binding variable...",!0),parent.postMessage({pluginMessage:{type:"bind-color-variable-by-name",issue:e,variableName:f.name,variableHex:f.hex}},"*")},S.appendChild(g)});let h=document.createElement("button");h.textContent="Cancel",h.style.cssText="margin-top:12px;padding:8px 16px;border:1px solid #ddd;border-radius:8px;background:#fff;cursor:pointer;font-size:13px;",h.onclick=()=>i.remove(),c.appendChild(p),c.appendChild(d),c.appendChild(S),c.appendChild(h),i.appendChild(c),i.onclick=f=>{f.target===i&&i.remove()},document.body.appendChild(i)}window.addEventListener("message",t)}function ft(e){if(!e||!e.nodeProps)return null;for(let t of Q)if(yn(e.nodeProps,t)===100)return console.log("[100% Match] node:",e.id,e.nodeName,"| nodeProps:",JSON.stringify({f:e.nodeProps.fontFamily,s:e.nodeProps.fontSize,w:e.nodeProps.fontWeight,lh:e.nodeProps.lineHeight,ls:e.nodeProps.letterSpacing}),"| style:",t.name,JSON.stringify({f:t.fontFamily,s:t.fontSize,w:t.fontWeight,lh:t.lineHeight,ls:t.letterSpacing})),t;return null}function ml(e){let t=(e||[]).filter(d=>d.type!=="typography-check"||!d.nodeProps?!1:ft(d)!==null);if(t.length===0){alert("No typography issues with 100% match found.");return}let o=0,l=0,n=0,s=document.getElementById("btn-fix-all-100");s&&(s.disabled=!0,s.textContent=`Fixing... (0/${t.length})`);function a(){s&&(s.textContent=`Fixing... (${o}/${t.length})`)}function i(){s&&(s.disabled=!1,s.textContent=`Fix all now (${t.length-l})`,l>=t.length&&(s.style.display="none")),alert(`\u2705 Done!

Processed ${t.length} item(s):
\u2022 Applied: ${l}
\u2022 Failed: ${n}`)}function c(d){let S=d.data&&d.data.pluginMessage;!S||S.type!=="apply-typography-style-result"||(o++,S.success?l++:n++,a(),o>=t.length?(window.removeEventListener("message",c),setTimeout(i,500)):setTimeout(()=>p(t[o]),300))}function p(d){let S=ft(d);if(!S){o++,n++,a(),o>=t.length?(window.removeEventListener("message",c),setTimeout(i,500)):setTimeout(()=>p(t[o]),300);return}re(d.id,"\u23F3 Applying style...",!0),S.styleId?parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:d,styleId:S.styleId,styleName:S.name}},"*"):parent.postMessage({pluginMessage:{type:"apply-typography-style",issue:d,style:S}},"*")}window.addEventListener("message",c),p(t[0])}window._batchFixInProgress=!1;function Un(e){window._batchFixInProgress=!0;let t=["typography-check","typography-style"],o=(e||[]).filter(x=>t.includes(x.type)&&x.nodeProps&&ft(x)!==null),l=[];o.forEach(function(x){x.subIssues&&x.subIssues.length>1?x.subIssues.forEach(function(E){E.nodeProps&&ft(Object.assign({},x,E))!==null&&l.push(Object.assign({},x,E))}):l.push(x)});let n=(e||[]).some(x=>x.type==="color-variable"&&x.matchingVariable&&(!x.colorOpacity||x.colorOpacity>=1));if(console.log("[Fix All Now] Color variable fixable:",(e||[]).filter(x=>x.type==="color-variable"&&x.matchingVariable&&(!x.colorOpacity||x.colorOpacity>=1)).length,", Typography 100% match:",l.length),l.length===0&&!n){alert("No auto-fixable issues found.");return}let s=document.getElementById("btn-fix-all-100");s&&(s.disabled=!0,s.textContent="Fixing...");let a=0,i=0,c=0,p=0,d=!1,S=l.length+(n?1:0),h=0,f=document.getElementById("fix-all-progress");f&&f.remove();let m=document.createElement("div");m.id="fix-all-progress",m.className="fix-all-progress",m.innerHTML=`
      <div class="fix-all-progress-info">
        <span class="fix-all-progress-text">Fixing... 0/${S}</span>
        <button class="fix-all-progress-cancel" title="Cancel">\u2715</button>
      </div>
      <div class="fix-all-progress-bar"><div class="fix-all-progress-fill" style="width: 0%"></div></div>
    `;let g=document.getElementById("results-issues");g&&g.parentNode.insertBefore(m,g);let M=m.querySelector(".fix-all-progress-text"),T=m.querySelector(".fix-all-progress-fill"),A=m.querySelector(".fix-all-progress-cancel");A.onclick=()=>{d=!0,j()};function F(x){h++;let E=Math.round(h/S*100);M&&(M.textContent=x+" "+h+"/"+S),T&&(T.style.width=E+"%")}function j(){window._batchFixInProgress=!1,s&&(s.disabled=!1,s.textContent="Fix all now"),m&&m.parentNode&&m.remove(),c>0&&k&&k.issues&&(k.issues=k.issues.filter(q=>q.type!=="color-variable"||!q.matchingVariable)),setTimeout(function(){lt(),k&&k.issues&&We(k.issues,!1)},300);let x=c+a,E=p+i;alert((d?`Cancelled!

`:`Done!

`)+"Color variables: "+c+" applied, "+p+` failed
Typography: `+a+" applied, "+i+` failed

Total: `+(x+E)+" processed")}function z(){s&&(s.textContent="Fixing colors...");function x(E){let q=E.data&&E.data.pluginMessage;!q||q.type!=="batch-bind-color-variables-result"||(window.removeEventListener("message",x),c=q.applied||0,p=q.failed||0,F("Colors done."),l.length>0&&!d?setTimeout(function(){ye()},300):j())}window.addEventListener("message",x),parent.postMessage({pluginMessage:{type:"batch-bind-color-variables",skipOpacity:!0}},"*")}let D=0;function ye(){s&&(s.textContent="Fixing Text Style..."),window.addEventListener("message",b),P(l[0])}function b(x){let E=x.data&&x.data.pluginMessage;!E||E.type!=="apply-typography-style-result"||(D++,E.success?a++:i++,F("Fixing Text Style"),d||D>=l.length?(window.removeEventListener("message",b),j()):setTimeout(function(){P(l[D])},300))}function P(x){let E=ft(x);if(!E){D++,i++,F("Fixing Text Style"),d||D>=l.length?(window.removeEventListener("message",b),j()):setTimeout(function(){P(l[D])},300);return}re(x.id,"\u23F3 Applying style...",!0),E.styleId?parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:x,styleId:E.styleId,styleName:E.name}},"*"):parent.postMessage({pluginMessage:{type:"apply-typography-style",issue:x,style:E}},"*")}n?z():l.length>0&&ye()}function jn(e,t){if(!t||t.length===0){alert("No issues to process");return}window._batchFixInProgress=!0;let o=0,l=0,n=0,s=!1,a=document.getElementById("fix-all-progress");a&&a.remove();let i=document.createElement("div");i.id="fix-all-progress",i.className="fix-all-progress",i.innerHTML=`
      <div class="fix-all-progress-info">
        <span class="fix-all-progress-text">Fixing... 0/${t.length}</span>
        <button class="fix-all-progress-cancel" title="Cancel">\u2715</button>
      </div>
      <div class="fix-all-progress-bar"><div class="fix-all-progress-fill" style="width: 0%"></div></div>
    `;let c=document.getElementById("results-issues");c&&c.parentNode.insertBefore(i,c);let p=i.querySelector(".fix-all-progress-text"),d=i.querySelector(".fix-all-progress-fill"),S=i.querySelector(".fix-all-progress-cancel");S.onclick=()=>{s=!0};function h(){let g=Math.round(o/t.length*100);p&&(p.textContent="Fixing... "+o+"/"+t.length),d&&(d.style.width=g+"%")}function f(){window._batchFixInProgress=!1,i&&i.parentNode&&i.remove(),lt(),k&&k.issues&&We(k.issues,!1);let M=(s?`Cancelled!

`:`Done!

`)+`Processed ${o} item(s):
\u2022 Applied: ${l}
\u2022 Ignored: ${n}`;alert(M)}function m(){if(s||o>=t.length){f();return}let g=t[o];o++,h(),parent.postMessage({pluginMessage:{type:"select-node",id:g.id}},"*");let M={current:o,total:t.length};if(g.type==="typography-check"||g.type==="typography-style"){let T=g.bestMatch&&g.bestMatch.name&&typeof g.bestMatch.name=="string"&&g.bestMatch.name.trim().length>0?g.bestMatch.name:null;if(!T){n++,m();return}Io(g,T,{showIgnore:!0,progress:M,onApply:()=>{l++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{s=!0,f()}})}else if(g.type==="color"){let T=St(g),F=(g.message||"").match(/Color (#[0-9A-Fa-f]{6})/),j=F?F[1].toUpperCase():null;On(g,j,T,{progress:M,onApply:()=>{l++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{s=!0,f()}})}else if(g.type==="spacing"){let T=kt(g),F=(g.message||"").match(/Padding\s+(\w+)\s+\((\d+)px\)/);if(F){let j=F[1],z=parseInt(F[2]);Vn(g,j,z,T,{progress:M,onApply:()=>{l++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{s=!0,f()}})}else n++,m()}else if(g.type==="autolayout")wn(g,{progress:M,onApply:()=>{l++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{s=!0,f()}});else if(g.type==="position")Mn(g,{progress:M,onApply:()=>{l++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{s=!0,f()}});else if(g.type==="group")$n(g,{progress:M,onApply:()=>{l++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{s=!0,f()}});else if(g.type==="empty-frame")Tn(g,{progress:M,onApply:()=>{l++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{s=!0,f()}});else if(g.type==="text-size-mobile")window.pendingTextSizeFixAllCallbacks={progress:M,onApply:()=>{l++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{s=!0,f()}},jt(g);else if(g.type==="contrast")window.pendingContrastFixAllCallbacks={progress:M,onApply:()=>{l++,setTimeout(()=>{m()},500)},onIgnore:()=>{n++,m()},onCancel:()=>{s=!0,f()}},Ot(g);else if(g.type==="color-variable")if(g.matchingVariable&&g.matchingVariable.id){let T=function(A){let F=A.data&&A.data.pluginMessage;!F||F.type!=="bind-color-variable-result"||F.issueId===g.id&&(window.removeEventListener("message",T),F.success?l++:n++,setTimeout(()=>{m()},300))};re(g.id,"\u23F3 Binding variable...",!0),window.addEventListener("message",T),parent.postMessage({pluginMessage:{type:"bind-color-variable",issue:g,variableId:g.matchingVariable.id}},"*")}else n++,m();else n++,m()}m()}function On(e,t,o,l={}){let n=Object.keys(J);Dt(e,t,o,J,n,ot(Ke({},l),{showIgnore:!0}))}function Vn(e,t,o,l,n={}){let s=document.getElementById("spacing-scale"),a=[0,4,8,12,16,24,32,40,48,64,72,80,88,96];if(s&&s.value.trim()){let i=s.value.split(",").map(c=>parseInt(c.trim(),10)).filter(c=>!isNaN(c));i.length>0&&(a=i)}Rt(e,t,o,l,a,ot(Ke({},n),{showIgnore:!0}))}function $o(e,t){if(!e||!t){console.error("handleApplyFigmaTextStyle: missing issue or style");return}re(e.id,"\u23F3 Applying style...",!0),parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:e,styleId:t.id,styleName:t.name}},"*")}function Vt(e,t){if(!e||!t){console.error("handleApplyTypographyStyle: missing issue or styleName");return}Io(e,t)}function Eo(e){if(console.log("handleCreateTextStyle called",e),!e){console.error("handleCreateTextStyle: issue is null/undefined");return}Co(e,t=>{console.log("handleCreateTextStyle: sending message",{type:"create-text-style",issueId:e.id,styleName:t}),re(e.id,"\u23F3 Creating style...",!0),parent.postMessage({pluginMessage:{type:"create-text-style",issue:e,styleName:t}},"*")})}function fl(e,t){if(e==="typography-style"){let n={nodeName:`${t.length} text node(s)`,message:`Found ${t.length} text node(s) without text style`};Co(n,s=>{t.forEach(a=>{re(a.id,"\u23F3 Creating style...",!0)}),parent.postMessage({pluginMessage:{type:"create-text-style-all",issues:t,styleName:s}},"*")});return}let o=t.filter(n=>n.bestMatch&&n.type==="typography-check"),l=t.filter(n=>!n.bestMatch||n.type!=="typography-check");if(o.length===0){alert(`No auto-fixable issues found in ${Tt(e)}.

All ${t.length} issues require manual intervention.`);return}l.length>0&&!confirm(`Found ${o.length} auto-fixable issues and ${l.length} issues that require manual fix.

Do you want to auto-fix the ${o.length} issues now?

The ${l.length} issues will need to be fixed manually.`)||parent.postMessage({pluginMessage:{type:"fix-all-issues",issues:o,issueType:e}},"*")}function Gn(e){console.log("filterAndSearchIssues called",{totalIssues:e.length,currentFilter:Ae,currentSearch:Ie});let t=e;if(Ae!=="all"&&(t=t.filter(o=>o.severity===Ae),console.log("After severity filter:",t.length)),Ie.trim()){let o=Ie.toLowerCase();t=t.filter(l=>{let n=(l.message||"").toLowerCase(),s=(l.nodeName||"").toLowerCase(),a=(l.type||"").toLowerCase();return n.includes(o)||s.includes(o)||a.includes(o)}),console.log("After search filter:",t.length)}return console.log("Final filtered issues:",t.length),t}function We(e=[],t=!1,o={}){let{skipSave:l=!1,restoreTimestamp:n=null,skipTabSwitch:s=!1}=o;s||Le("issues"),document.getElementById("issues-count").textContent=e.length,e&&Array.isArray(e)&&e.forEach(b=>{ue[b.id]===!0&&(b.ignored=!0,b.originalSeverity||(b.originalSeverity=b.severity),b.severity="info")});let a=k.issues!==e;k.issues=e;let i=n||new Date().toISOString();k.timestamp=i,Ct=!1,(t||a)&&(console.log("Resetting filters for new data"),Ae="all",Ve="all",Ue&&(Ue.value=""),Ie="",Be&&(Be.style.display="none"),$e&&$e.length>0&&$e.forEach(b=>{b.classList.remove("active"),b.getAttribute("data-filter")==="all"&&b.classList.add("active")}));let c=document.getElementById("filter-controls"),p=document.getElementById("color-type-filter"),d=document.getElementById("filter-buttons");c&&(c.style.display=e.length>0?"flex":"none"),p&&(p.style.display="none"),d&&(d.style.display="flex");let S=document.getElementById("export-group");S.style.display=e.length>0?"flex":"none",console.log("About to filter with:",{currentFilter:Ae,currentSearch:Ie});let h=Gn(e),f=new Set;if(a||(document.querySelectorAll(".issue-group").forEach(P=>{let x=P.getAttribute("data-issue-type");x&&!P.classList.contains("collapsed")&&f.add(x)}),console.log("Saved expanded groups:",Array.from(f))),zt("issues"),h.length===0&&e.length===0){ne.innerHTML=`
              <div class="empty-state success">
                <div class="icon">\u2705</div>
                <p><strong>No issues found!</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Your design passed all configured checks.</p>
              </div>
            `;return}if(h.length===0&&e.length>0&&Ae!=="all"){ne.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F50D}</div>
                <p><strong>No results found</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Try changing the filter or search keyword.</p>
              </div>
            `;return}let m={error:h.filter(b=>b.severity==="error"&&!b.ignored).length,warn:h.filter(b=>b.severity==="warn"&&!b.ignored).length,total:h.length,originalTotal:e.length},g=0,M=0;h.forEach(function(b){b.ignored||((b.type==="typography-check"||b.type==="typography-style")&&b.nodeProps&&ft(b)!==null&&g++,b.type==="color-variable"&&(console.log("[Header Count] color-variable:",b.id,"matchingVariable:",!!b.matchingVariable,"opacity:",b.colorOpacity),b.matchingVariable&&(!b.colorOpacity||b.colorOpacity>=1)&&M++))});let T=g+M;console.log("[Header Count] typo100:",g,"colorVar:",M,"total:",T);let A=document.createElement("div");A.className="results-header";let F=T>0;A.innerHTML=`<h3>Check Result</h3><button class="btn-fix-all" id="btn-fix-all-100"${F?"":' style="display:none"'}>Fix all now (${T})</button>`,ne.appendChild(A);let j=A.querySelector("#btn-fix-all-100");j&&(j.onclick=b=>{b.preventDefault(),b.stopPropagation(),Un(e)}),At(e);let z=h.reduce((b,P)=>(b[P.type]=b[P.type]||[],b[P.type].push(P),b),{}),D=e.reduce((b,P)=>(b[P.type]=b[P.type]||[],b[P.type].push(P),b),{}),ye=["naming","autolayout","spacing","color","color-variable","typography","typography-style","typography-check","line-height","position","duplicate","group","component","empty-frame","nested-group","contrast","text-size-mobile"];for(let b of ye){let P=z[b]||[],x=P.length,E=P.filter(r=>r.ignored?!1:r.severity==="error"||r.severity==="warn").length;if(x===0&&e.length===0||x===0&&Ae!=="all")continue;let q=document.createElement("div"),se=f.has(b);q.className=se?"issue-group":"issue-group collapsed",q.setAttribute("data-issue-type",b);let he=document.createElement("div");he.className="issue-group-header";let Ee=(D[b]||[]).some(r=>{try{if(!r)return!1;switch(r.type){case"color":return St(r)!==null;case"spacing":return kt(r)!==null;case"autolayout":return typeof pt=="function"&&pt(r)!==null;case"text-size-mobile":return typeof at=="function"&&at(r)!==null;case"contrast":return typeof mt=="function"&&mt(r)!==null;case"typography-style":case"typography-check":return r.bestMatch&&r.bestMatch.name&&typeof r.bestMatch.name=="string"&&r.bestMatch.name.trim().length>0&&Mt(r);case"position":return typeof it=="function"&&it(r)!==null;case"duplicate":case"component":return typeof ut=="function"&&ut(r)!==null;case"group":return!0;case"empty-frame":return typeof gt=="function"&&gt(r)!==null;default:return!1}}catch(xe){return console.error("[hasSuggestFixButton] Error checking issue:",r,xe),!1}});he.innerHTML=`
              <div class="issue-group-header-left">
                <button class="issue-group-toggle" type="button">
                  <span class="issue-group-toggle-icon">\u25B6</span>
                </button>
                <h4>${io(b)} ${Tt(b)}</h4>
                <span class="badge">${E}</span>
              </div>
              ${x>0&&b!=="typography"&&b!=="line-height"&&b!=="naming"&&b!=="component"&&b!=="duplicate"&&Ee?`<button class="btn-fix-all" data-type="${b}">Fix all now</button>`:""}
            `;let be=he.querySelector(".issue-group-toggle"),N=()=>{q.classList.contains("collapsed")?(q.classList.remove("collapsed"),K.style.display="block",setTimeout(()=>{K.style.opacity="1"},10)):(K.style.opacity="0",setTimeout(()=>{q.classList.add("collapsed"),K.style.display="none"},200))};be.onclick=r=>{r.stopPropagation(),N()},he.onclick=r=>{r.target!==be&&!be.contains(r.target)&&N()};let ce=he.querySelector(".btn-fix-all");ce&&(ce.onclick=r=>{try{r.preventDefault(),r.stopPropagation();let xe=(D[b]||[]).filter(ge=>{if(!ge)return!1;switch(ge.type){case"color":return St(ge)!==null;case"spacing":return kt(ge)!==null;case"autolayout":return typeof pt=="function"&&pt(ge)!==null;case"text-size-mobile":return typeof at=="function"&&at(ge)!==null;case"contrast":return typeof mt=="function"&&mt(ge)!==null;case"typography-style":case"typography-check":return ge.bestMatch&&ge.bestMatch.name&&typeof ge.bestMatch.name=="string"&&ge.bestMatch.name.trim().length>0&&Mt(ge);case"position":return typeof it=="function"&&it(ge)!==null;case"duplicate":case"component":return typeof ut=="function"&&ut(ge)!==null;case"group":return!0;case"empty-frame":return typeof gt=="function"&&gt(ge)!==null;default:return!1}});if(xe.length===0){alert("No issues with suggest fix available");return}console.log("[Fix All]",b,xe.length,"fixable issues"),jn(b,xe)}catch(xe){console.error("[Fix All] Error:",xe.message),alert("Error: "+xe.message)}}),q.appendChild(he);let K=document.createElement("div");if(K.className="issue-group-content",se?(K.style.display="block",K.style.opacity="1"):K.style.display="none",x===0){let r=document.createElement("div");r.className="issue info",r.style.opacity="0.7",r.innerHTML=`
                <div class="issue-header">
                  <div>
                    <span class="issue-type">\u2705 PASSED</span>
                    <div class="issue-body">No issues in this type.</div>
                  </div>
                </div>
              `,K.appendChild(r)}else z[b].forEach((r,xe)=>{let ge=xe+1,Qe=ue[r.id]===!0;if(Qe&&(r.originalSeverity||(r.originalSeverity=r.severity),r.severity="info",r.ignored=!0),r.type==="typography-check"){let W=document.createElement("div");K.appendChild(W);let ie=xn(r);if(ie){let je=document.createElement("span");je.className="issue-number",je.textContent=`#${ge}`,je.style.cssText="position: absolute; left: 8px; top: 8px; font-weight: bold; opacity: 0.5; font-size: 11px;",ie.style.position="relative",ie.style.paddingLeft="40px",ie.insertBefore(je,ie.firstChild),K.replaceChild(ie,W)}return}let de=document.createElement("div"),et=Qe?"info":r.severity;de.className=`issue ${et}`,de.setAttribute("data-issue-id",r.id);let De=u(r.message);if(r.type==="contrast"){let W=[];if(r.textColor&&W.push(`Text color: <code style="background: ${u(r.textColor)}; padding: 2px 6px; border-radius: 3px; color: ${wt(r.textColor)};">${u(r.textColor)}</code> (${r.textColorNode||r.nodeName||"Unnamed"})`),r.backgroundColor){let ie="Background:",je="",xt="";r.isGradient&&r.gradientString?(ie="Background (gradient):",je=`<code style="background: ${u(r.backgroundColor)}; padding: 2px 6px; border-radius: 3px; color: ${wt(r.backgroundColor)}; font-family: 'SF Mono', Monaco, monospace; font-size: 11px;">${u(r.gradientString)}</code>`,xt=" <span style='font-size: 11px; color: #999;'>(average: "+u(r.backgroundColor)+")</span>"):je=`<code style="background: ${u(r.backgroundColor)}; padding: 2px 6px; border-radius: 3px; color: ${wt(r.backgroundColor)};">${u(r.backgroundColor)}</code>`,r.fromSibling&&(xt+=" <span style='font-size: 11px; color: #3b82f6;'>(from sibling layer)</span>"),W.push(`${ie} ${je}${xt} (${r.backgroundColorNode||"Unknown"})`)}W.length>0&&(De+=`<div style="margin-top: 8px; font-size: 10px; color: #666;">${W.join(" | ")}</div>`)}de.innerHTML=`
                <div class="issue-header">
                  <div>
                    <span class="issue-type">
                      <span class="issue-number">#${ge}</span>
                      ${bn(Qe?"info":r.severity)} ${Qe?"INFO":r.severity.toUpperCase()}
                    </span>
                    <div class="issue-body">${De}</div>
                    ${r.nodeName?`<div class="issue-node">Node: ${u(r.nodeName)}</div>`:""}
                    ${r.type==="typography"||r.type==="line-height"?`<div style="margin-top: 8px; padding: 8px 12px; background: #fff3cd; border-left: 3px solid #ffc107; border-radius: 4px; font-size: 10px; color: #856404; line-height: 1.5;"><strong>Note:</strong> Check 'Typography Style Match' to resolve this issue.</div>`:""}
                    ${r.ignored?'<div class="issue-ignored-tag" style="margin-top: 4px; padding: 4px 8px; background: #e3f2fd; color: #1976d2; border-radius: 4px; font-size: 11px; font-weight: 600; display: inline-block;">\u2713 Pass with ignore custom</div>':""}
                  </div>
                  <div class="issue-actions">
                    <button class="btn-select" data-id="${r.id}">Select</button>
                    ${r.type==="color"?`
                      ${St(r)?`<button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${r.id}">Select Color</button>
                    `:""}
                    ${r.type==="color-variable"?`
                      ${r.matchingVariable?`<button class="btn-suggest-fix btn-bind-variable" data-id="${r.id}" data-variable-id="${r.matchingVariable.id}" data-variable-name="${u(r.matchingVariable.name)}">Bind Variable</button>`:""}
                      <button class="btn-fix btn-select-variable" data-id="${r.id}">Select Variable</button>
                    `:""}
                    ${r.type==="spacing"?`
                      ${kt(r)?`<button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${r.id}">Select Spacing</button>
                    `:""}
                    ${r.type==="autolayout"?`
                      ${pt(r)?`<button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${r.id}">Select</button>
                    `:""}
                    ${r.type==="text-size-mobile"?`
                      ${at(r)?`<button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${r.id}">Select Style</button>
                    `:""}
                    ${r.type==="contrast"?`
                      ${mt(r)?`<button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${r.id}">Select Color</button>
                      <button class="btn-ignore" data-id="${r.id}" ${r.ignored?'style="background: #22c55e; border-color: #22c55e;"':""}>${r.ignored?"Ignored":"Ignore"}</button>
                    `:""}
                    ${r.type==="typography-style"?`
                      ${r.bestMatch&&r.bestMatch.name&&Mt(r)?`
                        <button class="btn-suggest-fix" data-id="${r.id}" data-style-name="${u(r.bestMatch.name)}">Suggest Fix now</button>
                      `:""}
                      <button class="btn-fix" data-id="${r.id}">Select Style</button>
                      <button class="btn-create-style" data-id="${r.id}" data-issue-type="${r.type}">Create Style</button>
                    `:""}
                    ${r.type==="position"?`
                      ${it(r)?`<button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>`:""}
                      <button class="btn-remove-layer" data-id="${r.id}">Remove Layer</button>
                    `:""}
                    ${(r.severity==="error"||r.severity==="warn")&&r.type!=="position"?`
                      <button class="btn-remove-layer" data-id="${r.id}">Remove Layer</button>
                    `:""}
                    ${r.type==="duplicate"?`
                      ${ut(r)?`<button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>`:""}
                      <button class="btn-select-component" data-id="${r.id}">Select Component</button>
                      <button class="btn-create-component" data-id="${r.id}">Create New Component</button>
                    `:""}
                    ${r.type==="component"?`
                      ${ut(r)?`<button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>`:""}
                      <button class="btn-select-component" data-id="${r.id}">Select Component</button>
                      <button class="btn-create-component" data-id="${r.id}">Create New Component</button>
                    `:""}
                    ${r.type==="group"?`
                      <button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>
                    `:""}
                    ${r.type==="naming"?`
                      <button class="btn-rename" data-id="${r.id}">Rename</button>
                    `:""}
                    ${r.type==="empty-frame"?`
                      ${gt(r)?`<button class="btn-suggest-fix" data-id="${r.id}">Suggest Fix now</button>`:""}
                    `:""}
                  </div>
                </div>
              `,K.appendChild(de),de.setAttribute("data-issue-id",r.id),de.setAttribute("data-issue-type",r.type);let tt=de.querySelector("button.btn-select");tt&&(tt.onclick=()=>{document.querySelectorAll(".btn-select.active").forEach(W=>W.classList.remove("active")),document.querySelectorAll(".issue.selected").forEach(W=>W.classList.remove("selected")),tt.classList.add("active"),de.classList.add("selected"),parent.postMessage({pluginMessage:{type:"select-node",id:r.id}},"*")});let Ye=de.querySelector("button.btn-fix");Ye&&(r.type==="color"?Ye.onclick=()=>{Rn(r)}:r.type==="spacing"?Ye.onclick=()=>{Pn(r)}:r.type==="text-size-mobile"?Ye.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Text Size Fix button clicked",r),typeof xo=="function"?xo(r):(console.error("handleFixTextSizeIssue is not a function"),alert("Error: handleFixTextSizeIssue function not found"))}:r.type==="contrast"?Ye.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Contrast Fix button clicked",r),typeof vo=="function"?vo(r):(console.error("handleFixContrastIssue is not a function"),alert("Error: handleFixContrastIssue function not found"))}:Ye.onclick=()=>{Dn(r)});let ke=de.querySelector("button.btn-suggest-fix");ke&&(r.type==="color"?ke.onclick=()=>{vn(r)}:r.type==="spacing"?ke.onclick=()=>{Sn(r)}:r.type==="autolayout"?ke.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Autolayout Suggest Fix button clicked",r),typeof ao=="function"?ao(r):(console.error("handleSuggestFixAutolayout is not a function"),alert("Error: handleSuggestFixAutolayout function not found"))}:r.type==="text-size-mobile"?ke.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Text Size Suggest Fix button clicked",r),typeof jt=="function"?jt(r):(console.error("handleSuggestFixTextSize is not a function"),alert("Error: handleSuggestFixTextSize function not found"))}:r.type==="position"?ke.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Position Suggest Fix button clicked",r),typeof co=="function"?co(r):(console.error("handleSuggestFixPosition is not a function"),alert("Error: handleSuggestFixPosition function not found"))}:r.type==="duplicate"||r.type==="component"?ke.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Component Suggest Fix button clicked",r),typeof go=="function"?go(r):(console.error("handleSuggestFixComponent is not a function"),alert("Error: handleSuggestFixComponent function not found"))}:r.type==="contrast"?ke.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Contrast Suggest Fix button clicked",r),typeof Ot=="function"?Ot(r):(console.error("handleSuggestFixContrast is not a function"),alert("Error: handleSuggestFixContrast function not found"))}:r.type==="group"?ke.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Group Suggest Fix button clicked",r),typeof ro=="function"?ro(r):(console.error("handleSuggestFixGroup is not a function"),alert("Error: handleSuggestFixGroup function not found"))}:r.type==="empty-frame"?ke.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Empty Frame Suggest Fix button clicked",r),typeof po=="function"?po(r):(console.error("handleSuggestFixEmptyFrame is not a function"),alert("Error: handleSuggestFixEmptyFrame function not found"))}:r.type==="color-variable"&&(ke.onclick=W=>{if(W.preventDefault(),W.stopPropagation(),r.matchingVariable&&r.matchingVariable.id){if(r.colorOpacity&&r.colorOpacity<1){let ie=Math.round(r.colorOpacity*100);if(!confirm(`This layer has opacity ${ie}%. Binding a variable will reset opacity to 100%. Continue?`))return}re(r.id,"\u23F3 Binding variable...",!0),parent.postMessage({pluginMessage:{type:"bind-color-variable",issue:r,variableId:r.matchingVariable.id}},"*")}}));let Xe=de.querySelector("button.btn-select-component");Xe&&(r.type==="duplicate"||r.type==="component")&&(function(W){Xe.onclick=ie=>{ie.preventDefault(),ie.stopPropagation(),console.log("Select Component button clicked",W),typeof mo=="function"?mo(W):(console.error("handleSelectComponent is not a function"),alert("Error: handleSelectComponent function not found"))}})(r);let rt=de.querySelector("button.btn-create-component");rt&&(r.type==="duplicate"||r.type==="component")&&(function(W){rt.onclick=ie=>{ie.preventDefault(),ie.stopPropagation(),console.log("Create Component button clicked",W),typeof fo=="function"?fo(W):(console.error("handleCreateComponent is not a function"),alert("Error: handleCreateComponent function not found"))}})(r);let Ne=de.querySelector("button.btn-select-variable");Ne&&r.type==="color-variable"&&(function(W){Ne.onclick=ie=>{ie.preventDefault(),ie.stopPropagation(),Wn(W)}})(r);let Ze=de.querySelector("button.btn-rename");Ze&&r.type==="naming"&&(function(W){Ze.onclick=ie=>{ie.preventDefault(),ie.stopPropagation(),console.log("Rename button clicked",W),typeof yo=="function"?yo(W):(console.error("handleRenameNode is not a function"),alert("Error: handleRenameNode function not found"))}})(r);let nn=de.querySelector("button.btn-remove-layer");nn&&(function(W){nn.onclick=ie=>{ie.preventDefault(),ie.stopPropagation(),console.log("Remove Layer button clicked",W),typeof Ft=="function"?Ft(W):(console.error("handleRemoveLayer is not a function"),alert("Error: handleRemoveLayer function not found"))}})(r);let eo=de.querySelector("button.btn-ignore");if(eo&&r.type==="contrast"&&(eo.removeAttribute("disabled"),eo.onclick=W=>{W.preventDefault(),W.stopPropagation(),console.log("Ignore button clicked",r);try{typeof ko=="function"?ko(r):(console.error("handleIgnoreIssue is not a function"),alert("Error: handleIgnoreIssue function not found"))}catch(ie){console.error("Error handling ignore:",ie),alert(`Error: ${ie.message}`)}}),r.type==="typography-style"){let W=de.querySelector("button.btn-create-style");W?(console.log("Attaching create style handler to button",{issueId:r.id,issueType:r.type,nodeName:r.nodeName}),(function(Te){W.onclick=Fe=>{Fe.preventDefault(),Fe.stopPropagation(),console.log("Create Style button clicked",Te),typeof Eo=="function"?Eo(Te):(console.error("handleCreateTextStyle is not a function"),alert("Error: handleCreateTextStyle function not found"))}})(r)):console.error("Create Style button not found in DOM",{issueId:r.id,issueType:r.type,hasIssueEl:!!de,innerHTML:de.innerHTML.substring(0,200)});let ie=de.querySelector("button.btn-suggest-fix");ie&&r.bestMatch&&r.bestMatch.name&&r.type==="typography-style"&&(function(Te){ie.onclick=Fe=>{Fe.preventDefault(),Fe.stopPropagation();let vt=ie.getAttribute("data-style-name");vt?Vt(Te,vt):(console.error("Cannot apply: styleName is missing from button",Te),alert("Error: Style name is missing"))}})(r),ie&&r.bestMatch&&r.bestMatch.name&&r.type==="typography-check"&&(function(Te){ie.onclick=Fe=>{Fe.preventDefault(),Fe.stopPropagation(),Te.bestMatch&&Te.bestMatch.name?Vt(Te,Te.bestMatch.name):(console.error("Cannot apply: bestMatch.name is missing",Te),alert("Error: Best match style name is missing"))}})(r);let je=de.querySelector("button.btn-fix");je&&r.type==="typography-style"&&(function(Te){je.onclick=Fe=>{Fe.preventDefault(),Fe.stopPropagation(),parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:Te.id}},"*"),window.pendingTypographyStyleIssue=Te}})(r);let xt=de.querySelector("button.btn-style-dropdown"),ct=de.querySelector(".style-dropdown-menu");if(xt&&ct){let Te=!1;xt.onclick=Fe=>{Fe.preventDefault(),Fe.stopPropagation();let vt=ct.style.display!=="none";document.querySelectorAll(".style-dropdown-menu").forEach(ln=>{ln!==ct&&(ln.style.display="none")}),vt?ct.style.display="none":(ct.style.display="block",Te||(ct.innerHTML='<div style="padding: 8px 12px; color: #999; font-size: 12px; text-align: center;">Loading...</div>',parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:r.id}},"*")))},document.addEventListener("click",function(vt){de.contains(vt.target)||(ct.style.display="none")})}}});q.appendChild(K),ne.appendChild(q)}l||Wt({issues:e,issuesTimestamp:i,tokens:k.tokens,tokensTimestamp:k.tokensTimestamp,lastActiveTab:"issues",scanMode:k.scanMode||null,context:k.context||null})}function _n(e){if(console.log("filterAndSearchTokens called",{hasTokens:!!e,currentColorTypeFilter:Ve,currentSearch:Ie}),!e)return null;let t={},o=!1;for(let[l,n]of Object.entries(e)){let s=n||[];if(console.log(`Processing ${l}, initial count:`,s.length),(l==="colors"||l==="gradients")&&Ve!=="all"&&(s=s.filter(a=>(a.colorType||"").toLowerCase().includes(Ve.toLowerCase())),console.log(`After color type filter (${Ve}):`,s.length)),Ie.trim()){let a=Ie.toLowerCase();s=s.map(i=>{let c=String(i.value||"").toLowerCase(),p=(i.nodes||[]).map(m=>m.name||"").join(" ").toLowerCase(),d=(i.colorType||"").toLowerCase(),S=c.includes(a),h=p.includes(a),f=d.includes(a);if(S||h||f){let m=[];return S&&m.push("value"),h&&m.push("nodeName"),f&&m.push("colorType"),ot(Ke({},i),{_matchedBy:m,_matchedNodeNames:h?(i.nodes||[]).filter(g=>(g.name||"").toLowerCase().includes(a)).map(g=>g.name):[]})}return null}).filter(i=>i!==null),console.log(`After search filter (${l}):`,s.length)}s.length>0&&(o=!0),t[l]=s}return console.log("Final filtered tokens keys:",Object.keys(t)),{tokens:t,hasMatches:o}}function Jn(e){let t=document.getElementById("spacing-scale");if(!t)return;let o=document.getElementById("spacing-threshold"),l=o?parseInt(o.value,10):100,n=isNaN(l)?100:l,a=(e&&Array.isArray(e.spacing)?e.spacing:[]).map(c=>{let p=parseInt(String(c&&c.value!==void 0?c.value:"").trim(),10);return isNaN(p)?null:Math.abs(p)}).filter(c=>c!==null&&c<=n);if(!a.length)return;let i=Array.from(new Set(a)).sort((c,p)=>c-p);t.value=i.join(", ");try{t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(c){}}function It(e,t=!1,o={}){let{skipSave:l=!1,restoreTimestamp:n=null,skipTabSwitch:s=!1}=o;s||Le("tokens");let a=Object.values(e||{}).reduce((j,z)=>j+(Array.isArray(z)?z.length:0),0);document.getElementById("tokens-count").textContent=a;let i=k.tokens!==e;k.tokens=e;let c=n||new Date().toISOString();k.tokensTimestamp=c,Ct=!0,(t||i)&&(console.log("Resetting filters for new token data"),Ae="all",Ve="all",Ue&&(Ue.value=""),Ie="",Be&&(Be.style.display="none"),$e&&$e.length>0&&$e.forEach(j=>{j.classList.remove("active"),j.getAttribute("data-filter")==="all"&&j.classList.add("active")}),yt&&(yt.value="all"));let p=document.getElementById("filter-controls"),d=document.getElementById("color-type-filter"),S=document.getElementById("filter-buttons");p&&(p.style.display=e&&Object.keys(e).length>0?"flex":"none"),d&&(d.style.display=e&&(e.colors||e.gradients)?"block":"none"),S&&(S.style.display="none");let h=document.getElementById("export-group");h.style.display=e&&Object.keys(e).length>0?"flex":"none",console.log("About to filter tokens with:",{currentColorTypeFilter:Ve,currentSearch:Ie});let f=_n(e);if(zt("tokens"),!e||Object.keys(e).length===0){me.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F4CB}</div>
                <p>No design tokens found</p>
              </div>
            `;return}if(!f){me.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F50D}</div>
                <p><strong>No results found</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Try changing the filter or search keyword.</p>
              </div>
            `;return}let m=f.tokens||{},g=f.hasMatches;if((Ie.trim()||Ve!=="all")&&!g){me.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F50D}</div>
                <p><strong>No results found</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Try changing the filter or search keyword.</p>
              </div>
            `;return}let T={colors:{icon:"\u{1F3A8}",label:"Colors",values:m.colors||[]},gradients:{icon:"\u{1F308}",label:"Gradients",values:m.gradients||[]},spacing:{icon:"\u2194\uFE0F",label:"Spacing (px)",values:m.spacing||[]},borderRadius:{icon:"\u2B55",label:"Border Radius",values:m.borderRadius||[]},fontWeight:{icon:"\u{1F4AA}",label:"Font Weight",values:m.fontWeight||[]},lineHeight:{icon:"\u{1F4CF}",label:"Line Height (%)",values:m.lineHeight||[]},fontSize:{icon:"\u{1F4DD}",label:"Font Size",values:m.fontSize||[]},fontFamily:{icon:"\u{1F524}",label:"Font Family",values:m.fontFamily||[]}},A=document.createElement("div");A.className="results-header";let F=Object.values(T).reduce((j,z)=>j+z.values.length,0);A.innerHTML=`
            <h3>Design Tokens</h3>
            <div class="results-stats">
              <span class="stat">${F} Tokens</span>
            </div>
          `,me.appendChild(A);for(let[j,z]of Object.entries(T)){let D=document.createElement("div");D.className="issue-group collapsed";let ye=document.createElement("div");ye.className="issue-group-header",ye.innerHTML=`
              <div class="issue-group-header-left">
                <button class="issue-group-toggle" type="button">
                  <span class="issue-group-toggle-icon">\u25B6</span>
                </button>
                <h4>${z.icon} ${z.label}</h4>
                <span class="badge">${z.values.length}</span>
              </div>
            `;let b=document.createElement("div");b.className="issue-group-content",b.style.display="none";let P=ye.querySelector(".issue-group-toggle"),x=()=>{D.classList.contains("collapsed")?(D.classList.remove("collapsed"),b.style.display="block",setTimeout(()=>{b.style.opacity="1"},10)):(b.style.opacity="0",setTimeout(()=>{D.classList.add("collapsed"),b.style.display="none"},200))};if(P.onclick=q=>{q.stopPropagation(),x()},ye.onclick=q=>{q.target!==P&&!P.contains(q.target)&&x()},D.appendChild(ye),Array.isArray(z.values)&&z.values.length>0){let q=document.createElement("div");q.className="token-list",z.values.forEach((se,he)=>{let Ee=he+1,be=document.createElement("div");be.className="token-item";let N=se.value,ce=se.nodes||[],K=ce.length>0?ce[0]:null,r=typeof se.totalNodes=="number"?se.totalNodes:ce.length,xe=se.colorType||null,ge="";if(j==="colors"){let ke=xe?`<span class="token-color-type">${u(xe)}</span>`:"";ge=`
                  <span class="token-number">#${Ee}</span>
                  <span class="token-color-preview" style="background-color: ${u(N)}"></span>
                  <code>${u(N)}</code>
                  ${ke}
                `}else if(j==="gradients"){let ke=xe?`<span class="token-color-type">${u(xe)}</span>`:"";ge=`
                  <span class="token-number">#${Ee}</span>
                  <span class="token-gradient-preview" style="background: ${u(N)}"></span>
                  <code>${u(N)}</code>
                  ${ke}
                `}else ge=`<span class="token-number">#${Ee}</span><code>${u(String(N))}</code>`;let Qe=se._matchedBy||[],de=se._matchedNodeNames||[],et=Qe.includes("nodeName"),De="";K&&K.name&&(et&&de.length>0?De=`<div class="token-node-name token-matched-by-name">
                    <span class="match-indicator">\u{1F50D} Matched in:</span> ${de.map(Xe=>`<span class="token-matched-node">${u(Xe)}</span>`).join(", ")}
                  </div>`:De=`<div class="token-node-name">Node: ${u(K.name)}</div>`);let tt="";if(j==="fontWeight"){let Xe=Array.isArray(se.fontFamilies)?se.fontFamilies:null;if(!Xe){let rt={};ce.forEach(Ne=>{let Ze=Ne&&Ne.fontFamily?String(Ne.fontFamily):"Unknown";rt[Ze]=(rt[Ze]||0)+1}),Xe=Object.entries(rt).map(([Ne,Ze])=>({family:Ne,count:Ze})).sort((Ne,Ze)=>Ze.count-Ne.count||Ne.family.localeCompare(Ze.family))}Array.isArray(Xe)&&Xe.length>0&&(tt=`
                    <div class="token-note">
                      <div class="token-note-label">Font-family:</div>
                      <ul class="token-note-list">${Xe.map(Ne=>`<li><code>${u(Ne.family)}</code> (${Ne.count})</li>`).join("")}</ul>
                    </div>
                  `)}be.innerHTML=`
                <div class="token-item-row">
                  <div class="token-value">
                    ${ge}
                  </div>
                  ${K?`
                    <div class="token-actions">
                      <button class="btn-select" data-id="${K.id}">Select</button>
                      ${r>1?`<span class="token-node-count">(${r})</span>`:""}
                    </div>
                  `:""}
                </div>
                ${De}
                ${tt}
              `;let Ye=be.querySelector("button.btn-select");Ye&&(Ye.onclick=()=>{document.querySelectorAll(".btn-select.active").forEach(ke=>ke.classList.remove("active")),document.querySelectorAll(".issue.selected, .token-item.selected").forEach(ke=>ke.classList.remove("selected")),Ye.classList.add("active"),be.classList.add("selected"),parent.postMessage({pluginMessage:{type:"select-node",id:K.id}},"*")}),q.appendChild(be)}),b.appendChild(q)}else{let q=document.createElement("div");q.className="token-empty-message",q.textContent="No tokens in this group.",b.appendChild(q)}D.appendChild(b),me.appendChild(D)}l||Wt({issues:k.issues,issuesTimestamp:k.timestamp,tokens:e,tokensTimestamp:c,lastActiveTab:"tokens",scanMode:k.scanMode||null,context:k.context||null})}function st(e){let t=document.getElementById("validation-error"),o=document.getElementById("validation-error-message"),l=document.getElementById("btn-close-validation-error");t&&o&&(o.textContent=e,t.style.display="block",v.style.display="block",C.style.display="none",y.style.display="none",v.disabled=!1,I.disabled=!1,setTimeout(()=>{t.style.display==="block"&&(t.style.display="none")},1e4),l&&(l.onclick=()=>{t.style.display="none"}))}function Mo(e){var j,z,D,ye,b,P,x;v.style.display="none",C.style.display="block",y.style.display="block",w.style.transition="none",w.style.width="0%",$.textContent="0%",setTimeout(()=>{w.style.transition="width 0.3s"},10),X();let t=document.getElementById("spacing-scale"),o=document.getElementById("spacing-threshold"),l=document.getElementById("color-scale"),n=document.getElementById("font-size-scale"),s=document.getElementById("font-size-threshold"),a=document.getElementById("line-height-scale"),i=document.getElementById("line-height-threshold"),c=document.getElementById("line-height-baseline-threshold"),p=t?t.value.trim():"",d=o?parseInt(o.value,10):100,S=l?l.value.trim():"",h=n?n.value.trim():"",f=s?parseInt(s.value,10):100,m=a?a.value.trim():"",g=i?parseInt(i.value,10):300,M=c?parseInt(c.value,10):120,T={checkStyle:((j=document.getElementById("rule-typo-style"))==null?void 0:j.checked)||!1,checkFontFamily:((z=document.getElementById("rule-font-family"))==null?void 0:z.checked)||!1,checkFontSize:((D=document.getElementById("rule-font-size"))==null?void 0:D.checked)||!1,checkFontWeight:((ye=document.getElementById("rule-font-weight"))==null?void 0:ye.checked)||!1,checkLineHeight:((b=document.getElementById("rule-line-height"))==null?void 0:b.checked)||!1,checkLetterSpacing:((P=document.getElementById("rule-letter-spacing"))==null?void 0:P.checked)||!1,checkWordSpacing:((x=document.getElementById("rule-word-spacing"))==null?void 0:x.checked)||!1},A=document.getElementById("scan-skip-names"),F=A?A.value.trim():"not check design, sticky note, vector, Clip path group, Clip path";parent.postMessage({pluginMessage:{type:"scan",mode:e,spacingScale:p,spacingThreshold:d,colorScale:S,fontSizeScale:h,fontSizeThreshold:f,lineHeightScale:m,lineHeightThreshold:g,lineHeightBaselineThreshold:M,typographyStyles:Q,typographyRules:T,ignoredIssues:ue,skipNames:F}},"*"),console.log("Message sent:",{type:"scan",mode:e})}v.onclick=()=>{var e;console.log("btnScan clicked");try{let t=document.getElementById("validation-error");t&&(t.style.display="none");let o=((e=document.querySelector('input[name="scope"]:checked'))==null?void 0:e.value)||"page",l=document.getElementById("spacing-scale"),n=document.getElementById("spacing-threshold"),s=document.getElementById("color-scale"),a=document.getElementById("font-size-scale"),i=document.getElementById("font-size-threshold"),c=document.getElementById("line-height-scale"),p=document.getElementById("line-height-threshold"),d=document.getElementById("line-height-baseline-threshold"),S=l?l.value.trim():"",h=n?parseInt(n.value,10):100,f=s?s.value.trim():"",m=a?a.value.trim():"",g=i?parseInt(i.value,10):100,M=c?c.value.trim():"",T=p?parseInt(p.value,10):300,A=d?parseInt(d.value,10):120;if(S&&!/^\d+(\s*,\s*\d+)*$/.test(S)){st("Spacing guidelines format is incorrect. Please enter the numbers separated by commas (e.g. 4, 8, 12, 16)");return}if(f){let F=f.split(",").map(D=>D.trim()).filter(D=>D),j=/^#[0-9a-fA-F]{3,8}$/,z=F.filter(D=>!j.test(D));if(z.length>0){st(`Color format is incorrect. Invalid colors: ${z.join(", ")}. Please use hex format only.`);return}}if(m&&!/^\d+(\s*,\s*\d+)*$/.test(m)){st("Font-size scale format is incorrect. Please enter the numbers separated by commas (e.g. 32, 24, 20, 18)");return}if(M){let F=M.split(",").map(z=>z.trim()).filter(z=>z);if(!F.every(z=>z.toLowerCase()==="auto"||/^\d+$/.test(z))||F.length===0){st('Line-height scale format is incorrect. Please enter "auto" and/or numbers separated by commas.');return}}if(isNaN(h)||h<0){st("Spacing threshold must be a number >= 0");return}if(isNaN(g)||g<0){st("Font-size threshold must be a number >= 0");return}if(isNaN(T)||T<0){st("Line-height threshold must be a number >= 0");return}if(isNaN(A)||A<0){st("Line-height baseline threshold must be a number >= 0");return}ne.innerHTML=`
        <div class="scanning">
          <div class="spinner"></div>
          <p>Checking design size...</p>
        </div>
      `,Le("issues"),v.disabled=!0,I.disabled=!0,k.scanMode=o,ve(),Se={scope:o},parent.postMessage({pluginMessage:{type:"get-node-count",mode:o}},"*")}catch(t){console.error("Error in btnScan.onclick:",t),ne.innerHTML=`<div class="error-message">Error: ${u(t.message)}</div>`,Le("issues"),v.disabled=!1,I.disabled=!1}},I.onclick=()=>{var e;console.log("btnExtractTokens clicked");try{I.style.display="none",C.style.display="block",y.style.display="block",w.style.transition="none",w.style.width="0%",$.textContent="0%",setTimeout(()=>{w.style.transition="width 0.3s"},10);let t=((e=document.querySelector('input[name="scope"]:checked'))==null?void 0:e.value)||"page";me.innerHTML=`
        <div class="scanning">
          <div class="spinner"></div>
          <p>Extracting design tokens... Please wait</p>
        </div>
      `,Le("tokens"),v.disabled=!0,I.disabled=!0,k.scanMode=t,parent.postMessage({pluginMessage:{type:"extract-tokens",mode:t}},"*"),console.log("Message sent:",{type:"extract-tokens",mode:t})}catch(t){console.error("Error in btnExtractTokens.onclick:",t),me.innerHTML=`<div class="error-message">Error: ${u(t.message)}</div>`,Le("tokens"),v.disabled=!1,I.disabled=!1}},R.onclick=()=>{try{Jn(k.tokens)}catch(e){console.error("Failed to fill spacing guidelines from tokens",e)}},_.onclick=()=>{try{let e=k.tokens;if(!e||!Array.isArray(e.colors)||!e.colors.length){alert("No color tokens found. Please run 'Extract Design Tokens' first.");return}let t=document.getElementById("color-scale");if(!t)return;let l=(e.colors||[]).map(s=>String(s&&s.value!==void 0?s.value:"").trim().toUpperCase()).filter(s=>s&&s.startsWith("#"));if(!l.length)return;let n=Array.from(new Set(l)).sort((s,a)=>dt(s)-dt(a));t.value=n.join(", "),typeof He=="function"&&He();try{t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(s){}}catch(e){console.error("Failed to fill color from tokens",e)}},O.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-color-styles"}},"*")};let zo=document.getElementById("btn-extract-color-variables");zo&&(zo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-color-variables"}},"*")}),L.onclick=()=>{try{let e=k.tokens;if(!e||!Array.isArray(e.fontSize)||!e.fontSize.length){alert("No font size tokens found. Please run 'Extract Design Tokens' first.");return}let t=document.getElementById("font-size-scale");if(!t)return;let o=document.getElementById("font-size-threshold"),l=o?parseInt(o.value,10):100,n=isNaN(l)?100:l,s=e.fontSize.map(i=>parseInt(String(i&&i.value!==void 0?i.value:"").trim(),10)).filter(i=>!isNaN(i)&&i<=n);if(!s.length)return;let a=Array.from(new Set(s)).sort((i,c)=>c-i);t.value=a.join(", "),t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(e){console.error("Failed to fill font size from tokens",e)}},U.onclick=()=>{try{let e=k.tokens;if(!e||!Array.isArray(e.lineHeight)||!e.lineHeight.length){alert("No line height tokens found. Please run 'Extract Design Tokens' first.");return}let t=document.getElementById("line-height-scale");if(!t)return;let o=document.getElementById("line-height-threshold"),l=o?parseInt(o.value,10):300,n=isNaN(l)?300:l,s=[];if(e.lineHeight.forEach(d=>{let S=String(d&&d.value!==void 0?d.value:"").trim();if(S==="auto")s.push("auto");else{let h=parseFloat(S);!isNaN(h)&&h<=n&&s.push(h)}}),!s.length)return;let a=s.includes("auto"),i=s.filter(d=>d!=="auto"),c=Array.from(new Set(i)).sort((d,S)=>d-S),p=a?["auto",...c]:c;t.value=p.join(", "),t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(e){console.error("Failed to fill line height from tokens",e)}},V.onclick=()=>{try{if(!Q||!Array.isArray(Q)||Q.length===0){alert("No typography styles defined. Please add typography styles or extract from Figma first.");return}let e=document.getElementById("font-size-scale");if(!e)return;let t=Q.map(l=>{let n=parseInt(String(l.fontSize||"").trim(),10);return isNaN(n)?null:n}).filter(l=>l!==null);if(!t.length){alert("No valid font sizes found in typography styles.");return}let o=Array.from(new Set(t)).sort((l,n)=>n-l);e.value=o.join(", "),ve(),e.focus(),e.setSelectionRange(e.value.length,e.value.length),console.log("Filled font size from typography:",o)}catch(e){console.error("Failed to fill font size from typography",e)}},B.onclick=()=>{try{if(!Q||!Array.isArray(Q)||Q.length===0){alert("No typography styles defined. Please add typography styles or extract from Figma first.");return}let e=document.getElementById("line-height-scale");if(!e)return;let t=[];if(Q.forEach(a=>{let i=String(a.lineHeight||"").trim();if(i==="auto")t.push("auto");else{let c=parseFloat(i.replace("%",""));isNaN(c)||t.push(c)}}),!t.length){alert("No valid line heights found in typography styles.");return}let o=t.includes("auto"),l=t.filter(a=>a!=="auto"),n=Array.from(new Set(l)).sort((a,i)=>a-i),s=o?["auto",...n]:n;e.value=s.join(", "),ve(),e.focus(),e.setSelectionRange(e.value.length,e.value.length),console.log("Filled line height from typography:",s)}catch(e){console.error("Failed to fill line height from typography",e)}};let Gt=document.getElementById("typography-panel"),To=document.getElementById("typography-panel-header"),Fo=document.getElementById("typography-panel-toggle");To&&Gt&&Fo&&(To.onclick=()=>{let e=Gt.classList.contains("collapsed");Gt.classList.toggle("collapsed");let t=Fo.querySelector(".issue-group-toggle-icon");t&&(t.textContent="\u25B6")});let _t=document.getElementById("settings-panel"),No=document.getElementById("settings-panel-header"),$t=document.getElementById("settings-panel-toggle");if(No&&_t&&$t){let e=()=>{let t=_t.classList.contains("collapsed");_t.classList.toggle("collapsed");let o=$t.querySelector(".issue-group-toggle-icon");o&&(o.textContent="\u25B6")};No.onclick=t=>{t.target===$t||$t.contains(t.target)||e()},$t.onclick=t=>{t.stopPropagation(),e()}}function Jt(){let e=document.getElementById("color-preview-panel"),t=document.getElementById("color-preview-panel-header"),o=document.getElementById("color-preview-panel-toggle");if(!e||!t||!o){console.log("Color preview panel elements not found, retrying..."),setTimeout(Jt,100);return}console.log("Setting up color preview panel toggle");let l=()=>{let n=e.classList.contains("collapsed");e.classList.toggle("collapsed");let s=o.querySelector(".issue-group-toggle-icon");s&&(s.textContent="\u25B6"),console.log("Color preview panel toggled, isCollapsed:",!n)};t.onclick=n=>{n.preventDefault(),n.stopPropagation(),console.log("Color preview panel header clicked"),l()},o.onclick=n=>{n.preventDefault(),n.stopPropagation(),console.log("Color preview panel toggle button clicked"),l()}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",Jt):Jt();function He(){let e=document.getElementById("color-scale"),t=document.getElementById("color-preview");if(!e||!t)return;let o=e.value.trim();if(t.innerHTML="",!o)return;let l=o.split(",").map(a=>a.trim()).filter(a=>a),n=1;l.forEach(a=>{let i=a.toUpperCase(),c=J[i];if(c&&/^No name \d+$/.test(c)){let p=parseInt(c.replace("No name ",""),10);p>=n&&(n=p+1)}});let s=1;l.forEach((a,i)=>{let c=/^#[0-9A-Fa-f]{3,8}$/.test(a),p=/^rgba?\(/.test(a);if(!c&&!p)return;let d=document.createElement("div");d.className="color-swatch-container";let S=document.createElement("div");S.className="color-swatch",S.style.background=a;let h=document.createElement("button");h.innerHTML="\xD7",h.className="color-swatch-close",h.onclick=function(A){var D;A.stopPropagation();let F=e.value.split(",").map(ye=>ye.trim()).filter(ye=>ye),j=(D=F[i])==null?void 0:D.toUpperCase(),z=F.filter((ye,b)=>b!==i);e.value=z.join(", "),j&&J[j]&&delete J[j],He(),typeof ve=="function"&&ve()};let f=a.toUpperCase(),m=J[f];if(!m){for(;Object.values(J).includes(`No name ${s}`);)s++;m=`No name ${s}`,J[f]=m,s++,typeof ve=="function"&&ve()}let g=document.createElement("div");g.className="color-swatch-label";let M=document.createElement("div");M.className="color-swatch-label-name",M.textContent=m,M.title="Click to edit name",M.style.cursor="pointer",M.onclick=function(A){A.stopPropagation();let F=document.createElement("input");F.type="text",F.value=m,F.className="color-swatch-name-input",F.style.cssText="width: 100%; font-size: 11px; padding: 2px 4px; border: 1px solid #3b82f6; border-radius: 4px; text-align: center; box-sizing: border-box;",M.style.display="none",M.parentNode.insertBefore(F,M),F.focus(),F.select();let j=()=>{let z=F.value.trim()||`No name ${s}`;J[f]=z,M.textContent=z,M.style.display="",F.remove(),typeof ve=="function"&&ve()};F.onblur=j,F.onkeydown=function(z){z.key==="Enter"?(z.preventDefault(),j()):z.key==="Escape"&&(M.style.display="",F.remove())}};let T=document.createElement("div");T.className="color-swatch-label-hex",T.textContent=f,g.appendChild(M),g.appendChild(T),S.appendChild(h),d.appendChild(S),d.appendChild(g),t.appendChild(d)})}function Yn(){var e,t,o,l,n,s;return{fontFamily:((e=document.getElementById("rule-font-family"))==null?void 0:e.checked)||!1,fontSize:((t=document.getElementById("rule-font-size"))==null?void 0:t.checked)||!1,fontWeight:((o=document.getElementById("rule-font-weight"))==null?void 0:o.checked)||!1,lineHeight:((l=document.getElementById("rule-line-height"))==null?void 0:l.checked)||!1,letterSpacing:((n=document.getElementById("rule-letter-spacing"))==null?void 0:n.checked)||!1,wordSpacing:((s=document.getElementById("rule-word-spacing"))==null?void 0:s.checked)||!1}}function Ge(){let e=document.getElementById("typography-table-body"),t=document.querySelector("#typography-table thead tr");if(!e||!t)return;let o=Yn(),l='<th class="typography-table-actions">Actions</th>';if(l+='<th class="typography-table-style-name" style="width: 120px;">Style Name</th>',o.fontFamily&&(l+='<th class="typography-table-font-family" style="width: 140px;">Font Family</th>'),o.fontSize&&(l+='<th class="typography-table-font-size" style="width: 80px;">Size (px)</th>'),o.fontWeight&&(l+='<th class="typography-table-font-weight" style="width: 100px;">Weight</th>'),o.lineHeight&&(l+='<th class="typography-table-line-height" style="width: 100px;">Line Height</th>'),o.letterSpacing&&(l+='<th class="typography-table-letter-spacing" style="width: 100px;">Letter Spacing</th>'),o.wordSpacing&&(l+='<th class="typography-table-word-spacing" style="width: 100px;">Word Spacing</th>'),t.innerHTML=l,Q.length===0){let n=Object.values(o).filter(s=>s).length+2;e.innerHTML=`
        <tr>
          <td colspan="${n}" class="typography-empty-message">
            No typography styles defined. Click "Add Typography Style" to create one.
          </td>
        </tr>
      `;return}e.innerHTML=Q.map(n=>{let s=`<tr data-id="${n.id}">`;return s+='<td class="typography-table-actions">',n.styleId&&(s+=`<button class="btn-table-action" onclick="selectTypographyStyle('${n.styleId}')" title="Select layer in Figma" style="background: #0071e3; color: white;">\u{1F441}</button>`),s+=`<button class="btn-table-action delete" onclick="deleteTypographyStyle(${n.id})" title="Delete">\u{1F5D1}</button>
        </td>`,s+=`<td><input type="text" value="${u(n.name)}" data-field="name"></td>`,o.fontFamily&&(s+=`<td><input type="text" value="${u(n.fontFamily)}" data-field="fontFamily"></td>`),o.fontSize&&(s+=`<td><input type="number" value="${n.fontSize}" data-field="fontSize" min="1"></td>`),o.fontWeight&&(s+=`<td>
          <select data-field="fontWeight">
            <option value="Thin" ${n.fontWeight==="Thin"?"selected":""}>Thin (100)</option>
            <option value="ExtraLight" ${n.fontWeight==="ExtraLight"?"selected":""}>ExtraLight (200)</option>
            <option value="Light" ${n.fontWeight==="Light"?"selected":""}>Light (300)</option>
            <option value="Regular" ${n.fontWeight==="Regular"?"selected":""}>Regular (400)</option>
            <option value="Medium" ${n.fontWeight==="Medium"?"selected":""}>Medium (500)</option>
            <option value="SemiBold" ${n.fontWeight==="SemiBold"?"selected":""}>SemiBold (600)</option>
            <option value="Bold" ${n.fontWeight==="Bold"?"selected":""}>Bold (700)</option>
            <option value="ExtraBold" ${n.fontWeight==="ExtraBold"?"selected":""}>ExtraBold (800)</option>
            <option value="Black" ${n.fontWeight==="Black"?"selected":""}>Black (900)</option>
          </select>
        </td>`),o.lineHeight&&(s+=`<td><input type="text" value="${u(n.lineHeight)}" data-field="lineHeight" placeholder="120% or auto"></td>`),o.letterSpacing&&(s+=`<td><input type="text" value="${u(n.letterSpacing||"0")}" data-field="letterSpacing" placeholder="0 or 0.5px"></td>`),o.wordSpacing&&(s+=`<td><input type="text" value="${u(n.wordSpacing||"0")}" data-field="wordSpacing" placeholder="0"></td>`),s+="</tr>",s}).join(""),e.querySelectorAll("input, select").forEach(n=>{n.addEventListener("change",s=>{let a=s.target.closest("tr"),i=parseInt(a.dataset.id),c=s.target.dataset.field,p=s.target.value;Xn(i,c,p)})})}window.addTypographyStyle=function(){let e={id:nt++,name:"New Style",fontFamily:"Inter",fontSize:16,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"};Q.push(e),Ge(),ve()};function Xn(e,t,o){let l=Q.find(n=>n.id===e);l&&(t==="fontSize"?l[t]=parseInt(o)||16:l[t]=o,ve())}window.deleteTypographyStyle=function(e){confirm("Delete this typography style?")&&(Q=Q.filter(t=>t.id!==e),X(),Ge(),ve())},window.selectTypographyStyle=function(e){parent.postMessage({pluginMessage:{type:"select-text-style",styleId:e}},"*")};let Bo=document.getElementById("btn-add-typo-style");Bo&&(Bo.onclick=()=>addTypographyStyle());let Ao=document.getElementById("btn-extract-typo-desktop");Ao&&(Ao.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"desktop"}},"*")});let Lo=document.getElementById("btn-extract-typo-tablet");Lo&&(Lo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"tablet"}},"*")});let Ho=document.getElementById("btn-extract-typo-mobile");Ho&&(Ho.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"mobile"}},"*")});let qo=document.getElementById("btn-extract-typo-all");qo&&(qo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"all"}},"*")});let Po=document.getElementById("btn-reset-typo-table");Po&&(Po.onclick=()=>{confirm(`\u26A0\uFE0F Reset typography table to default styles?

This will:
\u2022 Clear all current styles
\u2022 Restore default H1-H6 and Body styles

This action cannot be undone.`)&&(Q=[{id:1,name:"H1",fontFamily:"Inter",fontSize:48,fontWeight:"Bold",lineHeight:"120%",letterSpacing:"0",wordSpacing:"0"},{id:2,name:"H2",fontFamily:"Inter",fontSize:36,fontWeight:"Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:3,name:"H3",fontFamily:"Inter",fontSize:30,fontWeight:"Semi Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:4,name:"H4",fontFamily:"Inter",fontSize:24,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:5,name:"H5",fontFamily:"Inter",fontSize:20,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:6,name:"H6",fontFamily:"Inter",fontSize:16,fontWeight:"Semi Bold",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"},{id:7,name:"Body",fontFamily:"Inter",fontSize:14,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"}],nt=8,Ge(),ve(),alert("\u2705 Typography table has been reset to default styles!"))}),Ge(),["rule-font-family","rule-font-size","rule-font-weight","rule-line-height","rule-letter-spacing","rule-word-spacing"].forEach(e=>{let t=document.getElementById(e);t&&t.addEventListener("change",()=>{Ge(),ve()})});let Ro=document.getElementById("color-scale");Ro&&(Ro.addEventListener("input",()=>{He()}),He());let Zn=mn({maxHistory:10,postPluginMessage:e=>parent.postMessage({pluginMessage:e},"*"),getCurrentReportData:()=>k,setIsViewingTokens:e=>{Ct=!!e},renderResults:We,renderTokens:It}),{saveScanHistory:Do,requestScanHistory:Wo,renderScanHistory:Yt,restoreReportFromHistory:hl,loadLastScanModeOnce:Kn,setHistory:Qn,clearLocalHistory:el}=Zn,tl=document.getElementById("export-group"),Bt=document.getElementById("export-dropdown");G.onclick=e=>{e.stopPropagation(),Bt.style.display=Bt.style.display==="block"?"none":"block"},document.querySelectorAll(".export-option").forEach(e=>{e.onclick=t=>{t.stopPropagation();let o=e.getAttribute("data-format");gn({format:o,reportData:k,getTypeDisplayName:Tt,colorNameMap:J}),Bt.style.display="none"}}),document.addEventListener("click",e=>{tl.contains(e.target)||(Bt.style.display="none")});let Ue,Be,$e,yt;function At(e){if(!e)return;let t=e.filter(i=>i.severity==="error"&&!i.ignored).length,o=e.filter(i=>i.severity==="warn"&&!i.ignored).length,l=e.filter(i=>!i.ignored).length,n=document.getElementById("filter-count-all"),s=document.getElementById("filter-count-error"),a=document.getElementById("filter-count-warn");n&&(n.textContent=l),s&&(s.textContent=t),a&&(a.textContent=o)}function Lt(){console.log("applyFilters called",{isViewingTokens:Ct,hasTokens:!!k.tokens,hasIssues:!!k.issues,currentFilter:Ae,currentSearch:Ie,currentColorTypeFilter:Ve});let e=document.querySelector(".report-tab.active"),t=e?e.getAttribute("data-tab"):null;t==="animations"?(console.log("Applying search to animations"),typeof window.searchAnimations=="function"&&window.searchAnimations(Ie)):t==="tokens"&&k.tokens?(console.log("Applying filters to tokens"),It(k.tokens,!1,{skipTabSwitch:!0})):t==="issues"&&k.issues?(console.log("Applying filters to issues"),We(k.issues,!1,{skipTabSwitch:!0})):Ct&&k.tokens?(console.log("Applying filters to tokens (fallback)"),It(k.tokens,!1,{skipTabSwitch:!0})):k.issues&&(console.log("Applying filters to issues (fallback)"),We(k.issues,!1,{skipTabSwitch:!0}))}function Xt(){if(console.log("setupFilterHandlers called"),Ue=document.getElementById("search-input"),Be=document.getElementById("btn-clear-search"),$e=document.querySelectorAll(".filter-btn"),yt=document.getElementById("color-type-select"),console.log("Elements found:",{searchInput:!!Ue,btnClearSearch:!!Be,filterButtons:$e?$e.length:0,colorTypeSelect:!!yt}),!Ue||!Be||!$e||$e.length===0){console.warn("Filter elements not found, retrying...",{searchInput:!!Ue,btnClearSearch:!!Be,filterButtons:$e?$e.length:0}),setTimeout(Xt,100);return}console.log("Setting up search input handler"),Ue.addEventListener("input",e=>{let t=e.target.value;console.log("Search input changed:",t),Ie=t,console.log("currentSearch set to:",Ie),Be&&(Be.style.display=Ie.trim()?"block":"none"),Lt()}),Be&&(console.log("Setting up clear search button handler"),Be.onclick=e=>{console.log("Clear search clicked"),e.preventDefault(),e.stopPropagation(),Ue&&(Ue.value=""),Ie="",Be.style.display="none",Lt()}),console.log("Setting up filter buttons handlers, count:",$e.length),$e.forEach((e,t)=>{console.log(`Setting up filter button ${t}:`,e.getAttribute("data-filter")),e.onclick=o=>{o.preventDefault(),o.stopPropagation();let l=e.getAttribute("data-filter"),n=e.classList.contains("active");console.log("Filter button clicked:",l,"isActive:",n),n&&l!=="all"?(e.classList.remove("active"),Ae="all",$e.forEach(s=>{s.getAttribute("data-filter")==="all"&&s.classList.add("active")})):($e.forEach(s=>s.classList.remove("active")),e.classList.add("active"),Ae=l),console.log("currentFilter set to:",Ae),Lt()}}),yt&&(console.log("Setting up color type select handler"),yt.addEventListener("change",e=>{console.log("Color type changed:",e.target.value),Ve=e.target.value,Lt()})),console.log("Filter handlers setup complete")}console.log("Setting up filter handlers, DOM readyState:",document.readyState),document.readyState==="loading"?(console.log("DOM still loading, waiting for DOMContentLoaded"),document.addEventListener("DOMContentLoaded",()=>{console.log("DOMContentLoaded fired, setting up handlers"),Xt(),lo(),so(),Wo()})):(console.log("DOM already ready, setting up handlers immediately"),Xt(),lo(),so(),Wo()),ae&&(C.onclick=()=>{console.log("Cancel operation clicked"),parent.postMessage({pluginMessage:{type:"cancel-scan"}},"*"),v.style.display="block",v.disabled=!1,I.style.display="block",I.disabled=!1,C.style.display="none",y.style.display="none"},oe.onclick=()=>{if(confirm(`\u26A0\uFE0F Are you sure you want to reset all settings to default and clear history?

This will:
\u2022 Reset all input values to default
\u2022 Clear scan history
\u2022 Clear current reports

This action cannot be undone.`)){document.getElementById("spacing-scale").value="0, 4, 8, 12, 16, 24, 32, 40, 48, 64, 72, 80, 88, 96",document.getElementById("spacing-threshold").value="100",document.getElementById("color-scale").value="",document.getElementById("font-size-scale").value="32, 24, 20, 18, 16, 14, 12",document.getElementById("font-size-threshold").value="100",document.getElementById("line-height-scale").value="auto, 100, 110, 120, 130, 140, 150, 160, 170",document.getElementById("line-height-threshold").value="300",document.getElementById("line-height-baseline-threshold").value="120",Q=[{id:1,name:"H1",fontFamily:"Inter",fontSize:48,fontWeight:"Bold",lineHeight:"120%",letterSpacing:"0",wordSpacing:"0"},{id:2,name:"H2",fontFamily:"Inter",fontSize:36,fontWeight:"Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:3,name:"H3",fontFamily:"Inter",fontSize:30,fontWeight:"Semi Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:4,name:"H4",fontFamily:"Inter",fontSize:24,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:5,name:"H5",fontFamily:"Inter",fontSize:20,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:6,name:"H6",fontFamily:"Inter",fontSize:16,fontWeight:"Semi Bold",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"},{id:7,name:"Body",fontFamily:"Inter",fontSize:14,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"}],nt=8,Ge(),document.getElementById("rule-typo-style").checked=!0,document.getElementById("rule-font-family").checked=!0,document.getElementById("rule-font-size").checked=!0,document.getElementById("rule-font-weight").checked=!0,document.getElementById("rule-line-height").checked=!0,document.getElementById("rule-letter-spacing").checked=!1,document.getElementById("rule-word-spacing").checked=!1,Ge(),He(),k={issues:null,tokens:null,scanMode:null,timestamp:null,context:null,lastActiveTab:"issues"},zt("issues"),zt("tokens"),Le("issues"),el(),parent.postMessage({pluginMessage:{type:"clear-history"}},"*");let e=document.getElementById("history-panel");e&&e.style.display!=="none"&&Yt(),ve(),alert("\u2705 All settings have been reset to default and history has been cleared!")}},ae.onclick=()=>{let e=document.getElementById("history-panel");if(e){let t=e.style.display!=="none";e.style.display=t?"none":"flex",t||Yt()}}),Z&&(Z.onclick=()=>{let e=document.getElementById("history-panel");e&&(e.style.display="none")});let Uo=document.getElementById("btn-save-settings"),qe=document.getElementById("save-settings-modal"),we=document.getElementById("setting-name-input"),Ht=document.getElementById("btn-confirm-save-settings"),jo=document.getElementById("btn-cancel-save-settings"),Oo=document.getElementById("btn-close-save-settings");Uo&&(Uo.onclick=()=>{parent.postMessage({pluginMessage:{type:"get-project-name"}},"*"),qe&&(qe.style.display="flex",we&&(we.value="",we.focus(),we.onkeydown=e=>{e.key==="Enter"&&(e.preventDefault(),Ht&&Ht.click())}))}),Oo&&(Oo.onclick=()=>{qe&&(qe.style.display="none")}),jo&&(jo.onclick=()=>{qe&&(qe.style.display="none")});let Me=document.getElementById("replace-confirm-modal"),Vo=document.getElementById("replace-setting-name"),Go=document.getElementById("btn-confirm-replace"),_o=document.getElementById("btn-cancel-replace"),Jo=document.getElementById("btn-close-replace-confirm"),ze=null;function Yo(e,t){parent.postMessage({pluginMessage:{type:"save-settings",name:e,values:t,forceReplace:!0}},"*")}Ht&&(Ht.onclick=()=>{var o,l,n,s,a,i,c,p,d,S,h,f,m,g,M,T,A;let e=(o=we==null?void 0:we.value)==null?void 0:o.trim();if(!e){alert("\u26A0\uFE0F Please enter a setting name");return}let t={spacingScale:((l=document.getElementById("spacing-scale"))==null?void 0:l.value)||"",spacingThreshold:((n=document.getElementById("spacing-threshold"))==null?void 0:n.value)||"100",colorScale:((s=document.getElementById("color-scale"))==null?void 0:s.value)||"",colorNameMap:J,ignoredIssues:ue,fontSizeScale:((a=document.getElementById("font-size-scale"))==null?void 0:a.value)||"",fontSizeThreshold:((i=document.getElementById("font-size-threshold"))==null?void 0:i.value)||"100",lineHeightScale:((c=document.getElementById("line-height-scale"))==null?void 0:c.value)||"",lineHeightThreshold:((p=document.getElementById("line-height-threshold"))==null?void 0:p.value)||"300",lineHeightBaselineThreshold:((d=document.getElementById("line-height-baseline-threshold"))==null?void 0:d.value)||"120",typographyStyles:Q,skipNames:((S=document.getElementById("scan-skip-names"))==null?void 0:S.value)||"",typographyRules:{checkStyle:((h=document.getElementById("rule-typo-style"))==null?void 0:h.checked)||!0,checkFontFamily:((f=document.getElementById("rule-font-family"))==null?void 0:f.checked)||!0,checkFontSize:((m=document.getElementById("rule-font-size"))==null?void 0:m.checked)||!0,checkFontWeight:((g=document.getElementById("rule-font-weight"))==null?void 0:g.checked)||!0,checkLineHeight:((M=document.getElementById("rule-line-height"))==null?void 0:M.checked)||!0,checkLetterSpacing:((T=document.getElementById("rule-letter-spacing"))==null?void 0:T.checked)||!1,checkWordSpacing:((A=document.getElementById("rule-word-spacing"))==null?void 0:A.checked)||!1}};ze={name:e,values:t},parent.postMessage({pluginMessage:{type:"check-setting-name",name:e}},"*")}),Go&&(Go.onclick=()=>{ze&&(Yo(ze.name,ze.values),ze=null),Me&&(Me.style.display="none")}),_o&&(_o.onclick=()=>{ze=null,Me&&(Me.style.display="none"),we&&(we.focus(),we.select())}),Jo&&(Jo.onclick=()=>{ze=null,Me&&(Me.style.display="none"),we&&(we.focus(),we.select())}),Me&&(Me.onclick=e=>{e.target===Me&&(ze=null,Me.style.display="none",we&&(we.focus(),we.select()))});let Xo=document.getElementById("btn-load-settings"),Pe=document.getElementById("load-settings-modal"),Et=document.getElementById("settings-list"),Zt=document.getElementById("settings-empty-state"),Zo=document.getElementById("btn-close-load-settings");function Ko(e){if(!(!Et||!Zt)){if(!e||e.length===0){Et.innerHTML="",Zt.style.display="block";return}Zt.style.display="none",Et.innerHTML=e.map(t=>{let o=new Date(t.updatedAt||t.createdAt),l=o.toLocaleDateString()+" "+o.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});return`
        <div class="settings-item" data-setting-name="${u(t.name)}">
          <div class="settings-item-info">
            <div class="settings-item-name">${u(t.name)}</div>
            <div class="settings-item-date">Updated: ${l}</div>
          </div>
          <div class="settings-item-actions">
            <button class="btn-remove-setting" data-setting-name="${u(t.name)}" title="Remove">\u{1F5D1}\uFE0F</button>
          </div>
        </div>
      `}).join(""),Et.querySelectorAll(".settings-item").forEach(t=>{let o=t.getAttribute("data-setting-name");t.onclick=l=>{l.target.closest(".btn-remove-setting")||(parent.postMessage({pluginMessage:{type:"load-settings",name:o}},"*"),Pe&&(Pe.style.display="none"))}}),Et.querySelectorAll(".btn-remove-setting").forEach(t=>{t.onclick=o=>{o.stopPropagation();let l=t.getAttribute("data-setting-name");confirm(`\u26A0\uFE0F Are you sure you want to remove "${l}"?`)&&parent.postMessage({pluginMessage:{type:"remove-settings",name:l}},"*")}})}}Xo&&(Xo.onclick=()=>{parent.postMessage({pluginMessage:{type:"get-saved-settings"}},"*"),Pe&&(Pe.style.display="flex")}),Zo&&(Zo.onclick=()=>{Pe&&(Pe.style.display="none")});let Qo=document.getElementById("btn-export-settings");Qo&&(Qo.onclick=()=>{var s,a,i,c,p,d,S,h,f,m,g,M,T,A,F;let e=((s=document.getElementById("color-scale"))==null?void 0:s.value)||"",t=e.split(",").map(j=>j.trim().toUpperCase()).filter(j=>j&&j.startsWith("#")),o=Ke({},J),l=1;Object.values(o).forEach(j=>{if(j&&/^No name \d+$/.test(j)){let z=parseInt(j.replace("No name ",""),10);z>=l&&(l=z+1)}}),t.forEach(j=>{o[j]||(o[j]=`No name ${l}`,l++)});let n={spacingScale:((a=document.getElementById("spacing-scale"))==null?void 0:a.value)||"",spacingThreshold:((i=document.getElementById("spacing-threshold"))==null?void 0:i.value)||"100",colorScale:e,colorNameMap:o,ignoredIssues:ue,fontSizeScale:((c=document.getElementById("font-size-scale"))==null?void 0:c.value)||"",fontSizeThreshold:((p=document.getElementById("font-size-threshold"))==null?void 0:p.value)||"100",lineHeightScale:((d=document.getElementById("line-height-scale"))==null?void 0:d.value)||"",lineHeightThreshold:((S=document.getElementById("line-height-threshold"))==null?void 0:S.value)||"300",lineHeightBaselineThreshold:((h=document.getElementById("line-height-baseline-threshold"))==null?void 0:h.value)||"120",typographyStyles:Q,typographyRules:{checkStyle:((f=document.getElementById("rule-typo-style"))==null?void 0:f.checked)||!0,checkFontFamily:((m=document.getElementById("rule-font-family"))==null?void 0:m.checked)||!0,checkFontSize:((g=document.getElementById("rule-font-size"))==null?void 0:g.checked)||!0,checkFontWeight:((M=document.getElementById("rule-font-weight"))==null?void 0:M.checked)||!0,checkLineHeight:((T=document.getElementById("rule-line-height"))==null?void 0:T.checked)||!0,checkLetterSpacing:((A=document.getElementById("rule-letter-spacing"))==null?void 0:A.checked)||!1,checkWordSpacing:((F=document.getElementById("rule-word-spacing"))==null?void 0:F.checked)||!1}};parent.postMessage({pluginMessage:{type:"get-project-name"}},"*"),window.pendingExportValues=n});let en=document.getElementById("btn-import-settings"),ht=document.getElementById("import-settings-modal"),_e=document.getElementById("import-settings-file-input"),tn=document.getElementById("btn-select-import-file"),Je=document.getElementById("import-file-info"),on=document.getElementById("import-file-name"),Re=document.getElementById("btn-confirm-import"),Kt=document.getElementById("btn-cancel-import"),Qt=document.getElementById("btn-close-import-settings"),bt=null,Ce=null;if(en&&(en.onclick=()=>{bt=null,Ce=null,_e&&(_e.value=""),Je&&(Je.style.display="none"),Re&&(Re.disabled=!0),ht&&(ht.style.display="flex")}),tn&&_e&&(tn.onclick=()=>{_e.click()}),_e&&(_e.onchange=e=>{let t=e.target.files[0];if(!t)return;if(!t.name.endsWith(".json")){alert("\u26A0\uFE0F Please select a JSON file");return}bt=t,on&&(on.textContent=t.name),Je&&(Je.style.display="block"),Re&&(Re.disabled=!1);let o=new FileReader;o.onload=l=>{try{Ce=JSON.parse(l.target.result),console.log("Imported settings data:",Ce)}catch(n){alert("\u274C Error parsing JSON file: "+n.message),bt=null,Ce=null,Je&&(Je.style.display="none"),Re&&(Re.disabled=!0)}},o.onerror=()=>{alert("\u274C Error reading file"),bt=null,Ce=null},o.readAsText(t)}),Re&&(Re.onclick=()=>{if(!Ce){alert("\u274C No file data to import");return}console.log("Import file data:",Ce);let e=null;if(Array.isArray(Ce)){if(Ce.length===0){alert("\u274C No settings found in file");return}if(e=Ce[0].values,!e){alert("\u274C Invalid settings format. No values found in setting object.");return}}else if(Ce.values)e=Ce.values;else if(Ce.spacingScale!==void 0||Ce.colorScale!==void 0)e=Ce;else{alert("\u274C Invalid settings file format. Expected an array of settings, a single setting object, or a values object."),console.error("Invalid import data structure:",Ce);return}if(!e||typeof e!="object"){alert("\u274C Invalid settings format. No values found.");return}console.log("Applying values:",e),Ut(e),ve(),ht&&(ht.style.display="none"),bt=null,Ce=null,_e&&(_e.value=""),Je&&(Je.style.display="none"),Re&&(Re.disabled=!0),alert("\u2705 Settings imported and applied to input fields successfully")}),Kt||Qt){let e=()=>{ht&&(ht.style.display="none"),bt=null,Ce=null,_e&&(_e.value=""),Je&&(Je.style.display="none"),Re&&(Re.disabled=!0)};Kt&&(Kt.onclick=e),Qt&&(Qt.onclick=e)}qe&&(qe.onclick=e=>{e.target===qe&&(qe.style.display="none")}),Pe&&(Pe.onclick=e=>{e.target===Pe&&(Pe.style.display="none")}),ee.onclick=()=>{parent.postMessage({pluginMessage:{type:"close"}},"*")},window.onmessage=e=>{var o,l;console.log("Received message:",e.data);let t=e.data.pluginMessage;if(t&&t.type==="fix-issue-result"){if(console.log("[fix-issue-result] Received:",{issueId:t.issueId,success:t.success,message:t.message}),re(t.issueId,t.message,t.success),!t.success){console.log("[fix-issue-result] Error detected, showing error modal...");let n=t.message||"An error occurred while fixing the issue.";console.log("[fix-issue-result] Error message:",n);try{to(n),console.log("[fix-issue-result] Error modal should be displayed")}catch(s){console.error("[fix-issue-result] Error showing error modal:",s),alert("Error: "+n)}}if(t.success)if(console.log("[fix-issue-result] Removing issueId:",t.issueId),k&&k.issues&&(k.issues=k.issues.filter(n=>String(n.id)!==String(t.issueId))),window._batchFixInProgress)console.log("[fix-issue-result] Batch fix in progress, skipping DOM update");else{let n=`.issue[data-issue-id="${t.issueId}"]`,s=document.querySelectorAll(n);[...document.querySelectorAll(`button.btn-fix[data-id="${t.issueId}"]`),...document.querySelectorAll(`button.btn-suggest-fix[data-id="${t.issueId}"]`)].forEach(c=>{let p=c.closest(".issue");p&&!Array.from(s).includes(p)&&s.push(p)});let i=Array.from(new Set(Array.from(s)));if(i.length>0){let c=new Map;i.forEach(p=>{let d=p.closest(".issue-group");if(d){let S=d.getAttribute("data-issue-type");if(!c.has(S)){let f=d.querySelector(".badge");if(f){let m=parseInt(f.textContent)||0;c.set(S,{groupEl:d,badge:f,currentCount:m,removeCount:0})}}let h=c.get(S);h&&h.removeCount++}}),i.forEach(p=>{p.style.transition="opacity 0.3s ease-out",p.style.opacity="0",setTimeout(()=>{p.parentNode&&p.remove()},300)}),setTimeout(()=>{c.forEach(p=>{let d=Math.max(0,p.currentCount-p.removeCount);p.badge.textContent=d,d===0&&(p.groupEl.style.display="none")}),lt(),k&&k.issues&&We(k.issues,!1)},350)}else lt(),k&&k.issues&&We(k.issues,!1)}return}if(t&&t.type==="create-text-style-result"){re(t.issueId,t.message,t.success),t.success&&setTimeout(()=>{var s;let n=document.querySelector(`.issue[data-issue-id="${t.issueId}"]`)||((s=document.querySelector(`button.btn-create-style[data-id="${t.issueId}"]`))==null?void 0:s.closest(".issue"));n&&(n.style.transition="opacity 0.5s ease-out",n.style.opacity="0",setTimeout(()=>{if(n.parentNode){n.remove();let a=n.closest(".issue-group");if(a){let i=a.querySelector(".badge");if(i){let c=parseInt(i.textContent)||0,p=Math.max(0,c-1);i.textContent=p,p===0&&(a.style.display="none")}}}},500))},5e3);return}if(t&&t.type==="components-for-issue-loaded"){console.log("=== [components-for-issue-loaded] HANDLER CALLED ==="),console.log("[components-for-issue-loaded] Received message",t);let n=window.pendingComponentIssue;if(console.log("[components-for-issue-loaded] Pending issue:",n,"Message issueId:",t.issueId),console.log("[components-for-issue-loaded] Similar components:",t.similarComponents),n){let s=document.querySelector(`.issue[data-issue-id="${n.id}"]`);if(s){let a=s.querySelector("button.btn-suggest-fix");a&&(a.disabled=!1,a.style.opacity="1",a.style.cursor="pointer",a.dataset.originalText&&(a.textContent=a.dataset.originalText,delete a.dataset.originalText))}}if(t.similarComponents&&t.similarComponents.length>0){console.log("[components-for-issue-loaded] Showing suggest modal with",t.similarComponents.length,"similar components");let s=n||{id:t.issueId,nodeName:"Unnamed"};try{Bn(s,t.similarComponents),console.log("[components-for-issue-loaded] Modal function called successfully")}catch(a){console.error("[components-for-issue-loaded] Error showing modal:",a),alert("Error showing component suggestion modal: "+a.message)}window.pendingComponentIssue=null;return}else{console.warn("[components-for-issue-loaded] No similar components found"),alert("No similar components found. Please use 'Select Component' to choose from all components or 'Create New Component' to create a new one."),window.pendingComponentIssue=null;return}}if(t&&t.type==="all-components-loaded"){console.log("=== [all-components-loaded] HANDLER CALLED ==="),console.log("[all-components-loaded] Received message",t);let n=window.pendingSelectComponentIssue;if(console.log("[all-components-loaded] Pending issue:",n),console.log("[all-components-loaded] Message issueId:",t.issueId,typeof t.issueId),console.log("[all-components-loaded] Pending issueId:",n==null?void 0:n.id,typeof(n==null?void 0:n.id)),console.log("[all-components-loaded] Components:",t.components),console.log("[all-components-loaded] Components length:",t.components?t.components.length:0),n){let s=document.querySelector(`.issue[data-issue-id="${n.id}"]`);if(s){let a=s.querySelector("button.btn-select-component");a&&(a.disabled=!1,a.style.opacity="1",a.style.cursor="pointer",a.dataset.originalText&&(a.textContent=a.dataset.originalText,delete a.dataset.originalText))}}if(t.components&&t.components.length>0){console.log("[all-components-loaded] \u2713 Showing select modal with",t.components.length,"components");let s=n||{id:t.issueId,nodeName:"Unnamed"};console.log("[all-components-loaded] Issue to use:",s),console.log("[all-components-loaded] Calling showComponentSelectModal...");try{An(s,t.components),console.log("[all-components-loaded] \u2713 Modal function called successfully")}catch(a){console.error("[all-components-loaded] \u2717 Error showing modal:",a),console.error("[all-components-loaded] Error stack:",a.stack),alert("Error showing component selection modal: "+a.message)}window.pendingSelectComponentIssue=null;return}else{console.warn("[all-components-loaded] \u2717 No components available"),alert("No components found. Please use 'Create New Component' to create a new one."),window.pendingSelectComponentIssue=null;return}}if(t&&t.type==="figma-text-styles-loaded"){let n=window.pendingSuggestTextSizeIssue;if(n&&n.id===t.issueId){let p=n.fontSize||12,d=(t.styles||[]).filter(f=>f.fontSize>=14);if(d.length===0){let f=at(n);f?Nt(n,p,f,null,null):alert("No suitable text size match found (need >= 14px for ADA compliance). Please add font sizes to Font Size input or create text styles in Figma."),window.pendingSuggestTextSizeIssue=null;return}let S=null,h=1/0;d.forEach(f=>{let m=Math.abs(f.fontSize-p);m<h&&(h=m,S=f)}),S?Nt(n,p,S.fontSize,null,S):alert("No suitable text style found (need >= 14px for ADA compliance)"),window.pendingSuggestTextSizeIssue=null;return}let s=window.pendingTextSizeIssue;if(s&&s.id===t.issueId){Hn(s,t.styles||[]),window.pendingTextSizeIssue=null;return}let a=window.pendingTypographyStyleIssue;if(a&&a.id===t.issueId){if(t.error||!t.styles||t.styles.length===0){let p=document.querySelector(`.issue[data-issue-id="${t.issueId}"]`);if(p){let d=p.querySelector("button.btn-fix"),S=p.querySelector("button.btn-suggest-fix");d&&(d.style.display="none"),S&&(S.style.display="none")}window.pendingTypographyStyleIssue=null;return}bo(a,t.styles||[]),window.pendingTypographyStyleIssue=null;return}let i=window.pendingTypographyCheckIssue;if(i&&i.id===t.issueId){if(t.error||!t.styles||t.styles.length===0){let p=document.querySelector(`.issue[data-issue-id="${t.issueId}"]`);if(p){let d=p.querySelector("button.btn-style-dropdown"),S=p.querySelector("button.btn-suggest-fix");d&&(d.style.display="none"),S&&(S.style.display="none")}window.pendingTypographyCheckIssue=null;return}bo(i,t.styles||[]),window.pendingTypographyCheckIssue=null;return}let c=document.querySelector(`.style-dropdown-menu[data-issue-id="${t.issueId}"]`);if(c){let p=c.closest(".issue"),d=p?p.getAttribute("data-issue-id"):null,S=p?p.getAttribute("data-issue-type"):null;if(t.error){c.innerHTML=`<div style="padding: 8px 12px; color: #ef4444; font-size: 12px;">Error: ${u(t.error)}</div>`;let h=p?p.querySelector("button.btn-style-dropdown"):null;h&&(h.style.display="none");let f=p?p.querySelector("button.btn-suggest-fix"):null;f&&(S==="typography-style"||S==="typography-check")&&(f.style.display="none")}else if(t.styles&&t.styles.length>0){let h=null;if(d&&k&&k.issues){let f=k.issues.find(m=>m.id===d);f&&f.bestMatch&&(h=f.bestMatch.name)}c.innerHTML=t.styles.map(f=>`
            <div class="style-dropdown-item" data-issue-id="${t.issueId}" data-style-id="${f.id}" data-style-name="${u(f.name)}" style="padding: 8px 12px; cursor: pointer; font-size: 12px; ${h===f.name?"background: #e3f2fd; font-weight: 600;":""}" onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background='${h===f.name?"#e3f2fd":"white"}'">
              ${u(f.name)} ${h===f.name?"\u2B50":""}
            </div>
          `).join(""),c.querySelectorAll(".style-dropdown-item").forEach(f=>{f.onclick=m=>{m.preventDefault(),m.stopPropagation();try{let T=f.getAttribute("data-issue-id");T&&parent.postMessage({pluginMessage:{type:"select-node",id:T}},"*")}catch(T){console.error("Failed to auto-select node for style dropdown item:",T)}let g=f.getAttribute("data-style-id"),M=f.getAttribute("data-style-name");if(p&&k&&k.issues){let T=k.issues.find(A=>A.id===d);if(T){let A=t.styles.find(F=>F.id===g);A&&(c.style.display="none",$o(T,A))}}}})}else{c.innerHTML='<div style="padding: 8px 12px; color: #999; font-size: 12px;">No text styles found in Figma</div>';let h=p?p.querySelector("button.btn-style-dropdown"):null;h&&(h.style.display="none");let f=p?p.querySelector("button.btn-suggest-fix"):null;f&&(S==="typography-style"||S==="typography-check")&&(f.style.display="none")}}return}if(t&&t.type==="contrast-colors-loaded"){let n=window.pendingContrastIssue;n&&n.id===t.issueId&&(qn(n,t.colors||[]),window.pendingContrastIssue=null);return}if(t&&t.type==="apply-typography-style-result"){if(re(t.issueId,t.message,t.success),t.success||to(t.message||"An error occurred while applying the style."),t.success){let n=["typography-check","typography-style","typography"];k&&k.issues&&(k.issues=k.issues.filter(s=>!(String(s.id)===String(t.issueId)&&n.includes(s.type)))),window._batchFixInProgress||setTimeout(()=>{lt(),k&&k.issues&&We(k.issues,!1)},350)}return}if(t&&t.type==="bind-color-variable-result"){re(t.issueId,t.message,t.success),t.success&&(k&&k.issues&&(k.issues=k.issues.filter(n=>!(String(n.id)===String(t.issueId)&&n.type==="color-variable"))),window._batchFixInProgress||setTimeout(()=>{lt(),k&&k.issues&&We(k.issues,!1)},350));return}if(t&&t.type==="scan-progress"){w&&$&&(w.style.width=t.progress+"%",$.textContent=t.progress+"% ("+t.current+"/"+t.total+")");return}if(t&&t.type==="node-count-result"){let n=t.count||0,s=t.mode||"page";n>Oe?confirm(`\u26A0\uFE0F Large Design Warning

This ${s==="page"?"page":"selection"} contains ${n.toLocaleString()} nodes.

Scanning large designs may take a while and could slow down Figma.

Do you want to continue?`)&&Se?Mo(Se.scope):(v&&(v.disabled=!1,v.textContent="Scan Issues"),y&&(y.style.display="none")):Se&&Mo(Se.scope),Se=null;return}if(t&&t.type==="last-report"){t.report?hn(t.report):console.log("No last report stored");return}if(t&&t.type==="history-data"){Qn(t.history),Kn();let n=document.getElementById("history-panel");n&&n.style.display!=="none"&&Yt();return}if(t&&t.type==="input-values-data"){t.values?(Ut(t.values),console.log("Restored input values:",t.values)):console.log("No saved input values to restore");return}if(t&&t.type==="project-name"){let n=t.name||"settings";if(window.pendingExportValues){let s=window.pendingExportValues;window.pendingExportValues=null;let a={name:n,values:s,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()},i=JSON.stringify([a],null,2),c=new Blob([i],{type:"application/json"}),p=URL.createObjectURL(c),d=document.createElement("a");d.href=p;let S=n.replace(/[^a-z0-9]/gi,"_").toLowerCase();d.download=`${S}-settings.json`,document.body.appendChild(d),d.click(),document.body.removeChild(d),URL.revokeObjectURL(p),console.log("\u2705 Settings exported successfully");return}we&&(we.value=n);return}if(t&&t.type==="check-setting-name-result"){t.exists?(Vo&&ze&&(Vo.textContent=t.name||ze.name),Me&&(Me.style.display="flex")):ze&&(Yo(ze.name,ze.values),ze=null);return}if(t&&t.type==="save-settings-result"){t.success?(Me&&(Me.style.display="none"),qe&&(qe.style.display="none"),we&&(we.value=""),ze=null,Pe&&Pe.style.display!=="none"&&parent.postMessage({pluginMessage:{type:"get-saved-settings"}},"*")):(alert("\u274C Failed to save settings: "+(t.error||"Unknown error")),Me&&(Me.style.display="none"),ze=null);return}if(t&&t.type==="saved-settings-list"){Ko(t.settings||[]);return}if(t&&t.type==="project-name"){let n=t.name||"settings";if(window.pendingExportValues){let s=window.pendingExportValues;window.pendingExportValues=null;let a={name:n,values:s,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()},i=JSON.stringify([a],null,2),c=new Blob([i],{type:"application/json"}),p=URL.createObjectURL(c),d=document.createElement("a");d.href=p;let S=n.replace(/[^a-z0-9]/gi,"_").toLowerCase();d.download=`${S}-settings.json`,document.body.appendChild(d),d.click(),document.body.removeChild(d),URL.revokeObjectURL(p),console.log("\u2705 Settings exported successfully")}return}if(t&&t.type==="load-settings-result"){t.success&&t.values?(Ut(t.values),ve()):alert("\u274C Failed to load settings: "+(t.error||"Unknown error"));return}if(t&&t.type==="remove-settings-result"){t.success?Ko(t.settings||[]):alert("\u274C Failed to remove settings: "+(t.error||"Unknown error"));return}if(t&&t.type==="report"){v.style.display="block",v.disabled=!1,C.style.display="none",y.style.display="none",I.disabled=!1;let n=t.issues||[];k.context=t.context||null,We(n);let s=((o=document.querySelector('input[name="scope"]:checked'))==null?void 0:o.value)||"page";Do(s,"issues",{issues:n},t.context||null)}if(t&&t.type==="tokens-report")if(I.style.display="block",I.disabled=!1,C.style.display="none",y.style.display="none",v.disabled=!1,t.error)me.innerHTML=`<div class="error-message">Error: ${u(t.error)}</div>`,Le("tokens");else{k.context=t.context||null,It(t.tokens),R.disabled=!(t.tokens&&Array.isArray(t.tokens.spacing)&&t.tokens.spacing.length>0),_.disabled=!(t.tokens&&Array.isArray(t.tokens.colors)&&t.tokens.colors.length>0),L.disabled=!(t.tokens&&Array.isArray(t.tokens.fontSize)&&t.tokens.fontSize.length>0),U.disabled=!(t.tokens&&Array.isArray(t.tokens.lineHeight)&&t.tokens.lineHeight.length>0);let n=((l=document.querySelector('input[name="scope"]:checked'))==null?void 0:l.value)||"page";Do(n,"tokens",{tokens:t.tokens},t.context||null)}if(t&&t.type==="typography-styles-extracted")if(t.styles&&Array.isArray(t.styles)&&t.styles.length>0){let n=t.mode==="desktop"?"Desktop":t.mode==="tablet"?"Tablet":t.mode==="mobile"?"Mobile":"All";Q=t.styles.map((s,a)=>({id:a+1,name:s.name,styleId:s.styleId,fontFamily:s.fontFamily,fontSize:s.fontSize,fontWeight:s.fontWeight,lineHeight:s.lineHeight,letterSpacing:s.letterSpacing||"0",wordSpacing:s.wordSpacing||"0"})),nt=Q.length+1,X(),Ge(),ve(),alert(`\u2705 Successfully imported ${t.styles.length} ${n} typography styles from Figma!

Styles: ${t.styles.map(s=>s.name).join(", ")}`)}else{let n=t.mode==="desktop"?"Desktop":t.mode==="tablet"?"Tablet":t.mode==="mobile"?"Mobile":"";alert(`\u26A0\uFE0F No ${n.toLowerCase()} text styles found in this Figma file.

Make sure you have defined text styles in your design system.`)}if(t&&t.type==="color-styles-extracted")if(t.colors&&Array.isArray(t.colors)&&t.colors.length>0){let n=document.getElementById("color-scale");if(!n)return;let a=Array.from(new Set(t.colors.map(i=>i.hex))).sort((i,c)=>dt(i)-dt(c));J={},t.colors.forEach(i=>{i.hex&&i.name&&(J[i.hex.toUpperCase()]=i.name)}),n.value=a.join(", "),typeof He=="function"&&He(),ve();try{n.focus(),n.setSelectionRange(n.value.length,n.value.length)}catch(i){}alert(`\u2705 Successfully imported ${t.colors.length} color styles from Figma!

Colors: ${t.colors.map(i=>i.name+" ("+i.hex+")").join(", ")}`)}else alert(`\u26A0\uFE0F No color styles found in this Figma file.

Make sure you have defined color styles (paint styles) in your design system.`);if(t&&t.type==="color-variables-extracted")if(t.colors&&Array.isArray(t.colors)&&t.colors.length>0){let n=document.getElementById("color-scale");if(!n)return;let a=Array.from(new Set(t.colors.map(i=>i.hex))).sort((i,c)=>dt(i)-dt(c));J={},t.colors.forEach(i=>{i.hex&&i.name&&(J[i.hex.toUpperCase()]=i.name)}),n.value=a.join(", "),typeof He=="function"&&He(),ve();try{n.focus(),n.setSelectionRange(n.value.length,n.value.length)}catch(i){}alert(`\u2705 Successfully imported ${t.colors.length} color variables from Figma!

Colors: ${t.colors.map(i=>i.name+" ("+i.hex+")").join(", ")}`)}else alert(`\u26A0\uFE0F No color variables found in this Figma file.

Make sure you have defined color variables in your design system.`)}})();})();
