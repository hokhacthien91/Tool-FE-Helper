(()=>{var Ln=Object.defineProperty,Hn=Object.defineProperties;var qn=Object.getOwnPropertyDescriptors;var Uo=Object.getOwnPropertySymbols;var Pn=Object.prototype.hasOwnProperty,Rn=Object.prototype.propertyIsEnumerable;var jo=(h,I,f)=>I in h?Ln(h,I,{enumerable:!0,configurable:!0,writable:!0,value:f}):h[I]=f,Je=(h,I)=>{for(var f in I||(I={}))Pn.call(I,f)&&jo(h,f,I[f]);if(Uo)for(var f of Uo(I))Rn.call(I,f)&&jo(h,f,I[f]);return h},it=(h,I)=>Hn(h,qn(I));function Oo(){function h(I){try{let f=I.target&&I.target.closest?I.target.closest("button"):null;if(!f)return;let C=f.closest?f.closest(".issue"):null;if(!C||!(f.closest&&f.closest(".issue-actions")))return;let v=f.getAttribute("data-id")||C.getAttribute("data-issue-id");if(!v)return;parent.postMessage({pluginMessage:{type:"select-node",id:v}},"*")}catch(f){console.error("autoSelectNodeFromIssueClick error:",f)}}document.addEventListener("click",h,!0)}function X(h,I,f){if(!I)return;let C=document.querySelector(`.issue[data-issue-id="${h}"]`);if(!C){let q=document.querySelector(`button.btn-fix[data-id="${h}"]`);q&&(C=q.closest(".issue"))}if(!C)return;let $=C.querySelector(".fix-message");$&&$.remove();let v=document.createElement("div");v.className="fix-message",v.style.cssText=`
      margin-top: 8px;
      padding: 8px 12px;
      border-radius: 6px;
      font-size: 12px;
      font-weight: 500;
      background: ${f?"#d4edda":"#f8d7da"};
      color: ${f?"#155724":"#721c24"};
      border: 1px solid ${f?"#c3e6cb":"#f5c6cb"};
      animation: slideIn 0.3s ease-out;
    `,v.textContent=I;let M=C.querySelector(".issue-header");M?M.parentNode.insertBefore(v,M.nextSibling):C.appendChild(v),setTimeout(()=>{v.style.animation="slideOut 0.3s ease-out",setTimeout(()=>{v.parentNode&&v.remove()},300)},5e3)}function d(h){return h==null?"":String(h).replace(/[&<>"']/g,function(f){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[f]})}function Wt(h){console.log("[showErrorModal] Called with message:",h);let I=document.getElementById("error-modal-overlay");I&&(console.log("[showErrorModal] Removing existing modal"),I.remove());let f=document.createElement("div");f.className="modal-overlay",f.id="error-modal-overlay",console.log("[showErrorModal] Created overlay element");let C=document.createElement("div");C.className="modal-dialog",C.style.maxWidth="450px";let $=String(h||"").replace(/^[❌⚠️✅]\s*/,"").trim();C.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title" style="color: #dc3545;">\u26A0\uFE0F Error</h2>
      </div>
      <div class="modal-body">
        <div style="padding: 16px; background: #f8d7da; border: 1px solid #f5c6cb; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 14px; color: #721c24; line-height: 1.6;">
            ${d($)}
          </div>
        </div>
        <div style="font-size: 12px; color: #666; line-height: 1.5;">
          Please check the issue and try again. If the problem persists, you may need to switch to Design Mode or edit the main component directly.
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-primary" id="error-modal-ok-btn" style="background: #dc3545; border-color: #dc3545; color: white;">OK</button>
      </div>
    `,f.appendChild(C),document.body.appendChild(f),console.log("[showErrorModal] Appended overlay to body, overlay visible:",f.offsetParent!==null),f.style.display="flex",f.style.visibility="visible",f.style.opacity="1";let v=C.querySelector("#error-modal-ok-btn"),M=C.querySelector(".modal-close");if(console.log("[showErrorModal] Found buttons:",{okBtn:!!v,closeBtn:!!M}),!v){console.error("[showErrorModal] OK button not found!");return}let q=()=>{f.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{f.parentNode&&f.remove()},200)};v.onclick=q,M&&(M.onclick=q),f.onclick=R=>{R.target===f&&q()},setTimeout(()=>{v.focus()},100),console.log("[showErrorModal] Modal setup complete")}function Ye(h){if(!h)return 0;let I=String(h).replace("#","");if(I.length<6)return 0;let f=parseInt(I.substring(0,2),16),C=parseInt(I.substring(2,4),16),$=parseInt(I.substring(4,6),16);return isNaN(f)||isNaN(C)||isNaN($)?0:(f*299+C*587+$*114)/1e3}function Et(h,I){let f=String(h||"").replace("#",""),C=String(I||"").replace("#","");if(f.length<6||C.length<6)return 1/0;let $=parseInt(f.substring(0,2),16),v=parseInt(f.substring(2,4),16),M=parseInt(f.substring(4,6),16),q=parseInt(C.substring(0,2),16),R=parseInt(C.substring(2,4),16),F=parseInt(C.substring(4,6),16);if([$,v,M,q,R,F].some(P=>isNaN(P)))return 1/0;let T=q-$,L=R-v,N=F-M;return Math.sqrt(T*T+L*L+N*N)}function Vo(h){let I=String(h||"").replace("#","");if(I.length<6)return 0;let f=parseInt(I.substring(0,2),16)/255,C=parseInt(I.substring(2,4),16)/255,$=parseInt(I.substring(4,6),16)/255;if(isNaN(f)||isNaN(C)||isNaN($))return 0;let v=f<=.03928?f/12.92:Math.pow((f+.055)/1.055,2.4),M=C<=.03928?C/12.92:Math.pow((C+.055)/1.055,2.4),q=$<=.03928?$/12.92:Math.pow(($+.055)/1.055,2.4);return .2126*v+.7152*M+.0722*q}function Mt(h,I){let f=Vo(h),C=Vo(I),$=Math.max(f,C),v=Math.min(f,C);return($+.05)/(v+.05)}function at(h){if(!h||!h.message)return null;let f=(h.message||"").match(/Color (#[0-9A-Fa-f]{6})/),C=f?f[1].toUpperCase():null;if(!C)return null;let $=document.getElementById("color-scale");if(!$||!$.value.trim())return null;let v=$.value.split(",").map(R=>R.trim().toUpperCase()).filter(R=>R&&R.startsWith("#"));if(v.length===0)return null;let M=null,q=1/0;return v.forEach(R=>{let F=Et(C,R);F<q&&(q=F,M=R)}),q>100?null:M}function rt(h){if(!h||!h.message)return null;let f=(h.message||"").match(/\((\d+)px\)/);if(!f)return null;let C=parseInt(f[1],10);if(isNaN(C))return null;let $=document.getElementById("spacing-scale");if(!$||!$.value.trim())return null;let v=$.value.split(",").map(F=>parseInt(F.trim(),10)).filter(F=>!isNaN(F)&&F>=0).sort((F,T)=>F-T);if(v.length===0)return null;let M=null,q=1/0;v.forEach(F=>{let T=Math.abs(F-C);T<q&&(q=T,M=F)});let R=Math.max(C*.2,10);return q>R?null:M}function Wn(h,I){if(!h||h.length===0){alert("No typography styles available. Please add styles in Typography Settings.");return}let f=document.createElement("div");f.className="modal-overlay",f.style.zIndex="10001";let C=document.createElement("div");C.className="modal-dialog",C.style.maxWidth="300px",C.style.padding="0",C.innerHTML=`
      <div class="modal-header" style="padding: 16px;">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title" style="font-size: 14px;">Choose Typography Style</h2>
      </div>
      <div style="max-height: 300px; overflow-y: auto;">
        ${h.map(v=>{let M=d(v.name||""),q=d(v.fontFamily||""),R=d(v.fontSize||""),F=d(v.fontWeight||"");return`
          <div class="style-dropdown-item" data-style-id="${v.id}" style="padding: 12px 16px; cursor: pointer; font-size: 13px; border-bottom: 1px solid #f0f0f0;" onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background='white'">
            <div style="font-weight: 600; color: #333;">${M}</div>
            <div style="font-size: 11px; color: #666; margin-top: 4px;">
              ${q} ${R}px ${F}
            </div>
          </div>
        `}).join("")}
      </div>
    `,f.appendChild(C),document.body.appendChild(f);let $=()=>{f.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{f.parentNode&&f.remove()},200)};C.querySelector(".modal-close").onclick=$,f.onclick=v=>{v.target===f&&$()},C.querySelectorAll(".style-dropdown-item").forEach(v=>{v.onclick=M=>{M.preventDefault(),M.stopPropagation();let q=parseInt(v.getAttribute("data-style-id"),10),R=h.find(F=>F.id===q);R&&I&&(I(R),$())}})}function Go(h,I){if(!h||!h.bestMatch){console.error("showTypographyFixModal: missing issue or bestMatch");return}let f=h.nodeProps||{},C=h.bestMatch,$=f.fontFamily||"",v=f.fontSize!==null&&f.fontSize!==void 0?f.fontSize:"",M=f.fontWeight||"",q=f.lineHeight||"",R=f.letterSpacing!==null&&f.letterSpacing!==void 0?f.letterSpacing:"",F=$,T=v,L=M,N=q,P=R;C.differences&&C.differences.forEach(B=>{B.property==="Font Family"&&B.expected?F=B.expected:B.property==="Font Size"&&B.expected?T=B.expected.replace("px",""):B.property==="Font Weight"&&B.expected?L=B.expected:B.property==="Line Height"&&B.expected?N=B.expected:B.property==="Letter Spacing"&&B.expected&&(P=B.expected)});let J=document.createElement("div");J.className="modal-overlay",J.id="typography-fix-modal-overlay";let V=document.createElement("div");V.className="modal-dialog",V.style.maxWidth="500px",V.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Fix Typography Style</h2>
        <p class="modal-subtitle">Node: ${d(h.nodeName||"Unnamed")} \u2192 Suggested: ${d(C.name)}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">
            Edit values below and click Apply to fix:
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Font Family</label>
            <input type="text" class="modal-input" id="fix-font-family" value="${d(F)}" style="width: 100%;" />
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Font Size (px)</label>
            <input type="number" class="modal-input" id="fix-font-size" value="${d(T)}" style="width: 100%;" />
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Font Weight</label>
            <select class="modal-input" id="fix-font-weight" style="width: 100%;">
              <option value="Regular" ${L==="Regular"?"selected":""}>Regular</option>
              <option value="Medium" ${L==="Medium"?"selected":""}>Medium</option>
              <option value="SemiBold" ${L==="SemiBold"||L==="Semi Bold"?"selected":""}>SemiBold</option>
              <option value="Bold" ${L==="Bold"?"selected":""}>Bold</option>
            </select>
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Line Height (% or px or auto)</label>
            <input type="text" class="modal-input" id="fix-line-height" value="${d(N)}" style="width: 100%;" placeholder="e.g. 120%, 24px, auto" />
          </div>

          <div style="margin-bottom: 12px;">
            <label style="display: block; font-size: 12px; font-weight: 600; color: #333; margin-bottom: 4px;">Letter Spacing (px or %)</label>
            <input type="text" class="modal-input" id="fix-letter-spacing" value="${d(P)}" style="width: 100%;" placeholder="e.g. 0, 0.5px, 1%" />
          </div>

          <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #eee;">
            <button class="modal-btn modal-btn-cancel" id="choose-typo-style-btn" style="width: 100%; margin-bottom: 8px; background: #0071e3; border-color: #0071e3; color: white;">
              Choose Typography Style
            </button>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="typography-fix-modal-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="typography-fix-modal-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,J.appendChild(V),document.body.appendChild(J);let he=V.querySelector("#fix-font-family"),se=V.querySelector("#fix-font-size"),te=V.querySelector("#fix-font-weight"),j=V.querySelector("#fix-line-height"),O=V.querySelector("#fix-letter-spacing"),z=V.querySelector("#choose-typo-style-btn"),K=V.querySelector("#typography-fix-modal-cancel-btn"),W=V.querySelector("#typography-fix-modal-apply-btn"),Q=V.querySelector(".modal-close");setTimeout(()=>{he.focus()},100);let k=()=>{J.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{J.parentNode&&J.remove()},200)};K.onclick=k,Q.onclick=k,J.onclick=B=>{B.target===J&&k()},z.onclick=()=>{Wn(I,B=>{B&&(he.value=B.fontFamily||"",se.value=B.fontSize||"",te.value=B.fontWeight||"Regular",j.value=B.lineHeight||"",O.value=B.letterSpacing||"0")})},W.onclick=()=>{let B={fontFamily:he.value.trim(),fontSize:se.value.trim(),fontWeight:te.value,lineHeight:j.value.trim(),letterSpacing:O.value.trim()};if(!B.fontFamily){he.focus(),he.style.borderColor="#ff3b30",setTimeout(()=>{he.style.borderColor="#0071e3"},2e3);return}if(!B.fontSize||isNaN(parseFloat(B.fontSize))){se.focus(),se.style.borderColor="#ff3b30",setTimeout(()=>{se.style.borderColor="#0071e3"},2e3);return}k(),X(h.id,"\u23F3 Fixing...",!0),parent.postMessage({pluginMessage:{type:"fix-issue",issue:h,fixData:B}},"*")}}function Jo(h,I,f,C){let $=document.createElement("div");$.className="modal-overlay",$.id="spacing-picker-modal-overlay";let v=document.createElement("div");v.className="modal-dialog",v.style.maxWidth="400px";let M=C.map(N=>`
        <div class="spacing-picker-item" data-value="${N}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 2px solid ${f===N?"#0071e3":"#ddd"};
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='${f===N?"#0071e3":"#ddd"}'; this.style.boxShadow='none'">
          <div style="display: flex; align-items: center; gap: 12px;">
            <div style="
              width: 40px;
              height: 40px;
              border-radius: 4px;
              background: #f0f0f0;
              border: 1px solid #ddd;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 12px;
              font-weight: 600;
              color: #666;
            ">${N}px</div>
            <div style="font-weight: 600; font-size: 14px; color: #333;">
              ${N}px
            </div>
          </div>
          ${f===N?'<div style="color: #0071e3; font-weight: 600;">Current</div>':""}
        </div>
      `).join(""),q=String(I||"").replace(/([A-Z])/g," $1").replace(/^./,N=>N.toUpperCase()).trim();v.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Spacing Value</h2>
        <p class="modal-subtitle">Node: ${d(h.nodeName||"Unnamed")} - ${d(q)}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Value:</div>
          <div style="font-size: 16px; font-weight: 600; color: #333;">${f}px</div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${M}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="spacing-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,$.appendChild(v),document.body.appendChild($);let R=v.querySelector("#spacing-picker-modal-cancel-btn"),F=v.querySelector(".modal-close"),T=v.querySelectorAll(".spacing-picker-item"),L=()=>{$.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{$.parentNode&&$.remove()},200)};R.onclick=L,F.onclick=L,$.onclick=N=>{N.target===$&&L()},T.forEach(N=>{N.onclick=P=>{P.preventDefault(),P.stopPropagation();let J=parseInt(N.getAttribute("data-value"),10);L(),Dt(h,I,f,J)}})}function Dt(h,I,f,C){let $=String(I||"").replace(/([A-Z])/g," $1").replace(/^./,L=>L.toUpperCase()).trim(),v=document.createElement("div");v.className="modal-overlay",v.id="spacing-fix-confirm-modal-overlay";let M=document.createElement("div");M.className="modal-dialog",M.style.maxWidth="400px",M.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Spacing Change</h2>
        <p class="modal-subtitle">Node: ${d(h.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Change ${d($)} from:</div>
          <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="
              width: 50px;
              height: 50px;
              border-radius: 6px;
              background: #f0f0f0;
              border: 2px solid #ddd;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 14px;
              font-weight: 600;
              color: #333;
            ">${f}px</div>
            <div>
              <div style="font-weight: 600; font-size: 16px; color: #333;">${f}px</div>
            </div>
          </div>
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">To:</div>
          <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="
              width: 50px;
              height: 50px;
              border-radius: 6px;
              background: #e3f2fd;
              border: 2px solid #0071e3;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 14px;
              font-weight: 600;
              color: #0071e3;
            ">${C}px</div>
            <div>
              <div style="font-weight: 600; font-size: 16px; color: #333;">${C}px</div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="spacing-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="spacing-fix-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,v.appendChild(M),document.body.appendChild(v);let q=M.querySelector("#spacing-fix-confirm-cancel-btn"),R=M.querySelector("#spacing-fix-confirm-apply-btn"),F=M.querySelector(".modal-close"),T=()=>{v.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{v.parentNode&&v.remove()},200)};q.onclick=T,F.onclick=T,v.onclick=L=>{L.target===v&&T()},R.onclick=()=>{T(),X(h.id,"\u23F3 Fixing spacing...",!0),parent.postMessage({pluginMessage:{type:"fix-spacing-issue",issue:h,propertyName:I,value:C}},"*")}}function ct(h){try{let I=parseInt(h.slice(1,3),16),f=parseInt(h.slice(3,5),16),C=parseInt(h.slice(5,7),16);return(I*299+f*587+C*114)/1e3>128?"#000000":"#ffffff"}catch(I){return"#000000"}}function Ut(h,I,f,C="",$=""){return ct(h),`
      <div class="color-picker-item" data-color="${d(h)}" style="
        padding: 12px;
        margin-bottom: 8px;
        border: 2px solid ${f};
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 12px;
        background: white;
        transition: all 0.2s;
      " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='${f}'; this.style.boxShadow='none'">
        <div style="
          width: 48px;
          height: 48px;
          border-radius: 6px;
          background: ${d(h)};
          border: 2px solid #ddd;
          flex-shrink: 0;
        "></div>
        <div style="flex: 1;">
          <div style="font-weight: 600; font-size: 14px; color: #333; margin-bottom: 4px;">
            ${I||d(h)}
          </div>
          <div style="font-size: 12px; color: #666; font-family: 'SF Mono', Monaco, monospace;">
            ${d(h)}
          </div>
          ${C?`<div style="font-size: 11px; color: #666; margin-top: 4px;">${C}</div>`:""}
        </div>
        ${$?`<div style="color: #0071e3; font-weight: 600; margin-left: auto;">${$}</div>`:""}
      </div>
    `}function Yo(h,I,f,C={}){if(!I){let N=(h.message||"").match(/Color (#[0-9A-Fa-f]{6})/);I=N?N[1].toUpperCase():null}if(!I){alert("Cannot determine current color from issue message");return}let $=document.createElement("div");$.className="modal-overlay",$.id="color-picker-modal-overlay";let v=document.createElement("div");v.className="modal-dialog",v.style.maxWidth="400px";let M=f.map(L=>{let N=C[L]||"";return Ut(L,N||L,I===L?"#0071e3":"#ddd","",I===L?"Current":"")}).join("");v.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Color</h2>
        <p class="modal-subtitle">Node: ${d(h.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Color:</div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 32px; height: 32px; border-radius: 4px; background: ${d(I)}; border: 1px solid #ddd;"></div>
            <div style="font-family: 'SF Mono', Monaco, monospace; font-size: 13px; font-weight: 600;">${d(I)}</div>
          </div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${M}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="color-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,$.appendChild(v),document.body.appendChild($);let q=v.querySelector("#color-picker-modal-cancel-btn"),R=v.querySelector(".modal-close"),F=v.querySelectorAll(".color-picker-item"),T=()=>{$.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{$.parentNode&&$.remove()},200)};q.onclick=T,R.onclick=T,$.onclick=L=>{L.target===$&&T()},F.forEach(L=>{L.onclick=N=>{N.preventDefault(),N.stopPropagation();let P=L.getAttribute("data-color");T(),jt(h,I,P,C)}})}function jt(h,I,f,C={}){let $=C[f]||f,v=document.createElement("div");v.className="modal-overlay",v.id="color-fix-confirm-modal-overlay";let M=document.createElement("div");M.className="modal-dialog",M.style.maxWidth="400px",M.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Color Change</h2>
        <p class="modal-subtitle">Node: ${d(h.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Change color from:</div>
          <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="width: 48px; height: 48px; border-radius: 6px; background: ${d(I)}; border: 2px solid #ddd;"></div>
            <div>
              <div style="font-weight: 600; font-size: 14px; color: #333;">${d(I)}</div>
            </div>
          </div>
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">To:</div>
          <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="width: 48px; height: 48px; border-radius: 6px; background: ${d(f)}; border: 2px solid #0071e3;"></div>
            <div>
              <div style="font-weight: 600; font-size: 14px; color: #333;">${d($)}</div>
              <div style="font-size: 12px; color: #666; font-family: 'SF Mono', Monaco, monospace;">${d(f)}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="color-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="color-fix-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,v.appendChild(M),document.body.appendChild(v);let q=M.querySelector("#color-fix-confirm-cancel-btn"),R=M.querySelector("#color-fix-confirm-apply-btn"),F=M.querySelector(".modal-close"),T=()=>{v.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{v.parentNode&&v.remove()},200)};q.onclick=T,F.onclick=T,v.onclick=L=>{L.target===v&&T()},R.onclick=()=>{T(),X(h.id,"\u23F3 Fixing color...",!0),parent.postMessage({pluginMessage:{type:"fix-color-issue",issue:h,color:f}},"*")}}function Ot({reportData:h,getTypeDisplayName:I}){let f=h||{},C=f.issues||[],$=f.tokens||null,v=f.timestamp||Date.now(),M=new Date(v).toLocaleString("vi-VN"),q="Design Review",R=T=>{try{return typeof I=="function"?I(T):String(T||"")}catch(L){return String(T||"")}},F=`<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Design Review Report - ${M}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      line-height: 1.6;
      color: #1d1d1f;
      background: #f5f5f7;
      padding: 40px 20px;
    }
    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
      padding: 40px;
    }
    .header {
      border-bottom: 2px solid #e5e5e7;
      padding-bottom: 20px;
      margin-bottom: 30px;
    }
    .header h1 {
      font-size: 28px;
      color: #1d1d1f;
      margin-bottom: 8px;
    }
    .header .meta {
      color: #86868b;
      font-size: 14px;
    }
    .section {
      margin-bottom: 40px;
    }
    .section-title {
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 16px;
      color: #1d1d1f;
      padding-bottom: 8px;
      border-bottom: 1px solid #e5e5e7;
    }
    .export-filter-group {
      display: flex;
      gap: 8px;
      margin-bottom: 16px;
    }
    .export-filter-btn {
      padding: 4px 10px;
      font-size: 12px;
      border-radius: 999px;
      border: 1px solid #e5e7eb;
      background: #f9fafb;
      cursor: pointer;
    }
    .export-filter-btn.active {
      background: #111827;
      color: #fff;
      border-color: #111827;
    }
    .stats {
      display: flex;
      gap: 16px;
      margin-bottom: 24px;
      flex-wrap: wrap;
    }
    .stat-card {
      padding: 16px 20px;
      border-radius: 8px;
      background: #f5f5f7;
      min-width: 120px;
    }
    .stat-card.error { background: #fee; color: #c33; }
    .stat-card.warn { background: #fff4e6; color: #d97706; }
    .stat-card .value {
      font-size: 32px;
      font-weight: 700;
      margin-bottom: 4px;
    }
    .stat-card .label {
      font-size: 12px;
      text-transform: uppercase;
      opacity: 0.8;
    }
    .issue-group {
      margin-bottom: 24px;
      border: 1px solid #e5e7eb;
      border-radius: 10px;
      padding: 16px;
      background: #fff;
    }
    .issue-group-header {
      font-size: 16px;
      font-weight: 600;
      color: #1d1d1f;
      display: flex;
      align-items: center;
      gap: 8px;
      cursor: pointer;
      user-select: none;
    }
    .issue-group-toggle {
      border: none;
      background: #f3f4f6;
      width: 24px;
      height: 24px;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
    }
    .issue-group-content {
      margin-top: 12px;
    }
    .issue-group.collapsed .issue-group-content {
      display: none;
    }
    .issue {
      padding: 12px 16px;
      margin-bottom: 8px;
      border-radius: 6px;
      border-left: 4px solid;
    }
    .issue.error {
      background: #fef2f2;
      border-left-color: #ef4444;
    }
    .issue.warn {
      background: #fffbeb;
      border-left-color: #f59e0b;
    }
    .issue-type {
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      margin-bottom: 4px;
    }
    .issue-message {
      font-size: 14px;
      margin-bottom: 4px;
    }
    .issue-node {
      font-size: 12px;
      color: #86868b;
      font-family: monospace;
      margin-top: 4px;
    }
    .token-list {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 12px;
    }
    .token-item {
      padding: 12px;
      background: #fafafa;
      border-radius: 6px;
      border: 1px solid #e5e5e7;
    }
    .token-value {
      font-family: monospace;
      font-size: 13px;
      margin-bottom: 4px;
    }
    .token-color-preview {
      display: inline-block;
      width: 24px;
      height: 24px;
      border-radius: 4px;
      border: 1px solid #d1d1d6;
      vertical-align: middle;
      margin-right: 8px;
    }
    .token-color-type {
      display: inline-block;
      font-size: 10px;
      padding: 2px 6px;
      background: #667eea;
      color: white;
      border-radius: 4px;
      margin-left: 6px;
    }
    .token-node-count {
      font-size: 11px;
      color: #86868b;
      margin-top: 4px;
    }
    .token-empty-message {
      padding: 12px;
      font-size: 12px;
      color: #9ca3af;
      font-style: italic;
    }
    @media print {
      body { padding: 20px; }
      .container { box-shadow: none; }
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>\u{1F3A8} Design Review Report</h1>
      <div class="meta">Generated: ${M} | Page: ${q}</div>
    </div>`;if(C&&C.length>0){let T={error:C.filter(N=>N.severity==="error").length,warn:C.filter(N=>N.severity==="warn").length,total:C.length},L=C.reduce((N,P)=>(N[P.type]=N[P.type]||[],N[P.type].push(P),N),{});F+=`
    <div class="section">
      <h2 class="section-title">\u{1F4CA} Summary</h2>
      <div class="stats">
        ${T.error>0?`<div class="stat-card error"><div class="value">${T.error}</div><div class="label">Errors</div></div>`:""}
        ${T.warn>0?`<div class="stat-card warn"><div class="value">${T.warn}</div><div class="label">Warnings</div></div>`:""}
        <div class="stat-card"><div class="value">${T.total}</div><div class="label">Total Issues</div></div>
      </div>
    </div>

    <div class="section">
      <h2 class="section-title">\u{1F50D} Issues</h2>
      <div class="export-filter-group">
        <button class="export-filter-btn active" data-severity="all">All</button>
        <button class="export-filter-btn" data-severity="error">Errors</button>
        <button class="export-filter-btn" data-severity="warn">Warnings</button>
      </div>`;for(let[N,P]of Object.entries(L)){let J=d(R(N));F+=`
      <div class="issue-group collapsed" data-type="${N}" data-label="${J}">
        <div class="issue-group-header">
          <button class="issue-group-toggle" type="button">+</button>
          <span>${J} (${P.length})</span>
        </div>
        <div class="issue-group-content">`,P.forEach(V=>{F+=`
          <div class="issue ${V.severity}">
            <div class="issue-type">${String(V.severity||"").toUpperCase()}</div>
            <div class="issue-message">${d(V.message)}</div>
            ${V.nodeName?`<div class="issue-node">Node: ${d(V.nodeName)}</div>`:""}
          </div>`}),F+=`
        </div>
      </div>`}F+=`
    </div>`}if($){F+=`
    <div class="section">
      <h2 class="section-title">\u{1F3A8} Design Tokens</h2>`;let T={colors:{label:"Colors",values:$.colors||[]},gradients:{label:"Gradients",values:$.gradients||[]},borderRadius:{label:"Border Radius",values:$.borderRadius||[]},fontWeight:{label:"Font Weight",values:$.fontWeight||[]},lineHeight:{label:"Line Height (%)",values:$.lineHeight||[]},fontSize:{label:"Font Size",values:$.fontSize||[]},fontFamily:{label:"Font Family",values:$.fontFamily||[]}};for(let[L,N]of Object.entries(T)){if(F+=`
      <div class="issue-group collapsed">
        <div class="issue-group-header">
          <button class="issue-group-toggle" type="button">+</button>
          <span>${N.label} (${N.values.length})</span>
        </div>
        <div class="issue-group-content">`,!N.values||N.values.length===0){F+=`
          <div class="token-empty-message">No tokens in this group.</div>`,F+=`
        </div>
      </div>`;continue}F+=`
          <div class="token-list">`,N.values.forEach(P=>{let J=P.value,V=typeof P.totalNodes=="number"?P.totalNodes:P.nodes?P.nodes.length:0,he=P.colorType||"";if(L==="colors")F+=`
          <div class="token-item">
            <div class="token-value">
              <span class="token-color-preview" style="background-color: ${d(J)}"></span>
              ${d(J)}
              ${he?`<span class="token-color-type">${d(he)}</span>`:""}
            </div>
            ${V>1?`<div class="token-node-count">Used in ${V} nodes</div>`:""}
          </div>`;else if(L==="gradients")F+=`
          <div class="token-item">
            <div class="token-value">
              <span class="token-color-preview" style="background: ${d(J)}"></span>
              ${d(J)}
              ${he?`<span class="token-color-type">${d(he)}</span>`:""}
            </div>
            ${V>1?`<div class="token-node-count">Used in ${V} nodes</div>`:""}
          </div>`;else{let se="";if(L==="fontWeight"){let te=Array.isArray(P.fontFamilies)?P.fontFamilies:null;if(!te){let j={};(Array.isArray(P.nodes)?P.nodes:[]).forEach(z=>{let K=z&&z.fontFamily?String(z.fontFamily):"Unknown";j[K]=(j[K]||0)+1}),te=Object.entries(j).map(([z,K])=>({family:z,count:K})).sort((z,K)=>K.count-z.count||z.family.localeCompare(K.family))}Array.isArray(te)&&te.length>0&&(se=`<div class="token-node-count" style="margin-top: 6px;">Font-family:<br/>${te.map(O=>`${d(O.family)} (${O.count})`).join("<br/>")}</div>`)}F+=`
          <div class="token-item">
            <div class="token-value">${d(String(J))}</div>
            ${V>1?`<div class="token-node-count">Used in ${V} nodes</div>`:""}
            ${se}
          </div>`}}),F+=`
          </div>
        </div>
      </div>`}F+=`
    </div>`}return F+=`
  </div>
  <script>
    (function() {
      function updateGroupState(group, content, toggleBtn) {
        const collapsed = group.classList.contains('collapsed');
        if (collapsed) {
          content.style.display = 'none';
          if (toggleBtn) toggleBtn.textContent = '+';
        } else {
          content.style.display = 'block';
          if (toggleBtn) toggleBtn.textContent = '\u2212';
        }
      }

      function initCollapsibles() {
        document.querySelectorAll('.issue-group').forEach(group => {
          const header = group.querySelector('.issue-group-header');
          const content = group.querySelector('.issue-group-content');
          const toggleBtn = group.querySelector('.issue-group-toggle');
          if (!content || !header) return;

          const toggle = () => {
            group.classList.toggle('collapsed');
            updateGroupState(group, content, toggleBtn);
          };

          if (toggleBtn) {
            toggleBtn.addEventListener('click', e => {
              e.stopPropagation();
              toggle();
            });
          }

          header.addEventListener('click', e => {
            if (toggleBtn && (e.target === toggleBtn || toggleBtn.contains(e.target))) {
              return;
            }
            toggle();
          });

          updateGroupState(group, content, toggleBtn);
        });
      }

      function applySeverityFilter(filter) {
        const buttons = document.querySelectorAll('.export-filter-btn');
        buttons.forEach(btn => {
          const val = btn.getAttribute('data-severity') || 'all';
          btn.classList.toggle('active', val === filter);
        });

        document.querySelectorAll('.issue-group').forEach(group => {
          const issues = group.querySelectorAll('.issue');
          const label = group.getAttribute('data-label') || '';
          let visibleCount = 0;

          issues.forEach(issue => {
            const isError = issue.classList.contains('error');
            const isWarn = issue.classList.contains('warn');
            let show = false;
            if (filter === 'all') show = true;
            else if (filter === 'error') show = isError;
            else if (filter === 'warn') show = isWarn;
            issue.style.display = show ? '' : 'none';
            if (show) visibleCount++;
          });

          const headerCountSpan = group.querySelector('.issue-group-header span:last-child');
          if (headerCountSpan && label) {
            headerCountSpan.textContent = label + ' (' + visibleCount + ')';
          }
        });
      }

      function initExportFilters() {
        const buttons = document.querySelectorAll('.export-filter-btn');
        if (!buttons.length) return;
        let current = 'all';

        buttons.forEach(btn => {
          btn.addEventListener('click', () => {
            const val = btn.getAttribute('data-severity') || 'all';
            current = val;
            applySeverityFilter(current);
          });
        });

        // Initial apply
        applySeverityFilter(current);
      }

      function initExportUI() {
        initCollapsibles();
        initExportFilters();
      }

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initExportUI);
      } else {
        initExportUI();
      }
    })();
  <\/script>
</body>
</html>`,F}function Dn(){let h=new Date,I=h.getFullYear(),f=String(h.getMonth()+1).padStart(2,"0"),C=String(h.getDate()).padStart(2,"0"),$=String(h.getHours()).padStart(2,"0"),v=String(h.getMinutes()).padStart(2,"0"),M=String(h.getSeconds()).padStart(2,"0");return`design-review-report-${I}-${f}-${C}-${$}-${v}-${M}`}function Un(h,I){if(!h||!Array.isArray(h.colors))return h;let f=I||{};return it(Je({},h),{colors:h.colors.map(C=>it(Je({},C),{name:f[String(C.value).toUpperCase()]||"No name"}))})}function _o({format:h,reportData:I,getTypeDisplayName:f,filenameBase:C,colorNameMap:$}={}){var q,R;let v=I||{};if(!v.issues&&!v.tokens){alert("No data to export!");return}let M=C||Dn();if(h==="html"){let F=Ot({reportData:v,getTypeDisplayName:f}),T=new Blob([F],{type:"text/html"}),L=URL.createObjectURL(T),N=document.createElement("a");N.href=L,N.download=`${M}.html`,N.click(),URL.revokeObjectURL(L);return}if(h==="pdf"){let F=Ot({reportData:v,getTypeDisplayName:f});try{let T=window.open("","_blank");if(!T){alert("Popup blocked. Downloading HTML - you can open the file and select Print to create PDF.");let L=new Blob([F],{type:"text/html"}),N=URL.createObjectURL(L),P=document.createElement("a");P.href=N,P.download=`${M}.html`,P.click(),URL.revokeObjectURL(N);return}T.document.open(),T.document.write(F),T.document.close(),T.onload=()=>{setTimeout(()=>{T.print()},250)},setTimeout(()=>{T.document&&T.document.readyState==="complete"&&T.print()},500)}catch(T){console.error("Error opening print window:",T),alert("Cannot open print window. Downloading HTML - you can open the file and select Print to create PDF.");let L=new Blob([F],{type:"text/html"}),N=URL.createObjectURL(L),P=document.createElement("a");P.href=N,P.download=`${M}.html`,P.click(),URL.revokeObjectURL(N)}return}if(h==="json"){console.log("Export JSON - colorNameMap:",$),console.log("Export JSON - tokens.colors:",(q=v.tokens)==null?void 0:q.colors);let F=it(Je({},v),{tokens:Un(v.tokens,$)});console.log("Export JSON - enriched colors:",(R=F.tokens)==null?void 0:R.colors);let T=JSON.stringify(F,null,2),L=new Blob([T],{type:"application/json"}),N=URL.createObjectURL(L),P=document.createElement("a");P.href=N,P.download=`${M}.json`,P.click(),URL.revokeObjectURL(N);return}}function Xo({maxHistory:h=10,postPluginMessage:I,getCurrentReportData:f,setIsViewingTokens:C,renderResults:$,renderTokens:v}={}){let M=[],q=!1,R=j=>{try{typeof I=="function"&&I(j)}catch(O){console.error("scanHistory postPluginMessage error:",O)}};function F(j){M=(Array.isArray(j)?j:[]).slice(0,h)}function T(){M=[],q=!1}function L(){return M||[]}function N(j,O,z,K){try{if(O==="issues"&&(!z.issues||z.issues.length===0)){console.log("Skipping save - no issues data");return}if(O==="tokens"&&(!z.tokens||Object.keys(z.tokens).length===0)){console.log("Skipping save - no tokens data");return}let W={id:Date.now().toString(),mode:j,type:O,timestamp:new Date().toISOString(),context:K||null,data:{issues:z.issues||null,tokens:z.tokens||null,issuesCount:z.issues?z.issues.length:0,tokensCount:z.tokens?Object.keys(z.tokens).reduce((k,B)=>{var ke;return k+(((ke=z.tokens[B])==null?void 0:ke.length)||0)},0):0}};M.unshift(W),M=M.slice(0,h);let Q=document.getElementById("history-panel");Q&&Q.style.display!=="none"&&se(),R({type:"save-history-entry",entry:W})}catch(W){console.error("Error saving scan history:",W)}}function P(){R({type:"get-history"})}function J(){try{let j=L();if(j.length>0){let O=j[0],z=document.querySelector(`input[name="scope"][value="${O.mode}"]`);z&&(z.checked=!0,console.log("Loaded last scan mode:",O.mode))}}catch(j){console.error("Error loading last scan mode:",j)}}function V(){q||(J(),q=!0)}function he(j){try{let O=new Date(j),K=new Date-O,W=Math.floor(K/6e4),Q=Math.floor(K/36e5),k=Math.floor(K/864e5);return W<1?"Just now":W<60?`${W} minutes ago`:Q<24?`${Q} hours ago`:k<7?`${k} days ago`:O.toLocaleString("en-US",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"})}catch(O){return j}}function se(){let j=document.getElementById("history-list");if(!j){console.error("history-list element not found");return}let O=L();if(console.log("Rendering scan history:",O.length,"entries"),O.length===0){j.innerHTML=`
              <div class="history-empty">
                <div class="icon">\u{1F4CB}</div>
                <p>No scan history</p>
                <p style="font-size: 11px; margin-top: 8px;">Scans will be saved automatically</p>
              </div>
            `;return}j.innerHTML=O.map(z=>{var _e,dt;let K=he(z.timestamp),W=z.mode==="page"?"Page":"Selection",Q=z.type==="issues"?"Issues":"Tokens",k=z.type==="issues"?"issues":"tokens",B=z.context&&z.context.label?z.context.label:`${W} scan`,ke="";if(z.type==="issues"){let ie=((_e=z.data.issues)==null?void 0:_e.filter(De=>De.severity==="error").length)||0,ft=((dt=z.data.issues)==null?void 0:dt.filter(De=>De.severity==="warn").length)||0;ke=`
                <span>\u274C ${ie} errors</span>
                <span>\u26A0\uFE0F ${ft} warnings</span>
                <span>\u{1F4CA} ${z.data.issuesCount} total</span>
              `}else ke=`
                <span>\u{1F3A8} ${z.data.tokensCount} tokens</span>
              `;return`
              <div class="history-item" data-id="${z.id}">
                <div class="history-item-header">
                  <span class="history-item-type ${k}">${Q}</span>
                  <span class="history-item-time">${K}</span>
                </div>
                <div class="history-item-info">${d(B)}</div>
                <div class="history-item-stats">${ke}</div>
              </div>
            `}).join(""),j.querySelectorAll(".history-item").forEach(z=>{z.onclick=()=>{let K=z.getAttribute("data-id");te(K)}})}function te(j){try{let z=L().find(k=>k.id===j);if(!z){alert("Scan history entry not found!");return}let K=document.querySelector(`input[name="scope"][value="${z.mode}"]`);K&&(K.checked=!0);let W=typeof f=="function"?f():null;if(!W){console.warn("restoreReportFromHistory: currentReportData is not available");return}W.scanMode=z.mode,W.context=z.context||null,z.type==="issues"&&z.data.issues?(W.issues=z.data.issues,W.tokens=null,typeof C=="function"&&C(!1),typeof $=="function"&&$(z.data.issues,!0,{restoreTimestamp:z.timestamp})):z.type==="tokens"&&z.data.tokens&&(W.issues=null,W.tokens=z.data.tokens,typeof C=="function"&&C(!0),typeof v=="function"&&v(z.data.tokens,!0,{restoreTimestamp:z.timestamp}));let Q=document.getElementById("history-panel");Q&&(Q.style.display="none"),console.log("Report restored from history:",j)}catch(O){console.error("Error restoring report from history:",O),alert("Error restoring report: "+O.message)}}return{setHistory:F,clearLocalHistory:T,getScanHistory:L,saveScanHistory:N,requestScanHistory:P,loadLastScanMode:J,loadLastScanModeOnce:V,renderScanHistory:se,restoreReportFromHistory:te}}console.log("Header.js22121211thien2");console.log("ui.js loaded");(function(){console.log("Initializing ui.js...");let h=document.getElementById("btn-scan"),I=document.getElementById("btn-cancel-scan"),f=document.getElementById("scan-progress"),C=document.getElementById("scan-progress-bar"),$=document.getElementById("scan-progress-text"),v=document.getElementById("btn-extract-tokens"),M=document.getElementById("btn-fill-spacing-scale"),q=document.getElementById("btn-fill-color-scale"),R=document.getElementById("btn-extract-color-styles"),F=document.getElementById("btn-fill-font-size-scale"),T=document.getElementById("btn-fill-line-height-scale"),L=document.getElementById("btn-fill-font-size-from-typo"),N=document.getElementById("btn-fill-line-height-from-typo"),P=document.getElementById("btn-export"),J=document.getElementById("btn-history"),V=document.getElementById("btn-close-history"),he=document.getElementById("btn-reset-all"),se=document.getElementById("results-issues"),te=document.getElementById("results-tokens"),j=document.getElementById("btn-close"),O=document.querySelectorAll(".report-tab"),z=document.querySelectorAll(".report-content"),K="issues";if(!h||!v||!se||!te||!j||!P||!J||!M||!q||!F||!T){console.error("Required elements not found",{btnScan:h,btnExtractTokens:v,btnFillSpacingScale:M,btnFillColorScale:q,btnFillFontSizeScale:F,btnFillLineHeightScale:T,resultsIssues:se,resultsTokens:te,btnClose:j,btnExport:P,btnHistory:J});return}Oo();let W={},Q={},k={issues:null,tokens:null,scanMode:null,timestamp:null,tokensTimestamp:null,context:null},B=[{id:1,name:"H1",fontFamily:"Inter",fontSize:48,fontWeight:"Bold",lineHeight:"120%",letterSpacing:"0",wordSpacing:"0"},{id:2,name:"H2",fontFamily:"Inter",fontSize:36,fontWeight:"Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:3,name:"H3",fontFamily:"Inter",fontSize:28,fontWeight:"SemiBold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:4,name:"H4",fontFamily:"Inter",fontSize:24,fontWeight:"SemiBold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:5,name:"H5",fontFamily:"Inter",fontSize:20,fontWeight:"Medium",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:6,name:"H6",fontFamily:"Inter",fontSize:18,fontWeight:"Medium",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:7,name:"Body",fontFamily:"Inter",fontSize:16,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"}],ke=8;function _e(e){e&&parent.postMessage({pluginMessage:{type:"save-last-report",report:e}},"*")}function dt(){parent.postMessage({pluginMessage:{type:"get-last-report"}},"*")}function ie(){var t,o,s,n,l,a,i,r,p,u,m,y,g,b,S;let e={spacingScale:((t=document.getElementById("spacing-scale"))==null?void 0:t.value)||"",spacingThreshold:((o=document.getElementById("spacing-threshold"))==null?void 0:o.value)||"100",colorScale:((s=document.getElementById("color-scale"))==null?void 0:s.value)||"",colorNameMap:W,ignoredIssues:Q,fontSizeScale:((n=document.getElementById("font-size-scale"))==null?void 0:n.value)||"",fontSizeThreshold:((l=document.getElementById("font-size-threshold"))==null?void 0:l.value)||"100",lineHeightScale:((a=document.getElementById("line-height-scale"))==null?void 0:a.value)||"",lineHeightThreshold:((i=document.getElementById("line-height-threshold"))==null?void 0:i.value)||"300",lineHeightBaselineThreshold:((r=document.getElementById("line-height-baseline-threshold"))==null?void 0:r.value)||"120",typographyStyles:B,typographyRules:{checkStyle:((p=document.getElementById("rule-typo-style"))==null?void 0:p.checked)||!0,checkFontFamily:((u=document.getElementById("rule-font-family"))==null?void 0:u.checked)||!0,checkFontSize:((m=document.getElementById("rule-font-size"))==null?void 0:m.checked)||!0,checkFontWeight:((y=document.getElementById("rule-font-weight"))==null?void 0:y.checked)||!0,checkLineHeight:((g=document.getElementById("rule-line-height"))==null?void 0:g.checked)||!0,checkLetterSpacing:((b=document.getElementById("rule-letter-spacing"))==null?void 0:b.checked)||!1,checkWordSpacing:((S=document.getElementById("rule-word-spacing"))==null?void 0:S.checked)||!1}};parent.postMessage({pluginMessage:{type:"save-input-values",values:e}},"*")}function ft(){parent.postMessage({pluginMessage:{type:"get-input-values"}},"*")}function De(e){if(!e)return;let t=document.getElementById("spacing-scale"),o=document.getElementById("spacing-threshold"),s=document.getElementById("color-scale"),n=document.getElementById("font-size-scale"),l=document.getElementById("font-size-threshold"),a=document.getElementById("line-height-scale"),i=document.getElementById("line-height-threshold"),r=document.getElementById("line-height-baseline-threshold");if(t&&e.spacingScale!==void 0&&(t.value=e.spacingScale),o&&e.spacingThreshold!==void 0&&(o.value=e.spacingThreshold),e.colorNameMap&&typeof e.colorNameMap=="object"?W=e.colorNameMap:W={},e.ignoredIssues&&typeof e.ignoredIssues=="object"?Q=e.ignoredIssues:Q={},s&&e.colorScale!==void 0&&(s.value=e.colorScale,typeof Ce=="function"&&Ce()),n&&e.fontSizeScale!==void 0&&(n.value=e.fontSizeScale),l&&e.fontSizeThreshold!==void 0&&(l.value=e.fontSizeThreshold),a&&e.lineHeightScale!==void 0&&(a.value=e.lineHeightScale),i&&e.lineHeightThreshold!==void 0&&(i.value=e.lineHeightThreshold),r&&e.lineHeightBaselineThreshold!==void 0&&(r.value=e.lineHeightBaselineThreshold),e.typographyStyles&&Array.isArray(e.typographyStyles)&&(B=e.typographyStyles,ke=Math.max(...B.map(p=>p.id||0),0)+1,Be()),e.typographyRules){let p=e.typographyRules;document.getElementById("rule-typo-style")&&(document.getElementById("rule-typo-style").checked=p.checkStyle!==!1),document.getElementById("rule-font-family")&&(document.getElementById("rule-font-family").checked=p.checkFontFamily!==!1),document.getElementById("rule-font-size")&&(document.getElementById("rule-font-size").checked=p.checkFontSize!==!1),document.getElementById("rule-font-weight")&&(document.getElementById("rule-font-weight").checked=p.checkFontWeight!==!1),document.getElementById("rule-line-height")&&(document.getElementById("rule-line-height").checked=p.checkLineHeight!==!1),document.getElementById("rule-letter-spacing")&&(document.getElementById("rule-letter-spacing").checked=p.checkLetterSpacing===!0),document.getElementById("rule-word-spacing")&&(document.getElementById("rule-word-spacing").checked=p.checkWordSpacing===!0),Be()}}function Ko(e){if(!e){console.log("No last report to apply");return}if(e.scanMode){let t=document.querySelector(`input[name="scope"][value="${e.scanMode}"]`);t&&(t.checked=!0)}k.scanMode=e.scanMode||k.scanMode,k.context=e.context||k.context,e.issues&&Array.isArray(e.issues)&&(console.log("Applying saved issues report"),Pe(e.issues,!0,{skipSave:!0,restoreTimestamp:e.issuesTimestamp})),e.tokens&&(console.log("Applying saved tokens report"),St(e.tokens,!0,{skipSave:!0,restoreTimestamp:e.tokensTimestamp})),e.lastActiveTab?Fe(e.lastActiveTab):e.issues?Fe("issues"):e.tokens&&Fe("tokens")}let we="all",ue="",ze="all",pt=!1;console.log("All elements found, setting up event listeners"),O.forEach(e=>{e.addEventListener("click",()=>{let t=e.dataset.tab;O.forEach(o=>o.classList.remove("active")),e.classList.add("active"),z.forEach(o=>o.classList.remove("active")),document.getElementById(`results-${t}`).classList.add("active"),K=t,(k.issues||k.tokens)&&_e({issues:k.issues,issuesTimestamp:k.timestamp,tokens:k.tokens,tokensTimestamp:k.tokensTimestamp,lastActiveTab:t,scanMode:k.scanMode||null,context:k.context||null})})});function ht(e=null){let t=e?document.getElementById(`results-${e}`):se;t&&(t.innerHTML="")}function Fe(e){O.forEach(t=>{t.dataset.tab===e?t.classList.add("active"):t.classList.remove("active")}),z.forEach(t=>{t.id===`results-${e}`?t.classList.add("active"):t.classList.remove("active")}),K=e}function Zo(e){return e==="error"?"\u274C":e==="warn"?"\u26A0\uFE0F":"\u2139\uFE0F"}function Vt(e){return{naming:"\u{1F3F7}\uFE0F",autolayout:"\u{1F4D0}",spacing:"\u{1F4CF}",color:"\u{1F3A8}",typography:"\u270D\uFE0F","typography-style":"\u{1F3A8}","typography-check":"\u{1F4DD}","typography-pass":"\u2705","typography-info":"\u2705","line-height":"\u{1F4DD}",position:"\u{1F4CD}",duplicate:"\u{1F504}",group:"\u{1F4E6}",component:"\u{1F9E9}","empty-frame":"\u{1F4ED}","nested-group":"\u{1F4DA}",contrast:"\u{1F308}","text-size-mobile":"\u{1F4F1}"}[e]||"\u{1F50D}"}function bt(e){return{naming:"Naming Layer",autolayout:"Auto Layout",spacing:"Spacing",color:"Color",typography:"Font Size","typography-style":"Text Style (variable)","typography-check":"Typography Style Match","typography-pass":"Typography \u2713 Matched","line-height":"Line Height",position:"Position Layer",duplicate:"Duplicate Layer",group:"Group Layer",component:"Component Reusable","empty-frame":"Empty Frame Layer","nested-group":"Nested Group Layer",contrast:"Contrast (ADA AA)","text-size-mobile":"Text Size (ADA)"}[e]||e.replace(/-/g," ")}function Qo(e){let t=document.createElement("div");t.className=`issue ${e.severity}`;let o="";e.type==="typography-check"&&e.nodeProps&&(o='<div class="typography-details" style="margin-top: 8px; padding: 8px; background: rgba(0,0,0,0.05); border-radius: 4px; font-size: 11px;">',o+='<div class="current-properties"><div style="margin-bottom: 6px;"><strong>Current Properties:</strong></div>',o+='<div style="padding-left: 0; line-height: 1.6;">',e.nodeProps.fontFamily&&(o+=`\u2022 Font Family: <code>${d(e.nodeProps.fontFamily)}</code><br>`),e.nodeProps.fontSize!==null&&e.nodeProps.fontSize!==void 0&&(o+=`\u2022 Font Size: <code>${e.nodeProps.fontSize}px</code><br>`),e.nodeProps.fontWeight&&(o+=`\u2022 Font Weight: <code>${d(e.nodeProps.fontWeight)}</code><br>`),e.nodeProps.lineHeight&&(o+=`\u2022 Line Height: <code>${d(e.nodeProps.lineHeight)}</code><br>`),e.nodeProps.letterSpacing!==null&&e.nodeProps.letterSpacing!==void 0&&(o+=`\u2022 Letter Spacing: <code>${d(e.nodeProps.letterSpacing)}</code><br>`),o+="</div></div>",e.bestMatch&&e.bestMatch.name&&e.severity==="error"?(o+=`<div class="closest-match"><div style="margin-bottom: 6px;"><strong>Closest Match: "${d(e.bestMatch.name)}" (${e.bestMatch.percentage||0}%)</strong></div>`,o+='<div style="padding-left: 0; line-height: 1.6;">',(e.bestMatch.differences||[]).forEach(i=>{let r=i.matches?"\u2713":"\u2717",p=i.matches?"green":"red";o+=`<span style="color: ${p}">${r} ${i.property}: <code>${d(i.current)}</code> \u2192 <code>${d(i.expected)}</code></span><br>`}),o+="</div></div>"):e.severity==="info"&&e.styleName&&(o+=`<div style="margin-top: 8px; color: green;"><strong>\u2713 All properties match style "${d(e.styleName)}"</strong></div>`),o+="</div>"),t.setAttribute("data-issue-id",e.id),t.innerHTML=`
      <div class="issue-header">
              <div>
                <span class="issue-type">${Vt(e.type)} ${bt(e.type)}</span>
      <div class="issue-body">${d(e.message)}</div>
                ${e.nodeName?`<div class="issue-node">Node: ${d(e.nodeName)}</div>`:""}
                ${o}
              </div>
              <div class="issue-actions">
                <button class="btn-select" data-id="${e.id}">Select</button>
                ${e.bestMatch&&e.bestMatch.name&&e.type==="typography-check"?`
                  <button class="btn-suggest-fix" data-id="${e.id}" data-style-name="${d(e.bestMatch.name)}">Suggest Fix now</button>
                  <button class="btn-style-dropdown" data-id="${e.id}" data-issue-id="${e.id}">Select Style</button>
                `:""}
                ${(e.severity==="error"||e.severity==="warn")&&e.type==="typography-check"?`
                  <button class="btn-remove-layer" data-id="${e.id}">Remove Layer</button>
                `:""}
              </div>
      </div>
    `;let s=t.querySelector("button.btn-select");s&&(s.onclick=()=>{parent.postMessage({pluginMessage:{type:"select-node",id:e.id}},"*")});let n=t.querySelector("button.btn-suggest-fix");n&&e.type==="typography-check"&&e.bestMatch&&e.bestMatch.name&&(function(i){n.onclick=r=>{r.preventDefault(),r.stopPropagation(),i.bestMatch&&i.bestMatch.name?Nt(i,i.bestMatch.name):(console.error("Cannot apply: bestMatch.name is missing",i),alert("Error: Best match style name is missing"))}})(e);let l=t.querySelector("button.btn-style-dropdown");l&&e.type==="typography-check"&&(function(i){l.onclick=r=>{r.preventDefault(),r.stopPropagation(),parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:i.id}},"*"),window.pendingTypographyCheckIssue=i}})(e);let a=t.querySelector("button.btn-remove-layer");return a&&e.type==="typography-check"&&(function(i){a.onclick=r=>{r.preventDefault(),r.stopPropagation(),console.log("Remove Layer button clicked for typography-check",i),typeof vt=="function"?vt(i):(console.error("handleRemoveLayer is not a function"),alert("Error: handleRemoveLayer function not found"))}})(e),t}function en(e){let t=at(e);if(!t){alert("No suitable color match found");return}let s=(e.message||"").match(/Color (#[0-9A-Fa-f]{6})/),n=s?s[1].toUpperCase():null;jt(e,n,t,W)}function tn(e){let t=rt(e);if(!t){alert("No suitable spacing match found");return}let o=e.message||"",s=o.match(/Padding\s+(\w+)\s+\((\d+)px\)/);if(!s){console.error("Cannot parse spacing issue message:",o),alert("Cannot determine spacing property from issue message. Message: "+o);return}let n=s[1],l=parseInt(s[2]);Dt(e,n,l,t)}function Xe(e){return!e||e.type!=="autolayout"?null:{action:"enable-autolayout"}}function Gt(e){if(!Xe(e)){alert("Cannot suggest fix for this autolayout issue");return}on(e)}function on(e){let t=document.createElement("div");t.className="modal-overlay",t.id="autolayout-fix-confirm-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="450px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Auto Layout Enable</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Action:</div>
          <div style="padding: 12px; background: #e3f2fd; border-left: 3px solid #0071e3; border-radius: 6px;">
            <div style="font-size: 14px; color: #333; margin-bottom: 8px;">
              <strong>Enable Auto Layout</strong>
            </div>
            <div style="font-size: 12px; color: #666;">
              Auto Layout will be enabled on this frame. The layout direction (horizontal/vertical) will be automatically determined based on the children arrangement.
            </div>
          </div>
        </div>
        <div style="padding: 12px; background: #e8f5e9; border-radius: 6px; border-left: 3px solid #28a745;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">\u{1F4DD} Note:</div>
          <div style="font-size: 12px; color: #333;">
            \u2022 Layout direction will be auto-detected (horizontal or vertical)<br>
            \u2022 Spacing and padding will be preserved if possible<br>
            \u2022 Frame structure will be maintained
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="autolayout-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="autolayout-fix-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let s=o.querySelector("#autolayout-fix-confirm-cancel-btn"),n=o.querySelector("#autolayout-fix-confirm-apply-btn"),l=o.querySelector(".modal-close"),a=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};s.onclick=a,l.onclick=a,t.onclick=i=>{i.target===t&&a()},n.onclick=()=>{a(),X(e.id,"\u23F3 Enabling auto layout...",!0),parent.postMessage({pluginMessage:{type:"fix-autolayout-issue",issue:e}},"*")}}function nn(e,t={}){let{onApply:o,onIgnore:s,onCancel:n,progress:l}=t,a=l?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${l.current}/${l.total}</div>`:"",i=document.createElement("div");i.className="modal-overlay",i.id="autolayout-fix-confirm-modal-overlay";let r=document.createElement("div");r.className="modal-dialog",r.style.maxWidth="450px",r.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Auto Layout Enable</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${a}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Action:</div>
          <div style="padding: 12px; background: #e3f2fd; border-left: 3px solid #0071e3; border-radius: 6px;">
            <div style="font-size: 14px; color: #333; margin-bottom: 8px;">
              <strong>Enable Auto Layout</strong>
            </div>
            <div style="font-size: 12px; color: #666;">
              Auto Layout will be enabled on this frame. The layout direction (horizontal/vertical) will be automatically determined based on the children arrangement.
            </div>
          </div>
        </div>
        <div style="padding: 12px; background: #e8f5e9; border-radius: 6px; border-left: 3px solid #28a745;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">\u{1F4DD} Note:</div>
          <div style="font-size: 12px; color: #333;">
            \u2022 Layout direction will be auto-detected (horizontal or vertical)<br>
            \u2022 Spacing and padding will be preserved if possible<br>
            \u2022 Frame structure will be maintained
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="autolayout-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="autolayout-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="autolayout-fix-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,i.appendChild(r),document.body.appendChild(i);let p=r.querySelector("#autolayout-fix-cancel-btn"),u=r.querySelector("#autolayout-fix-apply-btn"),m=r.querySelector("#autolayout-fix-ignore-btn"),y=r.querySelector(".modal-close"),g=()=>{i.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{i.parentNode&&i.remove()},200)};p.onclick=()=>{g(),n&&n()},y.onclick=()=>{g(),n&&n()},i.onclick=b=>{b.target===i&&(g(),n&&n())},m.onclick=()=>{g(),s&&s()},u.onclick=()=>{g(),X(e.id,"\u23F3 Enabling auto layout...",!0),parent.postMessage({pluginMessage:{type:"fix-autolayout-issue",issue:e}},"*"),o&&o()}}function ln(e){return{action:"convert-group"}}function Jt(e){if(!ln(e)){alert("Cannot suggest fix for this group issue");return}sn(e)}function sn(e){let t=document.createElement("div");t.className="modal-overlay",t.id="group-fix-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="450px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Convert Group to Frame</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          This will convert the Group to a Frame and enable Auto-layout automatically.
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Group</div>
        </div>
        <div style="background: #e8f5e9; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame with Auto-layout</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="group-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="group-fix-apply-btn">Apply</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let s=o.querySelector("#group-fix-cancel-btn"),n=o.querySelector(".modal-close"),l=o.querySelector("#group-fix-apply-btn"),a=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};s.onclick=a,n.onclick=a,t.onclick=i=>{i.target===t&&a()},l.onclick=()=>{l.disabled=!0,l.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-group-issue",issue:e}},"*"),a()}}function an(e,t={}){let{onApply:o,onIgnore:s,onCancel:n,progress:l}=t,a=l?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${l.current}/${l.total}</div>`:"",i=document.createElement("div");i.className="modal-overlay",i.id="group-fix-modal-overlay";let r=document.createElement("div");r.className="modal-dialog",r.style.maxWidth="450px",r.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Convert Group to Frame</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${a}
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          This will convert the Group to a Frame and enable Auto-layout automatically.
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Group</div>
        </div>
        <div style="background: #e8f5e9; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame with Auto-layout</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="group-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="group-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="group-fix-apply-btn">Apply</button>
      </div>
    `,i.appendChild(r),document.body.appendChild(i);let p=r.querySelector("#group-fix-cancel-btn"),u=r.querySelector("#group-fix-apply-btn"),m=r.querySelector("#group-fix-ignore-btn"),y=r.querySelector(".modal-close"),g=()=>{i.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{i.parentNode&&i.remove()},200)};p.onclick=()=>{g(),n&&n()},y.onclick=()=>{g(),n&&n()},i.onclick=b=>{b.target===i&&(g(),n&&n())},m.onclick=()=>{g(),s&&s()},u.onclick=()=>{u.disabled=!0,u.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-group-issue",issue:e}},"*"),g(),o&&o()}}function Ue(e){return!e||e.type!=="position"?null:{action:"fix-position"}}function Ke(e){return!e||e.type!=="duplicate"&&e.type!=="component"?null:{action:"suggest-component"}}function Ze(e){return!e||e.type!=="empty-frame"?null:{action:"fix-empty-frame"}}function Yt(e){if(!Ue(e)){alert("Cannot suggest fix for this position issue");return}rn(e)}function _t(e){if(!Ze(e)){alert("Cannot suggest fix for this empty frame issue");return}dn(e)}function rn(e){let t=e.message||"",o=t.match(/x:(-?\d+)/),s=t.match(/y:(-?\d+)/),n=o?parseInt(o[1],10):0,l=s?parseInt(s[1],10):0,a=document.createElement("div");a.className="modal-overlay",a.id="position-fix-confirm-modal-overlay";let i=document.createElement("div");i.className="modal-dialog",i.style.maxWidth="400px",i.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Fix Position Issue</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            This layer has a negative position which may cause layout issues.
          </p>
          <div style="padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Position:</strong></div>
            <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>${n}px</code><br>
              \u2022 Y: <code>${l}px</code>
            </div>
          </div>
          <div style="padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-size: 12px; color: #1976d2; margin-bottom: 8px;"><strong>After Fix:</strong></div>
            <div style="font-size: 11px; color: #1976d2; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>0px</code><br>
              \u2022 Y: <code>0px</code>
            </div>
          </div>
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          This will set the position to (0, 0) to fix the negative offset.
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="position-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="position-fix-confirm-apply-btn">Apply</button>
      </div>
    `,a.appendChild(i),document.body.appendChild(a);let r=i.querySelector("#position-fix-confirm-cancel-btn"),p=i.querySelector("#position-fix-confirm-apply-btn"),u=i.querySelector(".modal-close"),m=()=>{a.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{a.parentNode&&a.remove()},200)};r.onclick=m,u.onclick=m,a.onclick=y=>{y.target===a&&m()},p.onclick=()=>{m(),X(e.id,"\u23F3 Fixing position...",!0),parent.postMessage({pluginMessage:{type:"fix-position-issue",issue:e}},"*")}}function cn(e,t={}){let{onApply:o,onIgnore:s,onCancel:n,progress:l}=t,a=l?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${l.current}/${l.total}</div>`:"",i=e.message||"",r=i.match(/x:(-?\d+)/),p=i.match(/y:(-?\d+)/),u=r?parseInt(r[1],10):0,m=p?parseInt(p[1],10):0,y=document.createElement("div");y.className="modal-overlay",y.id="position-fix-confirm-modal-overlay";let g=document.createElement("div");g.className="modal-dialog",g.style.maxWidth="400px",g.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Fix Position Issue</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${a}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            This layer has a negative position which may cause layout issues.
          </p>
          <div style="padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Position:</strong></div>
            <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>${u}px</code><br>
              \u2022 Y: <code>${m}px</code>
            </div>
          </div>
          <div style="padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-size: 12px; color: #1976d2; margin-bottom: 8px;"><strong>After Fix:</strong></div>
            <div style="font-size: 11px; color: #1976d2; padding-left: 8px; line-height: 1.6;">
              \u2022 X: <code>0px</code><br>
              \u2022 Y: <code>0px</code>
            </div>
          </div>
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          This will set the position to (0, 0) to fix the negative offset.
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="position-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="position-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="position-fix-apply-btn">Apply</button>
      </div>
    `,y.appendChild(g),document.body.appendChild(y);let b=g.querySelector("#position-fix-cancel-btn"),S=g.querySelector("#position-fix-apply-btn"),x=g.querySelector("#position-fix-ignore-btn"),E=g.querySelector(".modal-close"),w=()=>{y.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{y.parentNode&&y.remove()},200)};b.onclick=()=>{w(),n&&n()},E.onclick=()=>{w(),n&&n()},y.onclick=H=>{H.target===y&&(w(),n&&n())},x.onclick=()=>{w(),s&&s()},S.onclick=()=>{w(),X(e.id,"\u23F3 Fixing position...",!0),parent.postMessage({pluginMessage:{type:"fix-position-issue",issue:e}},"*"),o&&o()}}function jn(e){Xt(e)}function vt(e){Xt(e)}function Xt(e){let t=document.createElement("div");t.className="modal-overlay",t.id="remove-layer-confirm-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="400px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Remove Layer</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            Are you sure you want to remove this layer?
          </p>
          <div style="padding: 12px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 6px;">
            <div style="font-size: 12px; color: #856404; margin-bottom: 4px;"><strong>\u26A0\uFE0F Warning:</strong></div>
            <div style="font-size: 11px; color: #856404; line-height: 1.6;">
              This action cannot be undone. The layer and all its children will be permanently deleted.
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="remove-layer-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-danger" id="remove-layer-confirm-apply-btn" style="background: #dc3545; border-color: #dc3545;color: white;">Remove</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let s=o.querySelector("#remove-layer-confirm-cancel-btn"),n=o.querySelector("#remove-layer-confirm-apply-btn"),l=o.querySelector(".modal-close"),a=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};s.onclick=a,l.onclick=a,t.onclick=i=>{i.target===t&&a()},n.onclick=()=>{a(),X(e.id,"\u23F3 Removing layer...",!0),parent.postMessage({pluginMessage:{type:"remove-layer",issue:e}},"*")}}function dn(e){let t=e.message||"",o=t.includes("Empty frame"),s=t.includes("redundant"),n=s?"Remove Redundant Frame":"Remove Empty Frame",l=s?"This will remove the redundant frame and keep its single child. The child will inherit the frame's name if it was unnamed.":"This will remove the empty frame. If it has a child, the child will be kept.",a=document.createElement("div");a.className="modal-overlay",a.id="empty-frame-fix-modal-overlay";let i=document.createElement("div");i.className="modal-dialog",i.style.maxWidth="450px",i.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">${n}</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          ${l}
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">${d(e.message)}</div>
        </div>
        <div style="background: #e8f5e9; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame removed, child kept (if applicable)</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="empty-frame-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="empty-frame-fix-apply-btn">Apply</button>
      </div>
    `,document.body.appendChild(a),a.appendChild(i);let r=i.querySelector("#empty-frame-fix-cancel-btn"),p=i.querySelector(".modal-close"),u=i.querySelector("#empty-frame-fix-apply-btn"),m=()=>{a.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{a.parentNode&&a.remove()},200)};r.onclick=m,p.onclick=m,a.onclick=y=>{y.target===a&&m()},u.onclick=()=>{u.disabled=!0,u.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-empty-frame-issue",issue:e}},"*"),m()}}function pn(e,t={}){let{onApply:o,onIgnore:s,onCancel:n,progress:l}=t,a=l?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${l.current}/${l.total}</div>`:"",i=e.message||"",r=i.includes("Empty frame"),p=i.includes("redundant"),u=p?"Remove Redundant Frame":"Remove Empty Frame",m=p?"This will remove the redundant frame and keep its single child. The child will inherit the frame's name if it was unnamed.":"This will remove the empty frame. If it has a child, the child will be kept.",y=document.createElement("div");y.className="modal-overlay",y.id="empty-frame-fix-modal-overlay";let g=document.createElement("div");g.className="modal-dialog",g.style.maxWidth="450px",g.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">${u}</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${a}
      <div class="modal-body">
        <p style="margin: 0 0 16px 0; color: #333; line-height: 1.5;">
          ${m}
        </p>
        <div style="background: #f5f5f5; padding: 12px; border-radius: 6px; margin-bottom: 16px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">${d(e.message)}</div>
        </div>
        <div style="background: #e8f5e9; padding: 12px; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">After fix:</div>
          <div style="font-size: 13px; color: #333; font-weight: 500;">Frame removed, child kept (if applicable)</div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="empty-frame-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="empty-frame-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="empty-frame-fix-apply-btn">Apply</button>
      </div>
    `,document.body.appendChild(y),y.appendChild(g);let b=g.querySelector("#empty-frame-fix-cancel-btn"),S=g.querySelector("#empty-frame-fix-apply-btn"),x=g.querySelector("#empty-frame-fix-ignore-btn"),E=g.querySelector(".modal-close"),w=()=>{y.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{y.parentNode&&y.remove()},200)};b.onclick=()=>{w(),n&&n()},E.onclick=()=>{w(),n&&n()},y.onclick=H=>{H.target===y&&(w(),n&&n())},x.onclick=()=>{w(),s&&s()},S.onclick=()=>{S.disabled=!0,S.textContent="Applying...",parent.postMessage({pluginMessage:{type:"fix-empty-frame-issue",issue:e}},"*"),w(),o&&o()}}function Kt(e){if(console.log("handleSuggestFixComponent called",e),!e||!e.id){console.error("Invalid issue in handleSuggestFixComponent",e),alert("Error: Invalid issue data");return}window.pendingComponentIssue=e,console.log("Stored pendingComponentIssue:",window.pendingComponentIssue);let t=document.querySelector(`.issue[data-issue-id="${e.id}"]`);if(t){let o=t.querySelector("button.btn-suggest-fix");if(o){let s=o.textContent;o.disabled=!0,o.textContent="Loading...",o.style.opacity="0.6",o.style.cursor="wait",o.dataset.originalText=s}}console.log("Sending get-components-for-issue message",{issueId:e.id,issue:e}),parent.postMessage({pluginMessage:{type:"get-components-for-issue",issue:e}},"*")}function Zt(e){if(console.log("handleSelectComponent called",e),!e||!e.id){console.error("Invalid issue in handleSelectComponent",e),alert("Error: Invalid issue data");return}window.pendingSelectComponentIssue=e,console.log("Stored pendingSelectComponentIssue:",window.pendingSelectComponentIssue);let t=document.querySelector(`.issue[data-issue-id="${e.id}"]`);if(t){let o=t.querySelector("button.btn-select-component");if(o){let s=o.textContent;o.disabled=!0,o.textContent="Loading...",o.style.opacity="0.6",o.dataset.originalText=s}}console.log("Sending get-all-components message",{issueId:e.id,issue:e}),parent.postMessage({pluginMessage:{type:"get-all-components",issue:e}},"*")}function Qt(e){gn(e)}function eo(e){un(e)}function un(e){let t=document.createElement("div");t.className="modal-overlay",t.id="rename-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="400px";let s=e.nodeName||"",n=s.replace(/^(Frame|Group)\s*/i,"").trim()||"";o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Rename Node</h2>
        <p class="modal-subtitle">Current: ${d(s)}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <label style="display: block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #333;">New Name:</label>
          <input type="text" id="rename-input" placeholder="Enter meaningful name" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px;" value="${d(n)}" autocomplete="off">
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          Enter a meaningful name that describes the purpose of this layer (e.g., "Header", "Button", "Card").
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="rename-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="rename-apply-btn">Rename</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let l=o.querySelector("#rename-cancel-btn"),a=o.querySelector("#rename-apply-btn"),i=o.querySelector(".modal-close"),r=o.querySelector("#rename-input");setTimeout(()=>{r.focus(),r.select()},100);let p=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};l.onclick=p,i.onclick=p,t.onclick=u=>{u.target===t&&p()},r.addEventListener("keydown",u=>{u.key==="Enter"&&(u.preventDefault(),a.click())}),a.onclick=()=>{let u=r.value.trim();if(!u){alert("Please enter a name"),r.focus();return}if(/^(Frame|Group)\s*$/i.test(u)&&!confirm("The name still contains default naming (Frame/Group). Do you want to continue?")){r.focus();return}p(),X(e.id,"\u23F3 Renaming...",!0),parent.postMessage({pluginMessage:{type:"rename-node",issue:e,newName:u}},"*")}}function gn(e){let t=document.createElement("div");t.className="modal-overlay",t.id="create-component-modal-overlay";let o=document.createElement("div");o.className="modal-dialog",o.style.maxWidth="400px",o.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Create New Component</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <label style="display: block; margin-bottom: 8px; font-size: 13px; font-weight: 600; color: #333;">Component Name:</label>
          <input type="text" id="create-component-name-input" placeholder="Enter component name" style="width: 100%; padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px;" value="${d(e.nodeName||"")}">
        </div>
        <p style="color: #666; font-size: 12px; margin-top: 12px;">
          This will convert the frame to a component and replace all duplicate frames with instances of this component.
        </p>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="create-component-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="create-component-apply-btn">Create</button>
      </div>
    `,t.appendChild(o),document.body.appendChild(t);let s=o.querySelector("#create-component-cancel-btn"),n=o.querySelector("#create-component-apply-btn"),l=o.querySelector(".modal-close"),a=o.querySelector("#create-component-name-input");setTimeout(()=>a.focus(),100);let i=()=>{t.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{t.parentNode&&t.remove()},200)};s.onclick=i,l.onclick=i,t.onclick=r=>{r.target===t&&i()},n.onclick=()=>{let r=a.value.trim();if(!r){alert("Please enter a component name");return}i(),X(e.id,"\u23F3 Creating component...",!0),parent.postMessage({pluginMessage:{type:"create-component-from-issue",issue:e,componentName:r}},"*")}}function mn(e,t){if(console.log("[showComponentSuggestModal] Called with",{issue:e,similarComponents:t}),!t||t.length===0){console.warn("[showComponentSuggestModal] No similar components provided"),alert("No similar components found.");return}let o=t[0];console.log("[showComponentSuggestModal] Using best match:",o),to(e,o,"This is the most similar component found.")}function yn(e,t){if(console.log("[showComponentSelectModal] Called with",{issue:e,components:t}),!t||t.length===0){console.warn("[showComponentSelectModal] No components provided"),alert("No components available.");return}let o=document.createElement("div");o.className="modal-overlay",o.id="component-select-modal-overlay";let s=document.createElement("div");s.className="modal-dialog",s.style.maxWidth="500px";let n=t.map(b=>`
        <div class="component-picker-item" data-component-id="${b.id}" data-component-name="${d(b.name.toLowerCase())}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 2px solid #ddd;
          border-radius: 8px;
          cursor: pointer;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='#ddd'; this.style.boxShadow='none'">
          <div style="font-weight: 600; font-size: 14px; color: #333;">${d(b.name)}</div>
          <div style="font-size: 11px; color: #666; margin-top: 4px;">
            ${b.description||"Component"}
          </div>
        </div>
      `).join(""),l=t.length>5,a=l?`
      <div style="margin-bottom: 16px;">
        <input type="text" id="component-search-input" placeholder="Search components by name..." style="
          width: 100%;
          padding: 8px 12px;
          border: 1px solid #ddd;
          border-radius: 6px;
          font-size: 13px;
          box-sizing: border-box;
        " autocomplete="off">
        <div id="component-search-results-count" style="font-size: 11px; color: #666; margin-top: 4px; display: none;"></div>
      </div>
    `:"";s.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Select Component</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        ${a}
        <div id="component-list-container" style="max-height: 400px; overflow-y: auto;">
          ${n}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="component-select-cancel-btn">Cancel</button>
      </div>
    `,o.appendChild(s),document.body.appendChild(o),console.log("[showComponentSelectModal] Modal added to DOM"),console.log("[showComponentSelectModal] Overlay element:",o),console.log("[showComponentSelectModal] Dialog element:",s),o.style.display="flex",o.style.opacity="1",o.style.zIndex="10000";let i=s.querySelector("#component-select-cancel-btn"),r=s.querySelector(".modal-close"),p=s.querySelectorAll(".component-picker-item"),u=s.querySelector("#component-search-input"),m=s.querySelector("#component-list-container"),y=s.querySelector("#component-search-results-count");console.log("[showComponentSelectModal] Found",p.length,"component items"),console.log("[showComponentSelectModal] Cancel button:",i,"Close button:",r),u&&l&&(u.addEventListener("input",b=>{let S=b.target.value.toLowerCase().trim(),x=0;p.forEach(E=>{let w=E.getAttribute("data-component-name")||"";S===""||w.includes(S)?(E.style.display="block",x++):E.style.display="none"}),y&&(S!==""?(y.textContent=`Showing ${x} of ${t.length} components`,y.style.display="block"):y.style.display="none")}),setTimeout(()=>u.focus(),100));let g=()=>{console.log("[showComponentSelectModal] Closing modal"),o.style.animation="fadeIn 0.2s ease-out reverse",o.style.opacity="0",setTimeout(()=>{o.parentNode&&(o.remove(),console.log("[showComponentSelectModal] Modal removed from DOM"))},200)};i?i.onclick=b=>{b.preventDefault(),b.stopPropagation(),g()}:console.error("[showComponentSelectModal] Cancel button not found!"),r?r.onclick=b=>{b.preventDefault(),b.stopPropagation(),g()}:console.error("[showComponentSelectModal] Close button not found!"),o.onclick=b=>{b.target===o&&g()},p.forEach((b,S)=>{b.onclick=x=>{x.preventDefault(),x.stopPropagation(),console.log("[showComponentSelectModal] Component item clicked",S);let E=b.getAttribute("data-component-id");console.log("[showComponentSelectModal] Component ID:",E);let w=t.find(H=>H.id===E);console.log("[showComponentSelectModal] Found component:",w),w?(g(),to(e,w,null)):console.error("[showComponentSelectModal] Component not found for ID:",E)}}),setTimeout(()=>{o.style.animation="fadeIn 0.2s ease-out",o.style.opacity="1",console.log("[showComponentSelectModal] Animation triggered, overlay visible:",o.offsetParent!==null)},10),console.log("[showComponentSelectModal] Modal setup complete")}function to(e,t,o){let s=document.createElement("div");s.className="modal-overlay",s.id="component-apply-confirm-modal-overlay";let n=document.createElement("div");n.className="modal-dialog",n.style.maxWidth="400px",n.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Component</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <p style="margin-bottom: 12px; color: #666; font-size: 13px;">
            This will replace the frame with an instance of the selected component.
          </p>
          <div style="padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-size: 12px; color: #1976d2; margin-bottom: 8px;"><strong>Selected Component:</strong></div>
            <div style="font-size: 14px; color: #333; font-weight: 600;">${d(t.name)}</div>
            ${t.description?`<div style="font-size: 11px; color: #666; margin-top: 4px;">${d(t.description)}</div>`:""}
          </div>
          ${o?`<p style="color: #666; font-size: 12px; margin-top: 12px;">${d(o)}</p>`:""}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="component-apply-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-primary" id="component-apply-apply-btn">Apply</button>
      </div>
    `,s.appendChild(n),document.body.appendChild(s);let l=n.querySelector("#component-apply-cancel-btn"),a=n.querySelector("#component-apply-apply-btn"),i=n.querySelector(".modal-close"),r=()=>{s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove()},200)};l.onclick=r,i.onclick=r,s.onclick=p=>{p.target===s&&r()},a.onclick=()=>{r(),X(e.id,"\u23F3 Applying component...",!0),parent.postMessage({pluginMessage:{type:"apply-component-to-issue",issue:e,componentId:t.id}},"*")}}function je(e){if(!e||!e.fontSize)return null;let t=e.fontSize,o=14,s=document.getElementById("font-size-scale");if(s&&s.value.trim()){let n=s.value.split(",").map(l=>parseInt(l.trim(),10)).filter(l=>!isNaN(l)&&l>=o).sort((l,a)=>l-a);if(n.length>0){let l=null,a=1/0;n.forEach(r=>{if(r>=o){let p=Math.abs(r-t);p<a&&(a=p,l=r)}});let i=Math.max(t*.5,10);if(l&&a<=i)return l}}return t<o?o:null}function Qe(e){if(!e||!e.textColor||!e.backgroundColor)return null;let t=e.textColor.toUpperCase(),o=e.backgroundColor.toUpperCase(),s=e.minContrast||4.5,n=document.getElementById("color-scale");if(!n||!n.value.trim())return null;let l=n.value.split(",").map(p=>p.trim().toUpperCase()).filter(p=>p&&p.startsWith("#"));if(l.length===0)return null;let a=null,i=0,r=1/0;return l.forEach(p=>{let u=Mt(p,o);if(u>=s){let m=Et(t,p);(u>i||u===i&&m<r)&&(i=u,a=p,r=m)}}),a}function oo(e,t){if(!t||t.length===0){alert("No text styles found in Figma. Please create text styles first.");return}let o=document.createElement("div");o.className="modal-overlay",o.id="text-style-picker-typography-modal-overlay";let s=document.createElement("div");s.className="modal-dialog",s.style.maxWidth="500px";let n=e.nodeProps||{},l=n.fontFamily||"Unknown",a=n.fontSize!==null&&n.fontSize!==void 0?`${n.fontSize}px`:"Unknown",i=n.fontWeight||"Unknown",r=n.lineHeight||"Unknown",p=n.letterSpacing!==null&&n.letterSpacing!==void 0?n.letterSpacing:"Unknown",u=null;e.bestMatch&&e.bestMatch.name&&(u=e.bestMatch.name);let m=t.map(x=>{let E=u===x.name;return`
        <div class="style-picker-item" data-style-id="${x.id}" data-font-size="${x.fontSize}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 2px solid ${E?"#0071e3":"#ddd"};
          border-radius: 8px;
          cursor: pointer;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='${E?"#0071e3":"#ddd"}'; this.style.boxShadow='none'">
          <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 8px;">
            <div>
              <div style="font-weight: 600; font-size: 14px; color: #333;">${d(x.name)} ${E?"\u2B50":""}</div>
              <div style="font-size: 11px; color: #666; margin-top: 4px;">
                ${d(x.fontFamily)} ${x.fontSize}px ${d(x.fontWeight)}
              </div>
            </div>
            ${E?'<div style="color: #0071e3; font-weight: 600; font-size: 12px;">Best Match</div>':""}
          </div>
          <div style="font-size: 11px; color: #666; padding-top: 8px; border-top: 1px solid #eee;">
            <div style="margin-bottom: 4px;"><strong>Details:</strong></div>
            <div style="padding-left: 8px; line-height: 1.6;">
              \u2022 Font Family: <code>${d(x.fontFamily)}</code><br>
              \u2022 Font Size: <code>${x.fontSize}px</code><br>
              \u2022 Font Weight: <code>${d(x.fontWeight)}</code><br>
              \u2022 Line Height: <code>${d(x.lineHeight)}</code><br>
              \u2022 Letter Spacing: <code>${d(x.letterSpacing||"0")}</code>
            </div>
          </div>
        </div>
      `}).join("");s.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Text Style</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Properties:</strong></div>
          <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
            \u2022 Font Family: <code>${d(l)}</code><br>
            \u2022 Font Size: <code>${d(a)}</code><br>
            \u2022 Font Weight: <code>${d(i)}</code><br>
            \u2022 Line Height: <code>${d(r)}</code><br>
            \u2022 Letter Spacing: <code>${d(p)}</code>
          </div>
        </div>
        <div style="max-height: 400px; overflow-y: auto;">
          ${m}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="text-style-picker-typography-modal-cancel-btn">Cancel</button>
      </div>
    `,o.appendChild(s),document.body.appendChild(o);let y=s.querySelector("#text-style-picker-typography-modal-cancel-btn"),g=s.querySelector(".modal-close"),b=s.querySelectorAll(".style-picker-item"),S=()=>{o.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{o.parentNode&&o.remove()},200)};y.onclick=S,g.onclick=S,o.onclick=x=>{x.target===o&&S()},b.forEach(x=>{x.onclick=E=>{E.preventDefault(),E.stopPropagation();let w=x.getAttribute("data-style-id"),H=t.find(D=>D.id===w);H&&(o.style.display="none",fn(e,H,o))}})}function fn(e,t,o){let s=document.createElement("div");s.className="modal-overlay",s.id="typography-style-confirm-modal-overlay";let n=document.createElement("div");n.className="modal-dialog",n.style.maxWidth="500px";let l=e.nodeProps||{},a=l.fontFamily||"Unknown",i=l.fontSize!==null&&l.fontSize!==void 0?`${l.fontSize}px`:"Unknown",r=l.fontWeight||"Unknown",p=l.lineHeight||"Unknown",u=l.letterSpacing!==null&&l.letterSpacing!==void 0?l.letterSpacing:"Unknown";n.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Text Style Application</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Apply Text Style:</div>
          <div style="padding: 12px; background: #e3f2fd; border-left: 3px solid #0071e3; border-radius: 6px;">
            <div style="font-weight: 600; font-size: 16px; color: #333; margin-bottom: 8px;">${d(t.name)}</div>
            <div style="font-size: 12px; color: #666; line-height: 1.6;">
              \u2022 Font Family: <code>${d(t.fontFamily)}</code><br>
              \u2022 Font Size: <code>${t.fontSize}px</code><br>
              \u2022 Font Weight: <code>${d(t.fontWeight)}</code><br>
              \u2022 Line Height: <code>${d(t.lineHeight)}</code><br>
              \u2022 Letter Spacing: <code>${d(t.letterSpacing||"0")}</code>
            </div>
          </div>
        </div>
        <div style="padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 8px;"><strong>Current Properties:</strong></div>
          <div style="font-size: 11px; color: #666; padding-left: 8px; line-height: 1.6;">
            \u2022 Font Family: <code>${d(a)}</code><br>
            \u2022 Font Size: <code>${d(i)}</code><br>
            \u2022 Font Weight: <code>${d(r)}</code><br>
            \u2022 Line Height: <code>${d(p)}</code><br>
            \u2022 Letter Spacing: <code>${d(u)}</code>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="typography-style-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="typography-style-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,s.appendChild(n),document.body.appendChild(s);let m=n.querySelector("#typography-style-confirm-cancel-btn"),y=n.querySelector("#typography-style-confirm-apply-btn"),g=n.querySelector(".modal-close"),b=()=>{s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove(),o&&o.parentNode&&(o.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{o.parentNode&&o.remove()},200))},200)},S=()=>{s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove(),o&&(o.style.display="flex")},200)};m.onclick=S,g.onclick=S,s.onclick=x=>{x.target===s&&S()},y.onclick=()=>{b(),X(e.id,"\u23F3 Applying style...",!0),po(e,t)}}function hn(e,t){let o=t.filter(u=>u.fontSize>=14);if(o.length===0){let u=je(e);u?xt(e,e.fontSize||12,u,null,null):alert("No text styles found with fontSize >= 14px. Please add font sizes to Font Size input or create text styles in Figma.");return}let s=document.createElement("div");s.className="modal-overlay",s.id="text-style-picker-modal-overlay";let n=document.createElement("div");n.className="modal-dialog",n.style.maxWidth="400px";let l=o.map(u=>`
        <div class="style-picker-item" data-style-id="${u.id}" data-font-size="${u.fontSize}" style="
          padding: 12px;
          margin-bottom: 8px;
          border: 2px solid #ddd;
          border-radius: 8px;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: white;
          transition: all 0.2s;
        " onmouseover="this.style.borderColor='#0071e3'; this.style.boxShadow='0 2px 8px rgba(0,113,227,0.2)'" onmouseout="this.style.borderColor='#ddd'; this.style.boxShadow='none'">
          <div>
            <div style="font-weight: 600; font-size: 14px; color: #333;">${d(u.name)}</div>
            <div style="font-size: 12px; color: #666; margin-top: 4px;">
              ${d(u.fontFamily)} ${d(u.fontSize)}px ${d(u.fontWeight)}
            </div>
          </div>
          <div style="color: #28a745; font-weight: 600; font-size: 12px;">\u2713 ADA</div>
        </div>
      `).join("");n.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Text Style</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")} - Select style with fontSize >= 14px</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Font Size:</div>
          <div style="font-size: 16px; font-weight: 600; color: #333;">${e.fontSize||12}px</div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${l}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="text-style-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,s.appendChild(n),document.body.appendChild(s);let a=n.querySelector("#text-style-picker-modal-cancel-btn"),i=n.querySelector(".modal-close"),r=n.querySelectorAll(".style-picker-item"),p=()=>{s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove()},200)};a.onclick=p,i.onclick=p,s.onclick=u=>{u.target===s&&p()},r.forEach(u=>{u.onclick=m=>{m.preventDefault(),m.stopPropagation();let y=u.getAttribute("data-style-id"),g=parseInt(u.getAttribute("data-font-size")),b=o.find(S=>S.id===y);b&&(s.style.display="none",xt(e,e.fontSize||12,g,s,b))}})}function bn(e,t){let o=document.getElementById("color-scale"),s=o&&o.value.trim()?o.value.split(",").map(S=>S.trim().toUpperCase()).filter(S=>S&&S.startsWith("#")):[],n=[];if(t.filter(S=>S.source==="variable").forEach(S=>{n.push({source:"Variable",name:S.name,hex:S.hex,id:S.id,variable:S.variable})}),t.filter(S=>S.source==="style").forEach(S=>{n.push({source:"Style",name:S.name,hex:S.hex,id:S.id,style:S.style})}),s.forEach(S=>{let x=W[S]||S;n.push({source:"Input",name:x,hex:S,id:null})}),n.length===0){alert("No colors available. Please add colors to Color input or create color styles/variables in Figma.");return}let l=e.backgroundColor||"#FFFFFF",a=e.minContrast||4.5,i=e.textColor||"#000000",r=document.createElement("div");r.className="modal-overlay",r.id="contrast-color-picker-modal-overlay";let p=document.createElement("div");p.className="modal-dialog",p.style.maxWidth="400px";let u=n.map(S=>{let x=Mt(S.hex,l),E=x>=a,w=E?"#28a745":"#ddd",H=`${d(S.name)} <span style="font-size: 11px; color: #666;">(${d(S.source)})</span>`,D=`<span style="color: ${E?"#28a745":"#dc3545"};">Contrast: ${x.toFixed(2)}:1 ${E?"\u2713":"\u2717"} (need >= ${a}:1)</span>`;return Ut(S.hex,H,w,D)}).join("");p.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Choose Color</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")} - Select color that passes contrast</p>
      </div>
      <div class="modal-body">
        <div style="margin-bottom: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px;">
          <div style="font-size: 12px; color: #666; margin-bottom: 4px;">Current Text Color:</div>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div style="width: 32px; height: 32px; border-radius: 4px; background: ${d(i)}; border: 1px solid #ddd;"></div>
            <div style="font-family: 'SF Mono', Monaco, monospace; font-size: 13px; font-weight: 600;">${d(i)}</div>
            <div style="font-size: 11px; color: #dc3545;">Contrast: ${e.contrast?e.contrast.toFixed(2):"N/A"}:1 (fails)</div>
          </div>
          <div style="font-size: 11px; color: #666; margin-top: 4px;">Background: ${d(l)}</div>
        </div>
        <div style="max-height: 300px; overflow-y: auto;">
          ${u}
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="contrast-color-picker-modal-cancel-btn">Cancel</button>
      </div>
    `,r.appendChild(p),document.body.appendChild(r);let m=p.querySelector("#contrast-color-picker-modal-cancel-btn"),y=p.querySelector(".modal-close"),g=p.querySelectorAll(".color-picker-item"),b=()=>{r.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{r.parentNode&&r.remove()},200)};m.onclick=b,y.onclick=b,r.onclick=S=>{S.target===r&&b()},g.forEach(S=>{S.onclick=x=>{x.preventDefault(),x.stopPropagation();let E=S.getAttribute("data-color");r.style.display="none",so(e,i,E,r)}})}function no(e){parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:e.id}},"*"),window.pendingTextSizeIssue=e}function Ft(e){parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:e.id}},"*"),window.pendingSuggestTextSizeIssue=e}function xt(e,t,o,s,n){let l=document.createElement("div");l.className="modal-overlay",l.id="text-size-fix-confirm-modal-overlay";let a=document.createElement("div");a.className="modal-dialog",a.style.maxWidth="400px";let i=window.pendingTextSizeFixAllCallbacks||null,r=i&&i.progress?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${i.progress.current}/${i.progress.total}</div>`:"",p=n?`
      <div style="margin-top: 16px; padding: 12px; background: #e8f5e9; border-radius: 6px; border-left: 3px solid #28a745;">
        <div style="font-size: 12px; color: #666; margin-bottom: 4px;">\u{1F4DD} Text Style s\u1EBD \u0111\u01B0\u1EE3c \xE1p d\u1EE5ng:</div>
        <div style="font-weight: 600; font-size: 14px; color: #333;">${d(n.name)}</div>
        <div style="font-size: 11px; color: #666; margin-top: 4px;">
          ${d(n.fontFamily)} ${n.fontSize}px ${d(n.fontWeight)}
        </div>
      </div>
    `:"";a.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Text Size Change</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${r}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Change font size from:</div>
          <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="font-weight: 600; font-size: 18px; color: #333;">${t}px</div>
            <div style="font-size: 12px; color: #999;">(Too small)</div>
          </div>
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">To:</div>
          <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #e3f2fd; border-radius: 6px;">
            <div style="font-weight: 600; font-size: 18px; color: #0071e3;">${o}px</div>
            <div style="font-size: 12px; color: #28a745;">\u2713 ADA compliant (>= 14px)</div>
          </div>
        </div>
        ${p}
      </div>
      <div class="modal-footer">
        ${window.pendingTextSizeFixAllCallbacks?'<button class="modal-btn modal-btn-cancel" id="text-size-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="text-size-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="text-size-fix-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,l.appendChild(a),document.body.appendChild(l);let u=a.querySelector("#text-size-fix-confirm-cancel-btn"),m=a.querySelector("#text-size-fix-confirm-apply-btn"),y=a.querySelector("#text-size-fix-ignore-btn"),g=a.querySelector(".modal-close"),b=i,S=()=>{l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove(),s&&(s.style.display="block")},200)},x=()=>{l.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{l.parentNode&&l.remove(),s&&s.parentNode&&(s.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{s.parentNode&&s.remove()},200))},200)};u.onclick=()=>{b&&b.onCancel?(x(),window.pendingTextSizeFixAllCallbacks=null,b.onCancel()):S()},g.onclick=()=>{b&&b.onCancel?(x(),window.pendingTextSizeFixAllCallbacks=null,b.onCancel()):S()},l.onclick=E=>{E.target===l&&(b&&b.onCancel?(x(),window.pendingTextSizeFixAllCallbacks=null,b.onCancel()):S())},y&&(y.onclick=()=>{x(),b&&b.onIgnore&&(window.pendingTextSizeFixAllCallbacks=null,b.onIgnore())}),m.onclick=()=>{x(),X(e.id,"\u23F3 Fixing text size...",!0),n&&n.id?parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:e,styleId:n.id,styleName:n.name}},"*"):parent.postMessage({pluginMessage:{type:"fix-text-size-issue",issue:e,fontSize:o}},"*"),b&&b.onApply&&(window.pendingTextSizeFixAllCallbacks=null,b.onApply())}}function lo(e){parent.postMessage({pluginMessage:{type:"get-contrast-colors",issue:e}},"*"),window.pendingContrastIssue=e}function Tt(e){let t=Qe(e);if(!t){alert("No suitable color found that passes contrast requirements");return}so(e,e.textColor,t,null)}function so(e,t,o,s){let n=W[o]||o,l=e.backgroundColor||"#FFFFFF",a=e.minContrast||4.5,i=Mt(o,l),r=window.pendingContrastFixAllCallbacks||null,p=r&&r.progress?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${r.progress.current}/${r.progress.total}</div>`:"",u=document.createElement("div");u.className="modal-overlay",u.id="contrast-fix-confirm-modal-overlay";let m=document.createElement("div");m.className="modal-dialog",m.style.maxWidth="400px",m.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Confirm Color Change</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${p}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Change text color from:</div>
          <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #f5f5f5; border-radius: 6px; margin-bottom: 12px;">
            <div style="width: 48px; height: 48px; border-radius: 6px; background: ${d(t)}; border: 2px solid #ddd;"></div>
            <div>
              <div style="font-weight: 600; font-size: 14px; color: #333;">${d(t)}</div>
              <div style="font-size: 11px; color: #dc3545;">Contrast: ${e.contrast?e.contrast.toFixed(2):"N/A"}:1 (fails)</div>
            </div>
          </div>
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">To:</div>
          <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #e3f2fd; border-radius: 6px; margin-bottom: 12px;">
            <div style="width: 48px; height: 48px; border-radius: 6px; background: ${d(o)}; border: 2px solid #0071e3;"></div>
            <div>
              <div style="font-weight: 600; font-size: 14px; color: #333;">${d(n)}</div>
              <div style="font-size: 11px; color: #666; font-family: 'SF Mono', Monaco, monospace;">${d(o)}</div>
              <div style="font-size: 11px; color: #28a745; margin-top: 4px;">Contrast: ${i.toFixed(2)}:1 \u2713 (passes >= ${a}:1)</div>
            </div>
          </div>
          <div style="padding: 8px; background: #f0f0f0; border-radius: 4px; font-size: 11px; color: #666;">
            Background: ${d(l)}
          </div>
        </div>
      </div>
      <div class="modal-footer">
        ${window.pendingContrastFixAllCallbacks?'<button class="modal-btn modal-btn-cancel" id="contrast-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="contrast-fix-confirm-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="contrast-fix-confirm-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,u.appendChild(m),document.body.appendChild(u);let y=m.querySelector("#contrast-fix-confirm-cancel-btn"),g=m.querySelector("#contrast-fix-confirm-apply-btn"),b=m.querySelector("#contrast-fix-ignore-btn"),S=m.querySelector(".modal-close"),x=r,E=()=>{u.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{u.parentNode&&u.remove(),s&&(s.style.display="block")},200)};y.onclick=()=>{x&&x.onCancel?(E(),window.pendingContrastFixAllCallbacks=null,x.onCancel()):E()},S.onclick=()=>{x&&x.onCancel?(E(),window.pendingContrastFixAllCallbacks=null,x.onCancel()):E()},u.onclick=w=>{w.target===u&&(x&&x.onCancel?(E(),window.pendingContrastFixAllCallbacks=null,x.onCancel()):E())},b&&(b.onclick=()=>{E(),x&&x.onIgnore&&(window.pendingContrastFixAllCallbacks=null,x.onIgnore())}),g.onclick=()=>{E(),X(e.id,"\u23F3 Fixing contrast...",!0),parent.postMessage({pluginMessage:{type:"fix-contrast-issue",issue:e,color:o}},"*"),x&&x.onApply&&(window.pendingContrastFixAllCallbacks=null,x.onApply())}}function io(e){try{if(Q[e.id]===!0){if(delete Q[e.id],k&&k.issues){let o=k.issues.find(s=>s.id===e.id);if(o){o.ignored=!1;let s=o.originalSeverity||(o.severity==="info"?"error":o.severity);o.severity=s,o.originalSeverity=void 0,e.severity=s,e.ignored=!1}}ie(),ao(e,!1),et(),parent.postMessage({pluginMessage:{type:"notify",message:"\u2705 Issue un-ignored"}},"*")}else{if(!confirm(`Ignore this contrast issue?

Node: ${e.nodeName||"Unnamed"}

This issue will be marked as "Pass with ignore custom" and won't be counted as an error.`))return;if(k&&k.issues){let o=k.issues.find(s=>s.id===e.id);o&&(o.originalSeverity||(o.originalSeverity=o.severity),o.ignored=!0,o.severity="info",e.ignored=!0,e.originalSeverity=o.originalSeverity,e.severity="info")}Q[e.id]=!0,ie(),ao(e,!0),et(),parent.postMessage({pluginMessage:{type:"notify",message:"\u2705 Issue ignored"}},"*")}}catch(t){console.error("Error in handleIgnoreIssue:",t),parent.postMessage({pluginMessage:{type:"notify",message:`\u274C Error: ${t.message}`}},"*")}}function ao(e,t){let o=document.querySelector(`.issue[data-issue-id="${e.id}"]`);if(o)if(t){let s=e.originalSeverity||"error";o.className=o.className.replace(/\b(error|warn)\b/g,"info");let n=o.querySelector(".issue-type");if(n){let a=n.querySelector(".issue-number");if(a){let i=a.textContent;n.innerHTML=`<span class="issue-number">${i}</span> \u2139\uFE0F INFO`}else n.innerHTML=n.innerHTML.replace(/❌|⚠️/g,"\u2139\uFE0F").replace(/ERROR|WARNING/g,"INFO")}if(!o.querySelector(".issue-ignored-tag")){let a=o.querySelector(".issue-body"),i=o.querySelector(".issue-node"),r=document.createElement("div");if(r.className="issue-ignored-tag",r.style.cssText="margin-top: 4px; padding: 4px 8px; background: #e3f2fd; color: #28a745; border-radius: 4px; font-size: 11px; font-weight: 600; display: inline-block;",r.textContent="\u2713 Pass with ignore custom",i)i.parentNode.insertBefore(r,i.nextSibling);else if(a)a.parentNode.insertBefore(r,a.nextSibling);else{let p=o.querySelector(".issue-header");p?p.parentNode.insertBefore(r,p.nextSibling):o.appendChild(r)}}let l=document.querySelector(`button.btn-ignore[data-id="${e.id}"]`);l&&(l.removeAttribute("disabled"),l.innerHTML="Ignored",l.style.cssText="padding: 6px 12px; border: 1px solid #28a745; background: #28a745; border-radius: 6px; font-size: 12px; font-weight: 500; cursor: pointer; transition: all 0.2s; color: white;")}else{let s=e.originalSeverity||(e.severity==="info"?"error":e.severity);o.className=o.className.replace(/\binfo\b/g,s);let n=o.querySelector(".issue-type");if(n){let i=s==="error"?"\u274C":s==="warn"?"\u26A0\uFE0F":"\u2139\uFE0F",r=s.toUpperCase(),p=n.querySelector(".issue-number");if(p){let u=p.textContent;n.innerHTML=`<span class="issue-number">${u}</span> ${i} ${r}`}else n.innerHTML=n.innerHTML.replace(/ℹ️/g,i).replace(/INFO/g,r)}let l=o.querySelector(".issue-ignored-tag");l&&l.remove();let a=document.querySelector(`button.btn-ignore[data-id="${e.id}"]`);a&&(a.removeAttribute("disabled"),a.innerHTML="Ignore",a.style.cssText="padding: 6px 12px; border: 1px solid #6c757d; background: #6c757d; border-radius: 6px; font-size: 12px; font-weight: 500; cursor: pointer; transition: all 0.2s; color: white;")}}function et(){if(!k||!k.issues)return;let e=k.issues,t={error:e.filter(s=>s.severity==="error"&&!s.ignored).length,warn:e.filter(s=>s.severity==="warn"&&!s.ignored).length,total:e.length},o=document.querySelector(".results-header");if(o){let s=o.querySelector(".results-stats");s&&(s.innerHTML=`
          ${t.error>0?`<span class="stat error">${t.error} Error</span>`:""}
          ${t.warn>0?`<span class="stat warn">${t.warn} Warning</span>`:""}
          <span class="stat">${t.total} Total</span>
        `)}document.querySelectorAll(".issue-group").forEach(s=>{let n=s.querySelector(".badge");if(n){let l=s.getAttribute("data-issue-type");if(l){let i=e.filter(r=>r.type===l).filter(r=>r.ignored?!1:r.severity==="error"||r.severity==="warn").length;n.textContent=i}}})}function vn(e){let t=e.message||"",o=t.match(/Padding\s+(\w+)\s+\((\d+)px\)/),s=null,n=null;if(o?(s=o[1],n=parseInt(o[2])):(o=t.match(/Gap\s+\(itemSpacing:\s+(\d+)px\)/),o&&(s="itemSpacing",n=parseInt(o[1]))),!o||!s||n===null){console.error("Cannot parse spacing issue message:",t),alert("Cannot determine spacing property from issue message. Message: "+t);return}let l=document.getElementById("spacing-scale");if(!l||!l.value.trim()){alert("No spacing scale defined. Please add spacing values to the Spacing input.");return}let a=l.value.split(",").map(i=>parseInt(i.trim(),10)).filter(i=>!isNaN(i)&&i>=0).sort((i,r)=>i-r);if(a.length===0){alert("No valid spacing values found in Spacing input.");return}Jo(e,s,n,a)}function xn(e){let o=(e.message||"").match(/Color (#[0-9A-Fa-f]{6})/),s=o?o[1].toUpperCase():null;if(!s){alert("Cannot determine current color from issue message");return}let n=document.getElementById("color-scale");if(!n||!n.value.trim()){alert("No color scale defined. Please add colors to the Color input.");return}let l=n.value.split(",").map(a=>a.trim().toUpperCase()).filter(a=>a&&a.startsWith("#"));if(l.length===0){alert("No valid colors found in Color input.");return}Yo(e,s,l,W)}function Sn(e){var t;if(e.type==="typography-check"&&e.bestMatch){Go(e,B);return}if(X(e.id,"\u23F3 Fixing...",!0),!e.bestMatch&&e.type!=="typography-check"){let o=prompt(`Cannot auto-fix this issue.

Issue: ${e.message}

Please provide fix instructions or press Cancel.`);if(o)parent.postMessage({pluginMessage:{type:"fix-issue",issue:e,manualFix:o}},"*");else{let s=document.querySelector(`.issue[data-issue-id="${e.id}"]`)||((t=document.querySelector(`button.btn-fix[data-id="${e.id}"]`))==null?void 0:t.closest(".issue"));if(s){let n=s.querySelector(".fix-message");n&&n.remove()}}return}parent.postMessage({pluginMessage:{type:"fix-issue",issue:e}},"*")}function ro(e,t){let o=document.createElement("div");o.className="modal-overlay",o.id="create-style-modal-overlay";let s=document.createElement("div");s.className="modal-dialog";let n=e.nodeName||"Unnamed";if(e.message&&e.message.includes("(")&&e.message.includes("nodes")){let u=e.message.match(/\((\d+) nodes\)/);u&&(n=`${n} (${u[1]} nodes)`)}s.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Create Style</h2>
        <p class="modal-subtitle">${d(n)}</p>
      </div>
      <div class="modal-body">
        <input 
          type="text" 
          class="modal-input" 
          id="style-name-input" 
          placeholder="Style Name" 
          value="${d(e.nodeName||"New Style")}"
          autofocus
        />
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="modal-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="modal-create-btn">Create</button>
      </div>
    `,o.appendChild(s),document.body.appendChild(o);let l=s.querySelector("#style-name-input"),a=s.querySelector("#modal-cancel-btn"),i=s.querySelector("#modal-create-btn"),r=s.querySelector(".modal-close");setTimeout(()=>{l.focus(),l.select()},100),l.onkeydown=u=>{u.key==="Enter"?(u.preventDefault(),i.click()):u.key==="Escape"&&(u.preventDefault(),a.click())};let p=()=>{o.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{o.parentNode&&o.remove()},200)};a.onclick=p,r.onclick=p,o.onclick=u=>{u.target===o&&p()},i.onclick=()=>{let u=l.value.trim();if(!u){l.focus(),l.style.borderColor="#ff3b30",setTimeout(()=>{l.style.borderColor="#0071e3"},2e3);return}p(),t&&t(u)}}function co(e,t,o={}){if(console.log("[showSuggestApplyModal] Called with issue:",e,"styleName:",t,"options:",o),!e||!t){console.error("[showSuggestApplyModal] Missing issue or styleName:",{issue:e,styleName:t});return}let{onApply:s,onIgnore:n,onCancel:l,showIgnore:a=!1,progress:i}=o;console.log("[showSuggestApplyModal] Looking for style:",t,"in typographyStyles:",B);let r=B.find(Y=>Y.name===t);if(!r){console.error("[showSuggestApplyModal] Style not found:",t),alert(`Style "${t}" not found`);return}console.log("[showSuggestApplyModal] Found style:",r);let p=e.nodeProps||{},u=p.fontFamily||"Unknown",m=p.fontSize!==null&&p.fontSize!==void 0?`${p.fontSize}px`:"Unknown",y=p.fontWeight||"Unknown",g=p.lineHeight||"Unknown",b=p.letterSpacing!==null&&p.letterSpacing!==void 0?p.letterSpacing:"Unknown",S=r.fontFamily||"Unknown",x=r.fontSize?`${r.fontSize}px`:"Unknown",E=r.fontWeight||"Unknown",w=r.lineHeight||"Unknown",H=r.letterSpacing!==null&&r.letterSpacing!==void 0?r.letterSpacing:"Unknown",D=document.createElement("div");D.className="modal-overlay",D.id="suggest-apply-modal-overlay";let oe=document.createElement("div");oe.className="modal-dialog",oe.style.maxWidth="500px";let re=`
      <div style="margin-top: 16px; font-size: 13px;">
        <div style="margin-bottom: 12px; font-weight: 600; color: #333;">Comparison:</div>
        <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
          <thead>
            <tr style="border-bottom: 1px solid #ddd;">
              <th style="text-align: left; padding: 8px; font-weight: 600; color: #666;">Property</th>
              <th style="text-align: left; padding: 8px; font-weight: 600; color: #666;">Current</th>
              <th style="text-align: left; padding: 8px; font-weight: 600; color: #28a745;">Suggested</th>
            </tr>
          </thead>
          <tbody>
            <tr style="border-bottom: 1px solid #f0f0f0;">
              <td style="padding: 8px; color: #666;">Font Family</td>
              <td style="padding: 8px;"><code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px;">${d(u)}</code></td>
              <td style="padding: 8px;"><code style="background: #d4edda; padding: 2px 6px; border-radius: 3px; color: #155724;">${d(S)}</code></td>
            </tr>
            <tr style="border-bottom: 1px solid #f0f0f0;">
              <td style="padding: 8px; color: #666;">Font Size</td>
              <td style="padding: 8px;"><code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px;">${d(m)}</code></td>
              <td style="padding: 8px;"><code style="background: #d4edda; padding: 2px 6px; border-radius: 3px; color: #155724;">${d(x)}</code></td>
            </tr>
            <tr style="border-bottom: 1px solid #f0f0f0;">
              <td style="padding: 8px; color: #666;">Font Weight</td>
              <td style="padding: 8px;"><code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px;">${d(y)}</code></td>
              <td style="padding: 8px;"><code style="background: #d4edda; padding: 2px 6px; border-radius: 3px; color: #155724;">${d(E)}</code></td>
            </tr>
            <tr style="border-bottom: 1px solid #f0f0f0;">
              <td style="padding: 8px; color: #666;">Line Height</td>
              <td style="padding: 8px;"><code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px;">${d(g)}</code></td>
              <td style="padding: 8px;"><code style="background: #d4edda; padding: 2px 6px; border-radius: 3px; color: #155724;">${d(w)}</code></td>
            </tr>
            <tr>
              <td style="padding: 8px; color: #666;">Letter Spacing</td>
              <td style="padding: 8px;"><code style="background: #f5f5f5; padding: 2px 6px; border-radius: 3px;">${d(b)}</code></td>
              <td style="padding: 8px;"><code style="background: #d4edda; padding: 2px 6px; border-radius: 3px; color: #155724;">${d(H)}</code></td>
            </tr>
          </tbody>
        </table>
      </div>
    `,ce=i?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${i.current}/${i.total}</div>`:"";oe.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Style</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${ce}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 14px; font-weight: 600; color: #333; margin-bottom: 8px;">
            Suggested Style: <span style="color: #28a745;">${d(t)}</span>
          </div>
          ${e.bestMatch&&e.bestMatch.percentage?`
            <div style="font-size: 12px; color: #666; margin-bottom: 8px;">
              Match: <strong>${e.bestMatch.percentage}%</strong>
            </div>
          `:""}
        </div>
        ${re}
      </div>
      <div class="modal-footer">
        ${a?'<button class="modal-btn modal-btn-cancel" id="suggest-modal-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>':""}
        <button class="modal-btn modal-btn-cancel" id="suggest-modal-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="suggest-modal-apply-btn" style="background: #28a745; border-color: #28a745;">Apply Style</button>
      </div>
    `,D.appendChild(oe),document.body.appendChild(D);let ye=oe.querySelector("#suggest-modal-cancel-btn"),Ne=oe.querySelector("#suggest-modal-apply-btn"),He=oe.querySelector("#suggest-modal-ignore-btn"),Z=oe.querySelector(".modal-close"),ne=()=>{D.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{D.parentNode&&D.remove()},200)};ye.onclick=()=>{ne(),a&&o.onCancel&&typeof o.onCancel=="function"&&o.onCancel()},Z.onclick=()=>{ne(),a&&o.onCancel&&typeof o.onCancel=="function"&&o.onCancel()},D.onclick=Y=>{Y.target===D&&(ne(),a&&o.onCancel&&typeof o.onCancel=="function"&&o.onCancel())},Ne.onclick=()=>{ne(),X(e.id,"\u23F3 Applying style...",!0),parent.postMessage({pluginMessage:{type:"apply-typography-style",issue:e,style:r}},"*"),s&&typeof s=="function"&&s()},He&&(He.onclick=()=>{ne(),n&&typeof n=="function"&&n()})}function kn(e,t){if(console.log("[handleFixAllWithSuggestFix] Called with type:",e,"issues:",t),!t||t.length===0){console.log("[handleFixAllWithSuggestFix] No issues to process"),alert("No issues to process");return}console.log("[handleFixAllWithSuggestFix] Processing",t.length,"issues");let o=0,s=0,n=0,l=!1;function a(){let p=`\u2705 \u0110\xE3 xong!

\u0110\xE3 x\u1EED l\xFD ${o} item(s):
\u2022 Applied: ${s}
\u2022 Ignored: ${n}`;alert(p)}function i(){if(l||o>=t.length){a();return}let r=t[o];console.log("[Fix All] Processing issue:",o+1,"of",t.length,"Issue:",r),console.log("[Fix All] Issue type:",r.type,"bestMatch:",r.bestMatch),o++,parent.postMessage({pluginMessage:{type:"select-node",id:r.id}},"*");let p={current:o,total:t.length};if(r.type==="typography-check"||r.type==="typography-style"){if(console.log("[Fix All] Typography issue - checking bestMatch:",r.bestMatch),!r.bestMatch||!r.bestMatch.name||typeof r.bestMatch.name!="string"||r.bestMatch.name.trim().length===0){console.warn("[Fix All] Issue missing bestMatch or bestMatch.name, skipping:",r),console.warn("[Fix All] Issue bestMatch value:",r.bestMatch),n++,i();return}let u=r.bestMatch&&r.bestMatch.name?r.bestMatch.name:null;if(console.log("[Fix All] Extracted styleName:",u),!u||typeof u!="string"||u.trim().length===0){console.warn("[Fix All] Issue bestMatch.name is invalid, skipping:",r),console.warn("[Fix All] styleName value:",u),n++,i();return}console.log("[Fix All] Calling showSuggestApplyModal with issue:",r.id,"styleName:",u),co(r,u,{showIgnore:!0,progress:p,onApply:()=>{s++,setTimeout(()=>{i()},500)},onIgnore:()=>{n++,i()},onCancel:()=>{l=!0,a()}})}else if(r.type==="color"){let u=at(r),y=(r.message||"").match(/Color (#[0-9A-Fa-f]{6})/),g=y?y[1].toUpperCase():null;wn(r,g,u,{progress:p,onApply:()=>{s++,setTimeout(()=>{i()},500)},onIgnore:()=>{n++,i()},onCancel:()=>{l=!0,a()}})}else if(r.type==="spacing"){let u=rt(r),y=(r.message||"").match(/Padding\s+(\w+)\s+\((\d+)px\)/);if(y){let g=y[1],b=parseInt(y[2]);Cn(r,g,b,u,{progress:p,onApply:()=>{s++,setTimeout(()=>{i()},500)},onIgnore:()=>{n++,i()},onCancel:()=>{l=!0,a()}})}else n++,i()}else r.type==="autolayout"?nn(r,{progress:p,onApply:()=>{s++,setTimeout(()=>{i()},500)},onIgnore:()=>{n++,i()},onCancel:()=>{l=!0,a()}}):r.type==="position"?cn(r,{progress:p,onApply:()=>{s++,setTimeout(()=>{i()},500)},onIgnore:()=>{n++,i()},onCancel:()=>{l=!0,a()}}):r.type==="group"?an(r,{progress:p,onApply:()=>{s++,setTimeout(()=>{i()},500)},onIgnore:()=>{n++,i()},onCancel:()=>{l=!0,a()}}):r.type==="empty-frame"?pn(r,{progress:p,onApply:()=>{s++,setTimeout(()=>{i()},500)},onIgnore:()=>{n++,i()},onCancel:()=>{l=!0,a()}}):r.type==="text-size-mobile"?(window.pendingTextSizeFixAllCallbacks={progress:p,onApply:()=>{s++,setTimeout(()=>{i()},500)},onIgnore:()=>{n++,i()},onCancel:()=>{l=!0,a()}},Ft(r)):r.type==="contrast"?(window.pendingContrastFixAllCallbacks={progress:p,onApply:()=>{s++,setTimeout(()=>{i()},500)},onIgnore:()=>{n++,i()},onCancel:()=>{l=!0,a()}},Tt(r)):(n++,i())}i()}function wn(e,t,o,s={}){let{onApply:n,onIgnore:l,onCancel:a,progress:i}=s,r=i?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${i.current}/${i.total}</div>`:"",p=document.createElement("div");p.className="modal-overlay";let u=document.createElement("div");u.className="modal-dialog",u.style.maxWidth="450px";let m=W[o]||o;u.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Color</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${r}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Color Change:</div>
          <div style="display: flex; align-items: center; gap: 16px; padding: 16px; background: #f5f5f5; border-radius: 8px;">
            <div style="text-align: center;">
              <div style="width: 64px; height: 64px; border-radius: 8px; background: ${d(t)}; border: 2px solid #ddd; margin-bottom: 8px;"></div>
              <div style="font-size: 11px; color: #666;">Current</div>
              <div style="font-size: 12px; font-weight: 600; color: #333; font-family: 'SF Mono', Monaco, monospace; margin-top: 4px;">${d(t)}</div>
            </div>
            <div style="font-size: 24px; color: #666;">\u2192</div>
            <div style="text-align: center;">
              <div style="width: 64px; height: 64px; border-radius: 8px; background: ${d(o)}; border: 2px solid #0071e3;"></div>
              <div style="font-size: 11px; color: #666;">Suggested</div>
              <div style="font-weight: 600; font-size: 14px; color: #333;">${d(m)}</div>
              <div style="font-size: 12px; color: #666; font-family: 'SF Mono', Monaco, monospace;">${d(o)}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="color-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="color-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="color-fix-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,p.appendChild(u),document.body.appendChild(p);let y=u.querySelector("#color-fix-cancel-btn"),g=u.querySelector("#color-fix-apply-btn"),b=u.querySelector("#color-fix-ignore-btn"),S=u.querySelector(".modal-close"),x=()=>{p.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{p.parentNode&&p.remove()},200)};y.onclick=()=>{x(),a&&a()},S.onclick=()=>{x(),a&&a()},p.onclick=E=>{E.target===p&&(x(),a&&a())},b.onclick=()=>{x(),l&&l()},g.onclick=()=>{x(),X(e.id,"\u23F3 Fixing color...",!0),parent.postMessage({pluginMessage:{type:"fix-color-issue",issue:e,color:o}},"*"),n&&n()}}function Cn(e,t,o,s,n={}){let{onApply:l,onIgnore:a,onCancel:i,progress:r}=n,p=r?`<div style="margin-bottom: 12px; padding: 8px 12px; background: #e3f2fd; border-radius: 6px; font-size: 13px; color: #1976d2; font-weight: 600;">Progress: ${r.current}/${r.total}</div>`:"",u=document.createElement("div");u.className="modal-overlay";let m=document.createElement("div");m.className="modal-dialog",m.style.maxWidth="450px",m.innerHTML=`
      <div class="modal-header">
        <button class="modal-close" aria-label="Close">\xD7</button>
        <h2 class="modal-title">Apply Suggested Spacing</h2>
        <p class="modal-subtitle">Node: ${d(e.nodeName||"Unnamed")}</p>
      </div>
      ${p}
      <div class="modal-body">
        <div style="margin-bottom: 16px;">
          <div style="font-size: 13px; color: #666; margin-bottom: 12px;">Spacing Change:</div>
          <div style="display: flex; align-items: center; gap: 16px; padding: 16px; background: #f5f5f5; border-radius: 8px;">
            <div style="text-align: center;">
              <div style="font-weight: 600; font-size: 18px; color: #333;">${o}px</div>
              <div style="font-size: 11px; color: #666; margin-top: 4px;">Current</div>
            </div>
            <div style="font-size: 24px; color: #666;">\u2192</div>
            <div style="text-align: center;">
              <div style="font-weight: 600; font-size: 18px; color: #333;">${s}px</div>
              <div style="font-size: 11px; color: #666; margin-top: 4px;">Suggested</div>
            </div>
          </div>
          <div style="font-size: 12px; color: #666; margin-top: 8px;">Property: <strong>${d(t)}</strong></div>
        </div>
      </div>
      <div class="modal-footer">
        <button class="modal-btn modal-btn-cancel" id="spacing-fix-ignore-btn" style="background: #6c757d; border-color: #6c757d; color: white;">Ignore</button>
        <button class="modal-btn modal-btn-cancel" id="spacing-fix-cancel-btn">Cancel</button>
        <button class="modal-btn modal-btn-create" id="spacing-fix-apply-btn" style="background: #28a745; border-color: #28a745;">Apply</button>
      </div>
    `,u.appendChild(m),document.body.appendChild(u);let y=m.querySelector("#spacing-fix-cancel-btn"),g=m.querySelector("#spacing-fix-apply-btn"),b=m.querySelector("#spacing-fix-ignore-btn"),S=m.querySelector(".modal-close"),x=()=>{u.style.animation="fadeIn 0.2s ease-out reverse",setTimeout(()=>{u.parentNode&&u.remove()},200)};y.onclick=()=>{x(),i&&i()},S.onclick=()=>{x(),i&&i()},u.onclick=E=>{E.target===u&&(x(),i&&i())},b.onclick=()=>{x(),a&&a()},g.onclick=()=>{x(),X(e.id,"\u23F3 Fixing spacing...",!0),parent.postMessage({pluginMessage:{type:"fix-spacing-issue",issue:e,propertyName:t,value:s}},"*"),l&&l()}}function po(e,t){if(!e||!t){console.error("handleApplyFigmaTextStyle: missing issue or style");return}X(e.id,"\u23F3 Applying style...",!0),parent.postMessage({pluginMessage:{type:"apply-figma-text-style",issue:e,styleId:t.id,styleName:t.name}},"*")}function Nt(e,t){if(!e||!t){console.error("handleApplyTypographyStyle: missing issue or styleName");return}co(e,t)}function uo(e){if(console.log("handleCreateTextStyle called",e),!e){console.error("handleCreateTextStyle: issue is null/undefined");return}ro(e,t=>{console.log("handleCreateTextStyle: sending message",{type:"create-text-style",issueId:e.id,styleName:t}),X(e.id,"\u23F3 Creating style...",!0),parent.postMessage({pluginMessage:{type:"create-text-style",issue:e,styleName:t}},"*")})}function On(e,t){if(e==="typography-style"){let n={nodeName:`${t.length} text node(s)`,message:`Found ${t.length} text node(s) without text style`};ro(n,l=>{t.forEach(a=>{X(a.id,"\u23F3 Creating style...",!0)}),parent.postMessage({pluginMessage:{type:"create-text-style-all",issues:t,styleName:l}},"*")});return}let o=t.filter(n=>n.bestMatch&&n.type==="typography-check"),s=t.filter(n=>!n.bestMatch||n.type!=="typography-check");if(o.length===0){alert(`No auto-fixable issues found in ${bt(e)}.

All ${t.length} issues require manual intervention.`);return}s.length>0&&!confirm(`Found ${o.length} auto-fixable issues and ${s.length} issues that require manual fix.

Do you want to auto-fix the ${o.length} issues now?

The ${s.length} issues will need to be fixed manually.`)||parent.postMessage({pluginMessage:{type:"fix-all-issues",issues:o,issueType:e}},"*")}function In(e){console.log("filterAndSearchIssues called",{totalIssues:e.length,currentFilter:we,currentSearch:ue});let t=e;if(we!=="all"&&(t=t.filter(o=>o.severity===we),console.log("After severity filter:",t.length)),ue.trim()){let o=ue.toLowerCase();t=t.filter(s=>{let n=(s.message||"").toLowerCase(),l=(s.nodeName||"").toLowerCase(),a=(s.type||"").toLowerCase();return n.includes(o)||l.includes(o)||a.includes(o)}),console.log("After search filter:",t.length)}return console.log("Final filtered issues:",t.length),t}function Pe(e=[],t=!1,o={}){let{skipSave:s=!1,restoreTimestamp:n=null}=o;Fe("issues"),document.getElementById("issues-count").textContent=e.length,e&&Array.isArray(e)&&e.forEach(w=>{Q[w.id]===!0&&(w.ignored=!0,w.originalSeverity||(w.originalSeverity=w.severity),w.severity="info")});let l=k.issues!==e;k.issues=e;let a=n||new Date().toISOString();k.timestamp=a,pt=!1,(t||l)&&(console.log("Resetting filters for new data"),we="all",ze="all",Te&&(Te.value=""),ue="",xe&&(xe.style.display="none"),pe&&pe.length>0&&pe.forEach(w=>{w.classList.remove("active"),w.getAttribute("data-filter")==="all"&&w.classList.add("active")}));let i=document.getElementById("filter-controls"),r=document.getElementById("color-type-filter"),p=document.getElementById("filter-buttons");i.style.display=e.length>0?"flex":"none",r.style.display="none",p.style.display="flex";let u=document.getElementById("export-group");u.style.display=e.length>0?"flex":"none",console.log("About to filter with:",{currentFilter:we,currentSearch:ue});let m=In(e),y=new Set;if(l||(document.querySelectorAll(".issue-group").forEach(H=>{let D=H.getAttribute("data-issue-type");D&&!H.classList.contains("collapsed")&&y.add(D)}),console.log("Saved expanded groups:",Array.from(y))),ht("issues"),m.length===0&&e.length===0){se.innerHTML=`
              <div class="empty-state success">
                <div class="icon">\u2705</div>
                <p><strong>No issues found!</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Your design passed all configured checks.</p>
              </div>
            `;return}if(m.length===0&&e.length>0&&we!=="all"){se.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F50D}</div>
                <p><strong>No results found</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Try changing the filter or search keyword.</p>
              </div>
            `;return}let g={error:m.filter(w=>w.severity==="error"&&!w.ignored).length,warn:m.filter(w=>w.severity==="warn"&&!w.ignored).length,total:m.length,originalTotal:e.length},b=document.createElement("div");b.className="results-header",b.innerHTML=`
            <h3>Check Result</h3>
            <div class="results-stats">
              ${g.error>0?`<span class="stat error">${g.error} Error</span>`:""}
              ${g.warn>0?`<span class="stat warn">${g.warn} Warning</span>`:""}
              <span class="stat">${g.total} Total</span>
              ${g.originalTotal!==g.total?`<span class="stat" style="opacity: 0.6;">(${g.originalTotal} total)</span>`:""}
            </div>
          `,se.appendChild(b);let S=m.reduce((w,H)=>(w[H.type]=w[H.type]||[],w[H.type].push(H),w),{}),x=e.reduce((w,H)=>(w[H.type]=w[H.type]||[],w[H.type].push(H),w),{}),E=["naming","autolayout","spacing","color","typography","typography-style","typography-check","line-height","position","duplicate","group","component","empty-frame","nested-group","contrast","text-size-mobile"];for(let w of E){let H=S[w]||[],D=H.length,oe=H.filter(c=>c.ignored?!1:c.severity==="error"||c.severity==="warn").length;if(D===0&&e.length===0||D===0&&we!=="all")continue;let re=document.createElement("div"),ce=y.has(w);re.className=ce?"issue-group":"issue-group collapsed",re.setAttribute("data-issue-type",w);let ye=document.createElement("div");ye.className="issue-group-header";let Ne=(x[w]||[]).some(c=>{try{if(!c)return!1;switch(c.type){case"color":return at(c)!==null;case"spacing":return rt(c)!==null;case"autolayout":return typeof Xe=="function"&&Xe(c)!==null;case"text-size-mobile":return typeof je=="function"&&je(c)!==null;case"contrast":return typeof Qe=="function"&&Qe(c)!==null;case"typography-style":case"typography-check":let le=c.bestMatch&&c.bestMatch!==null&&c.bestMatch!==void 0&&c.bestMatch.name&&typeof c.bestMatch.name=="string"&&c.bestMatch.name.trim().length>0;return w==="typography-style"&&console.log("[hasSuggestFixButton] Typography-style issue",c.id,"hasBestMatch:",le,"bestMatch:",c.bestMatch),le;case"position":return typeof Ue=="function"&&Ue(c)!==null;case"duplicate":case"component":return typeof Ke=="function"&&Ke(c)!==null;case"group":return!0;case"empty-frame":return typeof Ze=="function"&&Ze(c)!==null;default:return!1}}catch(le){return console.error("[hasSuggestFixButton] Error checking issue:",c,le),!1}});w==="typography-style"&&console.log("[hasSuggestFixButton] Type:",w,"hasSuggestFixButton:",Ne,"allGrouped[type]:",x[w]),ye.innerHTML=`
              <div class="issue-group-header-left">
                <button class="issue-group-toggle" type="button">
                  <span class="issue-group-toggle-icon">\u25B6</span>
                </button>
                <h4>${Vt(w)} ${bt(w)}</h4>
                <span class="badge">${oe}</span>
              </div>
              ${D>0&&w!=="typography"&&w!=="line-height"&&w!=="naming"&&w!=="typography-style"&&w!=="component"&&w!=="duplicate"&&Ne?`<button class="btn-fix-all" data-type="${w}">Fix all now</button>`:""}
            `;let He=ye.querySelector(".issue-group-toggle"),Z=()=>{re.classList.contains("collapsed")?(re.classList.remove("collapsed"),Y.style.display="block",setTimeout(()=>{Y.style.opacity="1"},10)):(Y.style.opacity="0",setTimeout(()=>{re.classList.add("collapsed"),Y.style.display="none"},200))};He.onclick=c=>{c.stopPropagation(),Z()},ye.onclick=c=>{c.target!==He&&!He.contains(c.target)&&Z()};let ne=ye.querySelector(".btn-fix-all");console.log("[Fix All] Setting up button for type:",w,"btnFixAll found:",!!ne),ne?ne.onclick=c=>{try{console.log("[Fix All] ========== BUTTON CLICKED =========="),console.log("[Fix All] Button clicked for type:",w),console.log("[Fix All] Event:",c),c.preventDefault(),c.stopPropagation(),console.log("[Fix All] All issues in group:",x[w]),console.log("[Fix All] allGrouped[type] length:",(x[w]||[]).length);let le=(x[w]||[]).filter(G=>{if(!G)return console.log("[Fix All] Filter: issue is null/undefined"),!1;switch(console.log("[Fix All] Filter: checking issue",G.id,"type:",G.type,"bestMatch:",G.bestMatch),G.type){case"color":return at(G)!==null;case"spacing":return rt(G)!==null;case"autolayout":return typeof Xe=="function"&&Xe(G)!==null;case"text-size-mobile":return typeof je=="function"&&je(G)!==null;case"contrast":return typeof Qe=="function"&&Qe(G)!==null;case"typography-style":case"typography-check":let Me=G.bestMatch&&G.bestMatch!==null&&G.bestMatch!==void 0&&G.bestMatch.name&&typeof G.bestMatch.name=="string"&&G.bestMatch.name.trim().length>0;return console.log("[Fix All] Filter: typography issue",G.id,"hasValidBestMatch:",Me,"bestMatch:",G.bestMatch),Me;case"position":return typeof Ue=="function"&&Ue(G)!==null;case"duplicate":case"component":return typeof Ke=="function"&&Ke(G)!==null;case"group":return!0;case"empty-frame":return typeof Ze=="function"&&Ze(G)!==null;default:return!1}});if(console.log("[Fix All] Filtered issues with suggest fix:",le),console.log("[Fix All] Issues count:",le.length),console.log("[Fix All] Filtered issues count:",le.length),le.length===0){console.log("[Fix All] No issues with suggest fix available"),alert("No issues with suggest fix available");return}console.log("[Fix All] Starting handleFixAllWithSuggestFix with",le.length,"issues"),kn(w,le)}catch(le){console.error("[Fix All] ERROR in button onclick:",le),console.error("[Fix All] Error stack:",le.stack),alert("Error: "+le.message)}}:console.log("[Fix All] Button not found for type:",w),re.appendChild(ye);let Y=document.createElement("div");if(Y.className="issue-group-content",ce?(Y.style.display="block",Y.style.opacity="1"):Y.style.display="none",D===0){let c=document.createElement("div");c.className="issue info",c.style.opacity="0.7",c.innerHTML=`
                <div class="issue-header">
                  <div>
                    <span class="issue-type">\u2705 PASSED</span>
                    <div class="issue-body">No issues in this type.</div>
                  </div>
                </div>
              `,Y.appendChild(c)}else S[w].forEach((c,le)=>{let G=le+1,Me=Q[c.id]===!0;if(Me&&(c.originalSeverity||(c.originalSeverity=c.severity),c.severity="info",c.ignored=!0),c.type==="typography-check"){let A=document.createElement("div");Y.appendChild(A);let U=Qo(c);if(U){let ee=document.createElement("span");ee.className="issue-number",ee.textContent=`#${G}`,ee.style.cssText="position: absolute; left: 8px; top: 8px; font-weight: bold; opacity: 0.5; font-size: 11px;",U.style.position="relative",U.style.paddingLeft="40px",U.insertBefore(ee,U.firstChild),Y.replaceChild(U,A)}return}let _=document.createElement("div"),It=Me?"info":c.severity;_.className=`issue ${It}`,_.setAttribute("data-issue-id",c.id);let Oe=d(c.message);if(c.type==="contrast"){let A=[];if(c.textColor&&A.push(`Text color: <code style="background: ${d(c.textColor)}; padding: 2px 6px; border-radius: 3px; color: ${ct(c.textColor)};">${d(c.textColor)}</code> (${c.textColorNode||c.nodeName||"Unnamed"})`),c.backgroundColor){let U="Background:",ee="",ve="";c.isGradient&&c.gradientString?(U="Background (gradient):",ee=`<code style="background: ${d(c.backgroundColor)}; padding: 2px 6px; border-radius: 3px; color: ${ct(c.backgroundColor)}; font-family: 'SF Mono', Monaco, monospace; font-size: 11px;">${d(c.gradientString)}</code>`,ve=" <span style='font-size: 11px; color: #999;'>(average: "+d(c.backgroundColor)+")</span>"):ee=`<code style="background: ${d(c.backgroundColor)}; padding: 2px 6px; border-radius: 3px; color: ${ct(c.backgroundColor)};">${d(c.backgroundColor)}</code>`,c.fromSibling&&(ve+=" <span style='font-size: 11px; color: #3b82f6;'>(from sibling layer)</span>"),A.push(`${U} ${ee}${ve} (${c.backgroundColorNode||"Unknown"})`)}A.length>0&&(Oe+=`<div style="margin-top: 8px; font-size: 12px; color: #666;">${A.join(" | ")}</div>`)}_.innerHTML=`
                <div class="issue-header">
                  <div>
                    <span class="issue-type">
                      <span class="issue-number">#${G}</span>
                      ${Zo(Me?"info":c.severity)} ${Me?"INFO":c.severity.toUpperCase()}
                    </span>
                    <div class="issue-body">${Oe}</div>
                    ${c.nodeName?`<div class="issue-node">Node: ${d(c.nodeName)}</div>`:""}
                    ${c.type==="typography"||c.type==="line-height"?`<div style="margin-top: 8px; padding: 8px 12px; background: #fff3cd; border-left: 3px solid #ffc107; border-radius: 4px; font-size: 12px; color: #856404; line-height: 1.5;"><strong>Note:</strong> Check 'Typography Style Match' to resolve this issue.</div>`:""}
                    ${c.ignored?'<div class="issue-ignored-tag" style="margin-top: 4px; padding: 4px 8px; background: #e3f2fd; color: #1976d2; border-radius: 4px; font-size: 11px; font-weight: 600; display: inline-block;">\u2713 Pass with ignore custom</div>':""}
                  </div>
                  <div class="issue-actions">
                    <button class="btn-select" data-id="${c.id}">Select</button>
                    ${c.type==="color"?`
                      ${at(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select Color</button>
                    `:""}
                    ${c.type==="spacing"?`
                      ${rt(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select Spacing</button>
                    `:""}
                    ${c.type==="autolayout"?`
                      ${Xe(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select</button>
                    `:""}
                    ${c.type==="text-size-mobile"?`
                      ${je(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select Style</button>
                    `:""}
                    ${c.type==="contrast"?`
                      ${Qe(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-fix" data-id="${c.id}">Select Color</button>
                      <button class="btn-ignore" data-id="${c.id}" ${c.ignored?'style="background: #28a745; border-color: #28a745;"':""}>${c.ignored?"Ignored":"Ignore"}</button>
                    `:""}
                    ${c.type==="typography-style"?`
                      ${c.bestMatch&&c.bestMatch.name?`
                        <button class="btn-suggest-fix" data-id="${c.id}" data-style-name="${d(c.bestMatch.name)}">Suggest Fix now</button>
                      `:""}
                      <button class="btn-fix" data-id="${c.id}">Select Style</button>
                      <button class="btn-create-style" data-id="${c.id}" data-issue-type="${c.type}">Create Style</button>
                    `:""}
                    ${c.type==="position"?`
                      ${Ue(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-remove-layer" data-id="${c.id}">Remove Layer</button>
                    `:""}
                    ${(c.severity==="error"||c.severity==="warn")&&c.type!=="position"?`
                      <button class="btn-remove-layer" data-id="${c.id}">Remove Layer</button>
                    `:""}
                    ${c.type==="duplicate"?`
                      ${Ke(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-select-component" data-id="${c.id}">Select Component</button>
                      <button class="btn-create-component" data-id="${c.id}">Create New Component</button>
                    `:""}
                    ${c.type==="component"?`
                      ${Ke(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                      <button class="btn-select-component" data-id="${c.id}">Select Component</button>
                      <button class="btn-create-component" data-id="${c.id}">Create New Component</button>
                    `:""}
                    ${c.type==="group"?`
                      <button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>
                    `:""}
                    ${c.type==="naming"?`
                      <button class="btn-rename" data-id="${c.id}">Rename</button>
                    `:""}
                    ${c.type==="empty-frame"?`
                      ${Ze(c)?`<button class="btn-suggest-fix" data-id="${c.id}">Suggest Fix now</button>`:""}
                    `:""}
                  </div>
                </div>
              `,Y.appendChild(_),_.setAttribute("data-issue-id",c.id),_.setAttribute("data-issue-type",c.type);let Ve=_.querySelector("button.btn-select");Ve&&(Ve.onclick=()=>{parent.postMessage({pluginMessage:{type:"select-node",id:c.id}},"*")});let We=_.querySelector("button.btn-fix");We&&(c.type==="color"?We.onclick=()=>{xn(c)}:c.type==="spacing"?We.onclick=()=>{vn(c)}:c.type==="text-size-mobile"?We.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Text Size Fix button clicked",c),typeof no=="function"?no(c):(console.error("handleFixTextSizeIssue is not a function"),alert("Error: handleFixTextSizeIssue function not found"))}:c.type==="contrast"?We.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Contrast Fix button clicked",c),typeof lo=="function"?lo(c):(console.error("handleFixContrastIssue is not a function"),alert("Error: handleFixContrastIssue function not found"))}:We.onclick=()=>{Sn(c)});let Se=_.querySelector("button.btn-suggest-fix");Se&&(c.type==="color"?Se.onclick=()=>{en(c)}:c.type==="spacing"?Se.onclick=()=>{tn(c)}:c.type==="autolayout"?Se.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Autolayout Suggest Fix button clicked",c),typeof Gt=="function"?Gt(c):(console.error("handleSuggestFixAutolayout is not a function"),alert("Error: handleSuggestFixAutolayout function not found"))}:c.type==="text-size-mobile"?Se.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Text Size Suggest Fix button clicked",c),typeof Ft=="function"?Ft(c):(console.error("handleSuggestFixTextSize is not a function"),alert("Error: handleSuggestFixTextSize function not found"))}:c.type==="position"?Se.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Position Suggest Fix button clicked",c),typeof Yt=="function"?Yt(c):(console.error("handleSuggestFixPosition is not a function"),alert("Error: handleSuggestFixPosition function not found"))}:c.type==="duplicate"||c.type==="component"?Se.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Component Suggest Fix button clicked",c),typeof Kt=="function"?Kt(c):(console.error("handleSuggestFixComponent is not a function"),alert("Error: handleSuggestFixComponent function not found"))}:c.type==="contrast"?Se.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Contrast Suggest Fix button clicked",c),typeof Tt=="function"?Tt(c):(console.error("handleSuggestFixContrast is not a function"),alert("Error: handleSuggestFixContrast function not found"))}:c.type==="group"?Se.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Group Suggest Fix button clicked",c),typeof Jt=="function"?Jt(c):(console.error("handleSuggestFixGroup is not a function"),alert("Error: handleSuggestFixGroup function not found"))}:c.type==="empty-frame"&&(Se.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Empty Frame Suggest Fix button clicked",c),typeof _t=="function"?_t(c):(console.error("handleSuggestFixEmptyFrame is not a function"),alert("Error: handleSuggestFixEmptyFrame function not found"))}));let $t=_.querySelector("button.btn-select-component");$t&&(c.type==="duplicate"||c.type==="component")&&(function(A){$t.onclick=U=>{U.preventDefault(),U.stopPropagation(),console.log("Select Component button clicked",A),typeof Zt=="function"?Zt(A):(console.error("handleSelectComponent is not a function"),alert("Error: handleSelectComponent function not found"))}})(c);let lt=_.querySelector("button.btn-create-component");lt&&(c.type==="duplicate"||c.type==="component")&&(function(A){lt.onclick=U=>{U.preventDefault(),U.stopPropagation(),console.log("Create Component button clicked",A),typeof Qt=="function"?Qt(A):(console.error("handleCreateComponent is not a function"),alert("Error: handleCreateComponent function not found"))}})(c);let mt=_.querySelector("button.btn-rename");mt&&c.type==="naming"&&(function(A){mt.onclick=U=>{U.preventDefault(),U.stopPropagation(),console.log("Rename button clicked",A),typeof eo=="function"?eo(A):(console.error("handleRenameNode is not a function"),alert("Error: handleRenameNode function not found"))}})(c);let yt=_.querySelector("button.btn-remove-layer");yt&&(function(A){yt.onclick=U=>{U.preventDefault(),U.stopPropagation(),console.log("Remove Layer button clicked",A),typeof vt=="function"?vt(A):(console.error("handleRemoveLayer is not a function"),alert("Error: handleRemoveLayer function not found"))}})(c);let qe=_.querySelector("button.btn-ignore");if(qe&&c.type==="contrast"&&(qe.removeAttribute("disabled"),qe.onclick=A=>{A.preventDefault(),A.stopPropagation(),console.log("Ignore button clicked",c);try{typeof io=="function"?io(c):(console.error("handleIgnoreIssue is not a function"),alert("Error: handleIgnoreIssue function not found"))}catch(U){console.error("Error handling ignore:",U),alert(`Error: ${U.message}`)}}),c.type==="typography-style"){let A=_.querySelector("button.btn-create-style");A?(console.log("Attaching create style handler to button",{issueId:c.id,issueType:c.type,nodeName:c.nodeName}),(function(fe){A.onclick=be=>{be.preventDefault(),be.stopPropagation(),console.log("Create Style button clicked",fe),typeof uo=="function"?uo(fe):(console.error("handleCreateTextStyle is not a function"),alert("Error: handleCreateTextStyle function not found"))}})(c)):console.error("Create Style button not found in DOM",{issueId:c.id,issueType:c.type,hasIssueEl:!!_,innerHTML:_.innerHTML.substring(0,200)});let U=_.querySelector("button.btn-suggest-fix");U&&c.bestMatch&&c.bestMatch.name&&c.type==="typography-style"&&(function(fe){U.onclick=be=>{be.preventDefault(),be.stopPropagation();let st=U.getAttribute("data-style-name");st?Nt(fe,st):(console.error("Cannot apply: styleName is missing from button",fe),alert("Error: Style name is missing"))}})(c),U&&c.bestMatch&&c.bestMatch.name&&c.type==="typography-check"&&(function(fe){U.onclick=be=>{be.preventDefault(),be.stopPropagation(),fe.bestMatch&&fe.bestMatch.name?Nt(fe,fe.bestMatch.name):(console.error("Cannot apply: bestMatch.name is missing",fe),alert("Error: Best match style name is missing"))}})(c);let ee=_.querySelector("button.btn-fix");ee&&c.type==="typography-style"&&(function(fe){ee.onclick=be=>{be.preventDefault(),be.stopPropagation(),parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:fe.id}},"*"),window.pendingTypographyStyleIssue=fe}})(c);let ve=_.querySelector("button.btn-style-dropdown"),Ge=_.querySelector(".style-dropdown-menu");if(ve&&Ge){let fe=!1;ve.onclick=be=>{be.preventDefault(),be.stopPropagation();let st=Ge.style.display!=="none";document.querySelectorAll(".style-dropdown-menu").forEach(Do=>{Do!==Ge&&(Do.style.display="none")}),st?Ge.style.display="none":(Ge.style.display="block",fe||(Ge.innerHTML='<div style="padding: 8px 12px; color: #999; font-size: 12px; text-align: center;">Loading...</div>',parent.postMessage({pluginMessage:{type:"get-figma-text-styles",issueId:c.id}},"*")))},document.addEventListener("click",function(st){_.contains(st.target)||(Ge.style.display="none")})}}});re.appendChild(Y),se.appendChild(re)}s||_e({issues:e,issuesTimestamp:a,tokens:k.tokens,tokensTimestamp:k.tokensTimestamp,lastActiveTab:"issues",scanMode:k.scanMode||null,context:k.context||null})}function $n(e){if(console.log("filterAndSearchTokens called",{hasTokens:!!e,currentColorTypeFilter:ze,currentSearch:ue}),!e)return null;let t={},o=!1;for(let[s,n]of Object.entries(e)){let l=n||[];if(console.log(`Processing ${s}, initial count:`,l.length),(s==="colors"||s==="gradients")&&ze!=="all"&&(l=l.filter(a=>(a.colorType||"").toLowerCase().includes(ze.toLowerCase())),console.log(`After color type filter (${ze}):`,l.length)),ue.trim()){let a=ue.toLowerCase();l=l.map(i=>{let r=String(i.value||"").toLowerCase(),p=(i.nodes||[]).map(b=>b.name||"").join(" ").toLowerCase(),u=(i.colorType||"").toLowerCase(),m=r.includes(a),y=p.includes(a),g=u.includes(a);if(m||y||g){let b=[];return m&&b.push("value"),y&&b.push("nodeName"),g&&b.push("colorType"),it(Je({},i),{_matchedBy:b,_matchedNodeNames:y?(i.nodes||[]).filter(S=>(S.name||"").toLowerCase().includes(a)).map(S=>S.name):[]})}return null}).filter(i=>i!==null),console.log(`After search filter (${s}):`,l.length)}l.length>0&&(o=!0),t[s]=l}return console.log("Final filtered tokens keys:",Object.keys(t)),{tokens:t,hasMatches:o}}function En(e){let t=document.getElementById("spacing-scale");if(!t)return;let s=(e&&Array.isArray(e.spacing)?e.spacing:[]).map(l=>{let a=parseInt(String(l&&l.value!==void 0?l.value:"").trim(),10);return isNaN(a)?null:Math.abs(a)}).filter(l=>l!==null);if(!s.length)return;let n=Array.from(new Set(s)).sort((l,a)=>l-a);t.value=n.join(", ");try{t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(l){}}function St(e,t=!1,o={}){let{skipSave:s=!1,restoreTimestamp:n=null}=o;Fe("tokens");let l=Object.values(e||{}).reduce((H,D)=>H+(Array.isArray(D)?D.length:0),0);document.getElementById("tokens-count").textContent=l;let a=k.tokens!==e;k.tokens=e;let i=n||new Date().toISOString();k.tokensTimestamp=i,pt=!0,(t||a)&&(console.log("Resetting filters for new token data"),we="all",ze="all",Te&&(Te.value=""),ue="",xe&&(xe.style.display="none"),pe&&pe.length>0&&pe.forEach(H=>{H.classList.remove("active"),H.getAttribute("data-filter")==="all"&&H.classList.add("active")}),tt&&(tt.value="all"));let r=document.getElementById("filter-controls"),p=document.getElementById("color-type-filter"),u=document.getElementById("filter-buttons");r.style.display=e&&Object.keys(e).length>0?"flex":"none",p.style.display=e&&(e.colors||e.gradients)?"block":"none",u.style.display="none";let m=document.getElementById("export-group");m.style.display=e&&Object.keys(e).length>0?"flex":"none",console.log("About to filter tokens with:",{currentColorTypeFilter:ze,currentSearch:ue});let y=$n(e);if(ht("tokens"),!e||Object.keys(e).length===0){te.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F4CB}</div>
                <p>No design tokens found</p>
              </div>
            `;return}if(!y){te.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F50D}</div>
                <p><strong>No results found</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Try changing the filter or search keyword.</p>
              </div>
            `;return}let g=y.tokens||{},b=y.hasMatches;if((ue.trim()||ze!=="all")&&!b){te.innerHTML=`
              <div class="empty-state">
                <div class="icon">\u{1F50D}</div>
                <p><strong>No results found</strong></p>
                <p style="margin-top: 8px; font-size: 12px;">Try changing the filter or search keyword.</p>
              </div>
            `;return}let x={colors:{icon:"\u{1F3A8}",label:"Colors",values:g.colors||[]},gradients:{icon:"\u{1F308}",label:"Gradients",values:g.gradients||[]},spacing:{icon:"\u2194\uFE0F",label:"Spacing (px)",values:g.spacing||[]},borderRadius:{icon:"\u2B55",label:"Border Radius",values:g.borderRadius||[]},fontWeight:{icon:"\u{1F4AA}",label:"Font Weight",values:g.fontWeight||[]},lineHeight:{icon:"\u{1F4CF}",label:"Line Height (%)",values:g.lineHeight||[]},fontSize:{icon:"\u{1F4DD}",label:"Font Size",values:g.fontSize||[]},fontFamily:{icon:"\u{1F524}",label:"Font Family",values:g.fontFamily||[]}},E=document.createElement("div");E.className="results-header";let w=Object.values(x).reduce((H,D)=>H+D.values.length,0);E.innerHTML=`
            <h3>Design Tokens</h3>
            <div class="results-stats">
              <span class="stat">${w} Tokens</span>
            </div>
          `,te.appendChild(E);for(let[H,D]of Object.entries(x)){let oe=document.createElement("div");oe.className="issue-group collapsed";let re=document.createElement("div");re.className="issue-group-header",re.innerHTML=`
              <div class="issue-group-header-left">
                <button class="issue-group-toggle" type="button">
                  <span class="issue-group-toggle-icon">\u25B6</span>
                </button>
                <h4>${D.icon} ${D.label}</h4>
                <span class="badge">${D.values.length}</span>
              </div>
            `;let ce=document.createElement("div");ce.className="issue-group-content",ce.style.display="none";let ye=re.querySelector(".issue-group-toggle"),Ne=()=>{oe.classList.contains("collapsed")?(oe.classList.remove("collapsed"),ce.style.display="block",setTimeout(()=>{ce.style.opacity="1"},10)):(ce.style.opacity="0",setTimeout(()=>{oe.classList.add("collapsed"),ce.style.display="none"},200))};if(ye.onclick=Z=>{Z.stopPropagation(),Ne()},re.onclick=Z=>{Z.target!==ye&&!ye.contains(Z.target)&&Ne()},oe.appendChild(re),Array.isArray(D.values)&&D.values.length>0){let Z=document.createElement("div");Z.className="token-list",D.values.forEach((ne,Y)=>{let c=Y+1,le=document.createElement("div");le.className="token-item";let G=ne.value,Me=ne.nodes||[],_=Me.length>0?Me[0]:null,It=typeof ne.totalNodes=="number"?ne.totalNodes:Me.length,Oe=ne.colorType||null,Ve="";if(H==="colors"){let qe=Oe?`<span class="token-color-type">${d(Oe)}</span>`:"";Ve=`
                  <span class="token-number">#${c}</span>
                  <span class="token-color-preview" style="background-color: ${d(G)}"></span>
                  <code>${d(G)}</code>
                  ${qe}
                `}else if(H==="gradients"){let qe=Oe?`<span class="token-color-type">${d(Oe)}</span>`:"";Ve=`
                  <span class="token-number">#${c}</span>
                  <span class="token-gradient-preview" style="background: ${d(G)}"></span>
                  <code>${d(G)}</code>
                  ${qe}
                `}else Ve=`<span class="token-number">#${c}</span><code>${d(String(G))}</code>`;let We=ne._matchedBy||[],Se=ne._matchedNodeNames||[],$t=We.includes("nodeName"),lt="";_&&_.name&&($t&&Se.length>0?lt=`<div class="token-node-name token-matched-by-name">
                    <span class="match-indicator">\u{1F50D} Matched in:</span> ${Se.map(A=>`<span class="token-matched-node">${d(A)}</span>`).join(", ")}
                  </div>`:lt=`<div class="token-node-name">Node: ${d(_.name)}</div>`);let mt="";if(H==="fontWeight"){let A=Array.isArray(ne.fontFamilies)?ne.fontFamilies:null;if(!A){let U={};Me.forEach(ee=>{let ve=ee&&ee.fontFamily?String(ee.fontFamily):"Unknown";U[ve]=(U[ve]||0)+1}),A=Object.entries(U).map(([ee,ve])=>({family:ee,count:ve})).sort((ee,ve)=>ve.count-ee.count||ee.family.localeCompare(ve.family))}Array.isArray(A)&&A.length>0&&(mt=`
                    <div class="token-note">
                      <div class="token-note-label">Font-family:</div>
                      <ul class="token-note-list">${A.map(ee=>`<li><code>${d(ee.family)}</code> (${ee.count})</li>`).join("")}</ul>
                    </div>
                  `)}le.innerHTML=`
                <div class="token-item-row">
                  <div class="token-value">
                    ${Ve}
                  </div>
                  ${_?`
                    <div class="token-actions">
                      <button class="btn-select" data-id="${_.id}">Select</button>
                      ${It>1?`<span class="token-node-count">(${It})</span>`:""}
                    </div>
                  `:""}
                </div>
                ${lt}
                ${mt}
              `;let yt=le.querySelector("button.btn-select");yt&&(yt.onclick=()=>{parent.postMessage({pluginMessage:{type:"select-node",id:_.id}},"*")}),Z.appendChild(le)}),ce.appendChild(Z)}else{let Z=document.createElement("div");Z.className="token-empty-message",Z.textContent="No tokens in this group.",ce.appendChild(Z)}oe.appendChild(ce),te.appendChild(oe)}s||_e({issues:k.issues,issuesTimestamp:k.timestamp,tokens:e,tokensTimestamp:i,lastActiveTab:"tokens",scanMode:k.scanMode||null,context:k.context||null})}function Re(e){let t=document.getElementById("validation-error"),o=document.getElementById("validation-error-message"),s=document.getElementById("btn-close-validation-error");t&&o&&(o.textContent=e,t.style.display="block",h.style.display="block",I.style.display="none",f.style.display="none",h.disabled=!1,v.disabled=!1,setTimeout(()=>{t.style.display==="block"&&(t.style.display="none")},1e4),s&&(s.onclick=()=>{t.style.display="none"}))}h.onclick=()=>{var e,t,o,s,n,l,a,i;console.log("btnScan clicked");try{let r=document.getElementById("validation-error");r&&(r.style.display="none"),h.style.display="none",I.style.display="block",f.style.display="block",C.style.transition="none",C.style.width="0%",$.textContent="0%",setTimeout(()=>{C.style.transition="width 0.3s"},10);let p=((e=document.querySelector('input[name="scope"]:checked'))==null?void 0:e.value)||"page",u=document.getElementById("spacing-scale"),m=document.getElementById("spacing-threshold"),y=document.getElementById("color-scale"),g=document.getElementById("font-size-scale"),b=document.getElementById("font-size-threshold"),S=document.getElementById("line-height-scale"),x=document.getElementById("line-height-threshold"),E=document.getElementById("line-height-baseline-threshold"),w=u?u.value.trim():"",H=m?parseInt(m.value,10):100,D=y?y.value.trim():"",oe=g?g.value.trim():"",re=b?parseInt(b.value,10):100,ce=S?S.value.trim():"",ye=x?parseInt(x.value,10):300,Ne=E?parseInt(E.value,10):120;if(w&&!/^\d+(\s*,\s*\d+)*$/.test(w)){Re("Spacing guidelines format is incorrect. Please enter the numbers separated by commas (e.g. 4, 8, 12, 16)");return}if(D){let Z=D.split(",").map(c=>c.trim()).filter(c=>c),ne=/^#[0-9a-fA-F]{3,8}$/,Y=Z.filter(c=>!ne.test(c));if(Y.length>0){Re(`Color format is incorrect. Invalid colors: ${Y.join(", ")}. Please use hex format only (e.g., #000000, #FFFFFF).`);return}}if(oe&&!/^\d+(\s*,\s*\d+)*$/.test(oe)){Re("Font-size scale format is incorrect. Please enter the numbers separated by commas (e.g. 32, 24, 20, 18)");return}if(ce){let Z=ce.split(",").map(Y=>Y.trim()).filter(Y=>Y);if(!Z.every(Y=>Y.toLowerCase()==="auto"||/^\d+$/.test(Y))||Z.length===0){Re('Line-height scale format is incorrect. Please enter "auto" and/or numbers separated by commas. "auto" can be placed anywhere (e.g. auto, 100, 120 or 100, auto, 150)');return}}if(isNaN(H)||H<0){Re("Spacing threshold must be a number >= 0");return}if(isNaN(re)||re<0){Re("Font-size threshold must be a number >= 0");return}if(isNaN(ye)||ye<0){Re("Line-height threshold must be a number >= 0");return}if(isNaN(Ne)||Ne<0){Re("Line-height baseline threshold must be a number >= 0");return}se.innerHTML=`
        <div class="scanning">
          <div class="spinner"></div>
          <p>Scanning design... Please wait</p>
        </div>
      `,Fe("issues"),h.disabled=!0,v.disabled=!0,k.scanMode=p,ie();let He={checkStyle:((t=document.getElementById("rule-typo-style"))==null?void 0:t.checked)||!1,checkFontFamily:((o=document.getElementById("rule-font-family"))==null?void 0:o.checked)||!1,checkFontSize:((s=document.getElementById("rule-font-size"))==null?void 0:s.checked)||!1,checkFontWeight:((n=document.getElementById("rule-font-weight"))==null?void 0:n.checked)||!1,checkLineHeight:((l=document.getElementById("rule-line-height"))==null?void 0:l.checked)||!1,checkLetterSpacing:((a=document.getElementById("rule-letter-spacing"))==null?void 0:a.checked)||!1,checkWordSpacing:((i=document.getElementById("rule-word-spacing"))==null?void 0:i.checked)||!1};parent.postMessage({pluginMessage:{type:"scan",mode:p,spacingScale:w,spacingThreshold:H,colorScale:D,fontSizeScale:oe,fontSizeThreshold:re,lineHeightScale:ce,lineHeightThreshold:ye,lineHeightBaselineThreshold:Ne,typographyStyles:B,typographyRules:He,ignoredIssues:Q}},"*"),console.log("Message sent:",{type:"scan",mode:p})}catch(r){console.error("Error in btnScan.onclick:",r),se.innerHTML=`<div class="error-message">Error: ${d(r.message)}</div>`,Fe("issues"),h.disabled=!1,v.disabled=!1}},v.onclick=()=>{var e;console.log("btnExtractTokens clicked");try{v.style.display="none",I.style.display="block",f.style.display="block",C.style.transition="none",C.style.width="0%",$.textContent="0%",setTimeout(()=>{C.style.transition="width 0.3s"},10);let t=((e=document.querySelector('input[name="scope"]:checked'))==null?void 0:e.value)||"page";te.innerHTML=`
        <div class="scanning">
          <div class="spinner"></div>
          <p>Extracting design tokens... Please wait</p>
        </div>
      `,Fe("tokens"),h.disabled=!0,v.disabled=!0,k.scanMode=t,parent.postMessage({pluginMessage:{type:"extract-tokens",mode:t}},"*"),console.log("Message sent:",{type:"extract-tokens",mode:t})}catch(t){console.error("Error in btnExtractTokens.onclick:",t),te.innerHTML=`<div class="error-message">Error: ${d(t.message)}</div>`,Fe("tokens"),h.disabled=!1,v.disabled=!1}},M.onclick=()=>{try{En(k.tokens)}catch(e){console.error("Failed to fill spacing guidelines from tokens",e)}},q.onclick=()=>{try{let e=k.tokens;if(!e||!Array.isArray(e.colors)||!e.colors.length){alert("No color tokens found. Please run 'Extract Design Tokens' first.");return}let t=document.getElementById("color-scale");if(!t)return;let s=(e.colors||[]).map(l=>String(l&&l.value!==void 0?l.value:"").trim().toUpperCase()).filter(l=>l&&l.startsWith("#"));if(!s.length)return;let n=Array.from(new Set(s)).sort((l,a)=>Ye(l)-Ye(a));t.value=n.join(", "),typeof Ce=="function"&&Ce();try{t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(l){}}catch(e){console.error("Failed to fill color from tokens",e)}},R.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-color-styles"}},"*")};let go=document.getElementById("btn-extract-color-variables");go&&(go.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-color-variables"}},"*")}),F.onclick=()=>{try{let e=k.tokens;if(!e||!Array.isArray(e.fontSize)||!e.fontSize.length){alert("No font size tokens found. Please run 'Extract Design Tokens' first.");return}let t=document.getElementById("font-size-scale");if(!t)return;let o=e.fontSize.map(n=>parseInt(String(n&&n.value!==void 0?n.value:"").trim(),10)).filter(n=>!isNaN(n));if(!o.length)return;let s=Array.from(new Set(o)).sort((n,l)=>l-n);t.value=s.join(", "),t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(e){console.error("Failed to fill font size from tokens",e)}},T.onclick=()=>{try{let e=k.tokens;if(!e||!Array.isArray(e.lineHeight)||!e.lineHeight.length){alert("No line height tokens found. Please run 'Extract Design Tokens' first.");return}let t=document.getElementById("line-height-scale");if(!t)return;let o=[];if(e.lineHeight.forEach(i=>{let r=String(i&&i.value!==void 0?i.value:"").trim();if(r==="auto")o.push("auto");else{let p=parseFloat(r);isNaN(p)||o.push(p)}}),!o.length)return;let s=o.includes("auto"),n=o.filter(i=>i!=="auto"),l=Array.from(new Set(n)).sort((i,r)=>i-r),a=s?["auto",...l]:l;t.value=a.join(", "),t.focus(),t.setSelectionRange(t.value.length,t.value.length)}catch(e){console.error("Failed to fill line height from tokens",e)}},L.onclick=()=>{try{if(!B||!Array.isArray(B)||B.length===0){alert("No typography styles defined. Please add typography styles or extract from Figma first.");return}let e=document.getElementById("font-size-scale");if(!e)return;let t=B.map(s=>{let n=parseInt(String(s.fontSize||"").trim(),10);return isNaN(n)?null:n}).filter(s=>s!==null);if(!t.length){alert("No valid font sizes found in typography styles.");return}let o=Array.from(new Set(t)).sort((s,n)=>n-s);e.value=o.join(", "),ie(),e.focus(),e.setSelectionRange(e.value.length,e.value.length),console.log("Filled font size from typography:",o)}catch(e){console.error("Failed to fill font size from typography",e)}},N.onclick=()=>{try{if(!B||!Array.isArray(B)||B.length===0){alert("No typography styles defined. Please add typography styles or extract from Figma first.");return}let e=document.getElementById("line-height-scale");if(!e)return;let t=[];if(B.forEach(a=>{let i=String(a.lineHeight||"").trim();if(i==="auto")t.push("auto");else{let r=parseFloat(i.replace("%",""));isNaN(r)||t.push(r)}}),!t.length){alert("No valid line heights found in typography styles.");return}let o=t.includes("auto"),s=t.filter(a=>a!=="auto"),n=Array.from(new Set(s)).sort((a,i)=>a-i),l=o?["auto",...n]:n;e.value=l.join(", "),ie(),e.focus(),e.setSelectionRange(e.value.length,e.value.length),console.log("Filled line height from typography:",l)}catch(e){console.error("Failed to fill line height from typography",e)}};let zt=document.getElementById("typography-panel"),mo=document.getElementById("typography-panel-header"),yo=document.getElementById("typography-panel-toggle");mo&&zt&&yo&&(mo.onclick=()=>{let e=zt.classList.contains("collapsed");zt.classList.toggle("collapsed");let t=yo.querySelector(".issue-group-toggle-icon");t&&(t.textContent="\u25B6")});let Bt=document.getElementById("settings-panel"),fo=document.getElementById("settings-panel-header"),ut=document.getElementById("settings-panel-toggle");if(fo&&Bt&&ut){let e=()=>{let t=Bt.classList.contains("collapsed");Bt.classList.toggle("collapsed");let o=ut.querySelector(".issue-group-toggle-icon");o&&(o.textContent="\u25B6")};fo.onclick=t=>{t.target===ut||ut.contains(t.target)||e()},ut.onclick=t=>{t.stopPropagation(),e()}}function At(){let e=document.getElementById("color-preview-panel"),t=document.getElementById("color-preview-panel-header"),o=document.getElementById("color-preview-panel-toggle");if(!e||!t||!o){console.log("Color preview panel elements not found, retrying..."),setTimeout(At,100);return}console.log("Setting up color preview panel toggle");let s=()=>{let n=e.classList.contains("collapsed");e.classList.toggle("collapsed");let l=o.querySelector(".issue-group-toggle-icon");l&&(l.textContent="\u25B6"),console.log("Color preview panel toggled, isCollapsed:",!n)};t.onclick=n=>{n.preventDefault(),n.stopPropagation(),console.log("Color preview panel header clicked"),s()},o.onclick=n=>{n.preventDefault(),n.stopPropagation(),console.log("Color preview panel toggle button clicked"),s()}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",At):At();function Ce(){let e=document.getElementById("color-scale"),t=document.getElementById("color-preview");if(!e||!t)return;let o=e.value.trim();if(t.innerHTML="",!o)return;o.split(",").map(n=>n.trim()).filter(n=>n).forEach((n,l)=>{let a=/^#[0-9A-Fa-f]{3,8}$/.test(n),i=/^rgba?\(/.test(n);if(!a&&!i)return;let r=document.createElement("div");r.className="color-swatch-container";let p=document.createElement("div");p.className="color-swatch",p.style.background=n;let u=document.createElement("button");u.innerHTML="\xD7",u.className="color-swatch-close",u.onclick=function(b){b.stopPropagation();let x=e.value.split(",").map(E=>E.trim()).filter(E=>E).filter((E,w)=>w!==l);e.value=x.join(", "),Ce(),typeof ie=="function"&&ie()};let m=n.toUpperCase(),y=W[m],g=document.createElement("div");g.className="color-swatch-label",y?g.innerHTML=`
          <div class="color-swatch-label-name">${d(y)}</div>
          <div class="color-swatch-label-hex">${d(m)}</div>
        `:g.innerHTML=`<div class="color-swatch-label-hex">${d(m)}</div>`,p.appendChild(u),r.appendChild(p),r.appendChild(g),t.appendChild(r)})}function Mn(){var e,t,o,s,n,l;return{fontFamily:((e=document.getElementById("rule-font-family"))==null?void 0:e.checked)||!1,fontSize:((t=document.getElementById("rule-font-size"))==null?void 0:t.checked)||!1,fontWeight:((o=document.getElementById("rule-font-weight"))==null?void 0:o.checked)||!1,lineHeight:((s=document.getElementById("rule-line-height"))==null?void 0:s.checked)||!1,letterSpacing:((n=document.getElementById("rule-letter-spacing"))==null?void 0:n.checked)||!1,wordSpacing:((l=document.getElementById("rule-word-spacing"))==null?void 0:l.checked)||!1}}function Be(){let e=document.getElementById("typography-table-body"),t=document.querySelector("#typography-table thead tr");if(!e||!t)return;let o=Mn(),s='<th class="typography-table-actions">Actions</th>';if(s+='<th class="typography-table-style-name" style="width: 120px;">Style Name</th>',o.fontFamily&&(s+='<th class="typography-table-font-family" style="width: 140px;">Font Family</th>'),o.fontSize&&(s+='<th class="typography-table-font-size" style="width: 80px;">Size (px)</th>'),o.fontWeight&&(s+='<th class="typography-table-font-weight" style="width: 100px;">Weight</th>'),o.lineHeight&&(s+='<th class="typography-table-line-height" style="width: 100px;">Line Height</th>'),o.letterSpacing&&(s+='<th class="typography-table-letter-spacing" style="width: 100px;">Letter Spacing</th>'),o.wordSpacing&&(s+='<th class="typography-table-word-spacing" style="width: 100px;">Word Spacing</th>'),t.innerHTML=s,B.length===0){let n=Object.values(o).filter(l=>l).length+2;e.innerHTML=`
        <tr>
          <td colspan="${n}" class="typography-empty-message">
            No typography styles defined. Click "Add Typography Style" to create one.
          </td>
        </tr>
      `;return}e.innerHTML=B.map(n=>{let l=`<tr data-id="${n.id}">`;return l+='<td class="typography-table-actions">',n.styleId&&(l+=`<button class="btn-table-action" onclick="selectTypographyStyle('${n.styleId}')" title="Select layer in Figma" style="background: #0071e3; color: white;">\u{1F441}</button>`),l+=`<button class="btn-table-action delete" onclick="deleteTypographyStyle(${n.id})" title="Delete">\u{1F5D1}</button>
        </td>`,l+=`<td><input type="text" value="${d(n.name)}" data-field="name"></td>`,o.fontFamily&&(l+=`<td><input type="text" value="${d(n.fontFamily)}" data-field="fontFamily"></td>`),o.fontSize&&(l+=`<td><input type="number" value="${n.fontSize}" data-field="fontSize" min="1"></td>`),o.fontWeight&&(l+=`<td>
          <select data-field="fontWeight">
            <option value="Thin" ${n.fontWeight==="Thin"?"selected":""}>Thin (100)</option>
            <option value="ExtraLight" ${n.fontWeight==="ExtraLight"?"selected":""}>ExtraLight (200)</option>
            <option value="Light" ${n.fontWeight==="Light"?"selected":""}>Light (300)</option>
            <option value="Regular" ${n.fontWeight==="Regular"?"selected":""}>Regular (400)</option>
            <option value="Medium" ${n.fontWeight==="Medium"?"selected":""}>Medium (500)</option>
            <option value="SemiBold" ${n.fontWeight==="SemiBold"?"selected":""}>SemiBold (600)</option>
            <option value="Bold" ${n.fontWeight==="Bold"?"selected":""}>Bold (700)</option>
            <option value="ExtraBold" ${n.fontWeight==="ExtraBold"?"selected":""}>ExtraBold (800)</option>
            <option value="Black" ${n.fontWeight==="Black"?"selected":""}>Black (900)</option>
          </select>
        </td>`),o.lineHeight&&(l+=`<td><input type="text" value="${d(n.lineHeight)}" data-field="lineHeight" placeholder="120% or auto"></td>`),o.letterSpacing&&(l+=`<td><input type="text" value="${d(n.letterSpacing||"0")}" data-field="letterSpacing" placeholder="0 or 0.5px"></td>`),o.wordSpacing&&(l+=`<td><input type="text" value="${d(n.wordSpacing||"0")}" data-field="wordSpacing" placeholder="0"></td>`),l+="</tr>",l}).join(""),e.querySelectorAll("input, select").forEach(n=>{n.addEventListener("change",l=>{let a=l.target.closest("tr"),i=parseInt(a.dataset.id),r=l.target.dataset.field,p=l.target.value;Fn(i,r,p)})})}window.addTypographyStyle=function(){let e={id:ke++,name:"New Style",fontFamily:"Inter",fontSize:16,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"};B.push(e),Be(),ie()};function Fn(e,t,o){let s=B.find(n=>n.id===e);s&&(t==="fontSize"?s[t]=parseInt(o)||16:s[t]=o,ie())}window.deleteTypographyStyle=function(e){confirm("Delete this typography style?")&&(B=B.filter(t=>t.id!==e),Be(),ie())},window.selectTypographyStyle=function(e){parent.postMessage({pluginMessage:{type:"select-text-style",styleId:e}},"*")};let ho=document.getElementById("btn-add-typo-style");ho&&(ho.onclick=()=>addTypographyStyle());let bo=document.getElementById("btn-extract-typo-desktop");bo&&(bo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"desktop"}},"*")});let vo=document.getElementById("btn-extract-typo-tablet");vo&&(vo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"tablet"}},"*")});let xo=document.getElementById("btn-extract-typo-mobile");xo&&(xo.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"mobile"}},"*")});let So=document.getElementById("btn-extract-typo-all");So&&(So.onclick=()=>{parent.postMessage({pluginMessage:{type:"extract-typography-styles",mode:"all"}},"*")});let ko=document.getElementById("btn-reset-typo-table");ko&&(ko.onclick=()=>{confirm(`\u26A0\uFE0F Reset typography table to default styles?

This will:
\u2022 Clear all current styles
\u2022 Restore default H1-H6 and Body styles

This action cannot be undone.`)&&(B=[{id:1,name:"H1",fontFamily:"Inter",fontSize:48,fontWeight:"Bold",lineHeight:"120%",letterSpacing:"0",wordSpacing:"0"},{id:2,name:"H2",fontFamily:"Inter",fontSize:36,fontWeight:"Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:3,name:"H3",fontFamily:"Inter",fontSize:30,fontWeight:"Semi Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:4,name:"H4",fontFamily:"Inter",fontSize:24,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:5,name:"H5",fontFamily:"Inter",fontSize:20,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:6,name:"H6",fontFamily:"Inter",fontSize:16,fontWeight:"Semi Bold",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"},{id:7,name:"Body",fontFamily:"Inter",fontSize:14,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"}],ke=8,Be(),ie(),alert("\u2705 Typography table has been reset to default styles!"))}),Be(),["rule-font-family","rule-font-size","rule-font-weight","rule-line-height","rule-letter-spacing","rule-word-spacing"].forEach(e=>{let t=document.getElementById(e);t&&t.addEventListener("change",()=>{Be(),ie()})});let wo=document.getElementById("color-scale");wo&&(wo.addEventListener("input",()=>{Ce()}),Ce());let Tn=Xo({maxHistory:10,postPluginMessage:e=>parent.postMessage({pluginMessage:e},"*"),getCurrentReportData:()=>k,setIsViewingTokens:e=>{pt=!!e},renderResults:Pe,renderTokens:St}),{saveScanHistory:Co,requestScanHistory:Io,renderScanHistory:Lt,restoreReportFromHistory:Gn,loadLastScanModeOnce:Nn,setHistory:zn,clearLocalHistory:Bn}=Tn,An=document.getElementById("export-group"),kt=document.getElementById("export-dropdown");P.onclick=e=>{e.stopPropagation(),kt.style.display=kt.style.display==="block"?"none":"block"},document.querySelectorAll(".export-option").forEach(e=>{e.onclick=t=>{t.stopPropagation();let o=e.getAttribute("data-format");_o({format:o,reportData:k,getTypeDisplayName:bt,colorNameMap:W}),kt.style.display="none"}}),document.addEventListener("click",e=>{An.contains(e.target)||(kt.style.display="none")});let Te,xe,pe,tt;function wt(){console.log("applyFilters called",{isViewingTokens:pt,hasTokens:!!k.tokens,hasIssues:!!k.issues,currentFilter:we,currentSearch:ue,currentColorTypeFilter:ze}),pt&&k.tokens?(console.log("Applying filters to tokens"),St(k.tokens,!1)):k.issues&&(console.log("Applying filters to issues"),Pe(k.issues,!1))}function Ht(){if(console.log("setupFilterHandlers called"),Te=document.getElementById("search-input"),xe=document.getElementById("btn-clear-search"),pe=document.querySelectorAll(".filter-btn"),tt=document.getElementById("color-type-select"),console.log("Elements found:",{searchInput:!!Te,btnClearSearch:!!xe,filterButtons:pe?pe.length:0,colorTypeSelect:!!tt}),!Te||!xe||!pe||pe.length===0){console.warn("Filter elements not found, retrying...",{searchInput:!!Te,btnClearSearch:!!xe,filterButtons:pe?pe.length:0}),setTimeout(Ht,100);return}console.log("Setting up search input handler"),Te.addEventListener("input",e=>{let t=e.target.value;console.log("Search input changed:",t),ue=t,console.log("currentSearch set to:",ue),xe&&(xe.style.display=ue.trim()?"block":"none"),wt()}),xe&&(console.log("Setting up clear search button handler"),xe.onclick=e=>{console.log("Clear search clicked"),e.preventDefault(),e.stopPropagation(),Te&&(Te.value=""),ue="",xe.style.display="none",wt()}),console.log("Setting up filter buttons handlers, count:",pe.length),pe.forEach((e,t)=>{console.log(`Setting up filter button ${t}:`,e.getAttribute("data-filter")),e.onclick=o=>{o.preventDefault(),o.stopPropagation();let s=e.getAttribute("data-filter"),n=e.classList.contains("active");console.log("Filter button clicked:",s,"isActive:",n),n&&s!=="all"?(e.classList.remove("active"),we="all",pe.forEach(l=>{l.getAttribute("data-filter")==="all"&&l.classList.add("active")})):(pe.forEach(l=>l.classList.remove("active")),e.classList.add("active"),we=s),console.log("currentFilter set to:",we),wt()}}),tt&&(console.log("Setting up color type select handler"),tt.addEventListener("change",e=>{console.log("Color type changed:",e.target.value),ze=e.target.value,wt()})),console.log("Filter handlers setup complete")}console.log("Setting up filter handlers, DOM readyState:",document.readyState),document.readyState==="loading"?(console.log("DOM still loading, waiting for DOMContentLoaded"),document.addEventListener("DOMContentLoaded",()=>{console.log("DOMContentLoaded fired, setting up handlers"),Ht(),dt(),ft(),Io()})):(console.log("DOM already ready, setting up handlers immediately"),Ht(),dt(),ft(),Io()),J&&(I.onclick=()=>{console.log("Cancel operation clicked"),parent.postMessage({pluginMessage:{type:"cancel-scan"}},"*"),h.style.display="block",h.disabled=!1,v.style.display="block",v.disabled=!1,I.style.display="none",f.style.display="none"},he.onclick=()=>{if(confirm(`\u26A0\uFE0F Are you sure you want to reset all settings to default and clear history?

This will:
\u2022 Reset all input values to default
\u2022 Clear scan history
\u2022 Clear current reports

This action cannot be undone.`)){document.getElementById("spacing-scale").value="0, 4, 8, 12, 16, 24, 32, 40, 48, 64, 72, 80, 88, 96",document.getElementById("spacing-threshold").value="100",document.getElementById("color-scale").value="",document.getElementById("font-size-scale").value="32, 24, 20, 18, 16, 14, 12",document.getElementById("font-size-threshold").value="100",document.getElementById("line-height-scale").value="auto, 100, 110, 120, 130, 140, 150, 160, 170",document.getElementById("line-height-threshold").value="300",document.getElementById("line-height-baseline-threshold").value="120",B=[{id:1,name:"H1",fontFamily:"Inter",fontSize:48,fontWeight:"Bold",lineHeight:"120%",letterSpacing:"0",wordSpacing:"0"},{id:2,name:"H2",fontFamily:"Inter",fontSize:36,fontWeight:"Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:3,name:"H3",fontFamily:"Inter",fontSize:30,fontWeight:"Semi Bold",lineHeight:"130%",letterSpacing:"0",wordSpacing:"0"},{id:4,name:"H4",fontFamily:"Inter",fontSize:24,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:5,name:"H5",fontFamily:"Inter",fontSize:20,fontWeight:"Semi Bold",lineHeight:"140%",letterSpacing:"0",wordSpacing:"0"},{id:6,name:"H6",fontFamily:"Inter",fontSize:16,fontWeight:"Semi Bold",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"},{id:7,name:"Body",fontFamily:"Inter",fontSize:14,fontWeight:"Regular",lineHeight:"150%",letterSpacing:"0",wordSpacing:"0"}],ke=8,Be(),document.getElementById("rule-typo-style").checked=!0,document.getElementById("rule-font-family").checked=!0,document.getElementById("rule-font-size").checked=!0,document.getElementById("rule-font-weight").checked=!0,document.getElementById("rule-line-height").checked=!0,document.getElementById("rule-letter-spacing").checked=!1,document.getElementById("rule-word-spacing").checked=!1,Be(),Ce(),k={issues:null,tokens:null,scanMode:null,timestamp:null,context:null,lastActiveTab:"issues"},ht("issues"),ht("tokens"),Fe("issues"),Bn(),parent.postMessage({pluginMessage:{type:"clear-history"}},"*");let e=document.getElementById("history-panel");e&&e.style.display!=="none"&&Lt(),ie(),alert("\u2705 All settings have been reset to default and history has been cleared!")}},J.onclick=()=>{let e=document.getElementById("history-panel");if(e){let t=e.style.display!=="none";e.style.display=t?"none":"flex",t||Lt()}}),V&&(V.onclick=()=>{let e=document.getElementById("history-panel");e&&(e.style.display="none")});let $o=document.getElementById("btn-save-settings"),Ie=document.getElementById("save-settings-modal"),ae=document.getElementById("setting-name-input"),Ct=document.getElementById("btn-confirm-save-settings"),Eo=document.getElementById("btn-cancel-save-settings"),Mo=document.getElementById("btn-close-save-settings");$o&&($o.onclick=()=>{parent.postMessage({pluginMessage:{type:"get-project-name"}},"*"),Ie&&(Ie.style.display="flex",ae&&(ae.value="",ae.focus(),ae.onkeydown=e=>{e.key==="Enter"&&(e.preventDefault(),Ct&&Ct.click())}))}),Mo&&(Mo.onclick=()=>{Ie&&(Ie.style.display="none")}),Eo&&(Eo.onclick=()=>{Ie&&(Ie.style.display="none")});let ge=document.getElementById("replace-confirm-modal"),Fo=document.getElementById("replace-setting-name"),To=document.getElementById("btn-confirm-replace"),No=document.getElementById("btn-cancel-replace"),zo=document.getElementById("btn-close-replace-confirm"),me=null;function Bo(e,t){parent.postMessage({pluginMessage:{type:"save-settings",name:e,values:t,forceReplace:!0}},"*")}Ct&&(Ct.onclick=()=>{var o,s,n,l,a,i,r,p,u,m,y,g,b,S,x,E;let e=(o=ae==null?void 0:ae.value)==null?void 0:o.trim();if(!e){alert("\u26A0\uFE0F Please enter a setting name");return}let t={spacingScale:((s=document.getElementById("spacing-scale"))==null?void 0:s.value)||"",spacingThreshold:((n=document.getElementById("spacing-threshold"))==null?void 0:n.value)||"100",colorScale:((l=document.getElementById("color-scale"))==null?void 0:l.value)||"",colorNameMap:W,ignoredIssues:Q,fontSizeScale:((a=document.getElementById("font-size-scale"))==null?void 0:a.value)||"",fontSizeThreshold:((i=document.getElementById("font-size-threshold"))==null?void 0:i.value)||"100",lineHeightScale:((r=document.getElementById("line-height-scale"))==null?void 0:r.value)||"",lineHeightThreshold:((p=document.getElementById("line-height-threshold"))==null?void 0:p.value)||"300",lineHeightBaselineThreshold:((u=document.getElementById("line-height-baseline-threshold"))==null?void 0:u.value)||"120",typographyStyles:B,typographyRules:{checkStyle:((m=document.getElementById("rule-typo-style"))==null?void 0:m.checked)||!0,checkFontFamily:((y=document.getElementById("rule-font-family"))==null?void 0:y.checked)||!0,checkFontSize:((g=document.getElementById("rule-font-size"))==null?void 0:g.checked)||!0,checkFontWeight:((b=document.getElementById("rule-font-weight"))==null?void 0:b.checked)||!0,checkLineHeight:((S=document.getElementById("rule-line-height"))==null?void 0:S.checked)||!0,checkLetterSpacing:((x=document.getElementById("rule-letter-spacing"))==null?void 0:x.checked)||!1,checkWordSpacing:((E=document.getElementById("rule-word-spacing"))==null?void 0:E.checked)||!1}};me={name:e,values:t},parent.postMessage({pluginMessage:{type:"check-setting-name",name:e}},"*")}),To&&(To.onclick=()=>{me&&(Bo(me.name,me.values),me=null),ge&&(ge.style.display="none")}),No&&(No.onclick=()=>{me=null,ge&&(ge.style.display="none"),ae&&(ae.focus(),ae.select())}),zo&&(zo.onclick=()=>{me=null,ge&&(ge.style.display="none"),ae&&(ae.focus(),ae.select())}),ge&&(ge.onclick=e=>{e.target===ge&&(me=null,ge.style.display="none",ae&&(ae.focus(),ae.select()))});let Ao=document.getElementById("btn-load-settings"),$e=document.getElementById("load-settings-modal"),gt=document.getElementById("settings-list"),qt=document.getElementById("settings-empty-state"),Lo=document.getElementById("btn-close-load-settings");function Ho(e){if(!(!gt||!qt)){if(!e||e.length===0){gt.innerHTML="",qt.style.display="block";return}qt.style.display="none",gt.innerHTML=e.map(t=>{let o=new Date(t.updatedAt||t.createdAt),s=o.toLocaleDateString()+" "+o.toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});return`
        <div class="settings-item" data-setting-name="${d(t.name)}">
          <div class="settings-item-info">
            <div class="settings-item-name">${d(t.name)}</div>
            <div class="settings-item-date">Updated: ${s}</div>
          </div>
          <div class="settings-item-actions">
            <button class="btn-remove-setting" data-setting-name="${d(t.name)}" title="Remove">\u{1F5D1}\uFE0F</button>
          </div>
        </div>
      `}).join(""),gt.querySelectorAll(".settings-item").forEach(t=>{let o=t.getAttribute("data-setting-name");t.onclick=s=>{s.target.closest(".btn-remove-setting")||(parent.postMessage({pluginMessage:{type:"load-settings",name:o}},"*"),$e&&($e.style.display="none"))}}),gt.querySelectorAll(".btn-remove-setting").forEach(t=>{t.onclick=o=>{o.stopPropagation();let s=t.getAttribute("data-setting-name");confirm(`\u26A0\uFE0F Are you sure you want to remove "${s}"?`)&&parent.postMessage({pluginMessage:{type:"remove-settings",name:s}},"*")}})}}Ao&&(Ao.onclick=()=>{parent.postMessage({pluginMessage:{type:"get-saved-settings"}},"*"),$e&&($e.style.display="flex")}),Lo&&(Lo.onclick=()=>{$e&&($e.style.display="none")});let qo=document.getElementById("btn-export-settings");qo&&(qo.onclick=()=>{var n,l,a,i,r,p,u,m,y,g,b,S,x,E,w;let e=((n=document.getElementById("color-scale"))==null?void 0:n.value)||"",t=e.split(",").map(H=>H.trim().toUpperCase()).filter(H=>H&&H.startsWith("#")),o=Je({},W);t.forEach(H=>{o[H]||(o[H]="No name")});let s={spacingScale:((l=document.getElementById("spacing-scale"))==null?void 0:l.value)||"",spacingThreshold:((a=document.getElementById("spacing-threshold"))==null?void 0:a.value)||"100",colorScale:e,colorNameMap:o,ignoredIssues:Q,fontSizeScale:((i=document.getElementById("font-size-scale"))==null?void 0:i.value)||"",fontSizeThreshold:((r=document.getElementById("font-size-threshold"))==null?void 0:r.value)||"100",lineHeightScale:((p=document.getElementById("line-height-scale"))==null?void 0:p.value)||"",lineHeightThreshold:((u=document.getElementById("line-height-threshold"))==null?void 0:u.value)||"300",lineHeightBaselineThreshold:((m=document.getElementById("line-height-baseline-threshold"))==null?void 0:m.value)||"120",typographyStyles:B,typographyRules:{checkStyle:((y=document.getElementById("rule-typo-style"))==null?void 0:y.checked)||!0,checkFontFamily:((g=document.getElementById("rule-font-family"))==null?void 0:g.checked)||!0,checkFontSize:((b=document.getElementById("rule-font-size"))==null?void 0:b.checked)||!0,checkFontWeight:((S=document.getElementById("rule-font-weight"))==null?void 0:S.checked)||!0,checkLineHeight:((x=document.getElementById("rule-line-height"))==null?void 0:x.checked)||!0,checkLetterSpacing:((E=document.getElementById("rule-letter-spacing"))==null?void 0:E.checked)||!1,checkWordSpacing:((w=document.getElementById("rule-word-spacing"))==null?void 0:w.checked)||!1}};parent.postMessage({pluginMessage:{type:"get-project-name"}},"*"),window.pendingExportValues=s});let Po=document.getElementById("btn-import-settings"),ot=document.getElementById("import-settings-modal"),Ae=document.getElementById("import-settings-file-input"),Ro=document.getElementById("btn-select-import-file"),Le=document.getElementById("import-file-info"),Wo=document.getElementById("import-file-name"),Ee=document.getElementById("btn-confirm-import"),Pt=document.getElementById("btn-cancel-import"),Rt=document.getElementById("btn-close-import-settings"),nt=null,de=null;if(Po&&(Po.onclick=()=>{nt=null,de=null,Ae&&(Ae.value=""),Le&&(Le.style.display="none"),Ee&&(Ee.disabled=!0),ot&&(ot.style.display="flex")}),Ro&&Ae&&(Ro.onclick=()=>{Ae.click()}),Ae&&(Ae.onchange=e=>{let t=e.target.files[0];if(!t)return;if(!t.name.endsWith(".json")){alert("\u26A0\uFE0F Please select a JSON file");return}nt=t,Wo&&(Wo.textContent=t.name),Le&&(Le.style.display="block"),Ee&&(Ee.disabled=!1);let o=new FileReader;o.onload=s=>{try{de=JSON.parse(s.target.result),console.log("Imported settings data:",de)}catch(n){alert("\u274C Error parsing JSON file: "+n.message),nt=null,de=null,Le&&(Le.style.display="none"),Ee&&(Ee.disabled=!0)}},o.onerror=()=>{alert("\u274C Error reading file"),nt=null,de=null},o.readAsText(t)}),Ee&&(Ee.onclick=()=>{if(!de){alert("\u274C No file data to import");return}console.log("Import file data:",de);let e=null;if(Array.isArray(de)){if(de.length===0){alert("\u274C No settings found in file");return}if(e=de[0].values,!e){alert("\u274C Invalid settings format. No values found in setting object.");return}}else if(de.values)e=de.values;else if(de.spacingScale!==void 0||de.colorScale!==void 0)e=de;else{alert("\u274C Invalid settings file format. Expected an array of settings, a single setting object, or a values object."),console.error("Invalid import data structure:",de);return}if(!e||typeof e!="object"){alert("\u274C Invalid settings format. No values found.");return}console.log("Applying values:",e),De(e),ie(),ot&&(ot.style.display="none"),nt=null,de=null,Ae&&(Ae.value=""),Le&&(Le.style.display="none"),Ee&&(Ee.disabled=!0),alert("\u2705 Settings imported and applied to input fields successfully")}),Pt||Rt){let e=()=>{ot&&(ot.style.display="none"),nt=null,de=null,Ae&&(Ae.value=""),Le&&(Le.style.display="none"),Ee&&(Ee.disabled=!0)};Pt&&(Pt.onclick=e),Rt&&(Rt.onclick=e)}Ie&&(Ie.onclick=e=>{e.target===Ie&&(Ie.style.display="none")}),$e&&($e.onclick=e=>{e.target===$e&&($e.style.display="none")}),j.onclick=()=>{parent.postMessage({pluginMessage:{type:"close"}},"*")},window.onmessage=e=>{var o,s;console.log("Received message:",e.data);let t=e.data.pluginMessage;if(t&&t.type==="fix-issue-result"){if(console.log("[fix-issue-result] Received:",{issueId:t.issueId,success:t.success,message:t.message}),X(t.issueId,t.message,t.success),!t.success){console.log("[fix-issue-result] Error detected, showing error modal...");let n=t.message||"An error occurred while fixing the issue.";console.log("[fix-issue-result] Error message:",n);try{Wt(n),console.log("[fix-issue-result] Error modal should be displayed")}catch(l){console.error("[fix-issue-result] Error showing error modal:",l),alert("Error: "+n)}}if(t.success){if(console.log("[fix-issue-result] Starting remove process for issueId:",t.issueId),console.log("[fix-issue-result] issueId type:",typeof t.issueId,"value:",t.issueId),k&&k.issues){let u=k.issues.length;k.issues=k.issues.filter(y=>String(y.id)!==String(t.issueId));let m=u-k.issues.length;console.log("[fix-issue-result] Removed",m,"issue(s) from data. Remaining issues:",k.issues.length)}let n=`.issue[data-issue-id="${t.issueId}"]`;console.log("[fix-issue-result] Trying selector1:",n);let l=document.querySelectorAll(n);console.log("[fix-issue-result] Found",l.length,"issue element(s) with this ID");let a=`button.btn-fix[data-id="${t.issueId}"]`,i=`button.btn-suggest-fix[data-id="${t.issueId}"]`;[...document.querySelectorAll(a),...document.querySelectorAll(i)].forEach(u=>{let m=u.closest(".issue");m&&!Array.from(l).includes(m)&&l.push(m)});let p=Array.from(new Set(Array.from(l)));if(console.log("[fix-issue-result] Total unique issue elements to remove:",p.length),p.length>0){let u=new Map;p.forEach((m,y)=>{console.log(`[fix-issue-result] Issue element ${y}:`,m),console.log(`[fix-issue-result] Issue element ${y} data-issue-id:`,m.getAttribute("data-issue-id")),console.log(`[fix-issue-result] Issue element ${y} data-issue-type:`,m.getAttribute("data-issue-type"));let g=m.closest(".issue-group");if(g){let b=g.getAttribute("data-issue-type");if(!u.has(b)){let x=g.querySelector(".badge");if(x){let E=parseInt(x.textContent)||0;u.set(b,{groupEl:g,badge:x,currentCount:E,removeCount:0})}}let S=u.get(b);S&&S.removeCount++}}),p.forEach((m,y)=>{m.style.transition="opacity 0.3s ease-out",m.style.opacity="0",setTimeout(()=>{m.parentNode&&(console.log(`[fix-issue-result] Removing element ${y} from DOM...`),m.remove())},300)}),setTimeout(()=>{let m=document.querySelectorAll(n);console.log("[fix-issue-result] After remove, remaining elements:",m.length),u.forEach((y,g)=>{let b=Math.max(0,y.currentCount-y.removeCount);y.badge.textContent=b,console.log(`[fix-issue-result] Updated badge for group "${g}" from ${y.currentCount} to ${b}`),b===0&&(y.groupEl.style.display="none",console.log(`[fix-issue-result] Hiding group "${g}" (no issues left)`))}),console.log("[fix-issue-result] Calling updateIssueCounts()..."),et(),console.log("[fix-issue-result] updateIssueCounts() completed"),console.log("[fix-issue-result] Re-rendering issues to sync UI..."),k&&k.issues&&Pe(k.issues,!1)},350)}else console.log("[fix-issue-result] No issue elements found! Trying to update counts anyway..."),et(),k&&k.issues&&Pe(k.issues,!1)}return}if(t&&t.type==="create-text-style-result"){X(t.issueId,t.message,t.success),t.success&&setTimeout(()=>{var l;let n=document.querySelector(`.issue[data-issue-id="${t.issueId}"]`)||((l=document.querySelector(`button.btn-create-style[data-id="${t.issueId}"]`))==null?void 0:l.closest(".issue"));n&&(n.style.transition="opacity 0.5s ease-out",n.style.opacity="0",setTimeout(()=>{if(n.parentNode){n.remove();let a=n.closest(".issue-group");if(a){let i=a.querySelector(".badge");if(i){let r=parseInt(i.textContent)||0,p=Math.max(0,r-1);i.textContent=p,p===0&&(a.style.display="none")}}}},500))},5e3);return}if(t&&t.type==="components-for-issue-loaded"){console.log("=== [components-for-issue-loaded] HANDLER CALLED ==="),console.log("[components-for-issue-loaded] Received message",t);let n=window.pendingComponentIssue;if(console.log("[components-for-issue-loaded] Pending issue:",n,"Message issueId:",t.issueId),console.log("[components-for-issue-loaded] Similar components:",t.similarComponents),n){let l=document.querySelector(`.issue[data-issue-id="${n.id}"]`);if(l){let a=l.querySelector("button.btn-suggest-fix");a&&(a.disabled=!1,a.style.opacity="1",a.style.cursor="pointer",a.dataset.originalText&&(a.textContent=a.dataset.originalText,delete a.dataset.originalText))}}if(t.similarComponents&&t.similarComponents.length>0){console.log("[components-for-issue-loaded] Showing suggest modal with",t.similarComponents.length,"similar components");let l=n||{id:t.issueId,nodeName:"Unnamed"};try{mn(l,t.similarComponents),console.log("[components-for-issue-loaded] Modal function called successfully")}catch(a){console.error("[components-for-issue-loaded] Error showing modal:",a),alert("Error showing component suggestion modal: "+a.message)}window.pendingComponentIssue=null;return}else{console.warn("[components-for-issue-loaded] No similar components found"),alert("No similar components found. Please use 'Select Component' to choose from all components or 'Create New Component' to create a new one."),window.pendingComponentIssue=null;return}}if(t&&t.type==="all-components-loaded"){console.log("=== [all-components-loaded] HANDLER CALLED ==="),console.log("[all-components-loaded] Received message",t);let n=window.pendingSelectComponentIssue;if(console.log("[all-components-loaded] Pending issue:",n),console.log("[all-components-loaded] Message issueId:",t.issueId,typeof t.issueId),console.log("[all-components-loaded] Pending issueId:",n==null?void 0:n.id,typeof(n==null?void 0:n.id)),console.log("[all-components-loaded] Components:",t.components),console.log("[all-components-loaded] Components length:",t.components?t.components.length:0),n){let l=document.querySelector(`.issue[data-issue-id="${n.id}"]`);if(l){let a=l.querySelector("button.btn-select-component");a&&(a.disabled=!1,a.style.opacity="1",a.style.cursor="pointer",a.dataset.originalText&&(a.textContent=a.dataset.originalText,delete a.dataset.originalText))}}if(t.components&&t.components.length>0){console.log("[all-components-loaded] \u2713 Showing select modal with",t.components.length,"components");let l=n||{id:t.issueId,nodeName:"Unnamed"};console.log("[all-components-loaded] Issue to use:",l),console.log("[all-components-loaded] Calling showComponentSelectModal...");try{yn(l,t.components),console.log("[all-components-loaded] \u2713 Modal function called successfully")}catch(a){console.error("[all-components-loaded] \u2717 Error showing modal:",a),console.error("[all-components-loaded] Error stack:",a.stack),alert("Error showing component selection modal: "+a.message)}window.pendingSelectComponentIssue=null;return}else{console.warn("[all-components-loaded] \u2717 No components available"),alert("No components found. Please use 'Create New Component' to create a new one."),window.pendingSelectComponentIssue=null;return}}if(t&&t.type==="figma-text-styles-loaded"){let n=window.pendingSuggestTextSizeIssue;if(n&&n.id===t.issueId){let p=n.fontSize||12,u=(t.styles||[]).filter(g=>g.fontSize>=14);if(u.length===0){let g=je(n);g?xt(n,p,g,null,null):alert("No suitable text size match found (need >= 14px for ADA compliance). Please add font sizes to Font Size input or create text styles in Figma."),window.pendingSuggestTextSizeIssue=null;return}let m=null,y=1/0;u.forEach(g=>{let b=Math.abs(g.fontSize-p);b<y&&(y=b,m=g)}),m?xt(n,p,m.fontSize,null,m):alert("No suitable text style found (need >= 14px for ADA compliance)"),window.pendingSuggestTextSizeIssue=null;return}let l=window.pendingTextSizeIssue;if(l&&l.id===t.issueId){hn(l,t.styles||[]),window.pendingTextSizeIssue=null;return}let a=window.pendingTypographyStyleIssue;if(a&&a.id===t.issueId){if(t.error||!t.styles||t.styles.length===0){let p=document.querySelector(`.issue[data-issue-id="${t.issueId}"]`);if(p){let u=p.querySelector("button.btn-fix"),m=p.querySelector("button.btn-suggest-fix");u&&(u.style.display="none"),m&&(m.style.display="none")}window.pendingTypographyStyleIssue=null;return}oo(a,t.styles||[]),window.pendingTypographyStyleIssue=null;return}let i=window.pendingTypographyCheckIssue;if(i&&i.id===t.issueId){if(t.error||!t.styles||t.styles.length===0){let p=document.querySelector(`.issue[data-issue-id="${t.issueId}"]`);if(p){let u=p.querySelector("button.btn-style-dropdown"),m=p.querySelector("button.btn-suggest-fix");u&&(u.style.display="none"),m&&(m.style.display="none")}window.pendingTypographyCheckIssue=null;return}oo(i,t.styles||[]),window.pendingTypographyCheckIssue=null;return}let r=document.querySelector(`.style-dropdown-menu[data-issue-id="${t.issueId}"]`);if(r){let p=r.closest(".issue"),u=p?p.getAttribute("data-issue-id"):null,m=p?p.getAttribute("data-issue-type"):null;if(t.error){r.innerHTML=`<div style="padding: 8px 12px; color: #dc3545; font-size: 12px;">Error: ${d(t.error)}</div>`;let y=p?p.querySelector("button.btn-style-dropdown"):null;y&&(y.style.display="none");let g=p?p.querySelector("button.btn-suggest-fix"):null;g&&(m==="typography-style"||m==="typography-check")&&(g.style.display="none")}else if(t.styles&&t.styles.length>0){let y=null;if(u&&k&&k.issues){let g=k.issues.find(b=>b.id===u);g&&g.bestMatch&&(y=g.bestMatch.name)}r.innerHTML=t.styles.map(g=>`
            <div class="style-dropdown-item" data-issue-id="${t.issueId}" data-style-id="${g.id}" data-style-name="${d(g.name)}" style="padding: 8px 12px; cursor: pointer; font-size: 12px; ${y===g.name?"background: #e3f2fd; font-weight: 600;":""}" onmouseover="this.style.background='#f5f5f5'" onmouseout="this.style.background='${y===g.name?"#e3f2fd":"white"}'">
              ${d(g.name)} ${y===g.name?"\u2B50":""}
            </div>
          `).join(""),r.querySelectorAll(".style-dropdown-item").forEach(g=>{g.onclick=b=>{b.preventDefault(),b.stopPropagation();try{let E=g.getAttribute("data-issue-id");E&&parent.postMessage({pluginMessage:{type:"select-node",id:E}},"*")}catch(E){console.error("Failed to auto-select node for style dropdown item:",E)}let S=g.getAttribute("data-style-id"),x=g.getAttribute("data-style-name");if(p&&k&&k.issues){let E=k.issues.find(w=>w.id===u);if(E){let w=t.styles.find(H=>H.id===S);w&&(r.style.display="none",po(E,w))}}}})}else{r.innerHTML='<div style="padding: 8px 12px; color: #999; font-size: 12px;">No text styles found in Figma</div>';let y=p?p.querySelector("button.btn-style-dropdown"):null;y&&(y.style.display="none");let g=p?p.querySelector("button.btn-suggest-fix"):null;g&&(m==="typography-style"||m==="typography-check")&&(g.style.display="none")}}return}if(t&&t.type==="contrast-colors-loaded"){let n=window.pendingContrastIssue;n&&n.id===t.issueId&&(bn(n,t.colors||[]),window.pendingContrastIssue=null);return}if(t&&t.type==="apply-typography-style-result"){if(X(t.issueId,t.message,t.success),t.success||Wt(t.message||"An error occurred while applying the style."),t.success){if(console.log("[apply-typography-style-result] Starting remove process for issueId:",t.issueId),console.log("[apply-typography-style-result] issueId type:",typeof t.issueId,"value:",t.issueId),k&&k.issues){let m=k.issues.length;k.issues=k.issues.filter(g=>String(g.id)!==String(t.issueId));let y=m-k.issues.length;console.log("[apply-typography-style-result] Removed",y,"issue(s) from data. Remaining issues:",k.issues.length)}let n=`.issue[data-issue-id="${t.issueId}"]`;console.log("[apply-typography-style-result] Trying selector1:",n);let l=document.querySelectorAll(n);console.log("[apply-typography-style-result] Found",l.length,"issue element(s) with this ID");let a=`button.btn-suggest-apply[data-id="${t.issueId}"]`,i=`button.btn-fix[data-id="${t.issueId}"]`,r=`button.btn-suggest-fix[data-id="${t.issueId}"]`;[...document.querySelectorAll(a),...document.querySelectorAll(i),...document.querySelectorAll(r)].forEach(m=>{let y=m.closest(".issue");y&&!Array.from(l).includes(y)&&l.push(y)});let u=Array.from(new Set(Array.from(l)));if(console.log("[apply-typography-style-result] Total unique issue elements to remove:",u.length),u.length>0){let m=new Map;u.forEach((y,g)=>{console.log(`[apply-typography-style-result] Issue element ${g}:`,y),console.log(`[apply-typography-style-result] Issue element ${g} data-issue-id:`,y.getAttribute("data-issue-id")),console.log(`[apply-typography-style-result] Issue element ${g} data-issue-type:`,y.getAttribute("data-issue-type"));let b=y.closest(".issue-group");if(b){let S=b.getAttribute("data-issue-type");if(!m.has(S)){let E=b.querySelector(".badge");if(E){let w=parseInt(E.textContent)||0;m.set(S,{groupEl:b,badge:E,currentCount:w,removeCount:0})}}let x=m.get(S);x&&x.removeCount++}}),u.forEach((y,g)=>{y.style.transition="opacity 0.3s ease-out",y.style.opacity="0",setTimeout(()=>{y.parentNode&&(console.log(`[apply-typography-style-result] Removing element ${g} from DOM...`),y.remove())},300)}),setTimeout(()=>{let y=document.querySelectorAll(n);console.log("[apply-typography-style-result] After remove, remaining elements:",y.length),m.forEach((g,b)=>{let S=Math.max(0,g.currentCount-g.removeCount);g.badge.textContent=S,console.log(`[apply-typography-style-result] Updated badge for group "${b}" from ${g.currentCount} to ${S}`),S===0&&(g.groupEl.style.display="none",console.log(`[apply-typography-style-result] Hiding group "${b}" (no issues left)`))}),console.log("[apply-typography-style-result] Calling updateIssueCounts()..."),et(),console.log("[apply-typography-style-result] updateIssueCounts() completed"),console.log("[apply-typography-style-result] Re-rendering issues to sync UI..."),k&&k.issues&&Pe(k.issues,!1)},350)}else console.log("[apply-typography-style-result] No issue elements found! Trying to update counts anyway..."),et(),k&&k.issues&&Pe(k.issues,!1)}return}if(t&&t.type==="scan-progress"){C&&$&&(C.style.width=t.progress+"%",$.textContent=t.progress+"% ("+t.current+"/"+t.total+")");return}if(t&&t.type==="last-report"){t.report?Ko(t.report):console.log("No last report stored");return}if(t&&t.type==="history-data"){zn(t.history),Nn();let n=document.getElementById("history-panel");n&&n.style.display!=="none"&&Lt();return}if(t&&t.type==="input-values-data"){t.values?(De(t.values),console.log("Restored input values:",t.values)):console.log("No saved input values to restore");return}if(t&&t.type==="project-name"){let n=t.name||"settings";if(window.pendingExportValues){let l=window.pendingExportValues;window.pendingExportValues=null;let a={name:n,values:l,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()},i=JSON.stringify([a],null,2),r=new Blob([i],{type:"application/json"}),p=URL.createObjectURL(r),u=document.createElement("a");u.href=p;let m=n.replace(/[^a-z0-9]/gi,"_").toLowerCase();u.download=`${m}-settings.json`,document.body.appendChild(u),u.click(),document.body.removeChild(u),URL.revokeObjectURL(p),console.log("\u2705 Settings exported successfully");return}ae&&(ae.value=n);return}if(t&&t.type==="check-setting-name-result"){t.exists?(Fo&&me&&(Fo.textContent=t.name||me.name),ge&&(ge.style.display="flex")):me&&(Bo(me.name,me.values),me=null);return}if(t&&t.type==="save-settings-result"){t.success?(ge&&(ge.style.display="none"),Ie&&(Ie.style.display="none"),ae&&(ae.value=""),me=null,$e&&$e.style.display!=="none"&&parent.postMessage({pluginMessage:{type:"get-saved-settings"}},"*")):(alert("\u274C Failed to save settings: "+(t.error||"Unknown error")),ge&&(ge.style.display="none"),me=null);return}if(t&&t.type==="saved-settings-list"){Ho(t.settings||[]);return}if(t&&t.type==="project-name"){let n=t.name||"settings";if(window.pendingExportValues){let l=window.pendingExportValues;window.pendingExportValues=null;let a={name:n,values:l,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()},i=JSON.stringify([a],null,2),r=new Blob([i],{type:"application/json"}),p=URL.createObjectURL(r),u=document.createElement("a");u.href=p;let m=n.replace(/[^a-z0-9]/gi,"_").toLowerCase();u.download=`${m}-settings.json`,document.body.appendChild(u),u.click(),document.body.removeChild(u),URL.revokeObjectURL(p),console.log("\u2705 Settings exported successfully")}return}if(t&&t.type==="load-settings-result"){t.success&&t.values?(De(t.values),ie()):alert("\u274C Failed to load settings: "+(t.error||"Unknown error"));return}if(t&&t.type==="remove-settings-result"){t.success?Ho(t.settings||[]):alert("\u274C Failed to remove settings: "+(t.error||"Unknown error"));return}if(t&&t.type==="report"){h.style.display="block",h.disabled=!1,I.style.display="none",f.style.display="none",v.disabled=!1;let n=t.issues||[];k.context=t.context||null,Pe(n);let l=((o=document.querySelector('input[name="scope"]:checked'))==null?void 0:o.value)||"page";Co(l,"issues",{issues:n},t.context||null)}if(t&&t.type==="tokens-report")if(v.style.display="block",v.disabled=!1,I.style.display="none",f.style.display="none",h.disabled=!1,t.error)te.innerHTML=`<div class="error-message">Error: ${d(t.error)}</div>`,Fe("tokens");else{k.context=t.context||null,St(t.tokens),M.disabled=!(t.tokens&&Array.isArray(t.tokens.spacing)&&t.tokens.spacing.length>0),q.disabled=!(t.tokens&&Array.isArray(t.tokens.colors)&&t.tokens.colors.length>0),F.disabled=!(t.tokens&&Array.isArray(t.tokens.fontSize)&&t.tokens.fontSize.length>0),T.disabled=!(t.tokens&&Array.isArray(t.tokens.lineHeight)&&t.tokens.lineHeight.length>0);let n=((s=document.querySelector('input[name="scope"]:checked'))==null?void 0:s.value)||"page";Co(n,"tokens",{tokens:t.tokens},t.context||null)}if(t&&t.type==="typography-styles-extracted")if(t.styles&&Array.isArray(t.styles)&&t.styles.length>0){let n=t.mode==="desktop"?"Desktop":t.mode==="tablet"?"Tablet":t.mode==="mobile"?"Mobile":"All";B=t.styles.map((l,a)=>({id:a+1,name:l.name,styleId:l.styleId,fontFamily:l.fontFamily,fontSize:l.fontSize,fontWeight:l.fontWeight,lineHeight:l.lineHeight,letterSpacing:l.letterSpacing||"0",wordSpacing:l.wordSpacing||"0"})),ke=B.length+1,Be(),ie(),alert(`\u2705 Successfully imported ${t.styles.length} ${n} typography styles from Figma!

Styles: ${t.styles.map(l=>l.name).join(", ")}`)}else{let n=t.mode==="desktop"?"Desktop":t.mode==="tablet"?"Tablet":t.mode==="mobile"?"Mobile":"";alert(`\u26A0\uFE0F No ${n.toLowerCase()} text styles found in this Figma file.

Make sure you have defined text styles in your design system.`)}if(t&&t.type==="color-styles-extracted")if(t.colors&&Array.isArray(t.colors)&&t.colors.length>0){let n=document.getElementById("color-scale");if(!n)return;let a=Array.from(new Set(t.colors.map(i=>i.hex))).sort((i,r)=>Ye(i)-Ye(r));W={},t.colors.forEach(i=>{i.hex&&i.name&&(W[i.hex.toUpperCase()]=i.name)}),n.value=a.join(", "),typeof Ce=="function"&&Ce(),ie();try{n.focus(),n.setSelectionRange(n.value.length,n.value.length)}catch(i){}alert(`\u2705 Successfully imported ${t.colors.length} color styles from Figma!

Colors: ${t.colors.map(i=>i.name+" ("+i.hex+")").join(", ")}`)}else alert(`\u26A0\uFE0F No color styles found in this Figma file.

Make sure you have defined color styles (paint styles) in your design system.`);if(t&&t.type==="color-variables-extracted")if(t.colors&&Array.isArray(t.colors)&&t.colors.length>0){let n=document.getElementById("color-scale");if(!n)return;let a=Array.from(new Set(t.colors.map(i=>i.hex))).sort((i,r)=>Ye(i)-Ye(r));W={},t.colors.forEach(i=>{i.hex&&i.name&&(W[i.hex.toUpperCase()]=i.name)}),n.value=a.join(", "),typeof Ce=="function"&&Ce(),ie();try{n.focus(),n.setSelectionRange(n.value.length,n.value.length)}catch(i){}alert(`\u2705 Successfully imported ${t.colors.length} color variables from Figma!

Colors: ${t.colors.map(i=>i.name+" ("+i.hex+")").join(", ")}`)}else alert(`\u26A0\uFE0F No color variables found in this Figma file.

Make sure you have defined color variables in your design system.`)}})();})();
